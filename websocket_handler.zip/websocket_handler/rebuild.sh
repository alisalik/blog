#!/bin/bash
target=ocpp_websocket

echo Delete old container $target
docker rm -f $target # sam as docker stop $target then docker rm $target
docker rmi $target
docker build -t $target .
echo Run new container $target
docker run -d -p 9091:9091 --log-opt max-size=50k --log-opt max-file=5 --restart always --name $target $target
docker logs -f $target
