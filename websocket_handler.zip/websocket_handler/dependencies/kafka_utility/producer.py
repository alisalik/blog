"""Kafka producer module."""

import json
import threading

from kafka import KafkaProducer
from kafka.errors import KafkaTimeoutError

from kafka_utility.lock import enforce_generic_lock
from kafka_utility import kafka_logger
from kafka_utility.constants import SASL_PLAINTEXT, PLAIN
from kafka_utility.exceptions import NebulaKafkaInitialisationError


class NebulaKafkaProducer:
    """Utility to bundle kafka producers."""
    generic_lock = threading.RLock()
    _extra_config_params = [
        "key_serializer", "value_serializer",
        "ssl_cafile", "ssl_certfile", "ssl_keyfile",
        "security_protocol", "sasl_mechanism", "sasl_plain_username", "sasl_plain_password",
        "max_request_size",
    ]

    def __init__(self, config, consumer_logger):
        bootstrap_servers = config.get("bootstrap_servers")
        self.__config = {
            "bootstrap_servers": bootstrap_servers if type(bootstrap_servers) == list else [bootstrap_servers],
            "client_id": consumer_logger.get_rule_name(),
        }
        # Set default security protocol
        if 'sasl_plain_username' in config and 'sasl_plain_password' in config:
            self.__config.update({
                "security_protocol": SASL_PLAINTEXT,
                "sasl_mechanism": PLAIN,
            })
        # Append extra parameters to config, if provided
        for param in self._extra_config_params:
            param_value = config.get(param)
            if param_value:
                self.__config.update({param: param_value})
        _empty_attrs = [k for (k, v) in self.__config.items() if not v]
        if _empty_attrs:
            raise AttributeError(
                f"Required attributes: {', '.join(_empty_attrs)}")

        # Logger instance of consumer module to map logs
        self.__consumer_logger = consumer_logger

        # Set rule name here to track log messages in aggregated log server
        if self.__consumer_logger:
            kafka_logger.use_different_rule_name(
                f'{self.__consumer_logger.get_rule_name()}_kafka_producer_logs')
        self.__producer = None
        self._initialize()

    @enforce_generic_lock
    def send_to_topic(self, topic, data, key=None, headers=None, partition=None):
        """Sends data to kafka topic."""
        if not topic:
            raise ValueError("Topic is required!")
        if not data:
            raise ValueError("Data is required!")

        kafka_logger.set_extra(self.__consumer_logger.get_extra())
        kafka_logger.i(f"Sending data: '{data}' to topic: '{topic}'")
        if not self.__config.get("value_serializer"):
            data = self._encode_data(data)
        if not self.__config.get("key_serializer"):
            key = self._encode_data(key)
        try:
            request = self.__producer.send(
                topic=topic,
                value=data,
                key=key,
                headers=headers,
                partition=partition
            )
            result = request.get(timeout=60)
            return result
        except KafkaTimeoutError as err:
            kafka_logger.e(err)
            # Keep retrying indefinitely
            self._initialize(True)
            return self.send_to_topic(topic, data, key, headers, partition)
        except Exception as err:
            kafka_logger.e(f"Error sending data to topic:{err}")

    def close(self):
        """Closes a producer."""
        if self.__producer:
            self.__producer.close()

    @staticmethod
    def _encode_data(data):
        """Encode data."""
        if type(data) == dict or type(data) == list:
            return json.dumps(data).encode('utf-8')
        elif type(data) == bytes:
            return data
        elif type(data) == int:
            return str(data).encode('utf-8')
        elif data:
            return data.encode('utf-8')
        else:
            return ''.encode('utf-8')

    def _initialize(self, force=False, retries=0):
        """Initialises to a producer."""
        if force or not self.__producer:
            try:
                self.__producer = KafkaProducer(**self.__config)
            except Exception as err:
                if retries <= 3:
                    retries += 1
                    return self._initialize(force, retries)
                else:
                    kafka_logger.e(
                        f"Error: {err} occurred while initialisation after {retries -1 } retries.")
                    raise NebulaKafkaInitialisationError(
                        f"Error: {err} occurred while initialisation after {retries -1 } retries.")

    def __del__(self):
        """Close producer when object is going out of scope."""
        self.close()
