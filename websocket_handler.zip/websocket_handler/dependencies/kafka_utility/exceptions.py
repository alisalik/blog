"""Module's exceptions."""


class NebulaKafkaInitialisationError(Exception):
    """Raised when kafka object is not able to initialise properly."""

    def __init__(self, message):
        super().__init__(message)
