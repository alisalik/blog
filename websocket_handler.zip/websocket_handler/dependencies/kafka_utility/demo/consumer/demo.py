from kafka_utility.demo.consumer import logger
from kafka_utility.demo.consumer import consumer


def run_demo(topic):
    consumer.subscribe(topic)
    for message in consumer.get_consumer():
        logger.i(message)


if __name__ == '__main__':
    run_demo('topic_name')
