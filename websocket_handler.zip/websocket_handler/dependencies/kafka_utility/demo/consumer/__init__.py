from logger_utility.logger import NebulaLogger
from kafka_utility.consumer import NebulaKafkaConsumer
from kafka_utility.constants import PLAIN, SASL_PLAINTEXT


logger = NebulaLogger('consumer_demo', handlers=['console', ])

config = {
    "bootstrap_servers": 'localhost:9092',
    "security_protocol": SASL_PLAINTEXT,
    "sasl_mechanism": PLAIN,
    "sasl_plain_username": "admin",
    "sasl_plain_password": "12345"
}

consumer = NebulaKafkaConsumer(config, logger)
