from kafka_utility.demo.admin import logger
from kafka_utility.demo.admin import admin


def run_demo():
    logger.i(admin.create_topics(["topic_name"], 1, 1))
    # logger.i(admin.delete_topics(["<topic_name>"]))
    # logger.i(admin.list_consumer_groups())


if __name__ == '__main__':
    run_demo()
