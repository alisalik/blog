from logger_utility.logger import NebulaLogger
from kafka_utility.producer import NebulaKafkaProducer
from kafka_utility.constants import PLAIN, SASL_PLAINTEXT
import json

logger = NebulaLogger('producer_demo', handlers=['console', ])

config = {
    "bootstrap_servers": 'localhost:9092',
    "value_serializer": lambda x: json.dumps({"name": x}).encode('utf-8'),
    "security_protocol": SASL_PLAINTEXT,
    "sasl_mechanism": PLAIN,
    "sasl_plain_username": "admin",
    "sasl_plain_password": "12345"
}

producer = NebulaKafkaProducer(config, logger)
