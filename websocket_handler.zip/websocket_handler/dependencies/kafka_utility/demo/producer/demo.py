import time
from kafka_utility.demo.producer import logger
from kafka_utility.demo.producer import producer


def run_demo():
    ack = producer.send_to_topic("topic_name", '<data>')
    logger.i(ack)


if __name__ == '__main__':
    while True:
        run_demo()
        time.sleep(3)
