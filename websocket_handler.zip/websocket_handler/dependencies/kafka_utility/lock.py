"""Decorator to enforce thread lock to avoid collision."""


def enforce_generic_lock(function):
    """Decorator to enforce generic lock."""
    def inner_wrapper(_, *args, **kwargs):
        # # Acquire lock
        with _.generic_lock:
            return function(_, *args, **kwargs)
    return inner_wrapper
