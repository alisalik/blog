"""Kafka consumer module."""
from kafka import KafkaConsumer

from kafka_utility import kafka_logger
from kafka_utility.constants import EARLIEST, SASL_PLAINTEXT, PLAIN
from kafka_utility.exceptions import NebulaKafkaInitialisationError


class NebulaKafkaConsumer:
    """Utility to bundle kafka consumers."""

    _required_params = [
        "key_deserializer", "value_deserializer",
        "ssl_cafile", "ssl_certfile", "ssl_keyfile",
        "security_protocol", "sasl_mechanism", "sasl_plain_username", "sasl_plain_password",
        "auto_offset_reset", "enable_auto_commit", "auto_commit_interval_ms",
    ]
    _not_required_params = ["group_id", ]

    def __init__(self, config, consumer_logger, topics=None):
        self.__topics = None
        if topics:
            self.__topics = topics if type(topics) == list else [topics]
        bootstrap_servers = config.get("bootstrap_servers")
        self.__config = {
            "bootstrap_servers": bootstrap_servers if type(bootstrap_servers) == list else [bootstrap_servers],
            "group_id": consumer_logger.get_rule_name(),
            "client_id": consumer_logger.get_rule_name(),
            "auto_offset_reset": EARLIEST,
            "enable_auto_commit": False,
        }
        # Set default security protocol
        if 'sasl_plain_username' in config and 'sasl_plain_password' in config:
            self.__config.update({
                "security_protocol": SASL_PLAINTEXT,
                "sasl_mechanism": PLAIN,
            })

        # Append extra parameters to config, if provided
        for param in self._required_params + self._not_required_params:
            param_value = config.get(param)
            if param_value is not None or param in self._not_required_params:
                self.__config.update({param: param_value})

        _empty_attrs = [k for (k, v) in self.__config.items(
        ) if v is None and k not in self._not_required_params]
        if _empty_attrs:
            raise AttributeError(
                f"Required attributes: {', '.join(_empty_attrs)}")
        self.__consumer = None
        # Logger instance of consumer module to map logs
        self.__consumer_logger = consumer_logger

        # Set rule name here to track log messages in aggregated log server
        if self.__consumer_logger:
            kafka_logger.use_different_rule_name(
                f'{self.__consumer_logger.get_rule_name()}_kafka_consumer_logs')
        self._initialize()

    def _initialize(self, retries=0):
        """Initialises  a consumer."""
        if not self.__consumer:
            try:
                if self.__topics:
                    self.__consumer = KafkaConsumer(
                        *self.__topics, **self.__config)
                else:
                    self.__consumer = KafkaConsumer(**self.__config)
            except Exception as err:
                if retries <= 3:
                    retries += 1
                    return self._initialize(retries)
                else:
                    kafka_logger.e(
                        f"Error: {err} occurred while initialisation after {retries -1 } retries.")
                    raise NebulaKafkaInitialisationError(
                        f"Error: {err} occurred while initialisation after {retries -1 } retries.")

    def get_consumer(self):
        """Gets consumer iterable."""
        kafka_logger.set_extra(self.__consumer_logger.get_extra())
        return self.__consumer

    def subscribe(self, topics, pattern=None):
        """Subscribes to a topic or a regex pattern."""
        kafka_logger.set_extra(self.__consumer_logger.get_extra())
        if pattern:
            return self.__consumer.subscribe(pattern=pattern)
        topic_list = topics if type(topics) == list else [topics]
        return self.__consumer.subscribe(topic_list)

    def unsubscribe(self):
        """Unsubscribe from all topics and clear all assigned partitions."""
        kafka_logger.set_extra(self.__consumer_logger.get_extra())
        return self.__consumer.unsubscribe()

    def commit(self):
        """Commit offsets to kafka, blocking until success or error."""
        # Commit all consumed messages
        return self.__consumer.commit()

    def close(self):
        """Closes a consumer."""
        if self.__consumer:
            self.__consumer.close()

    def __del__(self):
        """Close consumer when object is going out of scope."""
        self.close()
