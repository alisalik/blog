import os
from logger_utility.logger import NebulaLogger
# Initialize logger
kafka_logger = NebulaLogger(os.path.basename(os.path.dirname(__file__)))
