"""Kafka admin module."""

from kafka import KafkaAdminClient
from kafka.admin.new_topic import NewTopic
from kafka.errors import TopicAlreadyExistsError, UnknownTopicOrPartitionError

from kafka_utility import kafka_logger
from kafka_utility.exceptions import NebulaKafkaInitialisationError


class NebulaKafkaAdmin:
    """Utility to bundle kafka admin operations."""
    _extra_config_params = [
        "ssl_cafile", "ssl_certfile", "ssl_keyfile",
        "security_protocol", "sasl_mechanism", "sasl_plain_username", "sasl_plain_password",
    ]

    def __init__(self, config, consumer_logger):
        bootstrap_servers = config.get("bootstrap_servers")
        self.__config = {
            "bootstrap_servers": bootstrap_servers if type(bootstrap_servers) == list else [bootstrap_servers],
            "client_id": consumer_logger.get_rule_name(),
        }
        # Set default security protocol
        if 'sasl_plain_username' in config and 'sasl_plain_password' in config:
            self.__config.update({
                "security_protocol": SASL_PLAINTEXT,
                "sasl_mechanism": PLAIN,
            })

        # Append extra parameters to config, if provided
        for param in self._extra_config_params:
            param_value = config.get(param)
            if param_value:
                self.__config.update({param: param_value})

        _empty_attrs = [k for (k, v) in self.__config.items() if not v]
        if _empty_attrs:
            raise AttributeError(
                f"Required attributes: {', '.join(_empty_attrs)}")

        # Logger instance of consumer module to map logs
        self.__consumer_logger = consumer_logger

        # Set rule name here to track log messages in aggregated log server
        if self.__consumer_logger:
            kafka_logger.use_different_rule_name(
                f'{self.__consumer_logger.get_rule_name()}_kafka_admin_logs')

        self.__admin = None
        self._initialize()

    def create_topics(self, new_topics, num_partitions, replication_factor, timeout_ms=None, validate_only=False):
        """Create new topics in the cluster"""
        kafka_logger.set_extra(self.__consumer_logger.get_extra())
        try:
            new_topics = [
                NewTopic(topic, num_partitions, replication_factor) for topic in new_topics]
            return self.__admin.create_topics(new_topics, timeout_ms, validate_only)
        except TopicAlreadyExistsError as err:
            kafka_logger.e(f'Error while creating new topic:{err}')
        except Exception as err:
            kafka_logger.e(f'Error while creating new topic:{err}')

    def delete_topics(self, topics, timeout_ms=None):
        """Delete topics from the cluster."""
        kafka_logger.set_extra(self.__consumer_logger.get_extra())
        try:
            return self.__admin.delete_topics(topics, timeout_ms)
        except UnknownTopicOrPartitionError as err:
            kafka_logger.e(f'Error while deleting existing topic:{err}')
        except Exception as err:
            kafka_logger.e(f'Error while deleting existing topic:{err}')

    def list_consumer_groups(self, broker_ids=None):
        """List all consumer groups known to the cluster."""
        kafka_logger.set_extra(self.__consumer_logger.get_extra())
        return self.__admin.list_consumer_groups(broker_ids)

    def close(self):
        """Closes a admin."""
        if self.__admin:
            self.__admin.close()

    def _initialize(self, retries=0):
        """Initialises to a admin."""
        if not self.__admin:
            try:
                self.__admin = KafkaAdminClient(**self.__config)
            except Exception as err:
                if retries <= 3:
                    retries += 1
                    return self._initialize(retries)
                else:
                    kafka_logger.e(
                        f"Error: {err} occurred while initialisation after {retries - 1} retries.")
                    raise NebulaKafkaInitialisationError(
                        f"Error: {err} occurred while initialisation after {retries - 1} retries.")

    def __del__(self):
        """Close admin when object is going out of scope."""
        self.close()
