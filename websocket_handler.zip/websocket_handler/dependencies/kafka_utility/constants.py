"""Module constants file."""
# sasl mechanisms
PLAIN = "PLAIN"
GSSAPI = "GSSAPI"
OAUTHBEARER = "OAUTHBEARER"
SCRAM_SHA_256 = "SCRAM-SHA-256"
SCRAM_SHA_512 = "SCRAM-SHA-512"

# Security protocols
SASL_PLAINTEXT = "SASL_PLAINTEXT"
PLAINTEXT = "PLAINTEXT"
SSL = "SSL"
SASL_SSL = "SASL_SSL"

# Possible auto_offset_reset values
LATEST = 'latest'
EARLIEST = 'earliest'
