# Kafka Utility

## Overview
Python utility for kafka functionalities
- Python Version: `3.9.3`

---

## Kafka Consumer
- config: Configuration to setup
  ```
  from kafka_utility.constants import PLAIN, SASL_PLAINTEXT
  config = {
    "bootstrap_servers": 'localhost:9092', # required, string or list of kafka brokers
    "key_deserializer": <key_deserializer_function_object>, # Optional
    "value_deserializer": <value_deserializer_fucntion_object>, # Optional
    "ssl_cafile": <ssl_cafile_path>, # If ssl is setup
    "ssl_keyfile": <ssl_keyfile_path>, # If ssl is setup
    "ssl_certfile": <ssl_certfile_path>, # If ssl is setup
    "security_protocol": SASL_PLAINTEXT,# If sasl is setup, Default:SASL_PLAINTEXT if sasl_plain_username and password are provided
    "sasl_mechanism": PLAIN,# If sasl is setup, Default: PLAIN  if sasl_plain_username and password are provided
    "sasl_plain_username": <sasl_plain_username>, # If sasl is setup
    "sasl_plain_password": <sasl_plain_password>, # If sasl is setup    
    "group_id": '<Group id for consumer>', # Default is rule name. # Optional
    "auto_offset_reset":<EARLIEST or LATEST>, # Offset to start consuming from, default is EARLIEST, # Optional
    "enable_auto_commit": <True or False>, # Enable or disable autocommit, Default us disabled, # Optional
    "auto_commit_interval_ms": <Interval to commit if auto commit is enabled>, # Interval to commit offset, # Optional
  }
  ```
  - Note:
    - Configuration parameters are described in more detail at
      - `https://kafka-python.readthedocs.io/en/master/apidoc/KafkaConsumer.html`
  
- get_consumer: Get consumer iterable
- subscribe: To subscribe to kafka topics
  - Inputs:
    - topics: a string containing topic name or a list of topics
- unsubscribe: Unsubscribe from all topics and clear all assigned partitions
- close: To close kafka consumer
- commit: Commits consumed messages
  - By default auto commit is disabled
  - Commit your message explicitly
- Usage:
  - Set up consumer inside your `__init__.py` file
  ```
  from logger_utility.logger import NebulaLogger
  from kafka_utility.consumer import NebulaKafkaConsumer
  
  logger = NebulaLogger('consumer_demo', handlers=['console', ])
  
  config = {
      "bootstrap_servers": 'localhost:9092',
  }
  
  consumer = NebulaKafkaConsumer(config, logger)

  ```
  - Use as below in your package
  ```
  from your_package import consumer
  consumer.subscribe('<topic_name>')
  for message in consumer.get_consumer():
      logger.i(message)
  ```
  - `message` will be of type `ConsumerRecord` to verify the message:
  ```
    ConsumerRecord(
      topic='praveen-orahi', partition=0, offset=109, timestamp=1618582098884, 
      timestamp_type=0, key=None, value=b'Test Message', 
      headers=[], checksum=None, 
      serialized_key_size=-1, 
      serialized_value_size=12, 
      serialized_header_size=-1
    )
  ```

---

## Kafka Producer
- config: Configuration to setup
  ```
  from kafka_utility.constants import PLAIN, SASL_PLAINTEXT
  config = {
    "bootstrap_servers": 'localhost:9092', # required, string or list of kafka brokers
    "key_serializer": <key_serializer_function_object>, # Optional
    "value_serializer": <value_serializer_fucntion_object>, # Optional
    "ssl_cafile": <ssl_cafile_path>, # If ssl is setup
    "ssl_keyfile": <ssl_keyfile_path>, # If ssl is setup
    "ssl_certfile": <ssl_certfile_path>, # If ssl is setup
    "security_protocol": SASL_PLAINTEXT,# If sasl is setup, Default:SASL_PLAINTEXT if sasl_plain_username and password are provided
    "sasl_mechanism": PLAIN,# If sasl is setup, Default: PLAIN  if sasl_plain_username and password are provided
    "sasl_plain_username": <sasl_plain_username>, # If sasl is setup
    "sasl_plain_password": <sasl_plain_password>, # If sasl is setup 
    "max_request_size": <max_request_size>, # To increase request size, Optional   
  }
  ```
  - Note:
    - Configuration parameters are described in more detail at
      - `https://kafka-python.readthedocs.io/en/master/apidoc/KafkaProducer.html`
- send_to_topic: Send data to topic
  - Inputs:
    - topic: Topic name to send data to
    - data: data to send (can be of type str, int, dict, list or bytes)
    - key: Key to attach to record # Optional
    - headers: Headers to send with record
    - partition: Partition to use for saving record
    
  - Output:
    - Record set of type `RecordMetadata` to verify
  
- Usage
  - Set up producer inside your `__init__.py` file
    ```
    from logger_utility.logger import NebulaLogger
    from kafka_utility.producer import NebulaKafkaProducer

    logger = NebulaLogger('producer_demo', handlers=['console',])

    config = {
        "bootstrap_servers": 'localhost:9092',
    }
    producer = NebulaKafkaProducer(config, logger)
    ```
  - Use as below in your package
  ```
    from your_package import producer
    ack = producer.send_to_topic("praveen-orahi", 'Test Message')
  ```
  - `ack` will be of type `RecordMetadata` to verify the push message:
  ```
    RecordMetadata(
      topic='praveen-orahi', 
      partition=0, 
      topic_partition=TopicPartition(topic='praveen-orahi', partition=0), 
      offset=96, timestamp=1618580472900, checksum=None, 
      serialized_key_size=-1, 
      serialized_value_size=12, 
      serialized_header_size=-1)
  ```
  - To send a file to kafka topic
    - import base64
    - Encode into 'base64' and then decode to string from bytes
      - ```{"base64BinaryString" : base64.b64encode(open('filename', 'rb').read()).decode()}```
    - Decode into 'base64' bytes from 'base64' binary string in `consumer`
      - ```base64.b64decode(base64BinaryString)```
    - Note: Maximum file size that can be sent will depend on the system kafka broker is running.
    - Increase request size in producer using `max_request_size` flag in `produer` config
    
- close: To close kafka producer

---

## Kafka Admin
- config: Configuration to setup
  ```
  from kafka_utility.constants import PLAIN, SASL_PLAINTEXT
  config = {
    "bootstrap_servers": 'localhost:9092', # required, string or list of kafka brokers
    "ssl_cafile": <ssl_cafile_path>, # If ssl is setup
    "ssl_keyfile": <ssl_keyfile_path>, # If ssl is setup
    "ssl_certfile": <ssl_certfile_path>, # If ssl is setup
    "security_protocol": SASL_PLAINTEXT,# If sasl is setup, Default:SASL_PLAINTEXT if sasl_plain_username and password are provided
    "sasl_mechanism": PLAIN,# If sasl is setup, Default: PLAIN  if sasl_plain_username and password are provided
    "sasl_plain_username": <sasl_plain_username>, # If sasl is setup
    "sasl_plain_password": <sasl_plain_password>, # If sasl is setup    
  }
  ```
  - Note:
    - Configuration parameters are described in more detail at
      - `https://kafka-python.readthedocs.io/en/master/apidoc/KafkaAdminClient.html`
- create_topics: Create new topics in the cluster
  - Inputs:
    - topic: List of topics to create
  - Output:
    - Record set of type `CreateTopicsResponse_v2` to verify
- delete_topics: Delete topics from the cluster
  - Inputs:
    - topic: List of topics to delete
  - Output:
    - Record set of type `DeleteTopicsResponse_v1` to verify
- list_consumer_groups: List all consumer groups known to the cluster
  - Inputs:
    - node_id: Optional node id to search
  - Output:
    - List of consumer groups
- close: To close admin connection to the kafka broker.
- Usage:
  - Set up admin inside your `__init__.py` file
  ```
  from logger_utility.logger import NebulaLogger
  from kafka_utility.admin import NebulaKafkaAdmin
    
  logger = NebulaLogger('admin_demo', handlers=['console', ])
    
  config = {
      "bootstrap_servers": 'localhost:9092',
  }
    
  admin = NebulaKafkaAdmin(config, logger)

  ```
  - Use as below in your package
  ```
  from your_package import admin
  ack = admin.create_topics(["topic-name"], num_partitions=1, replication_factor=1)
  ack = admin.delete_topics(["topic-name"])
  ```
  - `ack` will be of type `CreateTopicsResponse_v2` to verify the message in case of new topic creations:
  ```
    CreateTopicsResponse_v2(throttle_time_ms=0, 
      topic_errors=[
        (topic='topic-name', error_code=0, error_message=None)
      ]
    )
  ```
  - `ack` will be of type `DeleteTopicsResponse_v1` to verify the message in case of topic deletion:
  ```
    DeleteTopicsResponse_v1(throttle_time_ms=0, 
      topic_error_codes=[
        (topic='topic-name', error_code=0)
      ]
    )
  ```

---

## Directory Structure
- demo
  - admin: Demo for admin connector
  - consumer: Demo for consumer connector
  - producer: Demo for producer connector
- `__init__.py`: Module's init file
- admin.py: Admin connector for kafka
- constants.py: Module's constants file
- consumer.py: Consumer connector for kafka
- producer.py: Producer connector for kafka
- README.md: Readme instructions
- requirements.py: Requirements file for module



