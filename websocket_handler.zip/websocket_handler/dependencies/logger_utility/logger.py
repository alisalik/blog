""" Module implements logging inside Nebula. """

import logging.config
import os
from typing import final
from logger_utility.handlers.kafka_handler import KafkaHandler
from logger_utility.constants import (HANDLERS, INPUT, OUTPUT, LOG_FILE_LOCATION,
                                      DEFAULT_MQTT_LOG_TOPIC, DEFAULT_KAFKA_LOG_TOPIC,
                                      COMMON_FORMAT, RUNTIME_RULE_ENGINE_CONFIG)
from logger_utility.helpers.helpers import get_sys_info
from logger_utility.watcher.watcher import Watcher
from logger_utility.handlers.mqtt_handler import MQTTHandler
from logger_utility.filters.base_filter import BaseFilter


class NebulaLogger:
    """
    Utility to bundle logger manipulation.

    Attributes:
        rule_name: Rule name for which logger is requested
        handlers: Handlers set to enable from HANDLERS or `all` to enable all handlers
    """

    def __init__(self, rule_name, handlers=(HANDLERS['file'],)):
        self.__rule_name = rule_name
        if not self.__rule_name:
            raise AttributeError('rule_name is required')

        if handlers == 'all':
            handlers = HANDLERS.keys()

        # Create a logger
        self.__log = None
        self._init_logger()

        # Extra params and sys info
        self.__sys_info = {**get_sys_info(), 'rule_name': self.__rule_name}
        self.__extra = {**self.__sys_info}

        # Add console handler
        if HANDLERS['console'] in handlers:
            self._add_console_handler()

        # Add file handler
        if HANDLERS['file'] in handlers:
            self._add_file_handler()

        # Add mqtt handler
        if HANDLERS['mqtt'] in handlers:
            self._add_mqtt_handler(DEFAULT_MQTT_LOG_TOPIC)

        # TODO(praveen): Enable it when MQTT utility is available
        # Set up a watcher to update run time config
        # Watcher(self)

        # Add kafka handler
        if HANDLERS['kafka'] in handlers:
            self._add_kafka_handler(DEFAULT_KAFKA_LOG_TOPIC)

    @final
    def w(self, message):
        """Writes warning messages.

        Parameters
        ----------
        message: Message to log
        """
        self.__log.warning(message, extra=self.__extra)

    @final
    def i(self, message):
        """Writes info messages.

        Parameters
        ----------
        message: Message to log
        """
        self.__log.info(message, extra=self.__extra)

    @final
    def d(self, message):
        """Writes debug messages.

        Parameters
        ----------
        message: Message to log
        """
        self.__log.debug(message, extra=self.__extra)

    @final
    def e(self, message):
        """Writes error messages

        Parameters
        ----------
        message: Message to log
        """
        self.__log.error(message, extra=self.__extra)

    @final
    def out(self, message):
        """Writes output messages

        Parameters
        ----------
        message: Message to log
        """
        self.__log.info(message, extra={**self.__extra, "io": OUTPUT})

    @final
    def inp(self, message):
        """Writes input messages

        Parameters
        ----------
        message: Message to log
        """
        self.__log.info(message, extra={**self.__extra, "io": INPUT})

    def reset_extra(self):
        """Resets extras to initial state."""
        self.__extra = {**self.__sys_info}

    @final
    def set_extra(self, extra):
        """ Sets extra attributes required for log message

        Parameters
        ----------
        extra: Extra parameters to update for log messages
        - { "user_id":"<user_id>", "device_id":"<device_id>", "platform_identifier": "Web App"}
        """
        self.__extra = {**self.__extra, **extra, **self.__sys_info}

    @final
    def get_extra(self):
        """ Gets extra attributes mainly used in parallel utility logs like db utility"""
        return self.__extra

    @final
    def get_rule_name(self):
        """ Gets rule name mainly used in parallel utility logs like db utility"""
        return self.__sys_info.get('rule_name')

    @final
    def use_different_rule_name(self, updated_rule_name):
        """ To use different rule name for log message in case of a
        parallel utility's logs like db utility logs.

        Parameters
        ----------
        updated_rule_name: Updated rule name for log message
        """
        self.__sys_info = {**self.__sys_info, 'rule_name': updated_rule_name}
        self.__extra = {**self.__extra, **self.__sys_info}

    @final
    def get_run_time_config_file(self):
        """Gets run time config file to update in watcher."""
        return RUNTIME_RULE_ENGINE_CONFIG.format(consumer_module_name=self.get_rule_name())

    def _init_logger(self):
        """Creates a logger."""
        if not self.__log:
            # Create a logger
            self.__log = logging.getLogger(self.__rule_name)

    @final
    def update_handlers(self, handlers):
        """ Updates handlers at runtime.

        Parameters
        ----------
        handlers: List of handlers to update
         - [ {
                "name":"file",
                "enable":False,
              },
              {
                "name":"mqtt",
                "enable":True,
                "mqtt_topic":"send_log_to_this_topic",
              }
          ]
        """
        self._init_logger()
        for handler in handlers:
            if handler.get("name") == HANDLERS['console']:
                if handler.get('enable'):
                    self._add_console_handler()
                else:
                    self._remove_handler(HANDLERS['console'])
            if handler.get("name") == HANDLERS['file']:
                if handler.get('enable'):
                    self._add_file_handler()
                else:
                    self._remove_handler(HANDLERS['file'])
            elif handler.get("name") == HANDLERS['mqtt']:
                if handler.get('enable'):
                    self._add_mqtt_handler(handler.get('mqtt_topic'))
                else:
                    self._remove_handler(HANDLERS['mqtt'])
            elif handler.get("name") == HANDLERS['kafka']:
                if handler.get('enable'):
                    self._add_kafka_handler()
                else:
                    self._remove_handler(HANDLERS['kafka'])

    def _add_kafka_handler(self, topic):
        """Push the logs to kafka queues """
        if not self._is_handler_running(HANDLERS['kafka']):
            kafka_handler = KafkaHandler(topic, self)
            self._setup_handler(kafka_handler)

    def _add_console_handler(self):
        """Adds console handler to logger."""
        if not self._is_handler_running(HANDLERS['console']):
            ch = logging.StreamHandler()
            self._setup_handler(ch)

    def _add_file_handler(self):
        """Adds file handler to  logger."""
        if not self._is_handler_running(HANDLERS['file']):
            filename = f'{LOG_FILE_LOCATION}{self.__rule_name}.log'
            # Create file if it does not exist
            os.makedirs(os.path.dirname(filename), exist_ok=True)
            fh = logging.FileHandler(filename, 'a+', 'utf-8')
            self._setup_handler(fh)

    def _add_mqtt_handler(self, mqtt_log_topic):
        """Adds mqtt handler to logger.

        Parameters
        ---------
        mqtt_log_topic: MQTT topic to push logs
        """
        if not self._is_handler_running(HANDLERS['mqtt']):
            if mqtt_log_topic:
                mh = MQTTHandler(mqtt_log_topic)
                self._setup_handler(mh)

    def _setup_handler(self, h):
        """Adds required operations to handler

        Parameters
        ---------
        h: Requested handler instance
        """
        h.addFilter(BaseFilter())
        h.setFormatter(self._get_formatter())
        self.__log.addHandler(h)
        self.__log.setLevel(logging.DEBUG)

    @staticmethod
    def _get_formatter():
        """Gets log message formatter."""
        return logging.Formatter(COMMON_FORMAT)

    def _is_handler_running(self, handler):
        """ Checks if handler is already running or not

        Parameters
        ---------
        handler: Handler name
        """
        if len(self._get_current_handlers(handler)):
            self.w(f"Requested handler '{handler}' is already running!")
            return True
        else:
            return False

    def _remove_handler(self, handler):
        """Removes handler from respective logger

        Parameters
        ---------
        handler: Handler name
        """
        _current_handlers = self._get_current_handlers(handler)
        if not _current_handlers:
            self.w(
                f"Cannot remove handler as '{handler}' handler is not running!")
            return
        [self.__log.removeHandler(h) for h in _current_handlers]

    def _get_current_handlers(self, handler):
        """Returns handler's current running instances

        Parameters
        ---------
        handler: Handler name
        """
        ref_instance = {
            HANDLERS['console']: logging.StreamHandler,
            HANDLERS['file']: logging.FileHandler,
            HANDLERS['mqtt']: MQTTHandler,
            HANDLERS['kafka']: KafkaHandler
        }.get(handler)
        return [h for h in self.__log.handlers if (type(h) == ref_instance)]
