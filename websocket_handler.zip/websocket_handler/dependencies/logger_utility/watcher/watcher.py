""" Module implements watcher to update run time configuration for handlers and log levels."""
import json
import os
import threading

from logger_utility.constants import WATCHER_MQTT_TOPIC


class Watcher:
    """ Utility to bundle watchers for logger"""

    def __init__(self, logger):
        thread = threading.Thread(target=self.keep_watching, args=(logger,))
        thread.daemon = True
        thread.start()

    @staticmethod
    def keep_watching(logger):
        """
        Watcher function for logger runtime changes

        Parameters
        -----------
        logger: Logger object for which watcher is requested
        """
        while True:
            # TODO(praveen): Fetch consumer module specific runtime config using MQTT Utility: WATCHER_MQTT_TOPIC
            runtime_config = {}
            run_time_config_file = logger.get_run_time_config_file()
            # Create file if it does not exist
            os.makedirs(os.path.dirname(run_time_config_file), exist_ok=True)
            # Store runtime config in local file
            with open(run_time_config_file, 'w') as fp:
                json.dump(runtime_config, fp)

            # Enable or disable handlers at run time ,if needed
            handlers = runtime_config.get('handlers')
            if handlers:
                logger.update_handlers(handlers)
