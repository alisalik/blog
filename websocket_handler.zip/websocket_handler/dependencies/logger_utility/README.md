# Logger Utility

## Overview
Python logger utility for nebula platform
  - Python 3.9.3 and above

---

## Initialize:
Initialize logger inside  `__init__.py` file of your module as below:
``` 
from logger_utility.logger import NebulaLogger
# Initialize logger
logger = NebulaLogger(rule_name="rule_1001")
```
---
## Usage:
Import above configured logger and use.
```
from your_package import logger
logger.i("Test Info message")

```
__will result into__

> 2021-03-21 21:39:24,573 || Personal || 192.168.1.2 || b44f53e51c6c0126f63c9c9d3389985f4b4843233211470cca438c0ce15f6602 || Mobile App  || demo_rule || UID1 ||  DID1 || INFO || OPR  || Test info message
---
## Log Methods:
- d :debug -> To log debug messages: 
  - `logger.d('Debug message.')`
- i :info -> To log info messages
  - `logger.i('Info message.')`
- w :warning -> To log warning messages 
  - `logger.w('Warning message.')`
- e :error -> To log error messages 
  - `logger.e('Error message.')`
- out: output -> To log outputs 
  - `logger.out('Output message.')`
- inp: input - To log inputs 
  - `logger.inp('Input message.')`
---
## MISC:
- Rule name is required to use a logger
- Default handler for a logger will be file handler
- Configure handlers for logger
    - All handlers
    ```
    from logger_utility.logger import NebulaLogger
    logger = NebulaLogger(rule_name='rule_1001', handlers='all')
    ```
    - Configure selected handlers
    ```
    from logger_utility.logger import NebulaLogger
    from logger_utility.config import HANDLERS
    logger = NebulaLogger(rule_name='rule_1001', 
                handlers=[HANDLER['file'], HANDLERS['mqtt']]]
             )
    ```
    - Available handlers:
      - file: `HANDLERS['file']`
      - console: `HANDLERS['console']`
      - mqtt: `HANDLERS['mqtt']`
- Do set extra params once every execution in the beginning as following:
```
logger.set_extra({
  user_id: 'UID1', 
  device_id: 'DID1', 
  platform_identifier:'Mobile App',
})
```
- Do reset extra params after every execution in the beginning as following:
```
logger.reset_extra()
```  

- Enable disable file, mqtt or console logger handlers at runtime
- Enable or disable logs for a device at runtime
- Enable or disable logs for a user at runtime
- Modify platform log level at runtime
- Log levels will be evaluated in following order to decide whether a message will be logged or not
  - Device > User > Platform log level
  - If device logging is on
    - Everything for that device will be logged
  - If User logging is on
    - Everything for that user will be logged
  - Platform log levels
    - 0: Only errors and warnings will be logged (default)
    - 1: Only errors, warnings, inputs and outputs will be logged
    - 2: Every log message will be processed
---
##Directory Structure:
- logger_utility
  - demo: Includes demo for logger utility for reference
  - filters: Filters for logger utility
    - base_filter.py: Base filter for utility
  - handlers: Handlers for logger utility
    - mqtt_handler: MQTT handler to push log messages
  - helpers
    - helpers.py: Helpers functions for logger utility
  - unittest
    - log_methods.py: Unit test cases for supported log methods
  - watcher
    - watcher.py: Watcher for run time changes of logger
  - .gitignore: To ignore stuff mentioned in file by git
  - constants.py: Constant file of the module
  - logger.py: Main utility file
  - README.md: Read me instructions for the utility

