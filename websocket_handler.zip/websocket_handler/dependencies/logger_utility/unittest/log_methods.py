"""Test cases for supported log methods"""

import unittest

from logger_utility.logger import NebulaLogger
from logger_utility.constants import HANDLERS

# Initialize logger
logger = NebulaLogger(rule_name=__name__, handlers=[HANDLERS['console'], ])


class TestLogMethods(unittest.TestCase):
    """Test cases for supported methods for logging."""

    def test_warning(self):
        with self.assertLogs(__name__, level='WARNING') as cm:
            logger.w('warning message')
            self.assertEqual(
                cm.output, [f'WARNING:{__name__}:warning message', ])

    def test_info(self):
        with self.assertLogs(__name__, level='INFO') as cm:
            logger.i('info message')
            self.assertEqual(cm.output, [f'INFO:{__name__}:info message', ])

    def test_debug(self):
        with self.assertLogs(__name__, level='DEBUG') as cm:
            logger.d('debug message')
            self.assertEqual(cm.output, [f'DEBUG:{__name__}:debug message', ])

    def test_error(self):
        with self.assertLogs(__name__, level='ERROR') as cm:
            logger.e('error message')
            self.assertEqual(cm.output, [f'ERROR:{__name__}:error message', ])

    def test_input(self):
        with self.assertLogs(__name__, level='INFO') as cm:
            logger.inp('input message')
            self.assertEqual(cm.output, [f'INFO:{__name__}:input message', ])

    def test_output(self):
        with self.assertLogs(__name__, level='INFO') as cm:
            logger.out('output message')
            self.assertEqual(cm.output, [f'INFO:{__name__}:output message', ])


if __name__ == '__main__':
    unittest.main()
