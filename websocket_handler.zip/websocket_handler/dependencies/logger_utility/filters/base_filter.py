"""Module implements base filter for logger"""

import json
import logging

from logger_utility.constants import (LOG_LEVEL_0, LOG_LEVEL_1, LOG_LEVEL_2,
                                      NA, OPR, INPUT, OUTPUT, RUNTIME_RULE_ENGINE_CONFIG)


class BaseFilter(logging.Filter):

    def filter(self, record):
        """Filter unwanted records
        - Log levels will be evaluated in following order to decide whether a message will be logged or not
          - Device > User > Platform log level
          - If device logging is on
            - Everything for that device will be logged
          - If User logging is on
            - Everything for that user will be logged
          - Platform log levels
            - 0: Only errors and warnings will be logged (default)
            - 1: Only errors, warnings, inputs and outputs will be logged
            - 2: Every log message will be processed

        Parameters
        ----------
        record: record object for logging
        """
        config = self._get_runtime_config(record.rule_name)

        # Add 'OPR' type for io other that I/O
        if not hasattr(record, 'io'):
            record.io = OPR

        # Add 'NA' for platform_identifier
        if not hasattr(record, 'platform_identifier'):
            record.platform_identifier = NA

        # Allow if logs are enabled for a device
        if hasattr(record, 'device_id'):
            if record.device_id in config.get("enabled_log_devices", []):
                return True
        else:
            # Add dummy device id for log format
            record.device_id = NA

        # Allow if logs are enabled for a user
        if hasattr(record, 'user_id'):
            if record.user_id in config.get("enabled_log_users", []):
                return True
        else:
            # Add dummy user id for log format
            record.user_id = NA

        # Fetch platform log level
        pf_level = config.get('platform_log_level', LOG_LEVEL_2)

        if pf_level == LOG_LEVEL_0:
            if record.levelno in {logging.WARNING, logging.ERROR}:
                return True
            else:
                return False
        elif pf_level == LOG_LEVEL_1:
            if record.io in {INPUT, OUTPUT} or record.levelno in {logging.WARNING, logging.ERROR}:
                return True
            else:
                return False
        elif pf_level == LOG_LEVEL_2:
            return True
        return False

    @staticmethod
    def _get_runtime_config(consumer_module_name):
        """Read run time configuration for consumer module from local file

        consumer_module_name: Consumer module name to read specific configuration
        """
        try:
            with open(RUNTIME_RULE_ENGINE_CONFIG.format(consumer_module_name=consumer_module_name)) as fp:
                return json.load(fp)
        except Exception as err:
            # File not found or json decode error
            return {}
