""" Module for some_service of demo module"""
from logger_utility.demo.demo_rule import logger


def i_will_do_something_and_log():
    # do something
    for i in range(5):
        pass
    logger.e("Sub service Error!!")
