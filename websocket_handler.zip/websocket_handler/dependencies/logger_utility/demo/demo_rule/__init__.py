"""Entry point for module
Import and initialize utilities here.
"""


from logger_utility.logger import NebulaLogger

# Initialize logger
logger = NebulaLogger(rule_name=__name__, handlers='all')
