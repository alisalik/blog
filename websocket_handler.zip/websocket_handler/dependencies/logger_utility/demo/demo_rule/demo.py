"""Demo module for logger utility"""

from logger_utility.demo.demo_rule import logger
from logger_utility.demo.demo_rule.some_service import i_will_do_something_and_log


def add(a, b):
    logger.e("Error!!")
    i_will_do_something_and_log()
    logger.w("Warning!!")
    return a + b


def run_logger():
    # Set extras once per execution
    logger.set_extra({'user_id': 'UID1', 'device_id': 'DID1',
                     'platform_identifier': 'Mobile App'})
    for i in range(1):
        logger.i('Normal info!!')

        logger.inp(f'Inputs: {i}, {i+1}')

        sum_ = add(i, i + 1)

        logger.out(f'Output: {sum_}')

        logger.d("Debug!!")


if __name__ == '__main__':
    run_logger()
