""" Module implements helper functions."""

import os
import subprocess

from logger_utility.constants import NA


def get_container_id():
    """Gets container id from process"""
    try:
        bash_command = """head -1 /proc/self/cgroup|cut -d/ -f3"""
        return subprocess.check_output(['bash', '-c', bash_command]).decode('utf-8').strip('\n') or NA
    except:
        # In case of windows OSs
        return NA


def get_sys_info():
    """Gets system info"""
    return {
        'hostname': os.environ.get("HOSTNAME", NA),
        'host_ip': os.environ.get("HOST_IP", NA),
        'container_id': get_container_id(),
    }
