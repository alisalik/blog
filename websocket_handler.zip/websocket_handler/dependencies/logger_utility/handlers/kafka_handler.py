"""Handler to push the logs to Kafka stream"""


from logging import StreamHandler
from logger_utility.constants import SASL_PLAINTEXT, SCRAM_SHA_512, BOOTSTRAP_SRVR, KAFKA_USERNAME, KAFKA_PASSWORD


class KafkaHandler(StreamHandler):
    """
    Utility holds the operation related to the Kafka
    to push the logs to the Kafka Queue.
    """

    def __init__(self, topic, logger_ins):
        """Initialize the Kafka Handler"""
        super().__init__()
        self.__config = {
            "bootstrap_servers": BOOTSTRAP_SRVR,
            "security_protocol": SASL_PLAINTEXT,
            "sasl_mechanism": SCRAM_SHA_512,
            "sasl_plain_username": KAFKA_USERNAME,
            "sasl_plain_password": KAFKA_PASSWORD
        }
        self.__topic = topic
        self.logger_ins = logger_ins

    def emit(self, record):
        """Send log message to Kafka Queue Stream"""
        from kafka_utility.producer import NebulaKafkaProducer
        kfk_producer = NebulaKafkaProducer(self.__config, self.logger_ins)
        msg = self.format(record)
        req = kfk_producer.send_to_topic(
            topic=self.__topic, data=bytes(msg, 'utf-8'))
        # req.get(timeout=10)
