"""Module implements mqtt handler to push logs to mqtt topic"""

from logging import StreamHandler


class MQTTHandler(StreamHandler):
    """
    Utility bundles mqtt handler operations

    Attributes:
        topic: MQTT topic to push logs.
    """

    def __init__(self, topic):
        super().__init__()
        self.__topic = topic

    def emit(self, record):
        """Pushes message to mqtt topic."""
        msg = self.format(record)
        # TODO(praveen): Use a MQTT utility to push logs.
