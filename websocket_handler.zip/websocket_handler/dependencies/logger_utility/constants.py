""" Module's constants file."""
import os

# Log levels
LOG_LEVEL_0 = 0  # errors and warnings will be logged
LOG_LEVEL_1 = 1  # errors, warnings, inputs & outputs will be logged
LOG_LEVEL_2 = 2  # every log message will be processed

# Not applicable string
NA = 'NA'
# Operation string
OPR = 'OPR'
# Input string
INPUT = 'INPUT'
# Output string
OUTPUT = 'OUTPUT'

# Log location of container for rule logs
LOG_FILE_LOCATION = '/var/log/'
# Format for logging messages
COMMON_FORMAT = '%(asctime)s || %(hostname)s || %(host_ip)s || %(container_id)s || %(platform_identifier)s ' \
                '|| %(rule_name)s || %(user_id)s ||  %(device_id)s || %(levelname)s || %(io)s  || %(message)s'
# Available handlers
HANDLERS = {'file': 'file', 'console': 'console',
            'mqtt': 'mqtt', 'kafka': 'kafka'}

# Runtime config file for consumer module
RUNTIME_RULE_ENGINE_CONFIG = 'nebula/configs/{consumer_module_name}_runtime_rule_engine_config.json'
# MQTT topic to watch for run time configuration changes
WATCHER_MQTT_TOPIC = 'watcher_mqtt_topic'

# Default mqtt topic for sending logs
DEFAULT_MQTT_LOG_TOPIC = 'default_mqtt_log_topic'
DEFAULT_KAFKA_LOG_TOPIC = os.getenv("KAFKA_TOPIC")

"""Module constants file."""
# sasl mechanisms
PLAIN = "PLAIN"
GSSAPI = "GSSAPI"
OAUTHBEARER = "OAUTHBEARER"
SCRAM_SHA_256 = "SCRAM-SHA-256"
SCRAM_SHA_512 = "SCRAM-SHA-512"

# Security protocols
SASL_PLAINTEXT = "SASL_PLAINTEXT"
PLAINTEXT = "PLAINTEXT"
SSL = "SSL"
SASL_SSL = "SASL_SSL"

# Kafka Credentials

BOOTSTRAP_SRVR = os.getenv("BOOTSTRAP_SRVR")
KAFKA_USERNAME = os.getenv("KAFKA_USERNAME")
KAFKA_PASSWORD = os.getenv("KAFKA_PASSWORD")

# Checks if users has permission to write to log location
# For local runs


def is_writable(directory):
    try:
        tmp_prefix = "write_tester"
        count = 0
        filename = os.path.join(directory, tmp_prefix)
        while os.path.exists(filename):
            filename = "{}.{}".format(
                os.path.join(directory, tmp_prefix), count)
            count = count + 1
        f = open(filename, "w")
        f.close()
        os.remove(filename)
        return True
    except Exception as __e:
        return False


try:
    if not is_writable(LOG_FILE_LOCATION):
        LOG_FILE_LOCATION = os.path.expanduser('~/var/log/nebula_logs') + '/'
    else:
        LOG_FILE_LOCATION = LOG_FILE_LOCATION + "nebula_logs/"
except:
    # In case of windows system
    LOG_FILE_LOCATION = LOG_FILE_LOCATION + "nebula_logs/"
