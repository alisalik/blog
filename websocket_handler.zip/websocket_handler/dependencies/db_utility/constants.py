"""Module constants."""
from pypika import Order
from pypika.enums import JoinType

# Supported Joins
INNER_JOIN = JoinType.inner
LEFT_JOIN = JoinType.left
RIGHT_JOIN = JoinType.right
OUTER_JOIN = JoinType.outer
LEFT_OUTER_JOIN = JoinType.left_outer
RIGHT_OUTER_JOIN = JoinType.right_outer
FULL_OUTER_JOIN = JoinType.full_outer

# Supported operators
ISIN = 'isin'
NOTIN = 'notin'
BETWEEN = 'between'
LIKE = 'like'
GT = ">"
LT = "<"
GTE = ">="
LTE = "<="
EQ = "=="
NEQ = "!="
INTERVAL = 'interval'

# Allowed operators in having clause
COMPARISON_OPERATORS = [GT, LT, GTE, LTE, EQ, NEQ]
# Allowed operators in where clause
ALLOWED_OPERATORS = COMPARISON_OPERATORS + [ISIN, BETWEEN, NOTIN, LIKE]

ALLOWED_OPERATORS_DRUID = ALLOWED_OPERATORS + [INTERVAL]

# Supported Functions
SUM = 'Sum'
MAX = 'Max'
MIN = 'Min'
AVG = 'Avg'
COUNT = 'Count'

OR = 'OR'
AND = 'AND'

STAR = '*'
COUNT_MULTI_HACK = "#####"

ASC = Order.asc.value
DESC = Order.desc.value
DRUID_ASC = 'ascending'
DRUID_DESC = 'descending'
ALL = "all"

DRUID_TIME_KEY = '__time'

ALLOWED_FUNCTIONS = [SUM, MIN, MAX, AVG, COUNT]

# Maximum number of records allowed to fetch at a time
MAX_RECORDS = 1000

# Access detail db and table information for both MySQL and Druid databases
ACCESS_DETAIL_DB_NAME = 'db_access_details'
ACCESS_DETAIL_TABLE_NAME = 'tbl_rule_access_details'

# Access file location
DB_ACCESS_DETAILS_FILE = 'nebula/configs/access_config.json'
DB_INDEX_DETAILS_FILE = 'nebula/configs/index_config.json'
MAX_INDEX_CONFIG_UPDATE_TIME = 60  # In minutes
UPDATE_TIME_FORMAT = "%b %d %Y %I:%M%p"

# DB Operations
INSERT = 'insert'
UPDATE = 'update'
SELECT = 'select'
DELETE = 'delete'
