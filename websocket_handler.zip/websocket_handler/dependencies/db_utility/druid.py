"""Module implements Druid query builder utility."""

from typing import final

from pydruid.client import *

from db_utility import db_logger
from db_utility.access import ConsumerModuleAccess
from db_utility.constants import MAX_RECORDS, SELECT
from db_utility.druid_json_query_builder import DruidQueryBuilder
from db_utility.exceptions import NebulaDruidError
from db_utility.singleton import Singleton


class NebulaDruid(DruidQueryBuilder, metaclass=Singleton):
    """Utility to bundle Druid database manipulation.

    Attributes:
        consumer_logger: Logger of consumer utility to map logs
        db_config: Config for database
            url: Host to connect
            endpoint: Endpoint for database
            port: Port for database
            username: Username
            password: Password for the user
    """

    def __init__(self, db_config, consumer_logger=None):
        self.__db_config = {
            "url": db_config.get('url') + ':' + str(db_config.get('port', 8888)),
            "endpoint": db_config.get('endpoint', 'druid/v2'),
            "username": db_config.get('username', ''),
            "password": db_config.get('password', ''),
        }

        _empty_attrs = [k for (k, v) in self.__db_config.items() if v is None]
        if _empty_attrs:
            raise AttributeError(
                f"Required attributes: {', '.join(_empty_attrs)}")

        # Connection and cursor objects
        self.__py_druid = None
        # Logger instance of consumer module to map logs
        self.__consumer_logger = consumer_logger

        # Set rule name here to track log messages in aggregated log server
        if self.__consumer_logger:
            db_logger.use_different_rule_name(
                f'{self.__consumer_logger.get_rule_name()}_db_logs')

        # Initialize a py_druid instance
        self._init_py_druid()

    @final
    def push_to_queue(self, insert_params):
        """Pushes data to data to MQTT Topic."""
        # TODO(praveen): Format data and
        # TODO(praveen): Use MQTT Utility to push data to MQTT topic
        pass

    @final
    @ConsumerModuleAccess(SELECT, check_index=False)
    def fetchall(self, table_name,
                 select_columns=[],
                 filters=[],
                 group_by=[],
                 limit=MAX_RECORDS,
                 order_by={}, retries=0):
        """Fetches multiple data from database."""
        query = self.get_select_query(table_name,
                                      select_columns,
                                      filters,
                                      group_by,
                                      limit,
                                      order_by,
                                      False)
        try:
            if group_by:
                return self.__py_druid.groupby(**query).result
            else:
                return self.__py_druid.scan(**query).result
        except Exception as err:
            if retries <= 3:
                retries += 1
                self.fetchall(table_name,
                              select_columns,
                              filters,
                              group_by,
                              limit,
                              order_by,
                              retries)
            else:
                db_logger.e(
                    f"Error while fetching data:{err}, after {retries-1} retries!")
                raise NebulaDruidError(
                    f"Error while fetching data:{err}, after {retries-1} retries!")

    @final
    def _init_py_druid(self):
        """Creates a py_druid instance to make fetch request."""
        self.__py_druid = PyDruid(url=self.__db_config.get('url'),
                                  endpoint=self.__db_config.get('endpoint'))
        self.__py_druid.set_basic_auth_credentials(username=self.__db_config.get('password'),
                                                   password=self.__db_config.get('username'))
