# Database utility

## Overview
Python database utility for nebula platform.
- Python 3.9.3 and above

## Run Tests
- Please run test cases after making changes
```
python -m unittest db_utility/unittest/mysql/tests.py
```
```
python -m unittest db_utility/unittest/druid/tests.py
```
## Initialize
Initialize db inside  `__init__.py` file of your module as below:```

``` 
from db_utility.mysql import NebulaMySQL
# Initialise mysql db
mysql = NebulaMySQL({
    "host": '<host_ip>',
    "user": '<db_username>',
    "password": '<db_password>',
    "database": '<db_name>',
    # If it requires ssl
    "ssl": {
        'ca': '<local_ssl_certificate_location>', # /var/pem/ca-cert.pem
        'key': '<local_client_key_location>', # /var/pem/client-key.pem
        'cert': '<local_client_certificate_location>') # /var/pem/client-certificate.pem
    }
}, <consumer_rule_logger>)
```

``` 
from db_utility.druid import NebulaDruid
# Initialise druid db
druid = NebulaDruid({
  url: <Host to connect>
  endpoint: <Endpoint for database>
  port: <Port for database>
  username: <Username>
  password: <Password for the user>
}, <consumer_rule_logger>)
```

## Usage
- Please use constants available in `db_utility.constants` while using utility.
- Import above configured database and use.
```
from your_package import mysql
# Fetch data from mysql database
mysql.fetchall(
  table_name=TABLE_NAME, # Required
  select_columns=SELECT_COLUMNS, # Required
  filters=[], # Optional
  group_by=[], # Optional
  order_by={}, # Optional
  limit=10, # Optional
)
```

```
from your_package import druid
# Fetch data from druid database
druid.fetchall(
  table_name=TABLE_NAME, # Required
  select_columns=SELECT_COLUMNS, # Required in when using without group by
  filters=[], # Optional
  group_by=[], # Optional
  order_by={}, # Optional
  limit=10, # Optional
)
```

## Filter Object
- If object contains `function` key then it will be considered as `group by / having` filter otherwise a `where` filter.
```
{
"key": <col_name>,
"value": <val_to_compare>,
"operator": <operator>,
"function": <function_name> (Default: NULL)
"conjunction": <AND|OR>, (Default: AND)
"join_table": <join table neame> (Default: NULL) # if filter is to be applied on join table's column
}
```
- `join_table` argument is used to specify name of join table for which filter is requested. 
- Optionally, you can use `get_filter_object` to create object as follows
```
mysql.get_filter_object('<col_name>','<value_to_compare>', '<operator>', <conjuction: OR/AND>, <function>, <join_table>)
```

## Supported Methods in MYSQL Utility
- insert: Inserts single record into database
  - Inputs
    - table_name: Table name
    - insert_param: dictionary of column as key and value to insert as value: `{"first_name": "Praveen"}`
  - Sample Input
  ```
      insert_param = {
          'first_name': "Praveen",
          'last_name': "Sharma",
          'age': 25,
          'sex': "Male"
      }
      mysql.insert(table_name, insert_param)
  ```
  - Output
    - `{'affected_rows': <total_affected_rows>, 'insert_id': <auto_incremented_id>}`
    - Note that insert id will return 0 if no auto increment id is available in table.
- insert_many: Inserts multiple records into database
  - Inputs
    - table_name: Table name
    - insert_param_list: List of dictionary of column as key and value to insert as value: `[{"first_name": "Praveen"}]`
  - Sample Input
  ```
      insert_param_list = [{
          'first_name': "Praveen",
          'last_name': "Sharma",
          'age': 25,
          'sex': "Male"
      },]
      mysql.insert(table_name, insert_param_list)
  ```
  - Output
    - `{'affected_rows': <total_affected_rows>, 'insert_ids': [<auto_incremented_id1>,<auto_incremented_id2>]}`
    - Note that insert id will return 0 if no auto increment id is available in table.

- update: Updates record(s) into database based on optional filters
  - Inputs
    - table_name: Table name
    - update_param: dictionary of column as key and value to update as value: `{"first_name": "Praveen"}`
    - Filters: List of filter object
  - Sample Input
  ```
      update_param = {
          'first_name': "Praveen",
          'age': 25,
      }
      update_filter = [
        mysql.get_filter_object('age', 25, constants.GTE),
      ] # This is optional
      mysql.update(table_name, update_param)
  ```
  - Output
    - No of affected rows
  
- delete: Deletes record(s) from table based on required filters.
  - Inputs
    - Table Name: `Persons`
    - Filters: List of filter object: At least one where clause filter is required 
    - Limit: Optional limit to apply while deletion
  - No `having filters` are allowed while deletion.
  - Sample Input
  ```
      filters = [
        mysql.get_filter_object('age', 25, constants.GTE),
      ] # Atleast one filter is required
      mysql.delete(table_name, filters)
  ```
  - Output
    - No of affected rows
- fetchall: Fetches records based on optional filters, optional group by conditions
  - Inputs
    - Table Name: `Persons`
    - Select Columns: List of columns: `['first_name', 'last_name']`
    - Filters: List of filter object
    - Group by column list: List of group by columns: `['first_name', 'last_name']`
    - Order by dictionary: `{key :value}` pair of column and order requested `{'first_name': constants.ASC}`
    - Limit: Integer value for no of records (Maximum allowed is 1000)
    - Joins: To perform join operation, accepts list of dictionary of format
      ```
      {
          "type": constants.INNER_JOIN,
          # This table is either in from clause or previous joins in order
          "with_table": {
              "name": "Person",
              "on": "id"
          },
          "join_table": {
              "name": "PersonInfo",
              "on": "id",
              "select_columns": [{"col":"first_name", "as":"custom_name"}, ]
          }
      }
      ```
    - is_distinct: To specify if we need to perform `DISTINCT`.
      - ```
        mysql.fetchall(
          table_name=TABLE_NAME,
          select_columns=["first_name"],
          filters=[mysql.get_filter_object("person_id", 2, constants.EQ)],
          is_distinct=True,
        )
        ```
        ```SELECT DISTINCT `first_name` FROM `Persons` WHERE `person_id`=2 LIMIT 1000```
    - offset: To pick data from offset, used for pagination, 
      It will pick rows from offset+1 as offset works in mysql
      - sample: To fetch results in batch of constants.MAX_RECORDS(1000) records
        ```
          results = []
          # First fetch the total results returned by the query usig COUNT
          total_results = mysql.fetchone(
              table_name='Person',
              select_columns=[{"col": "*", "function": constants.COUNT, "as": "total_results",}],
              filters=[mysql.get_filter_object("first_name", 'Praveen', constants.EQ), ]
          ).get("total_results") or 0
          # Iterate over total results and fetch data in batch of constants.MAX_RECORDS
          for offset in range(0, total_results, constants.MAX_RECORDS):
            results += mysql.fetchall(
                table_name='Person',
                select_columns=["person_id"],
                filters=[mysql.get_filter_object("first_name", 'Praveen', constants.EQ), ],
                offset=offset
            )
        ```
  - Sample Input
  ```
      select_columns = ['first_name', 'last_name']
      mysql.fetchall(table_name, update_param)
  ```
  - Output
    - List of record object in dictionary format: `[{ "first_name":"Praveen", "last_name":"Sharma" },]`
- fetchone: Fetches single record based on optional filters, optional group by conditions
  - It will not take limit as argument
  - Inputs
    - Table Name: `Persons`
    - Select Columns: List of columns: `['first_name', 'last_name']`
    - Filters: List of filter object
    - Group by column list: List of group by columns: `['first_name', 'last_name']`
    - Order by dictionary: `{key :value}` pair of column and order requested `{'first_name': constants.ASC}`
    - Joins: To perform join operation, accepts list of dictionary of format
      ```
      {
          "type": constants.INNER_JOIN,
          # This table is either in from clause or previous joins in order
          "with_table": {
              "name": "Person",
              "on": "id"
          },
          "join_table": {
              "name": "PersonInfo",
              "on": "id",
              "select_columns": [{"col":"first_name", "as":"custom_name"}, ]
          }
      }
      ```
    - is_distinct: To specify if we need to perform `DISTINCT`.
      - ```
        mysql.fetchall(
          table_name=TABLE_NAME,
          select_columns=["first_name"],
          filters=[mysql.get_filter_object("person_id", 2, constants.EQ)],
          is_distinct=True,
        )
        ```
        ```SELECT DISTINCT `first_name` FROM `Persons` WHERE `person_id`=2 LIMIT 1000```
  - Sample Input
  ```
      select_columns = ['first_name', 'last_name']
      mysql.fetchone(table_name, update_param)
  ```
  - Output
    - Record object in dictionary format: `{ "first_name":"Praveen", "last_name":"Sharma" }`   
- close: Closes the database connection
- get_filter_object: Gets filter object
- get_select_query: Gets generated raw SQL query for select
- get_update_query:  Gets generated raw SQL query for update
- get_insert_query:  Gets generated raw SQL query for insert
- get_delete_query:  Gets generated raw SQL query for delete
- get_indexes_of_table: Gets indexes of a table
  
## Join Operation MySQL select queries
- Supported join operations:
  ```
  INNER_JOIN = JoinType.inner
  LEFT_JOIN = JoinType.left
  RIGHT_JOIN = JoinType.right
  OUTER_JOIN = JoinType.outer
  LEFT_OUTER_JOIN = JoinType.left_outer
  RIGHT_OUTER_JOIN = JoinType.right_outer
  FULL_OUTER_JOIN = JoinType.full_outer
  ```
- Sample join input and respective output:
  ```
  mysql.get_select_query(
          "Person",
          joins=[
              {
                  "type": constants.INNER_JOIN,
                  # This table is either in from clause or previous joins in order
                  "with_table": {
                      "name": "Person",
                      "on": "id"
                  },
                  "join_table": {
                      "name": "PersonInfo",
                      "on": "id",
                      "select_columns": [{"col": "first_name", "as": "first_name"}, ]
                  }
              }
          ]
      )
  ```
  ```
  SELECT `PersonInfo`.`first_name` `first_name` FROM `Person` JOIN `PersonInfo` ON `PersonInfo`.`id`=`Person`.`id` LIMIT 1000
  ```
  - If same key is not selected from different tables:`{"first_name": "Praveen"}`
  - If same key is selected from different tables: `{"PersonInfo.first_name": "Praveen", "first_name": "SomeValue"}`
  - So in order to avoid conflict, it is advised to use `as` operator aliased with unique columns names to select.

## Select Columns: MySQL Utility
We can choose to select columns in two different ways:
- with `as` operator: by passing list of dictionaries of format 
  `{"col": '<column_name_to_select>', "as": '<alias_to_use>'}`
  - select_columns = [{"col": "first_name", "as": "custom_first_name"}]
  - output: `{"custom_first_name": 'Praveen'}`
- without `as` operator: by passing list of strings `["column_name_to_select",]`
  - select_columns = ["first_name",]
  - output: `{"first_name": 'Praveen'}`
- Perform COUNT in select clause, supported COUNT operations
  - COUNT(*)
    - is_distinct is not allowed in this case
  - COUNT(col1)
  - COUNT(DISTINCT col1)
  - COUNT(DISTINCT col1, col2...)
    - is_distinct is required in this case
  - Samples:
    - COUNT(*) 
      ```
       mysql.get_select_query(
        table_name='person',
        select_columns=[{"col": "*", "function": constants.COUNT, "as": "my_count",}],
      )
      ```
      `SELECT COUNT(*) `my_count` FROM `person` LIMIT 1000`
  
    - COUNT(col1) 
      ```
       mysql.get_select_query(
        table_name='person',
        select_columns=[{"col": "first_name", "function": constants.COUNT, "as": "my_count",}],
      )
      ```
      ```SELECT COUNT(`first_name`) `my_count` FROM `person` LIMIT 1000```
  
    - COUNT(DISTINCT col1)
      ```
       mysql.get_select_query(
        table_name='person',
        select_columns=[{
          "col": "first_name", "function": constants.COUNT, 
          "as": "my_count", "is_distinct": True
        }],
      )
      ```
      ```SELECT COUNT(DISTINCT `first_name`) `my_count` FROM `person` LIMIT 1000```
  
    - COUNT(DISTINCT col1, col2...)
      ```
       mysql.get_select_query(
        table_name='person',
        select_columns=[{
          "col": ["first_name", "last_name"], "function": constants.COUNT, 
          "as": "my_count", "is_distinct": True
        }],
      )
      ```
      ```SELECT COUNT(DISTINCT `first_name`, `last_name`) `my_count` FROM `person` LIMIT 1000```

## Supported Methods in DRUID Utility
- push_to_queue: To push streaming data to queue
- fetchall: Fetches records based on optional filters, optional group by conditions
  - Inputs
    - Table Name: `Persons`
    - Select Columns: List of columns: `['first_name', 'last_name']`
    - Filters: List of filter object (interval filter is required in all cases)
    - Group by column list: List of group by columns: `['first_name', 'last_name']`
    - Order by dictionary: `{key :value}` pair of column and order requested `{'first_name': constants.ASC}`
      - Only __time is allowed in select operation without group by (scan)
      - Order by columns can be allowed only if they are in group by columns with group by select(groupBY)
    - Limit: Integer value for no of records (Maximum allowed is 1000)
  - Sample Input
    - interval filter is required in all operations
    - Scan query
      - Input 
        ```
            select_columns = ['first_name', 'last_name']
            filters = [
              query_builder.get_filter_object(
                value=["2020-10-21T00:00:00.000Z/2020-10-22T23:59:59.000Z", ],
                operator=constants.INTERVAL),
            ]
            druid.fetchall(table_name=table_name, select_columns=select_columns, filters=filters)
        ```
      - Output
      ```
        [{
          'segmentId': 'Persons_2010-01-01T00:00:00.000Z_2010-01-02T00:00:00.000Z_2021-03-27T17:41:38.375Z', 
          'columns': ['first_name', 'last_name'], 
          'events': [{'first_name': 'Manu', 'last_name': 'Sharma'}, {'first_name': 'Manu2', 'last_name': 'Sharma2'}]
        }]
      ```
    - Group query
      - Input 
        ```
            group_by = ['first_name', 'last_name']
            filters = [
              query_builder.get_filter_object(
                value=["2020-10-21T00:00:00.000Z/2020-10-22T23:59:59.000Z", ],
                operator=constants.INTERVAL),
            ]
            druid.fetchall(table_name=table_name, filters=filters, group_by=group_by)
        ```
      - Output
      ```
        [
          {
            'version': 'v1', 
            'timestamp': '2010-01-01T00:00:00.000Z', 
            'event': {'last_name': 'Sharma', 'first_name': 'Manu'}
          }, 
          {
            'version': 'v1', 
            'timestamp': '2010-01-01T00:00:00.000Z', 
            'event': {'last_name': 'Sharma2', 'first_name': 'Manu2'}
          }
        ]
      ```
- get_filter_object: Gets filter object
- get_select_query: Gets generated json query

## Supported Operators
```
ISIN = 'isin'
NOTIN = 'notin'
BETWEEN = 'between'
LIKE = 'like'
GT = ">"
LT = "<"
GTE = ">="
LTE = "<="
EQ = "=="
NEQ = "!="
```

## Supported Functions
```
SUM = 'Sum'
MAX = 'Max'
MIN = 'Min'
AVG = 'Avg'
COUNT = 'Count'

```

## MISC
- Rule must have access to perform `select`, `insert`, `delete` or `update` operation on requested `table`
  - To locally setup access config to enable access, 
    please create a config file at location from variable `DB_ACCESS_DETAILS_FILE`'s value from constants file
    with json values like: `{"Table1":  ["select", "insert", "update", "delete"], "Table2":  ["select", "insert", "update", "delete"]}`
- Indexes are required for all the where clause filters in `select`, `delete` or `update` MySQL operations.
    - Indexes will be fetched for the first time while initialising databse object
    - Fetched indexes will be stored at location `constants.MAX_INDEX_CONFIG_TIME` file
    - Index refresh will be triggered only if last updated time has surpassed one hour on next db operation
- Group by columns are required if `filters` contain having filters.

## Singleton object utility
 - from db_utility.mysql import NebulaMySQL
 - Use it when we want to create single object
 - Can be used in parallel executions (may affect performance as connection and cursor objects are shared)


## Independent instance utility
 - from db_utility.mysql_async import NebulaMySQLSync
 - Use it when we want to create separate objects
 - Do not use same object in parallel executions

## Example Usage
- Please go through `db_utility.demo.mysql_demo.demo` for MySQL demo usage
- Please go through `db_utility.unittest.mysql.tests` for MySQL usage
- Please go through `db_utility.demo.druid_demo.demo` for DRUID demo usage
- Please go through `db_utility.unittest.druid.tests` for DRUID usage

## Directory Structure:
- db_utility
  - demo: Includes demo for db utilities for reference
    - mysql_demo: Demo for MySQL utility
    - druid_demo: Demo for DRUID utility
  - unittest: Unit tests for utility
    - mysql
      - queries.py: Static SQL queries for test cases reference
      - tests.py: Test cases for MySQL utility
    - druid
      - static_json_queries.py : Static JSON queries for test cases reference
      - tests.py: Test cases for DRUID utility
  - .gitignore: To ignore stuff mentioned in file by git
  - `__init__.py`
  - access.py: Access module for utility
  - constants.py: Constant file of the module
  - druid.py: Main file for DRUID utility
  - druid_json_query_builder: Query builder for DRUID utility
  - exceptions.py: Exception file for the module
  - lock.py: Decorator function to enforce thread lock
  - mysql.py: Main file for MySQL utility with singleton object
  - mysql_base.py: MySQL base class
  - mysql_sync.py: Main file for MySQL utility, synchronous executions, 
    create separate objects for parallel executions
  - mysql_query_builder.py: Query builder for MySQL utility
  - README.md: Read me instructions for the utility
  - requirements.txt: Required modules to run utility
  - singleton.py: To make db instance singleton 