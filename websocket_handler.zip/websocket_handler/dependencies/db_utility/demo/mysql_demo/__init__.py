from logger_utility.logger import NebulaLogger
from db_utility.mysql import NebulaMySQL

# Initialize logger
logger = NebulaLogger(rule_name='Rule_1001', handlers=['console', ])

# Initialise db
db_config = {
    "host": '192.168.1.100',
    "user": 'root',
    "password": 'Abc@12345',
    "database": 'nebula',
}
mysql = NebulaMySQL(db_config, logger)
