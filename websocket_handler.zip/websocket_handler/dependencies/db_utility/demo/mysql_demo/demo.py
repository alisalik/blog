from database_utility.demo.mysql_demo import mysql
from database_utility.demo.mysql_demo import logger
import database_utility.constants as constants


def run_db():
    logger.set_extra({"user_id": "UID67676", "device_id": "DID75675",
                     "platform_identifier": "Mobile App"})
    logger.inp("Setting up inside")

    table_name = 'Persons'

    insert_param = {
        'first_name': "Praveen",
        'last_name': "Sharma",
        'age': 25,
        'sex': "Male"
    }
    # Use `insert` instead of `get_insert_query` to insert data
    print(mysql.get_insert_query(table_name, insert_param))  # Affected rows

    insert_param_list = [{
        'first_name': "Manu",
        'last_name': "Sharma",
        'age': 11,
        'sex': "Male"
    },
        {
        'first_name': "Manu2",
        'last_name': "Sharma2",
        'age': 12,
        'sex': "Male"
    },
    ]
    # Use `insert_many` instead of `get_insert_query` to insert multiple data
    # mysql.insert_many(table_name, insert_param_list)
    for insert_param in insert_param_list:
        print(mysql.get_insert_query(table_name, insert_param))  # Affected rows

    update_param = {
        'sex': "Male"
    }
    update_filters = [
        mysql.get_filter_object('age', 25, constants.GTE),
    ]
    # Use `update` instead of `get_update_query` to update data
    print(mysql.get_update_query(table_name,
          update_param, update_filters))  # Affected rows

    select_columns = ['first_name', 'last_name']
    select_filters = [
        mysql.get_filter_object('age', 60, constants.NEQ),
        mysql.get_filter_object('age', (80, 100), constants.BETWEEN),
        mysql.get_filter_object('sex', 'male', constants.EQ),
        mysql.get_filter_object('age', 70, constants.GTE, constants.OR),
        mysql.get_filter_object('age', 100, constants.LTE, constants.OR),
        # Following will be auto detected as group by filters
        mysql.get_filter_object('age', 23, constants.GT,
                                constants.AND, constants.SUM),
        mysql.get_filter_object('age', 45, constants.NEQ,
                                constants.AND, constants.MIN),
    ]
    # group by filters will be ignored if below does not present
    group_by = ['first_name', 'last_name']
    order_by = {'first_name': constants.ASC, 'age': constants.DESC}
    limit = 2
    # Use fetchall/fetchone  instead of get_select_query get data
    print(mysql.get_select_query(
        table_name,
        select_columns=select_columns,
        filters=select_filters,
        limit=limit,
        group_by=group_by,
        order_by=order_by
    ))


if __name__ == '__main__':
    run_db()
