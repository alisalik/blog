from database_utility.demo.druid_demo import druid
from database_utility.demo.druid_demo import logger
import database_utility.constants as constants


def run_druid_db():
    logger.set_extra({"user_id": "UID67676", "device_id": "DID75675",
                     "platform_identifier": "Mobile App"})
    logger.inp("Setting up inside")

    table_name = 'moxiam'

    select_columns = ["count", "deviceid", "devicetype", "room_name"]
    select_filters = [
        druid.get_filter_object('__time', [
                                "2020-10-21T00:00:00.000Z/2020-10-22T23:59:59.000Z", ], constants.INTERVAL),
        druid.get_filter_object('deviceid', 315, constants.EQ),
        # Following will be auto detected as group by filters
        # druid.get_filter_object('count', 11, constants.NEQ, constants.AND, constants.SUM),
    ]
    # group by filters will be ignored if below does not present
    group_by = ['devicetype', 'room_name', 'count']
    # Allowed with group by
    order_by = {'room_name': constants.ASC}
    # Allowed without group by: only __time column
    # order_by = { constants.DRUID_TIME_KEY: constants.DESC }
    limit = 20
    # Use fetchall instead of get_select_query get results instead of json query
    result = druid.get_select_query(
        table_name=table_name,
        select_columns=select_columns,
        filters=select_filters,
        limit=limit,
        # group_by=group_by,
        # order_by=order_by
    )
    print(result)


if __name__ == '__main__':
    run_druid_db()
