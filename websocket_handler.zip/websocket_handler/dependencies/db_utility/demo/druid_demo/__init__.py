from logger_utility.logger import NebulaLogger
from db_utility.druid import NebulaDruid

# Initialize logger
logger = NebulaLogger(rule_name='Rule_1001', handlers=['console', ])

# Initialize a MySQL connection here to update rule access details in local file

# Initialise db
db_config = {
    # 'url': 'http://<host_ip_or_address>',
    'url': 'http://192.168.1.100',
}
druid = NebulaDruid(db_config, logger)
