import os
import urllib.request as urllib
from logger_utility.logger import NebulaLogger

# Initialize logger
db_logger = NebulaLogger(rule_name=os.path.basename(os.path.dirname(__file__)))
