"""Module implements synchronous MySQL database utility."""
from typing import final
from db_utility.mysql_base import _NebulaMySQLBase
from db_utility.constants import MAX_RECORDS


class NebulaMySQLSync(_NebulaMySQLBase):
    """Bundles mysql synchronous utility to be used when running parallel executions.
    Use separate instances for parallel executions.

    Attributes:
        consumer_logger: Logger of consumer utility to map logs
        db_config: Config for database
            host: Host to connect
            user: User for database
            password: Password for the user
            database: Database name
            port: Port on which MySQL server is running
            ssl: SSL information
              ca: ssl certificate location
              key: client key
              cert: client certificate
    """

    def __init__(self, *args, **kwargs):
        super(NebulaMySQLSync, self).__init__(*args, **kwargs)

    @final
    def insert(self, table_name, insert_param):
        """Inserts data into database."""
        return super(NebulaMySQLSync, self).insert(table_name, insert_param)

    @final
    def insert_many(self, table_name, insert_param_list):
        """Inserts multiple data into database."""
        return super(NebulaMySQLSync, self).insert_many(table_name, insert_param_list)

    @final
    def delete(self, table_name, filters, limit=None):
        """Deletes data from table based on required filters."""
        return super(NebulaMySQLSync, self).delete(table_name, filters, limit)

    @final
    def update(self, table_name, update_param, filters=[]):
        """Updates data into database."""
        return super(NebulaMySQLSync, self).update(table_name, update_param, filters)

    @final
    def fetchall(self, table_name,
                 select_columns=[],
                 filters=[],
                 group_by=[],
                 limit=MAX_RECORDS,
                 order_by={},
                 joins=[],
                 is_distinct=False,
                 offset=None):
        """Fetches multiple data from database."""
        return super(NebulaMySQLSync, self).fetchall(
            table_name,
            select_columns,
            filters,
            group_by,
            limit,
            order_by,
            joins,
            is_distinct,
            offset
        )

    @final
    def fetchone(self, table_name,
                 select_columns=[],
                 filters=[],
                 group_by=[],
                 order_by={},
                 joins=[],
                 is_distinct=False):
        """Fetches single data from database."""
        return super(NebulaMySQLSync, self).fetchone(
            table_name,
            select_columns,
            filters,
            group_by,
            order_by,
            joins,
            is_distinct
        )
