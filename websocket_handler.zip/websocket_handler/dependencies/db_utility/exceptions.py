"""Module's exceptions."""


class AccessError(Exception):
    """Raised when access is not valid."""

    def __init__(self, message):
        super().__init__(message)


class NebulaMySQLError(Exception):
    """Raised when mysql query throws an error while execution."""

    def __init__(self, message):
        super().__init__(message)


class NebulaDruidError(Exception):
    """Raised when druid query throws an error while execution."""

    def __init__(self, message):
        super().__init__(message)
