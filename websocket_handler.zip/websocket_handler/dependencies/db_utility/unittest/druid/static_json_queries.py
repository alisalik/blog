""" Static json queries for test cases. """

SIMPLE_SELECT_QUERY = {
    'queryType': 'scan',
    'dataSource': 'Persons',
    'columns': ['first_name', 'last_name'],
    'limit': 1000,
    'intervals': ['2020-10-21T00:00:00.000Z/2020-10-22T23:59:59.000Z']
}

SELECT_WITH_ORDER_BY_QUERY = {
    'queryType': 'scan',
    'dataSource': 'Persons',
    'columns': ['first_name', 'last_name', '__time'],
    'limit': 1000,
    'intervals': ['2020-10-21T00:00:00.000Z/2020-10-22T23:59:59.000Z'],
    'order': 'ascending'
}

SELECT_SINGLE_FILTER = {
    'queryType': 'scan',
    'dataSource': 'Persons',
    'columns': ['first_name', 'last_name'],
    'limit': 1000,
    'intervals': ['2020-10-21T00:00:00.000Z/2020-10-22T23:59:59.000Z'],
    'filter': {
        'type': 'selector',
        'dimension': 'first_name',
        'value': 'FirstName'
    }
}

SELECT_MULTIPLE_AND_FILTER = {
    'queryType': 'scan',
    'dataSource': 'Persons',
    'columns': ['first_name', 'last_name'],
    'limit': 1000,
    'intervals': ['2020-10-21T00:00:00.000Z/2020-10-22T23:59:59.000Z'],
    'filter': {
        'type': 'and',
        'fields': [
            {
                'type': 'selector',
                'dimension': 'first_name',
                'value': 'FirstName'
            },
            {
                'type': 'not',
                'field': {
                    'type': 'selector',
                    'dimension': 'first_name',
                    'value': 'LastName'
                }
            }
        ]
    }
}

SELECT_MULTIPLE_OR_FILTER = {
    'queryType': 'scan',
    'dataSource': 'Persons',
    'columns': ['first_name', 'last_name'],
    'limit': 1000,
    'intervals': ['2020-10-21T00:00:00.000Z/2020-10-22T23:59:59.000Z'],
    'filter': {
        'type': 'or',
        'fields': [
            {
                'type': 'selector',
                'dimension': 'first_name',
                'value': 'FirstName'
            },
            {
                'type': 'not',
                'field': {
                    'type': 'selector',
                    'dimension': 'first_name',
                    'value': 'LastName'
                }
            }
        ]
    }
}

SIMPLE_GROUP_BY_QUERY = {
    'queryType': 'groupBy',
    'dataSource': 'Persons',
    'dimensions': ['first_name', 'last_name'],
    'granularity': 'all',
    'limitSpec': {
        'type': 'default',
        'limit': 1000
    },
    'intervals': ['2020-10-21T00:00:00.000Z/2020-10-22T23:59:59.000Z']
}

SIMPLE_GROUP_BY_WITH_HAVING_QUERY = {
    'queryType': 'groupBy',
    'dataSource': 'Persons',
    'dimensions': ['first_name', 'last_name'],
    'granularity': 'all',
    'limitSpec': {
        'type': 'default',
        'limit': 1000
    },
    'intervals': ['2020-10-21T00:00:00.000Z/2020-10-22T23:59:59.000Z'],
    'aggregations': [
        {
            'type': 'doubleSum',
            'fieldName': 'age',
            'name': 'Sum_age'
        }
    ],
    'having': {
        'aggregation': 'Sum_age',
        'value': 11,
        'type': 'greaterThan'
    }
}


GROUP_BY_WITH_HAVING_MULTIPLE_AND_FILTERS_QUERY = {
    'queryType': 'groupBy',
    'dataSource': 'Persons',
    'dimensions': ['first_name', 'last_name'],
    'granularity': 'all',
    'limitSpec': {
        'type': 'default',
        'limit': 1000
    },
    'intervals': ['2020-10-21T00:00:00.000Z/2020-10-22T23:59:59.000Z'],
    'aggregations': [
        {
            'type': 'doubleSum',
            'fieldName': 'age',
            'name': 'Sum_age'
        },
        {
            'type': 'count',
            'fieldName': 'age',
            'name': 'Count_age'
        }
    ],
    'having': {
        'type': 'and',
        'havingSpecs': [
            {
                'aggregation': 'Sum_age',
                'value': 11,
                'type': 'greaterThan'
            },
            {
                'type': 'not',
                'havingSpec': {
                    'type': 'equalTo',
                    'aggregation': 'Count_age',
                    'value': 11
                }
            }
        ]
    }
}
GROUP_BY_WITH_HAVING_MULTIPLE_OR_FILTERS_QUERY = {
    'queryType': 'groupBy',
    'dataSource': 'Persons',
    'dimensions': ['first_name', 'last_name'],
    'granularity': 'all',
    'limitSpec': {
        'type': 'default',
        'limit': 1000
    },
    'intervals': ['2020-10-21T00:00:00.000Z/2020-10-22T23:59:59.000Z'],
    'aggregations': [
        {
            'type': 'doubleSum',
            'fieldName': 'age',
            'name': 'Sum_age'
        },
        {
            'type': 'count',
            'fieldName': 'age',
            'name': 'Count_age'
        }
    ],
    'having': {
        'type': 'or',
        'havingSpecs': [
            {
                'aggregation': 'Sum_age',
                'value': 11,
                'type': 'greaterThan'
            },
            {
                'type': 'not',
                'havingSpec': {
                    'type': 'equalTo',
                    'aggregation': 'Count_age',
                    'value': 11
                }
            }
        ]
    }
}

GROUP_BY_WITH_ORDER_BY = {
    'queryType': 'groupBy',
    'dataSource': 'Persons',
    'dimensions': ['first_name', 'last_name'],
    'granularity': 'all',
    'limitSpec': {
        'type': 'default',
        'limit': 1000,
        'columns': [
            {
                'dimension': 'first_name',
                'direction': 'ascending'
            }
        ]
    },
    'intervals': ['2020-10-21T00:00:00.000Z/2020-10-22T23:59:59.000Z']
}
