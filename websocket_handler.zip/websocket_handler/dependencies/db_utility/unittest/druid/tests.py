""" Test cases for druid db utility """

import unittest

from db_utility import constants
from db_utility.druid_json_query_builder import DruidQueryBuilder
from db_utility.unittest.druid.static_json_queries import (
    SIMPLE_SELECT_QUERY,
    SELECT_SINGLE_FILTER,
    SELECT_MULTIPLE_AND_FILTER,
    SELECT_MULTIPLE_OR_FILTER,
    SIMPLE_GROUP_BY_QUERY,
    SIMPLE_GROUP_BY_WITH_HAVING_QUERY,
    GROUP_BY_WITH_HAVING_MULTIPLE_AND_FILTERS_QUERY,
    GROUP_BY_WITH_HAVING_MULTIPLE_OR_FILTERS_QUERY,
    GROUP_BY_WITH_ORDER_BY,
    SELECT_WITH_ORDER_BY_QUERY,
)

# Initialize query builder
query_builder = DruidQueryBuilder()
TABLE_NAME = 'Persons'


class TestDBMethods(unittest.TestCase):
    """Test cases for supported methods for db utility."""

    def test_simple_without_intervals_should_fail(self):
        # Assert
        self.assertRaises(
            ValueError,
            query_builder.get_select_query,
            table_name=TABLE_NAME,
            select_columns=['first_name', 'age'],
            filters=[
                query_builder.get_filter_object(
                    'first_name', 'FirstName', constants.EQ),
            ]
        )

    def test_simple_select(self):
        # Act
        generated_query = query_builder.get_select_query(
            table_name=TABLE_NAME,
            select_columns=['first_name', 'last_name'],
            filters=[
                query_builder.get_filter_object(
                    value=["2020-10-21T00:00:00.000Z/2020-10-22T23:59:59.000Z", ],
                    operator=constants.INTERVAL
                ),
            ]
        )

        # Assert
        self.assertEqual(generated_query, SIMPLE_SELECT_QUERY)

    def test_select_with_order_by(self):
        # Act
        generated_query = query_builder.get_select_query(
            table_name=TABLE_NAME,
            select_columns=['first_name', 'last_name'],
            filters=[
                query_builder.get_filter_object(
                    value=["2020-10-21T00:00:00.000Z/2020-10-22T23:59:59.000Z", ],
                    operator=constants.INTERVAL
                ),
            ],
            # Only `__time` key order by is allowed
            order_by={constants.DRUID_TIME_KEY: constants.ASC}
        )

        # Assert
        self.assertEqual(generated_query, SELECT_WITH_ORDER_BY_QUERY)

    def test_select_with_order_by_column_not_time_key_should_fail(self):
        # Assert
        self.assertRaises(
            ValueError,
            query_builder.get_select_query,
            table_name=TABLE_NAME,
            select_columns=['first_name', 'last_name'],
            filters=[
                query_builder.get_filter_object(
                    value=["2020-10-21T00:00:00.000Z/2020-10-22T23:59:59.000Z", ],
                    operator=constants.INTERVAL
                ),
            ],
            # Only `__time` key order by is allowed
            order_by={'first_name': constants.ASC}
        )

    def test_select_single_filter(self):
        # Act
        generated_query = query_builder.get_select_query(
            table_name=TABLE_NAME,
            select_columns=['first_name', 'last_name'],
            filters=[
                query_builder.get_filter_object(
                    value=["2020-10-21T00:00:00.000Z/2020-10-22T23:59:59.000Z", ],
                    operator=constants.INTERVAL
                ),
                query_builder.get_filter_object(
                    'first_name', 'FirstName', constants.EQ)
            ]
        )

        # Assert
        self.assertEqual(generated_query, SELECT_SINGLE_FILTER)

    def test_select_multiple_and_filter(self):
        # Act
        generated_query = query_builder.get_select_query(
            table_name=TABLE_NAME,
            select_columns=['first_name', 'last_name'],
            filters=[
                query_builder.get_filter_object(
                    value=["2020-10-21T00:00:00.000Z/2020-10-22T23:59:59.000Z", ],
                    operator=constants.INTERVAL
                ),
                query_builder.get_filter_object(
                    'first_name', 'FirstName', constants.EQ),
                query_builder.get_filter_object(
                    'first_name', 'LastName', constants.NEQ)
            ]
        )

        # Assert
        self.assertEqual(generated_query, SELECT_MULTIPLE_AND_FILTER)

    def test_select_multiple_or_filter(self):
        # Act
        generated_query = query_builder.get_select_query(
            table_name=TABLE_NAME,
            select_columns=['first_name', 'last_name'],
            filters=[
                query_builder.get_filter_object(
                    value=["2020-10-21T00:00:00.000Z/2020-10-22T23:59:59.000Z", ],
                    operator=constants.INTERVAL
                ),
                query_builder.get_filter_object(
                    'first_name', 'FirstName', constants.EQ, constants.OR),
                query_builder.get_filter_object(
                    'first_name', 'LastName', constants.NEQ, constants.OR)
            ]
        )

        # Assert
        self.assertEqual(generated_query, SELECT_MULTIPLE_OR_FILTER)

    def test_group_by_with_select_columns_should_fail(self):
        # Assert
        self.assertRaises(
            ValueError,
            query_builder.get_select_query,
            table_name=TABLE_NAME,
            select_columns=['first_name', 'age'],
            filters=[
                query_builder.get_filter_object(
                    'first_name', 'FirstName', constants.EQ),
            ],
            group_by=['first_name', 'age']
        )

    def test_simple_group_by(self):
        # Act
        generated_query = query_builder.get_select_query(
            table_name=TABLE_NAME,
            group_by=['first_name', 'last_name'],
            filters=[
                query_builder.get_filter_object(
                    value=["2020-10-21T00:00:00.000Z/2020-10-22T23:59:59.000Z", ],
                    operator=constants.INTERVAL
                ),
            ]
        )

        # Assert
        self.assertEqual(generated_query, SIMPLE_GROUP_BY_QUERY)

    def test_simple_group_by_with_having(self):
        # Act
        generated_query = query_builder.get_select_query(
            table_name=TABLE_NAME,
            group_by=['first_name', 'last_name'],
            filters=[
                query_builder.get_filter_object(
                    value=["2020-10-21T00:00:00.000Z/2020-10-22T23:59:59.000Z", ],
                    operator=constants.INTERVAL
                ),
                query_builder.get_filter_object(
                    'age', 11, constants.GT, constants.AND, constants.SUM),
            ]
        )

        # Assert
        self.assertEqual(generated_query, SIMPLE_GROUP_BY_WITH_HAVING_QUERY)

    def test_group_by_with_multiple_having_AND_filters(self):
        # Act
        generated_query = query_builder.get_select_query(
            table_name=TABLE_NAME,
            group_by=['first_name', 'last_name'],
            filters=[
                query_builder.get_filter_object(
                    value=["2020-10-21T00:00:00.000Z/2020-10-22T23:59:59.000Z", ],
                    operator=constants.INTERVAL
                ),
                query_builder.get_filter_object(
                    'age', 11, constants.GT, constants.AND, constants.SUM),
                query_builder.get_filter_object(
                    'age', 11, constants.NEQ, constants.AND, constants.COUNT),
            ]
        )

        # Assert
        self.assertEqual(
            generated_query, GROUP_BY_WITH_HAVING_MULTIPLE_AND_FILTERS_QUERY)

    def test_group_by_with_multiple_having_OR_filters(self):
        # Act
        generated_query = query_builder.get_select_query(
            table_name=TABLE_NAME,
            group_by=['first_name', 'last_name'],
            filters=[
                query_builder.get_filter_object(
                    value=["2020-10-21T00:00:00.000Z/2020-10-22T23:59:59.000Z", ],
                    operator=constants.INTERVAL
                ),
                query_builder.get_filter_object(
                    'age', 11, constants.GT, constants.OR, constants.SUM),
                query_builder.get_filter_object(
                    'age', 11, constants.NEQ, constants.OR, constants.COUNT),
            ]
        )

        # Assert
        self.assertEqual(
            generated_query, GROUP_BY_WITH_HAVING_MULTIPLE_OR_FILTERS_QUERY)

    def test_group_by_with_order_by(self):
        # Act
        generated_query = query_builder.get_select_query(
            table_name=TABLE_NAME,
            group_by=['first_name', 'last_name'],
            filters=[
                query_builder.get_filter_object(
                    value=["2020-10-21T00:00:00.000Z/2020-10-22T23:59:59.000Z", ],
                    operator=constants.INTERVAL
                ),
            ],
            order_by={"first_name": constants.ASC}
        )

        # Assert
        self.assertEqual(generated_query, GROUP_BY_WITH_ORDER_BY)

    def test_column_in_order_by_not_in_group_by_should_fail(self):
        # Assert
        self.assertRaises(
            ValueError,
            query_builder.get_select_query,
            table_name=TABLE_NAME,
            group_by=['first_name', 'last_name'],
            filters=[
                query_builder.get_filter_object(
                    value=["2020-10-21T00:00:00.000Z/2020-10-22T23:59:59.000Z", ],
                    operator=constants.INTERVAL
                ),
            ],
            order_by={"age": constants.ASC}
        )

    def test_multiple_conjunction_types_should_fail(self):
        # Assert
        self.assertRaises(
            ValueError,
            query_builder.get_select_query,
            table_name=TABLE_NAME,
            select_columns=['first_name', 'age'],
            filters=[
                query_builder.get_filter_object(
                    value=["2020-10-21T00:00:00.000Z/2020-10-22T23:59:59.000Z", ],
                    operator=constants.INTERVAL
                ),
                query_builder.get_filter_object(
                    'first_name', 'FirstName', constants.EQ, constants.OR),
                query_builder.get_filter_object(
                    'first_name', 'FirstName', constants.EQ, constants.AND),
            ]
        )


if __name__ == '__main__':
    unittest.main()
