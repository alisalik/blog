""" Static queries for test cases. """
INSERT_QUERY = "INSERT INTO `Persons` (`first_name`,`last_name`,`age`,`sex`) VALUES ('FirstName','LastName',25,'male')"
UPDATE_QUERY_WITHOUT_WHERE = "UPDATE `Persons` SET `first_name`='FirstNameNew',`age`=32,`sex`='female'"
UPDATE_QUERY_WITH_WHERE = "UPDATE `Persons` SET `first_name`='FirstNameNew',`age`=32,`sex`='female' WHERE " \
                          "`first_name`='FirstName'"
SIMPLE_SELECT_QUERY = "SELECT `first_name`,`age` FROM `Persons` LIMIT 1000"
SELECT_WITH_OFFSET_QUERY = "SELECT `first_name`,`age` FROM `Persons` WHERE `age`<=70 LIMIT 1000 OFFSET 5"
SIMPLE_SELECT_WITH_AS_QUERY = "SELECT `first_name` `custom_first_name` FROM `Persons` LIMIT 1000"
SIMPLE_SELECT_QUERY_WITH_LIMIT = "SELECT `first_name`,`age` FROM `Persons` LIMIT 20"
SIMPLE_SELECT_QUERY_ORDER_BY = "SELECT `first_name`,`age` FROM `Persons` ORDER BY `first_name` ASC LIMIT 1000"
SELECT_WITH_AND_IN_WHERE = "SELECT `first_name`,`age` FROM `Persons` WHERE `age`<=70 AND " \
                           "`first_name`='FirstName' LIMIT 1000"
SELECT_WITH_OR_IN_WHERE = "SELECT `first_name`,`age` FROM `Persons` WHERE `age`<=70 OR " \
                          "`first_name`='FirstName' LIMIT 1000"
SELECT_WITH_MULTIPLE_AND_SAME_COL_IN_WHERE = "SELECT `first_name`,`age` FROM `Persons` WHERE `age`>=70 AND " \
                                             "`age`<=100 LIMIT 1000"
SELECT_WITH_GROUP_BY_WITH_HAVING = "SELECT `first_name`,`age` FROM `Persons` GROUP BY `age`,`first_name` HAVING SUM(" \
                                   "`age`)>23 OR MIN(`age`)>11 LIMIT 1000"

SELECT_INNER_JOIN_QUERY = "SELECT `Persons`.`first_name`,`Persons`.`age`," \
                          "`NewTablePerson`.`new_person_first_name` FROM `Persons` JOIN `NewTablePerson` ON " \
                          "`NewTablePerson`.`age`=`Persons`.`age` WHERE `Persons`.`age`>23 AND " \
                          "`NewTablePerson`.`age`<>-1 LIMIT 1000"
SELECT_LEFT_JOIN_QUERY = "SELECT `Persons`.`first_name`,`Persons`.`age`,`NewTablePerson`.`new_person_first_name` FROM " \
                         "`Persons` LEFT JOIN `NewTablePerson` ON `NewTablePerson`.`age`=`Persons`.`age` WHERE " \
                         "`Persons`.`age`>23 AND `NewTablePerson`.`age`<>-1 LIMIT 1000"
SELECT_RIGHT_JOIN_QUERY = "SELECT `Persons`.`first_name`,`Persons`.`age`,`NewTablePerson`.`new_person_first_name` " \
                          "FROM `Persons` RIGHT JOIN `NewTablePerson` ON `NewTablePerson`.`age`=`Persons`.`age` WHERE " \
                          "`Persons`.`age`>23 AND `NewTablePerson`.`age`<>-1 LIMIT 1000"
SELECT_OUTER_JOIN_QUERY = "SELECT `Persons`.`first_name`,`Persons`.`age`,`NewTablePerson`.`new_person_first_name` " \
                          "FROM `Persons` FULL OUTER JOIN `NewTablePerson` ON `NewTablePerson`.`age`=`Persons`.`age` " \
                          "WHERE `Persons`.`age`>23 AND `NewTablePerson`.`age`<>-1 LIMIT 1000"

SELECT_LEFT_OUTER_JOIN_QUERY = "SELECT `Persons`.`first_name`,`Persons`.`age`,`NewTablePerson`.`new_person_first_name` " \
                               "FROM `Persons` LEFT OUTER JOIN `NewTablePerson` ON " \
                               "`NewTablePerson`.`age`=`Persons`.`age` WHERE `Persons`.`age`>23 AND " \
                               "`NewTablePerson`.`age`<>-1 LIMIT 1000"

SELECT_RIGHT_OUTER_JOIN_QUERY = "SELECT `Persons`.`first_name`,`Persons`.`age`," \
                                "`NewTablePerson`.`new_person_first_name` FROM `Persons` RIGHT OUTER JOIN " \
                                "`NewTablePerson` ON `NewTablePerson`.`age`=`Persons`.`age` WHERE `Persons`.`age`>23 " \
                                "AND `NewTablePerson`.`age`<>-1 LIMIT 1000"

SELECT_FULL_OUTER_JOIN_QUERY = "SELECT `Persons`.`first_name`,`Persons`.`age`," \
                               "`NewTablePerson`.`new_person_first_name` FROM `Persons` FULL OUTER JOIN " \
                               "`NewTablePerson` ON `NewTablePerson`.`age`=`Persons`.`age` WHERE `Persons`.`age`>23 " \
                               "AND `NewTablePerson`.`age`<>-1 LIMIT 1000"

SELECT_MULTIPLE_JOIN_QUERY = "SELECT `Persons`.`first_name`,`Persons`.`age`,`NewTablePerson`.`new_person_first_name`," \
                             "`NewTablePersonTwo`.`new_person_2_first_name` FROM `Persons` JOIN `NewTablePerson` ON " \
                             "`NewTablePerson`.`age`=`Persons`.`age` JOIN `NewTablePersonTwo` ON " \
                             "`NewTablePersonTwo`.`age`=`NewTablePerson`.`age` WHERE `Persons`.`age`>23 AND " \
                             "`NewTablePerson`.`age`<>-1 LIMIT 1000"

SIMPLE_DELETE_QUERY = "DELETE FROM `Persons` WHERE `id`=2"

DELETE_WITH_LIMIT_QUERY = "DELETE FROM `Persons` WHERE `id`=2 LIMIT 2"

DISTINCT_QUERY = "SELECT DISTINCT `first_name` FROM `Persons` LIMIT 1000"
DISTINCT_MULTI_QUERY = "SELECT DISTINCT `first_name`,`last_name` FROM `Persons` LIMIT 1000"
DISTINCT_WITH_FILTER_QUERY = "SELECT DISTINCT `first_name` FROM `Persons` WHERE `person_id`=2 LIMIT 1000"
DISTINCT_WITH_GROUP_BY_QUERY = "SELECT DISTINCT `first_name` FROM `Persons` GROUP BY `first_name`,`last_name` LIMIT " \
                               "1000"

COUNT_STAR_QUERY = "SELECT COUNT(*) `my_count` FROM `Persons` LIMIT 1000"
COUNT_SINGLE_QUERY = "SELECT COUNT(`first_name`) `my_count` FROM `Persons` LIMIT 1000"
COUNT_SINGLE_DISTINCT_QUERY = "SELECT COUNT(DISTINCT `first_name`) `my_count` FROM `Persons` LIMIT 1000"
COUNT_MULTIPLE_DISTINCT_QUERY = "SELECT COUNT(DISTINCT `first_name`, `last_name`) `my_count` FROM `Persons` LIMIT 1000"
COUNT_MULTIPLE_DISTINCT_WITH_JOINS_QUERY = "SELECT COUNT(DISTINCT `Persons`.`first_name`, `Persons`.`last_name`) " \
                                           "`my_count` FROM `Persons` JOIN `AnotherPersons` ON " \
                                           "`AnotherPersons`.`first_name`=`Persons`.`first_name` LIMIT 1000"
