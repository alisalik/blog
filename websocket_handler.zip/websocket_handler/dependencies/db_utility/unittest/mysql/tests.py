""" Test cases for MySQL db utility """
import unittest

from db_utility.mysql_query_builder import MySQLQueryBuilder
from db_utility.unittest.mysql import queries
from db_utility import constants

# Initialize query builder
query_builder = MySQLQueryBuilder()
TABLE_NAME = 'Persons'


class TestQueryBuilderMethods(unittest.TestCase):
    """Test cases for supported query builder methods for db utility."""

    def test_insert(self):
        # Act
        generated_query = query_builder.get_insert_query(
            TABLE_NAME,
            {
                "first_name": "FirstName",
                "last_name": "LastName",
                "age": 25,
                "sex": "male",
            }
        )

        # Assert
        self.assertEqual(generated_query, queries.INSERT_QUERY)

    def test_update_without_where_clause(self):
        # Act
        generated_query = query_builder.get_update_query(
            TABLE_NAME,
            {
                "first_name": "FirstNameNew",
                "age": 32,
                "sex": "female",
            }
        )

        # Assert
        self.assertEqual(generated_query, queries.UPDATE_QUERY_WITHOUT_WHERE)

    def test_update_with_where_clause(self):
        # Act
        generated_query = query_builder.get_update_query(
            TABLE_NAME,
            {
                "first_name": "FirstNameNew",
                "age": 32,
                "sex": "female",
            },
            [
                {
                    "key": "first_name",
                    "operator": "==",
                    "value": "FirstName",
                }
            ])

        # Assert
        self.assertEqual(generated_query, queries.UPDATE_QUERY_WITH_WHERE)

    def test_simple_select(self):
        # Act
        generated_query = query_builder.get_select_query(
            TABLE_NAME,
            ['first_name', 'age']
        )
        # Assert
        self.assertEqual(generated_query, queries.SIMPLE_SELECT_QUERY)

    def test_select_with_offset(self):
        # Act
        generated_query = query_builder.get_select_query(
            TABLE_NAME,
            select_columns=['first_name', 'age'],
            filters=[
                {
                    "key": "age",
                    "operator": "<=",
                    "value": 70,
                    "conjunction": "OR"
                }
            ],
            offset=5
        )

        # Assert
        self.assertEqual(generated_query, queries.SELECT_WITH_OFFSET_QUERY)

    def test_select_with_non_integer_offset_throws_error(self):
        self.assertRaises(ValueError,
                          query_builder.get_select_query,
                          TABLE_NAME,
                          select_columns=["first_name"],
                          filters=[
                              {
                                  "key": "age",
                                  "operator": "<=",
                                  "value": 70,
                                  "conjunction": "OR"
                              }
                          ],
                          offset='some_string'
                          )

    def test_simple_select_with_as_operator(self):
        # Act
        generated_query = query_builder.get_select_query(
            TABLE_NAME,
            [{'col': 'first_name', 'as': 'custom_first_name'}, ]
        )
        # Assert
        self.assertEqual(generated_query, queries.SIMPLE_SELECT_WITH_AS_QUERY)

    def test_simple_select_with_limit(self):
        # Act
        generated_query = query_builder.get_select_query(
            TABLE_NAME,
            select_columns=['first_name', 'age'],
            limit=20,
        )

        # Assert
        self.assertEqual(
            generated_query, queries.SIMPLE_SELECT_QUERY_WITH_LIMIT)

    def test_simple_select_order_by(self):
        # Act
        generated_query = query_builder.get_select_query(
            TABLE_NAME,
            select_columns=['first_name', 'age'],
            order_by={
                "first_name": "asc",
            }
        )

        # Assert
        self.assertEqual(generated_query, queries.SIMPLE_SELECT_QUERY_ORDER_BY)

    def test_select_and_in_where_clause(self):
        # Act
        generated_query = query_builder.get_select_query(
            TABLE_NAME,
            select_columns=['first_name', 'age'],
            filters=[
                {
                    "key": "age",
                    "operator": "<=",
                    "value": 70,
                },
                {
                    "key": "first_name",
                    "operator": "==",
                    "value": "FirstName",
                }
            ]
        )

        # Assert
        self.assertEqual(generated_query, queries.SELECT_WITH_AND_IN_WHERE)

    def test_select_or_in_where_clause(self):
        # Act
        generated_query = query_builder.get_select_query(
            TABLE_NAME,
            select_columns=['first_name', 'age'],
            filters=[
                {
                    "key": "age",
                    "operator": "<=",
                    "value": 70,
                    "conjunction": "OR"
                },
                {
                    "key": "first_name",
                    "operator": "==",
                    "value": "FirstName",
                    "conjunction": "OR"
                }
            ]
        )

        # Assert
        self.assertEqual(generated_query, queries.SELECT_WITH_OR_IN_WHERE)

    def test_select_group_by_with_having(self):
        # Act
        generated_query = query_builder.get_select_query(
            TABLE_NAME,
            select_columns=['first_name', 'age'],
            filters=[
                {
                    "key": 'age',
                    "value": 23,
                    "operator": ">",
                    "conjunction": "OR",
                    "function": "Sum",
                },
                {
                    "key": 'age',
                    "value": 11,
                    "operator": ">",
                    "conjunction": "OR",
                    "function": "Min",
                },
            ],
            group_by=["age", 'first_name'],
        )

        # Assert
        self.assertEqual(
            generated_query, queries.SELECT_WITH_GROUP_BY_WITH_HAVING)

    def test_select_group_by_without_having_should_throw_error(self):
        # Assert
        self.assertRaises(ValueError, query_builder.get_select_query, TABLE_NAME,
                          select_columns=['first_name', 'age'],
                          filters=[
                              {
                                  "key": 'age',
                                  "value": 23,
                                  "operator": ">",
                                  "conjunction": "OR",
                                  "function": "Sum",
                              },
                              {
                                  "key": 'age',
                                  "value": 11,
                                  "operator": ">",
                                  "conjunction": "OR",
                                  "function": "Min",
                              },
                          ])

    def test_invalid_operator_should_throw_error(self):
        # Assert
        self.assertRaises(ValueError, query_builder.get_select_query, TABLE_NAME,
                          select_columns=['first_name', 'age'],
                          filters=[
                              {
                                  "key": 'age',
                                  "value": 23,
                                  "operator": "<some_invalid_op>",
                                  "conjunction": "OR",
                              },
                          ])

    def test_invalid_function_should_throw_error(self):
        # Assert
        self.assertRaises(ValueError, query_builder.get_select_query, TABLE_NAME,
                          select_columns=['first_name', 'age'],
                          filters=[
                              {
                                  "key": 'age',
                                  "value": 23,
                                  "operator": ">",
                                  "function": "<some_invalid_function>",
                                  "conjunction": "OR",
                              },
                          ])

    def test_select_inner_join(self):
        generated_query = query_builder.get_select_query(
            TABLE_NAME,
            select_columns=['first_name', 'age'],
            filters=[
                {
                    "key": 'age',
                    "value": 23,
                    "operator": ">",
                },
                {
                    "key": 'age',
                    "value": -1,
                    "operator": "!=",
                    "join_table": "NewTablePerson"
                },
            ],
            joins=[
                {
                    "type": constants.INNER_JOIN,
                    # This table is either in from clause or previous joins in order
                    "with_table": {
                        "name": TABLE_NAME,
                        "on": "age"
                    },
                    "join_table": {
                        "name": "NewTablePerson",
                        "on": "age",
                        "select_columns": ["new_person_first_name", ]
                    }
                }
            ]
        )

        # Assert
        self.assertEqual(generated_query, queries.SELECT_INNER_JOIN_QUERY)

    def test_select_left_join(self):
        generated_query = query_builder.get_select_query(
            TABLE_NAME,
            select_columns=['first_name', 'age'],
            filters=[
                {
                    "key": 'age',
                    "value": 23,
                    "operator": ">",
                },
                {
                    "key": 'age',
                    "value": -1,
                    "operator": "!=",
                    "join_table": "NewTablePerson"
                },
            ],
            joins=[
                {
                    "type": constants.LEFT_JOIN,
                    # This table is either in from clause or previous joins in order
                    "with_table": {
                        "name": TABLE_NAME,
                        "on": "age"
                    },
                    "join_table": {
                        "name": "NewTablePerson",
                        "on": "age",
                        "select_columns": ["new_person_first_name", ]
                    }
                }
            ]
        )

        # Assert
        self.assertEqual(generated_query, queries.SELECT_LEFT_JOIN_QUERY)

    def test_select_right_join(self):
        generated_query = query_builder.get_select_query(
            TABLE_NAME,
            select_columns=['first_name', 'age'],
            filters=[
                {
                    "key": 'age',
                    "value": 23,
                    "operator": ">",
                },
                {
                    "key": 'age',
                    "value": -1,
                    "operator": "!=",
                    "join_table": "NewTablePerson"
                },
            ],
            joins=[
                {
                    "type": constants.RIGHT_JOIN,
                    # This table is either in from clause or previous joins in order
                    "with_table": {
                        "name": TABLE_NAME,
                        "on": "age"
                    },
                    "join_table": {
                        "name": "NewTablePerson",
                        "on": "age",
                        "select_columns": ["new_person_first_name", ]
                    }
                }
            ]
        )

        # Assert
        self.assertEqual(generated_query, queries.SELECT_RIGHT_JOIN_QUERY)

    def test_select_outer_join(self):
        generated_query = query_builder.get_select_query(
            TABLE_NAME,
            select_columns=['first_name', 'age'],
            filters=[
                {
                    "key": 'age',
                    "value": 23,
                    "operator": ">",
                },
                {
                    "key": 'age',
                    "value": -1,
                    "operator": "!=",
                    "join_table": "NewTablePerson"
                },
            ],
            joins=[
                {
                    "type": constants.OUTER_JOIN,
                    # This table is either in from clause or previous joins in order
                    "with_table": {
                        "name": TABLE_NAME,
                        "on": "age"
                    },
                    "join_table": {
                        "name": "NewTablePerson",
                        "on": "age",
                        "select_columns": ["new_person_first_name", ]
                    }
                }
            ]
        )

        # Assert
        self.assertEqual(generated_query, queries.SELECT_OUTER_JOIN_QUERY)

    def test_select_left_outer_join(self):
        generated_query = query_builder.get_select_query(
            TABLE_NAME,
            select_columns=['first_name', 'age'],
            filters=[
                {
                    "key": 'age',
                    "value": 23,
                    "operator": ">",
                },
                {
                    "key": 'age',
                    "value": -1,
                    "operator": "!=",
                    "join_table": "NewTablePerson"
                },
            ],
            joins=[
                {
                    "type": constants.LEFT_OUTER_JOIN,
                    # This table is either in from clause or previous joins in order
                    "with_table": {
                        "name": TABLE_NAME,
                        "on": "age"
                    },
                    "join_table": {
                        "name": "NewTablePerson",
                        "on": "age",
                        "select_columns": ["new_person_first_name", ]
                    }
                }
            ]
        )

        # Assert
        self.assertEqual(generated_query, queries.SELECT_LEFT_OUTER_JOIN_QUERY)

    def test_select_right_outer_join(self):
        generated_query = query_builder.get_select_query(
            TABLE_NAME,
            select_columns=['first_name', 'age'],
            filters=[
                {
                    "key": 'age',
                    "value": 23,
                    "operator": ">",
                },
                {
                    "key": 'age',
                    "value": -1,
                    "operator": "!=",
                    "join_table": "NewTablePerson"
                },
            ],
            joins=[
                {
                    "type": constants.RIGHT_OUTER_JOIN,
                    # This table is either in from clause or previous joins in order
                    "with_table": {
                        "name": TABLE_NAME,
                        "on": "age"
                    },
                    "join_table": {
                        "name": "NewTablePerson",
                        "on": "age",
                        "select_columns": ["new_person_first_name", ]
                    }
                }
            ]
        )

        # Assert
        self.assertEqual(
            generated_query, queries.SELECT_RIGHT_OUTER_JOIN_QUERY)

    def test_select_full_outer_join(self):
        generated_query = query_builder.get_select_query(
            TABLE_NAME,
            select_columns=['first_name', 'age'],
            filters=[
                {
                    "key": 'age',
                    "value": 23,
                    "operator": ">",
                },
                {
                    "key": 'age',
                    "value": -1,
                    "operator": "!=",
                    "join_table": "NewTablePerson"
                },
            ],
            joins=[
                {
                    "type": constants.FULL_OUTER_JOIN,
                    # This table is either in from clause or previous joins in order
                    "with_table": {
                        "name": TABLE_NAME,
                        "on": "age"
                    },
                    "join_table": {
                        "name": "NewTablePerson",
                        "on": "age",
                        "select_columns": ["new_person_first_name", ]
                    }
                }
            ]
        )

        # Assert
        self.assertEqual(generated_query, queries.SELECT_FULL_OUTER_JOIN_QUERY)

    def test_select_with_multiple_joins(self):
        generated_query = query_builder.get_select_query(
            TABLE_NAME,
            select_columns=['first_name', 'age'],
            filters=[
                {
                    "key": 'age',
                    "value": 23,
                    "operator": ">",
                },
                {
                    "key": 'age',
                    "value": -1,
                    "operator": "!=",
                    "join_table": "NewTablePerson"
                },
            ],
            joins=[
                {
                    "type": constants.INNER_JOIN,
                    # This table is either in from clause or previous joins in order
                    "with_table": {
                        "name": TABLE_NAME,
                        "on": "age"
                    },
                    "join_table": {
                        "name": "NewTablePerson",
                        "on": "age",
                        "select_columns": ["new_person_first_name", ]
                    }
                },
                {
                    "type": constants.INNER_JOIN,
                    # This table is either in from clause or previous joins in order
                    "with_table": {
                        "name": "NewTablePerson",
                        "on": "age"
                    },
                    "join_table": {
                        "name": "NewTablePersonTwo",
                        "on": "age",
                        "select_columns": ["new_person_2_first_name", ]
                    }
                }
            ]
        )

        # Assert
        self.assertEqual(generated_query, queries.SELECT_MULTIPLE_JOIN_QUERY)

    def test_simple_delete(self):
        generated_query = query_builder.get_delete_query(
            table_name=TABLE_NAME,
            filters=[query_builder.get_filter_object("id", 2, constants.EQ)],
        )

        # Assert
        self.assertEqual(generated_query, queries.SIMPLE_DELETE_QUERY)

    def test_delete_without_filters_throws_error(self):
        # Assert
        self.assertRaises(ValueError,
                          query_builder.get_delete_query,
                          table_name=TABLE_NAME,
                          filters=[]
                          )

    def test_delete_with_limit(self):
        generated_query = query_builder.get_delete_query(
            table_name=TABLE_NAME,
            filters=[query_builder.get_filter_object("id", 2, constants.EQ)],
            limit=2
        )

        # Assert
        self.assertEqual(generated_query, queries.DELETE_WITH_LIMIT_QUERY)

    def test_distinct(self):
        generated_query = query_builder.get_select_query(
            table_name=TABLE_NAME,
            select_columns=["first_name"],
            is_distinct=True,
        )

        # Assert
        self.assertEqual(generated_query, queries.DISTINCT_QUERY)

    def test_distinct_multi(self):
        generated_query = query_builder.get_select_query(
            table_name=TABLE_NAME,
            select_columns=["first_name", "last_name"],
            is_distinct=True,
        )

        # Assert
        self.assertEqual(generated_query, queries.DISTINCT_MULTI_QUERY)

    def test_distinct_with_filter(self):
        generated_query = query_builder.get_select_query(
            table_name=TABLE_NAME,
            select_columns=["first_name"],
            filters=[query_builder.get_filter_object(
                "person_id", 2, constants.EQ)],
            is_distinct=True,
        )

        # Assert
        self.assertEqual(generated_query, queries.DISTINCT_WITH_FILTER_QUERY)

    def test_distinct_with_group_by(self):
        generated_query = query_builder.get_select_query(
            table_name=TABLE_NAME,
            select_columns=["first_name"],
            group_by=["first_name", "last_name"],
            is_distinct=True,
        )

        # Assert
        self.assertEqual(generated_query, queries.DISTINCT_WITH_GROUP_BY_QUERY)

    def test_distinct_with_having_throws_error(self):
        # Assert
        self.assertRaises(ValueError,
                          query_builder.get_select_query,
                          table_name=TABLE_NAME,
                          select_columns=["first_name"],
                          is_distinct=True,
                          group_by=["first_name", "last_name"],
                          filters=[
                              {
                                  "key": 'person_id',
                                  "value": 23,
                                  "operator": ">",
                                  "function": "Count",
                              },
                          ]
                          )

    def test_count_star(self):
        generated_query = query_builder.get_select_query(
            table_name=TABLE_NAME,
            select_columns=[
                {"col": "*", "function": constants.COUNT, "as": "my_count"}],
        )

        # Assert
        self.assertEqual(generated_query, queries.COUNT_STAR_QUERY)

    def test_count_distinct_star_throws_error(self):
        # Assert
        self.assertRaises(ValueError,
                          query_builder.get_select_query,
                          table_name=TABLE_NAME,
                          select_columns=[{
                              "col": "*", "function": constants.COUNT,
                              "as": "my_count", "is_distinct": True
                          }],
                          )

    def test_count_single(self):
        generated_query = query_builder.get_select_query(
            table_name=TABLE_NAME,
            select_columns=[{"col": "first_name",
                             "function": constants.COUNT, "as": "my_count"}],
        )

        # Assert
        self.assertEqual(generated_query, queries.COUNT_SINGLE_QUERY)

    def test_count_single_distinct(self):
        # Assert
        generated_query = query_builder.get_select_query(
            table_name=TABLE_NAME,
            select_columns=[{
                "col": "first_name", "function": constants.COUNT,
                "as": "my_count",
                "is_distinct": True,
            }],
        )

        # Assert
        self.assertEqual(generated_query, queries.COUNT_SINGLE_DISTINCT_QUERY)

    def test_count_multi_throws_error(self):
        # Assert
        self.assertRaises(ValueError,
                          query_builder.get_select_query,
                          table_name=TABLE_NAME,
                          select_columns=[
                              {
                                  "col": ["first_name", "last_name"],
                                  "function": constants.COUNT,
                                  "as": "my_count"
                              }
                          ]
                          )

    def test_count_distinct_multi(self):
        # Assert
        generated_query = query_builder.get_select_query(
            table_name=TABLE_NAME,
            select_columns=[{
                "col": ["first_name", "last_name"], "function": constants.COUNT,
                "as": "my_count",
                "is_distinct": True,
            }],
        )

        # Assert
        self.assertEqual(
            generated_query, queries.COUNT_MULTIPLE_DISTINCT_QUERY)

    def test_count_distinct_multi_with_joins(self):
        # Assert
        generated_query = query_builder.get_select_query(
            table_name=TABLE_NAME,
            select_columns=[{
                "col": ["first_name", "last_name"], "function": constants.COUNT,
                "as": "my_count",
                "is_distinct": True,
            }],
            joins=[
                {
                    "type": constants.INNER_JOIN,
                    "with_table": {
                        "name": TABLE_NAME,
                        "on": "first_name"
                    },
                    "join_table": {
                        "name": "AnotherPersons",
                        "on": "first_name",
                    }
                }
            ]
        )

        # Assert
        self.assertEqual(
            generated_query, queries.COUNT_MULTIPLE_DISTINCT_WITH_JOINS_QUERY)


if __name__ == '__main__':
    unittest.main()
