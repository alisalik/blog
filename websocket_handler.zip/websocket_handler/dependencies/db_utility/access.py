"""Module implements access helper for db utility. """
import json
from collections import defaultdict
from datetime import datetime

from db_utility import db_logger
from db_utility.constants import (
    DB_ACCESS_DETAILS_FILE, SELECT, UPDATE, INSERT, DELETE, DB_INDEX_DETAILS_FILE,
    MAX_INDEX_CONFIG_UPDATE_TIME, UPDATE_TIME_FORMAT,
)
from db_utility.exceptions import AccessError


class ConsumerModuleAccess:
    """ Utility to bundle consumer module access for different db operations."""

    def __init__(self, operation, check_index=True):
        self.operation = operation
        self.check_index = check_index

    def __call__(self, function):
        parent = self

        def _validate(_, *args, **kwargs):
            if parent._validate_consumer_access(_, *args, **kwargs) and \
                    parent._validate_index(_, *args, **kwargs):
                return function(_, *args, **kwargs)
        return _validate

    def _validate_consumer_access(self, _, *args, **kwargs):
        """Validates if consumer has proper access."""
        table_name = kwargs.get('table_name') or args[0]
        if self.operation in self._get_access_config().get(table_name, []):
            return True
        else:
            raise AccessError(
                f'Rule is not allowed to perform: {self.operation} on table: {table_name}')

    def _validate_index(self, _, *args, **kwargs):
        """Validates if proper indexes are configured on where clause filters."""
        if not self.check_index:
            # In case of a druid db operation
            return True
        table_name = kwargs.get('table_name') or args[0]
        if self.operation in [SELECT, UPDATE, DELETE]:
            if self.operation == DELETE:
                if kwargs.get('filters') or len(args) > 1:
                    filters = kwargs.get('filters') or args[1]
                else:
                    # Should never come here
                    raise AccessError(
                        "Filters are required in delete operation for index verification!")
            else:
                if kwargs.get('filters') or len(args) > 2:
                    filters = kwargs.get('filters') or args[2]
                else:
                    # Update or select was requested without filters
                    return True
            table_columns_map = defaultdict(set)
            for _filter in filters:
                if _filter.get("join_table"):
                    table_columns_map[_filter["join_table"]].add(
                        _filter.get("key"))
                else:
                    table_columns_map[table_name].add(_filter.get("key"))
            index_config = self._get_index_config(_)
            for t_name, columns in table_columns_map.items():
                for col in columns:
                    if col not in index_config.get(t_name, set()):
                        self._raise_index_access_error(t_name, col)
            else:
                return True
        elif self.operation == INSERT:
            return True
        raise AccessError(f'Unexpected operation requested: {self.operation}')

    def _raise_index_access_error(self, table_name, col):
        """Raise index access error."""
        raise AccessError(f'Table `{table_name}` does not have '
                          f'index configured on column `{col}` '
                          f'to perform `{self.operation}` operation')

    @staticmethod
    def _get_access_config():
        """Read db access configuration for consumer module from local file"""
        try:
            with open(DB_ACCESS_DETAILS_FILE) as fp:
                return json.load(fp).get("access_map")
        except Exception as err:
            # File not found or json decode error
            db_logger.w(
                f"No access restrictions available for the consumer module!:{err}")
            return {}

    @staticmethod
    def _get_index_config(db_instance):
        """Read db access configuration for consumer module from local file"""
        try:
            with open(DB_INDEX_DETAILS_FILE) as fp:
                config = json.load(fp)
                if (datetime.now() - datetime.strptime(config.get("updated_time"), UPDATE_TIME_FORMAT)).\
                        seconds // 60 >= MAX_INDEX_CONFIG_UPDATE_TIME:
                    # Re-fetch indexes
                    db_instance.update_index_config()
                    return ConsumerModuleAccess._get_index_config(db_instance)
                return config.get("index_map")
        except Exception as err:
            # File not found or json decode error
            db_logger.w(f"No indexes available for the consumer module!:{err}")
            return {}
