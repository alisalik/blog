"""Module implements Druid database utility."""

from db_utility.constants import (ALLOWED_OPERATORS_DRUID, MAX_RECORDS, ISIN, BETWEEN,
                                  COMPARISON_OPERATORS, NOTIN, LIKE, LT, GT, LTE, GTE, EQ,
                                  NEQ, SUM, MIN, MAX, AVG, COUNT, ALLOWED_FUNCTIONS, ALL,
                                  OR, AND, INTERVAL, ASC, DESC, DRUID_ASC, DRUID_DESC, DRUID_TIME_KEY)

from typing import final
from pydruid.utils.filters import Filter, Bound
from pydruid.utils.having import Having
from pydruid.query import QueryBuilder

import pydruid.utils.aggregators as druid_aggregators


class DruidQueryBuilder:
    """Utility to bundle Druid query builder manipulation."""

    @final
    def get_select_query(self, table_name,
                         select_columns=[],
                         filters=[],
                         group_by=[],
                         limit=MAX_RECORDS,
                         order_by={},
                         is_external=True):
        """ Gets select query."""
        self._validate_table_name(table_name)
        if '*' in select_columns:
            raise ValueError('Please remove `*` from select column list!')
        if group_by:
            if select_columns:
                raise ValueError("Please remove select columns as they "
                                 "are not supported with group by query.")
            return self._build_group_by_query(table_name, filters,
                                              group_by, limit, order_by, is_external)
        if not select_columns:
            raise ValueError(
                f"Please provide columns to select: {select_columns}")
        return self._build_scan_query(table_name, select_columns, filters,
                                      limit, order_by, is_external)

    @final
    def get_filter_object(self, key=None, value='', operator='', conjunction=AND, function=None):
        """ Gets filter object."""
        filter_object = {
            "key": key,
            "value": value,
            "operator": operator,
            "conjunction": conjunction,
        }
        if function:
            filter_object["function"] = function
        return filter_object

    @staticmethod
    def _validate_table_name(table_name):
        """ Validates if table name is proper no empty string."""
        if type(table_name) != str or not table_name:
            raise ValueError(
                f"Please provide valid value for table name: {table_name}")

    @classmethod
    def _build_group_by_query(cls, table_name,
                              filters=[],
                              group_by=[],
                              limit=MAX_RECORDS,
                              order_by={},
                              is_external=True):
        """Builds a druid group by query."""
        query = {
            "datasource": table_name,
            "dimensions": group_by,
            "granularity": ALL,
            "limit_spec": {
                "type": "default",
                "limit": min(limit, MAX_RECORDS),
            }
        }

        # Update order by columns
        cls._get_order_by(query, group_by, order_by)

        # Separate clause filters
        where_filters, having_filters, intervals = cls._separate_clause_filters(
            filters)

        if not intervals:
            # Interval is required
            raise ValueError("Intervals are required in filters!")
        # Configure intervals
        query["intervals"] = intervals.get("value")
        # Configure where conditions
        cls._build_where_clause(query, where_filters)

        # Configure group by
        if group_by:
            # Set having
            cls._build_having_clause(query, having_filters)
        elif having_filters:
            raise ValueError(
                "Having clause requested without group by columns!")

        # To verify final query at developer's end
        if is_external:
            return QueryBuilder().groupby(query).query_dict
        return query

    @classmethod
    def _build_scan_query(cls, table_name,
                          select_columns,
                          filters=[],
                          limit=MAX_RECORDS,
                          order_by={},
                          is_external=True):
        """Builds a druid scan query."""
        query = {
            "datasource": table_name,
            "columns": select_columns,
            "limit": min(limit, MAX_RECORDS),
        }

        # Separate clause filters
        where_filters, having_filters, intervals = cls._separate_clause_filters(
            filters)
        # Raise error if having filters are requested without group by columns
        if having_filters:
            raise ValueError(
                "Please provide either group by columns or remove having filters!")

        if not intervals:
            # Intervals are required
            raise ValueError("Intervals are required in filters!")

        # Configure intervals
        query["intervals"] = intervals.get("value")

        # Configure where conditions
        cls._build_where_clause(query, where_filters)

        if order_by:
            if len(order_by.keys()) > 1 or DRUID_TIME_KEY not in order_by.keys():
                raise ValueError(f"Only {DRUID_TIME_KEY} key is allowed in "
                                 f"select query without group by for ordering!")
            # Only order by __time is supported
            if ASC == order_by.get(DRUID_TIME_KEY, '').upper():
                query["order"] = DRUID_ASC
                query["columns"].append(DRUID_TIME_KEY)
            elif DESC == order_by.get(DRUID_TIME_KEY, '').upper():
                query["columns"].append(DRUID_TIME_KEY)
                query["order"] = DRUID_DESC

        # To verify final query at developer's end
        if is_external:
            return QueryBuilder().scan(query).query_dict
        return query

    @classmethod
    def _get_order_by(cls, query, group_by, order_by):
        """Gets order by specs for group by query."""
        if not order_by:
            return
        specs = []
        for col, order in order_by.items():
            if col not in group_by:
                raise ValueError(f"Please include order_by column `{col}` "
                                 f"in group_by columns to apply ordering.")
            if ASC == order.upper():
                specs.append({
                    "dimension": col,
                    "direction": DRUID_ASC,
                })
            elif DESC == order.upper():
                specs.append({
                    "dimension": col,
                    "direction": DRUID_DESC,
                })
        query["limit_spec"].update({"columns": specs})

    @staticmethod
    def _separate_clause_filters(filters):
        """ Separates where and having clause filters."""
        where_filters = []
        having_filters = []
        intervals = {}
        for filter_ in filters:
            if filter_.get('operator').lower() == INTERVAL:
                intervals = filter_
            elif filter_.get('function'):
                having_filters.append(filter_)
            else:
                where_filters.append(filter_)
        return where_filters, having_filters, intervals

    @classmethod
    def _build_having_clause(cls, query, filters):
        """ Build conditions for having clause"""
        if not filters:
            return

        query["aggregations"] = {}
        query["having"] = {"havingSpecs": []}
        is_and = is_or = False
        for filter_ in filters:
            if cls._is_allowed_fn_op(filter_):
                aggregation, having_filter = cls._get_aggregate_fn_and_having_filter(
                    filter_)
                query["aggregations"].update(aggregation)
                query["having"]["havingSpecs"].append(having_filter)
                if filter_.get('conjunction', '').upper() == OR:
                    query["having"]["type"] = OR.lower()
                    is_or = True
                else:
                    query["having"]["type"] = AND.lower()
                    is_and = True
            if is_or and is_and:
                raise ValueError(
                    "Please provide either 'AND' or 'OR' conjunction!")
        if len(query["having"]["havingSpecs"]) == 1:
            query.update(
                {"having": Having(**query["having"]["havingSpecs"][0])})
        else:
            query.update({"having": Having(**query["having"])})

    @classmethod
    def _build_where_clause(cls, query, filters):
        """ Build conditions for where clause"""
        if not filters:
            return
        is_and = is_or = False
        query["filter"] = {}
        query["filter"]["fields"] = []

        for filter_ in filters:
            if cls._is_allowed_op(filter_):
                query["filter"]["fields"].append(
                    cls._get_where_filter(filter_))
                if filter_.get('conjunction', '').upper() == OR:
                    query["filter"]["type"] = OR.lower()
                    is_or = True
                else:
                    query["filter"]["type"] = AND.lower()
                    is_and = True
            if is_or and is_and:
                raise ValueError(
                    "Please provide either 'AND' or 'OR' conjunction!")
        if len(query["filter"]["fields"]) == 1:
            query["filter"] = query["filter"]["fields"][0]
        else:
            query["filter"] = Filter(**query["filter"])

    @classmethod
    def _get_aggregate_fn_and_having_filter(cls, filter_):
        """Gets aggregate function."""
        fn = filter_.get('function').capitalize()
        col = filter_.get('key')
        aggregated_field_name = f"{fn}_{col}"
        aggregator = {}
        filter_["aggregated_field_name"] = aggregated_field_name
        having_filter = cls._get_having_filter(filter_)
        if fn == SUM:
            aggregator = {
                aggregated_field_name: druid_aggregators.doublesum(col)}
        elif fn == MIN:
            aggregator = {
                aggregated_field_name: druid_aggregators.doublemin(col)}
        elif fn == MAX:
            aggregator = {
                aggregated_field_name: druid_aggregators.doublemax(col)}
        elif fn == AVG:
            aggregator = {
                aggregated_field_name: {
                    "type": "doubleMean",
                    "fieldName": col
                }
            }
        elif fn == COUNT:
            aggregator = {aggregated_field_name: druid_aggregators.count(col)}
        return aggregator, having_filter

    @classmethod
    def _get_having_filter(cls, filter_):
        """Gets filter for having clause."""
        having_filter = {
            "aggregation": filter_.get("aggregated_field_name"),
            "value": filter_.get("value")
        }
        op = filter_.get('operator').lower()
        if op == NEQ:
            having_filter = {
                "type": "not",
                "havingSpec": {
                    "type": "equalTo",
                    "aggregation": filter_.get("aggregated_field_name"),
                    "value": filter_.get("value")
                }
            }
        elif op == EQ:
            having_filter = {**having_filter, "type": "equalTo"}
        elif op == LT:
            having_filter = {**having_filter, "type": "lessThan"}
        elif op == GT:
            having_filter = {**having_filter, "type": "greaterThan"}
        elif op == GTE:
            having_filter = {
                "type": "or",
                "havingSpecs": [
                    {
                        "type": "greaterThan",
                        "aggregation": filter_.get("aggregated_field_name"),
                        "value": filter_.get("value")
                    },
                    {
                        "type": "equalTo",
                        "aggregation": filter_.get("aggregated_field_name"),
                        "value": filter_.get("value")
                    }
                ]
            }
        elif op == LTE:
            having_filter = {
                "type": "or",
                "havingSpecs": [
                    {
                        "type": "lessThan",
                        "aggregation": filter_.get("aggregated_field_name"),
                        "value": filter_.get("value")
                    },
                    {
                        "type": "equalTo",
                        "aggregation": filter_.get("aggregated_field_name"),
                        "value": filter_.get("value")
                    }
                ]
            }
        return having_filter

    @classmethod
    def _get_where_filter(cls, filter_):
        """Gets filter for where clause."""
        op = filter_.get('operator').lower()
        if op == NEQ:
            return cls._create_filter({"type": "not", "field": cls._create_filter({
                "type": "selector",
                "dimension": filter_.get('key'),
                "value": filter_.get('value')
            })})
        elif op == EQ:
            return cls._create_filter({
                "type": "selector",
                "dimension": filter_.get('key'),
                "value": filter_.get('value')
            })
        elif op == LT:
            return cls._create_bound_filter({
                # "type": "bound",
                "dimension": filter_.get('key'),
                "upper": filter_.get('value'),
                "upperStrict": True,
                "ordering": "numeric"
            })
        elif op == GT:
            return cls._create_bound_filter({
                # "type": "bound",
                "dimension": filter_.get('key'),
                "lower": filter_.get('value'),
                "lowerStrict": True,
                "ordering": "numeric"
            })
        elif op == GTE:
            return cls._create_bound_filter({
                # "type": "bound",
                "dimension": filter_.get('key'),
                "lower": filter_.get('value'),
                "ordering": "numeric"
            })
        elif op == LTE:
            return cls._create_bound_filter({
                # "type": "bound",
                "dimension": filter_.get('key'),
                "upper": filter_.get('value'),
                "ordering": "numeric"
            })
        elif op == BETWEEN:
            lower, upper = filter_.get("value", (0, 0))
            return cls._create_bound_filter({
                # "type": "bound",
                "dimension": filter_.get('key'),
                "lower": lower,
                "upper": upper,
                "ordering": "numeric"
            })
        elif op == ISIN:
            return cls._create_filter({
                "type": "in",
                "dimension": filter_.get('key'),
                "values": filter_.get("value")
            })
        elif op == NOTIN:
            return cls._create_filter({"type": "not", "field": cls._create_filter({
                "type": "in",
                "dimension": filter_.get('key'),
                "values": filter_.get("value")
            })})
        elif op == LIKE:
            return cls._create_filter({
                "type": "like",
                "dimension": filter_.get('key'),
                "pattern": filter_.get("value")
            })

    @classmethod
    def _create_bound_filter(cls, filter_):
        """Create druid's bound filter."""
        return Bound(**filter_)

    @classmethod
    def _create_filter(cls, filter_):
        """Create druid's filter."""
        return Filter(**filter_)

    @staticmethod
    def _is_allowed_fn_op(filter_):
        """Checks whether operator and function for having clause is allowed or not."""
        if filter_.get('operator') in COMPARISON_OPERATORS and filter_.get('function') in ALLOWED_FUNCTIONS:
            return True
        else:
            raise ValueError(f"Requested operator '{filter_.get('operator')}' or "
                             f"function {filter_.get('function')} is not allowed!")

    @staticmethod
    def _is_allowed_op(filter_):
        """Checks whether a operator is allowed or not."""
        if filter_.get('operator') in ALLOWED_OPERATORS_DRUID:
            return True
        else:
            raise ValueError(
                f"Requested operator '{filter_.get('operator')}' is not allowed!")
