"""Module implements MySQL database utility."""
import threading
from typing import final


from db_utility.constants import (
    ACCESS_DETAIL_DB_NAME, ACCESS_DETAIL_TABLE_NAME,
    DB_ACCESS_DETAILS_FILE, MAX_RECORDS, INSERT, UPDATE,
    SELECT, EQ, DELETE, DB_INDEX_DETAILS_FILE,
)
from db_utility.lock import enforce_generic_lock
from db_utility.mysql_base import _NebulaMySQLBase
from db_utility.singleton import Singleton


class NebulaMySQL(_NebulaMySQLBase, metaclass=Singleton):
    """Utility to bundle MySQL database manipulation.

    Attributes:
        consumer_logger: Logger of consumer utility to map logs
        db_config: Config for database
            host: Host to connect
            user: User for database
            password: Password for the user
            database: Database name
            port: Port on which MySQL server is running
            ssl: SSL information
              ca: ssl certificate location
              key: client key
              cert: client certificate
    """
    generic_lock = threading.RLock()

    def __init__(self, *args, **kwargs):
        super(NebulaMySQL, self).__init__(*args, **kwargs)

    @final
    @enforce_generic_lock
    def insert(self, table_name, insert_param):
        """Inserts data into database."""
        return super(NebulaMySQL, self).insert(table_name, insert_param)

    @final
    @enforce_generic_lock
    def insert_many(self, table_name, insert_param_list):
        """Inserts multiple data into database."""
        return super(NebulaMySQL, self).insert_many(table_name, insert_param_list)

    @final
    @enforce_generic_lock
    def delete(self, table_name, filters, limit=None):
        """Deletes data from table based on required filters."""
        return super(NebulaMySQL, self).delete(table_name, filters, limit)

    @final
    @enforce_generic_lock
    def update(self, table_name, update_param, filters=[]):
        """Updates data into database."""
        return super(NebulaMySQL, self).update(table_name, update_param, filters)

    @final
    @enforce_generic_lock
    def fetchall(self, table_name,
                 select_columns=[],
                 filters=[],
                 group_by=[],
                 limit=MAX_RECORDS,
                 order_by={},
                 joins=[],
                 is_distinct=False,
                 offset=None):
        """Fetches multiple data from database."""
        return super(NebulaMySQL, self).fetchall(
            table_name,
            select_columns,
            filters,
            group_by,
            limit,
            order_by,
            joins,
            is_distinct,
            offset
        )

    @final
    @enforce_generic_lock
    def fetchone(self, table_name,
                 select_columns=[],
                 filters=[],
                 group_by=[],
                 order_by={},
                 joins=[],
                 is_distinct=False):
        """Fetches single data from database."""
        return super(NebulaMySQL, self).fetchone(
            table_name,
            select_columns,
            filters,
            group_by,
            order_by,
            joins,
            is_distinct
        )
