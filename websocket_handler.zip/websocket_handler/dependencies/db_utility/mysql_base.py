"""Module implements MySQL database base class utility."""
import json
import os
import time
from collections import defaultdict
from datetime import datetime

import pymysql
import pymysql.cursors

from db_utility import db_logger
from db_utility.access import ConsumerModuleAccess
from db_utility.constants import (
    ACCESS_DETAIL_DB_NAME, ACCESS_DETAIL_TABLE_NAME,
    DB_ACCESS_DETAILS_FILE, MAX_RECORDS, INSERT, UPDATE,
    SELECT, EQ, DELETE, DB_INDEX_DETAILS_FILE,
)
from db_utility.exceptions import NebulaMySQLError
from db_utility.mysql_query_builder import MySQLQueryBuilder

from db_utility.constants import MAX_INDEX_CONFIG_UPDATE_TIME, UPDATE_TIME_FORMAT


class _NebulaMySQLBase(MySQLQueryBuilder):
    """Utility to bundle MySQL database manipulation.

    Attributes:
        consumer_logger: Logger of consumer utility to map logs
        db_config: Config for database
            host: Host to connect
            user: User for database
            password: Password for the user
            database: Database name
            port: Port on which MySQL server is running
            ssl: SSL information
              ca: ssl certificate location
              key: client key
              cert: client certificate
    """

    def __init__(self, db_config, consumer_logger=None):
        self.__db_config = {
            "host": db_config.get('host'),
            "user": db_config.get('user'),
            "password": db_config.get('password'),
            "database": db_config.get('database'),
        }
        port = db_config.get('port')
        if port:
            self.__db_config["port"] = port
        ssl = db_config.get('ssl')
        if ssl:
            self.__db_config["ssl"] = {
                'ssl':
                    {
                        'ca': ssl.get('ssl_certificate'),
                        'key': ssl.get('client_key'),
                        'cert': ssl.get('client_certificate')
                    }
            }

        _empty_attrs = [k for (k, v) in self.__db_config.items() if not v]
        if _empty_attrs:
            raise AttributeError(
                f"Required attributes: {', '.join(_empty_attrs)}")

        # Connection and cursor objects
        self.__connection = None
        self.__cursor = None

        # Logger instance of consumer module to map logs
        self.__consumer_logger = consumer_logger

        # Set rule name here to track log messages in aggregated log server
        if self.__consumer_logger:
            db_logger.use_different_rule_name(
                f'{self.__consumer_logger.get_rule_name()}_db_logs')

        # Initialize a db connection
        self._connect()

    @ConsumerModuleAccess(INSERT)
    def insert(self, table_name, insert_param):
        """Inserts data into database."""
        affected_rows = self._execute(
            self.get_insert_query(table_name, insert_param))
        self._commit()
        return {"affected_rows": affected_rows, "insert_id": self._get_last_insert_id()}

    @ConsumerModuleAccess(INSERT)
    def insert_many(self, table_name, insert_param_list):
        """Inserts multiple data into database."""
        affected_rows = 0
        insert_ids = []
        for insert_param in insert_param_list:
            row = self._execute(
                self.get_insert_query(table_name, insert_param))
            if row:
                affected_rows += row
                self._commit()
                insert_ids.append(self._get_last_insert_id())
        return {"affected_rows": affected_rows, "insert_ids": insert_ids}

    @ConsumerModuleAccess(DELETE)
    def delete(self, table_name, filters, limit=None):
        """Deletes data from table based on required filters."""
        affected_rows = self._execute(
            self.get_delete_query(table_name, filters, limit))
        self._commit()
        return affected_rows

    @ConsumerModuleAccess(UPDATE)
    def update(self, table_name, update_param, filters=[]):
        """Updates data into database."""
        affected_rows = self._execute(
            self.get_update_query(table_name, update_param, filters))
        self._commit()
        return affected_rows

    @ConsumerModuleAccess(SELECT)
    def fetchall(self, table_name,
                 select_columns=[],
                 filters=[],
                 group_by=[],
                 limit=MAX_RECORDS,
                 order_by={},
                 joins=[],
                 is_distinct=False,
                 offset=None):
        """Fetches multiple data from database."""
        self._execute(self.get_select_query(table_name,
                                            select_columns,
                                            filters,
                                            group_by,
                                            limit,
                                            order_by,
                                            joins,
                                            is_distinct,
                                            offset))
        results = self.__cursor.fetchall()
        self._commit()
        return results

    @ConsumerModuleAccess(SELECT)
    def fetchone(self, table_name,
                 select_columns=[],
                 filters=[],
                 group_by=[],
                 order_by={},
                 joins=[],
                 is_distinct=False):
        """Fetches single data from database."""
        self._execute(self.get_select_query(table_name,
                                            select_columns,
                                            filters,
                                            group_by,
                                            1,
                                            order_by,
                                            joins,
                                            is_distinct))
        result = self.__cursor.fetchone()
        self._commit()
        return result

    def close(self):
        """Closes database connection."""
        if self.__cursor:
            self.__cursor.close()
        if self.__connection:
            self.__connection.close()

    @staticmethod
    def _skip_update(filename):
        """Whether to update index or not."""
        is_skip = False
        try:
            with open(filename) as fp:
                config = json.load(fp)
                if config.get("updated_time"):
                    if (datetime.now() - datetime.strptime(config.get("updated_time"), UPDATE_TIME_FORMAT)). \
                            seconds // 60 < MAX_INDEX_CONFIG_UPDATE_TIME:
                        # No need to update indexes
                        is_skip = True
        except Exception as _:
            pass
        return is_skip

    def update_index_config(self):
        """Fetch and store indexes of all the allowed tables
        to user in local config file."""
        if self._skip_update(DB_INDEX_DETAILS_FILE):
            # No need to update indexes as they were updated within an hour
            db_logger.d(
                "Skipping index update as they were updated within an hour!")
            return
        db_logger.i("Fetching index details...")
        index_map = defaultdict(list)
        with pymysql.connect(**{**self.__db_config, "database": "INFORMATION_SCHEMA"}) as connection:
            cursor = connection.cursor()
            cursor.execute(self.get_select_query(
                table_name="STATISTICS",
                select_columns=[
                    {"col": "TABLE_NAME", "as": "table_name"},
                    {"col": "COLUMN_NAME", "as": "col"}
                ],
                filters=[
                    self.get_filter_object(
                        "table_schema", self.__db_config.get("database"), EQ),
                ]
            ))
            for result in cursor.fetchall():
                index_map[result[0]].append(result[1])
            # Create file if it does not exist
            os.makedirs(os.path.dirname(DB_INDEX_DETAILS_FILE), exist_ok=True)
            # Store runtime config in local file
            with open(DB_INDEX_DETAILS_FILE, 'w') as fp:
                json.dump({
                    "index_map": index_map,
                    "updated_time": datetime.now().strftime(UPDATE_TIME_FORMAT)},
                    fp,
                    indent=2
                )

    def _get_last_insert_id(self):
        """Gets last insert id on the cursor."""
        return self.__cursor.lastrowid

    def _execute(self, query, retries=0):
        """Executes a sql query."""
        try:
            if retries == 0:
                db_logger.set_extra(self.__consumer_logger.get_extra())
                db_logger.i(query)
            return self.__cursor.execute(query)
        except (pymysql.OperationalError, pymysql.InternalError) as err:
            if retries <= 3:
                retries += 1
                self._connect(True)
                return self._execute(query, retries)
            else:
                db_logger.e(f"OperationalError or InternalError in query:{query}\n {err}, "
                            f"after {retries - 1} retries!")
                raise NebulaMySQLError(f"OperationalError or InternalError in query:{query}\n {err}, "
                                       f"after {retries - 1} retries!")
        except pymysql.MySQLError as err:
            db_logger.e(f"MySQL Error in query:{query}\n {err}")
            raise NebulaMySQLError(f"MySQL Error in query:{query}\n {err}")
        except pymysql.ProgrammingError as err:
            db_logger.e(f"Syntax Error in query:{query}\n {err}")
            raise NebulaMySQLError(f"Syntax Error in query:{query}\n {err}")
        except Exception as err:
            db_logger.e(
                f"Unknown error occurred while executing query:{query}\n {err}.")

    def _commit(self):
        """Commits transaction to db"""
        self.__connection.commit()

    def _get_consumer_access_details(self):
        """ Get access details of consumer module like rule."""
        if self._skip_update(DB_ACCESS_DETAILS_FILE):
            # No need to update access details as it was updated within an hour
            db_logger.d(
                "Skipping access details update as they were updated within an hour!")
            return
        try:
            db_logger.i("Fetching consumer access details details...")
            with pymysql.connect(
                    **{**self.__db_config, "database": ACCESS_DETAIL_DB_NAME},
                    cursorclass=pymysql.cursors.DictCursor
            ) as connection:
                cursor = connection.cursor()
                cursor.execute(self.get_select_query(
                    ACCESS_DETAIL_TABLE_NAME,
                    select_columns=['table_name', 'allow_insert',
                                    'allow_update', 'allow_select', 'is_druid_table'],
                    filters=[
                        self.get_filter_object(
                            'rule_name', self.__consumer_logger.get_rule_name(), EQ),
                        self.get_filter_object(
                            'database_name', self.__db_config.get('database'), EQ)
                    ]))
                access_rows = cursor.fetchall()
                access_details = {}
                for row in access_rows:
                    operations = []
                    if row["allow_insert"]:
                        operations.append(INSERT)
                    if row["allow_update"]:
                        operations.append(UPDATE)
                    if row["allow_select"] or row["is_druid_table"]:
                        operations.append(SELECT)
                    access_details[row["table_name"]] = operations
                # Create file if it does not exist
                os.makedirs(os.path.dirname(
                    DB_ACCESS_DETAILS_FILE), exist_ok=True)
                # Store runtime config in local file
                with open(DB_ACCESS_DETAILS_FILE, 'w') as fp:
                    json.dump({
                        "access_map": access_details,
                        "updated_time": datetime.now().strftime(UPDATE_TIME_FORMAT)},
                        fp,
                        indent=2
                    )
        except Exception as err:
            db_logger.w(f"Access db details are not correct: {err}")
        finally:
            # Reset to requested db
            self.__connection.select_db(self.__db_config.get('database'))

    def _connect(self, force=False):
        """Connects to a database."""
        if force or not self.__cursor:
            try:
                db_logger.i("Creating connection to database...")
                # Close first, if it is a retry if it is open
                self.close()
                self.__connection = pymysql.connect(**self.__db_config,
                                                    cursorclass=pymysql.cursors.DictCursor, autocommit=True)
                self.__cursor = self.__connection.cursor()
                # Setup only on initialisation
                if not force:
                    db_logger.i("Updating index and access configs...")
                    # Fetch and save access details to local json file
                    self._get_consumer_access_details()
                    # Fetch and save index details to local json file
                    self.update_index_config()
            except Exception as err:
                db_logger.e(
                    f'Error while connecting to database:\n{err}\nTrying to reconnect...')
                time.sleep(1)
                self._connect(True)

    def __del__(self):
        """Make sure to close connection when instance of this class is being destroyed."""
        self.close()
