"""Module implements MySQL query builder for database utility."""

from db_utility.constants import (
    ALLOWED_OPERATORS, MAX_RECORDS, ISIN, BETWEEN,
    COMPARISON_OPERATORS, NOTIN, LIKE, LT, GT, LTE, GTE, EQ,
    NEQ, SUM, MIN, MAX, AVG, COUNT, ALLOWED_FUNCTIONS,
    OR, AND, STAR, COUNT_MULTI_HACK)
from pypika import Table, MySQLQuery, Order, Criterion, functions as pypika_fn
from typing import final


class MySQLQueryBuilder:
    """Utility to bundle MySQL query builder manipulation."""

    @final
    def get_insert_query(self, table_name, insert_param):
        """ Gets insert query."""
        if type(insert_param) == list:
            raise ValueError(
                "Please send insert columns objects one by one to get raw SQL.")

        self._validate_table_name(table_name)
        if not insert_param:
            raise ValueError("Please provide columns and values to insert.")
        return self._build_insert_query(table_name, insert_param)

    @final
    def get_update_query(self, table_name, update_param, filters=[]):
        """ Gets update query."""
        self._validate_table_name(table_name)
        if not update_param:
            raise ValueError("Please provide columns and values to update.")
        return self._build_update_query(table_name, update_param, filters)

    @final
    def get_delete_query(self, table_name, filters, limit=None):
        """Gets delete query."""
        self._validate_table_name(table_name)
        return self._build_delete_query(table_name, filters, limit)

    @final
    def get_select_query(self, table_name,
                         select_columns=[],
                         filters=[],
                         group_by=[],
                         limit=MAX_RECORDS,
                         order_by={},
                         joins=[],
                         is_distinct=False,
                         offset=None):
        """ Gets select query."""
        self._validate_table_name(table_name)
        if STAR in select_columns:
            raise ValueError('Please remove `*` from select column list!')
        return self._build_select_query(table_name, select_columns, filters,
                                        group_by, limit, order_by, joins, is_distinct, offset)

    @final
    def get_filter_object(self, key, value, operator, conjunction=AND, function=None, join_table=None):
        """ Gets filter object."""
        filter_object = {
            "key": key,
            "value": value,
            "operator": operator,
            "conjunction": conjunction,
        }
        if function:
            filter_object["function"] = function
        if join_table:
            filter_object["join_table"] = join_table
        return filter_object

    @staticmethod
    def _validate_table_name(table_name):
        """ Validates if table name is proper no empty string."""
        if type(table_name) != str or not table_name:
            raise ValueError("Please provide valid value for table name.")

    @classmethod
    def _build_delete_query(cls, table_name, filters, limit=None):
        """Builds a raw delete sql query."""
        table = Table(table_name)
        query = MySQLQuery.from_(table).delete()
        # Separate clause filters
        where_filters, having_filters = cls._separate_clause_filters(filters)
        if not where_filters:
            raise ValueError("Deletion without filters is not allowed.")
        if having_filters:
            raise ValueError("Having filters are not allowed while deletion.")
        query = cls._build_where_clause(table, query, where_filters)

        if limit:
            # Set limit to number of records to be deleted from query
            query = query.limit(min(limit, MAX_RECORDS))
        return query.get_sql()

    @classmethod
    def _build_select_query(cls, table_name,
                            select_columns,
                            filters=[],
                            group_by=[],
                            limit=MAX_RECORDS,
                            order_by={},
                            joins=[],
                            is_distinct=False,
                            offset=None):
        """Builds a raw select sql query."""
        table = Table(table_name)
        _select_columns, count_columns = cls._build_select_columns(
            table, select_columns, group_by)
        query = MySQLQuery.from_(table).select(*_select_columns)
        if is_distinct:
            query = query.distinct()

        # Setup joins
        if joins:
            query, has_selected = cls._build_joins(query, joins, group_by)

        if not select_columns and not has_selected:
            raise ValueError("Please provide columns to select.")

        # Separate clause filters
        where_filters, having_filters = cls._separate_clause_filters(filters)
        # Configure where conditions
        query = cls._build_where_clause(table, query, where_filters)

        # Configure group by
        if group_by:
            for col in group_by:
                query = query.groupby(col)
            # Set having
            if having_filters and is_distinct:
                raise ValueError(
                    "Having filters are not allowed when distinct is True.")
            query = cls._build_having_clause(query, having_filters, table)
        elif having_filters:
            raise ValueError(
                "Having clause requested without group by columns!")

        # Set order by
        for col, order in order_by.items():
            if Order.asc.value == order.upper():
                query = query.orderby(table[col], order=Order.asc)
            elif Order.desc.value == order.upper():
                query = query.orderby(table[col], order=Order.desc)

        # Set limit to number of records
        query = query.limit(min(limit, MAX_RECORDS))
        if offset:
            if isinstance(offset, int):
                query = query.offset(offset)
            else:
                raise ValueError(
                    f"Please provide offset as an integer: {offset}")
        sql_query = query.get_sql()
        if count_columns:
            # TODO(praveen):  Remove this hack when support is available in
            #  pypika library for multiple columns in COUNT
            sql_query = sql_query.replace(
                f"'{COUNT_MULTI_HACK}'",
                ', '.join(f"`{table_name}`.`{col}`" for col in count_columns) if joins else
                ', '.join(f"`{col}`" for col in count_columns)
            )
        return sql_query

    @staticmethod
    def _build_select_columns(table, select_columns, group_by, is_join=False):
        """Builds select columns."""
        query_select_columns = []
        count_columns = []
        has_count = False
        for col in select_columns:
            if type(col) == str:
                query_select_columns.append(table[col])
            elif type(col) == dict:
                if STAR in col["col"] or col.get("function"):
                    if is_join:
                        raise ValueError(
                            f"{COUNT} is not allowed in join select columns.")
                    col_send = col["col"]
                    if col.get("function") != COUNT:
                        raise ValueError(f"Invalid function: {col.get('function')} requested in select columns. "
                                         f"Allowed function: {COUNT}")
                    if isinstance(col["col"], list):
                        count_columns, col_send = col_send, COUNT_MULTI_HACK
                    select_column = MySQLQueryBuilder._get_fn({
                        "key": col_send,
                        **col
                    }, table)
                    has_count = True
                else:
                    select_column = table[col["col"]]
                if col.get("as"):
                    select_column = select_column.as_(col["as"])
                query_select_columns.append(select_column)
        if has_count:
            MySQLQueryBuilder._validate_count_aggregation(
                select_columns, group_by)

        return query_select_columns, count_columns

    @staticmethod
    def _validate_count_aggregation(select_columns, group_by):
        """Validates count aggregation against select columns."""
        for col in select_columns:
            key = None
            if type(col) == str:
                key = col
            elif type(col) == dict:
                # Skip the COUNT aggregation
                if col.get("function"):
                    continue
                key = col["col"]
            if key not in group_by:
                raise ValueError(
                    f"Column: {key} must be in group by when using {COUNT} aggregation.")

    @classmethod
    def _build_joins(cls, query, joins, group_by):
        """Builds requested joins."""
        has_selected = False
        for join in joins:
            join_table = Table(join["join_table"]["name"])
            with_table = Table(join["with_table"]["name"])
            query = query.join(join_table, join["type"]) \
                .on(join_table[join["join_table"]["on"]] == with_table[join["with_table"]["on"]])
            if join["join_table"].get("select_columns"):
                has_selected = True
                _select_columns, _ = cls._build_select_columns(
                    join_table,
                    join["join_table"]["select_columns"],
                    group_by,
                    True
                )
                query = query.select(*_select_columns)
        return query, has_selected

    @staticmethod
    def _build_insert_query(table_name, insert_columns):
        """Builds a raw insert sql query."""
        table = Table(table_name)
        query = MySQLQuery.into(table). \
            columns(*insert_columns.keys()). \
            insert(*insert_columns.values())
        return query.get_sql()

    @classmethod
    def _build_update_query(cls, table_name, update_columns, filters):
        """Builds a raw update sql query."""
        table = Table(table_name)
        query = MySQLQuery.update(table)
        # Setup columns to update
        for col, val in update_columns.items():
            query = query.set(col, val)
        # Setup where conditions
        query = cls._build_where_clause(table, query, filters)
        return query.get_sql()

    @staticmethod
    def _separate_clause_filters(filters):
        """ Separates where and having clause filters."""
        where_filters = []
        having_filters = []
        for filter_ in filters:
            if filter_.get('function'):
                having_filters.append(filter_)
            else:
                where_filters.append(filter_)
        return where_filters, having_filters

    @classmethod
    def _build_where_clause(cls, table, query, filters):
        """Builds conditions in where clause as per requested criterion"""
        if not filters:
            return query
        and_conditions, or_conditions = cls._build_where_conditions(
            table, filters)

        if or_conditions and and_conditions:
            return query.where(Criterion.all(and_conditions) | Criterion.any(or_conditions))
        elif and_conditions:
            return query.where(Criterion.all(and_conditions))
        elif or_conditions:
            return query.where(Criterion.any(or_conditions))
        return query

    @classmethod
    def _build_having_clause(cls, query, filters, table):
        """Builds having clause"""
        if not filters:
            return query
        and_conditions, or_conditions = cls._build_having_conditions(
            filters, table)

        # If both conditions are present join them with 'OR'
        if or_conditions and and_conditions:
            return query.having(Criterion.all(and_conditions) | Criterion.any(or_conditions))
        elif and_conditions:
            return query.having(Criterion.all(and_conditions))
        elif or_conditions:
            return query.having(Criterion.any(or_conditions))
        return query

    @classmethod
    def _build_having_conditions(cls, filters, table):
        """ Build conditions for having clause"""
        and_conditions = []
        or_conditions = []
        for filter_ in filters:
            if cls._is_allowed_fn_op(filter_):
                if filter_.get('conjunction', '').upper() == OR:
                    or_conditions.append(cls._get_having_fn(filter_, table))
                else:
                    and_conditions.append(cls._get_having_fn(filter_, table))
        return and_conditions, or_conditions

    @classmethod
    def _build_where_conditions(cls, table, filters):
        """ Build conditions for where clause"""
        and_conditions = []
        or_conditions = []
        for filter_ in filters:
            if cls._is_allowed_op(filter_):
                if filter_.get('conjunction', '').upper() == OR:
                    or_conditions.append(cls._get_criterion(table, filter_))
                else:
                    and_conditions.append(cls._get_criterion(table, filter_))
        return and_conditions, or_conditions

    @classmethod
    def _get_having_fn(cls, filter_, table):
        """Gets functions for having clause."""
        having_fn = cls._get_fn(filter_, table)
        if having_fn:
            return cls._perform_operator(filter_, having_fn)

    @staticmethod
    def _get_fn(filter_, table):
        """Gets function."""
        fn = filter_.get('function').capitalize()
        col = filter_.get('key')
        if fn == SUM:
            return pypika_fn.Sum(table[col])
        elif fn == MIN:
            return pypika_fn.Min(table[col])
        elif fn == MAX:
            return pypika_fn.Max(table[col])
        elif fn == AVG:
            return pypika_fn.Avg(table[col])
        elif fn == COUNT:
            if col == STAR:
                if filter_.get('is_distinct'):
                    raise ValueError(f"Distinct with {STAR} is not allowed.")
                _res = pypika_fn.Count(col)
            elif col == COUNT_MULTI_HACK:
                if not filter_.get('is_distinct'):
                    raise ValueError(
                        f"Distinct is required for multiple columns in count.")
                _res = pypika_fn.Count(col)
            else:
                _res = pypika_fn.Count(table[col])
            if filter_.get('is_distinct'):
                return _res.distinct()
            return _res

    @staticmethod
    def _perform_operator(filter_, operand):
        """Perform operator for where or having clause."""
        op = filter_.get('operator').lower()
        if op == LT:
            return operand.gte(filter_.get('value'))
        elif op == GT:
            return operand.gt(filter_.get('value'))
        elif op == GTE:
            return operand.gte(filter_.get('value'))
        elif op == LTE:
            return operand.lte(filter_.get('value'))
        elif op == NEQ:
            return operand != filter_.get('value')
        elif op == EQ:
            return operand.eq(filter_.get('value'))
        elif op == ISIN:
            return operand.isin(filter_.get('value'))
        elif op == NOTIN:
            return operand.notin(filter_.get('value'))
        elif op == BETWEEN:
            return operand.between(*filter_.get('value'))
        elif op == LIKE:
            return operand.like(filter_.get('value'))

    @classmethod
    def _get_criterion(cls, table, filter_):
        """Gets criterion to apply in where filter_."""
        if filter_.get("join_table"):
            table = Table(filter_.get("join_table"))
        return cls._perform_operator(filter_, table[filter_.get('key')])

    @staticmethod
    def _is_allowed_fn_op(filter_):
        """Checks whether operator and function for having clause is allowed or not."""
        if filter_.get('operator') in COMPARISON_OPERATORS and filter_.get('function') in ALLOWED_FUNCTIONS:
            return True
        else:
            raise ValueError(f"Requested operator '{filter_.get('operator')}' or "
                             f"function {filter_.get('function')} is not allowed!")

    @staticmethod
    def _is_allowed_op(filter_):
        """Checks whether a operator is allowed or not."""
        if filter_.get('operator') in ALLOWED_OPERATORS:
            return True
        else:
            raise ValueError(
                f"Requested operator '{filter_.get('operator')}' is not allowed!")
