from datetime import datetime
from email.policy import default
from pymysql import DateFromTicks, InternalError
from sqlalchemy import BigInteger, Integer, BINARY, CHAR, Column, Date, DateTime, Enum, Float, Index, LargeBinary, String, text,TIMESTAMP, Table, Text,ForeignKey, SmallInteger
from sqlalchemy.dialects.mysql import BIGINT, ENUM, INTEGER, MEDIUMINT, SET, TEXT, TINYINT, VARCHAR
import sqlalchemy
from sqlalchemy.orm import relationship


from sqlalchemy.ext.declarative import DeclarativeMeta, declarative_base

Base = declarative_base()


class TblChargingProfile(Base):

    __tablename__="tbl_charging_profile"
    id = Column(Integer,primary_key=True)
    chargepoint_id = Column(VARCHAR(100))
    connector_id = Column(Integer)
    purpose = Column(VARCHAR(50))
    profile_id = Column(Integer)
    stack_level = Column(Integer)
    profile_kind = Column(VARCHAR(50))
    duration = Column(Integer)
    number_phases = Column(Integer)
    limit = Column(Integer)
    unit = Column(String)
    valid_from = Column(DateTime)
    valid_to = Column(DateTime)
    is_deleted = Column(Integer)
    created_on = Column(DateTime)
    updated_on = Column(DateTime)
    updated_by = Column(VARCHAR(50))


class ChargerState(Base):
    __tablename__ = "tbl_device_state"
    id = Column(Integer, primary_key=True)
    datetime = Column(DateTime)
    chargepoint_id = Column(String, ForeignKey("tbl_device.service_device_id"))
    connector_id = Column(Integer)
    status = Column(String)
    errorcode = Column(String)
    state = Column(String)
    info = Column(String)
    metervalue_time_interval = Column(DateTime)
    heartbeat_datetime = Column(DateTime)
    heartbeat_time_interval = Column(DateTime)
    meterValue_datetime = Column(DateTime)
    last_status= Column(VARCHAR(100))


class ChargerSession(Base):
    __tablename__ = "tbl_device_session"
    id = Column(Integer, primary_key=True)
    datetime = Column(DateTime)
    chargepoint_id = Column(String, ForeignKey("tbl_device.service_device_id"))
    connector_id = Column(Integer)
    transaction_id = Column(Integer)
    meter_start = Column(Integer)
    meter_stop = Column(Integer)
    start_time = Column(DateTime)
    stop_time = Column(DateTime)
    energy = Column(Integer)
    power = Column(Integer)
    current = Column(Integer)
    voltage = Column(Integer)
    energy_unit = Column(String)
    power_unit = Column(String)
    current_unit = Column(String)
    voltage_unit = Column(String)
    soc = Column(Integer)
    energy_consumed = Column(Float)
    vehicle_id = Column(String)


class Charger(Base):
    __tablename__ = "tbl_device"
    id = Column(Integer, primary_key=True)
    service_device_id = Column(String(length=20))
    charger_name = Column(String(length=50))
    site_id = Column(Integer, ForeignKey("tbl_site.id"))
    no_of_connectors = Column(Integer)
    mac_address = Column(String(length=50))
    model = Column(String(length=50))
    manufacturer = Column(String(length=50))
    created_on = Column(DateTime)
    updated_on = Column(DateTime)
    created_by = Column(Integer)
    updated_by = Column(Integer)
    is_deleted = Column(SmallInteger)