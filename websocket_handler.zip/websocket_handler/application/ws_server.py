import asyncio
import json
import random
from datetime import datetime

import websockets
from aiokafka import AIOKafkaConsumer

import dependencies.db_utility.constants as constants
from config import kafka_config
from dependencies.db_utility.constants import *
import requests
import uuid
from . import Session
from kafka_producer_model import logger, producer_send
from ocpp_mh.ocpp.charge_point import ChargePoint as cp
from ocpp_mh.ocpp.routing import on
from aiokafka.helpers import create_ssl_context
from ocpp_mh.ocpp.v16 import call, call_result
from ocpp_mh.ocpp.v16.enums import *
from utility.constants import *
from .models import Charger,ChargerSession,ChargerState


class ChargePoint(cp):
    @on(Action.BootNotification)
    async def on_boot_notif(self, charge_point_model, charge_point_vendor, **kwargs):
        value = call_result.BootNotificationPayload(
            current_time=datetime.utcnow().isoformat()[:-3] + "Z",
            interval=20,
            status=RegistrationStatus.accepted,
        )

        log_data = value.__dict__
        log_data["chargepoint_id"] = self.id
        logdata = {"BootNotificationPayload": log_data}

        print(logdata)
        return value

    @on(Action.StatusNotification)
    def on_status_notitication(self, **kwargs):
        value = call_result.StatusNotificationPayload()
        log_data = value.__dict__
        log_data["chargepoint_id"] = self.id
        log_data["datetime"] = str(datetime.utcnow())
        logdata = {"StatusNotificationPayload": log_data}
        print(logdata)
        return value

    @on(Action.Heartbeat)
    def on_heartbeat(self, **kwargs):
        value = call_result.HeartbeatPayload(
            current_time=datetime.utcnow().isoformat()[:-3] + "Z"
        )
        log_data = value.__dict__
        log_data["chargepoint_id"] = self.id
        logdata = {"HeartbeatPayload": log_data}
        print(logdata)
        return value

    @on(Action.Authorize)
    def on_authorize(self, **kwargs):
        value = call_result.AuthorizePayload(id_tag_info={"status": "Accepted"})
        log_data = value.__dict__
        log_data["chargepoint_id"] = self.id
        log_data["datetime"] = str(datetime.utcnow())
        logdata = {"AuthorizePayload": log_data}
        print(logdata)
        return value

    @on(Action.FirmwareStatusNotification)
    def on_firmware_status(self, **kwargs):
        value = call.FirmwareStatusNotificationPayload()
        log_data = value.__dict__
        log_data["chargepoint_id"] = self.id
        log_data["datetime"] = str(datetime.utcnow())
        logdata = {"FirmwareStatusNotificationPayload": log_data}
        print(logdata)
        return value

    @on(Action.MeterValues)
    def on_metervalues(self, **kwargs):
        value = call_result.MeterValuesPayload()
        log_data = value.__dict__
        log_data["chargepoint_id"] = self.id
        log_data["datetime"] = str(datetime.utcnow())
        logdata = {"MeterValuesPayload": log_data}
        print(logdata)
        return value

    @on(Action.StartTransaction)
    def on_start_trans(self, **kwargs):

        connector_id = kwargs["connector_id"]
        chargepoint_id = str(self.id)
        try:
            now = datetime.utcnow()
            previous_session = Session.query(ChargerSession.chargepoint_id,ChargerSession.connector_id,ChargerSession.transaction_id,
                                            ChargerSession.energy,ChargerSession.meter_stop,ChargerSession.stop_time
                                            ).filter(ChargerSession.chargepoint_id==chargepoint_id,
                                                    ChargerSession.connector_id==connector_id,
                                                    ChargerSession.meter_stop==None
                                            ).order_by(ChargerSession.datetime.desc()
                                            
                                            ).first()
            
            Session.commit()
        except Exception as e:
         
            Session.rollback()
        finally:
            Session.remove()
            # previous_session = db.fetchone(
            #     "tbl_device_session",
            #     [
            #         "connector_id",
            #         "chargepoint_id",
            #         "transaction_id",
            #         "energy",
            #         "meter_stop",
            #         "stop_time",
            #     ],
            #     filters=[
            #         db.get_filter_object("chargepoint_id", chargepoint_id, constants.EQ),
            #         db.get_filter_object("connector_id", connector_id, constants.EQ),
            #         # db.get_filter_object( "meter_stop", [None], constants.ISIN),  # unable to create query "meter_stop is NULL"
            #     ],
            #     order_by={"datetime": constants.DESC},
            # )
            # update previous session on same chargepoint and connector id if not updated
            # if previous_session:
                
            #     now = datetime.utcnow()
            #     up = Session.query(ChargerSession
            #                     ).filter(ChargerSession.transaction_id)

            #     update_param = {
            #         "meter_stop": previous_session["energy"]
            #         if previous_session["energy"]
            #         else 0,
            #         "stop_time": now,
            #     }
            #     update_filters = [
            #         db.get_filter_object(
            #             "transaction_id",
            #             previous_session["transaction_id"],
            #             constants.EQ,
            #         ),
            #     ]
            #     db.update("tbl_device_session", update_param, update_filters)
            if previous_session:
                try:
                    up=Session.query(ChargerSession
                                    ).filter(
                                        ChargerSession.transaction_id==previous_session.transaction_id
                                    ).update(
                                            {
                                                ChargerSession.meter_stop: previous_session["energy"] if previous_session["energy"] else 0,
                                                ChargerSession.stop_time: datetime.utcnow(),
                                            }
                                    )
                    Session.commit()
                except Exception as e:
         
                    Session.rollback()
                finally:
                    Session.remove()
                
                print(
                    {
                        "Previous session status": "updated meter_stop and stop_time ",
                        "meter_stop": previous_session["energy"],
                        "stop_time": now,
                        "connector_id": previous_session["connector_id"],
                        "chargepoint_id": previous_session["chargepoint_id"],
                    }
                )
       
 
        transac_id = str(uuid.uuid4().fields[-1])[:8]
        transac_id=int(transac_id)
        print(
            {
                "Transaction id status": "New Transaction ID assigned",
                "transaction_id : ": transac_id,
                "chargepoint": chargepoint_id,
            }
        )
        data = kwargs
        data.update({"transactionId": str(transac_id)})
        data.update({"chargepoint_id": chargepoint_id})
        print({"data to be sent on kafka": data})
        topic = "wennstrom-stream-raw-data-dev"
        try:
            producer_send(topic, data)
        except Exception as e:
            print(e)
        value = call_result.StartTransactionPayload(
            transaction_id=transac_id, id_tag_info={"status": "Accepted"}
        )
        log_data = value.__dict__
        log_data["chargepoint_id"] = self.id
        log_data["datetime"] = str(datetime.utcnow())
        logdata = {"StartTransactionPayload": log_data}
        print(logdata)
        return value

    @on(Action.StopTransaction)
    def on_stop_trans(self, **kwargs):
        value = call_result.StopTransactionPayload(id_tag_info=None)
        log_data = value.__dict__
        log_data["chargepoint_id"] = self.id
        log_data["datetime"] = str(datetime.utcnow())
        logdata = {"StopTransactionPayload": log_data}
        print(logdata)
        return value

    @on(Action.DiagnosticsStatusNotification)
    def diagnostic_status(self, **kwargs):
        value = call_result.DiagnosticsStatusNotificationPayload()
        log_data = value.__dict__
        log_data["chargepoint_id"] = self.id
        log_data["datetime"] = str(datetime.utcnow())
        logdata = {"DiagnosticsStatusNotificationPayload": log_data}
        print(logdata)
        return value

    @on(Action.DataTransfer)
    def on_data_transfer(self, vendor_id, message_id, data):
        value = call_result.DataTransferPayload(status="Accepted")
        log_data = value.__dict__
        log_data["chargepoint_id"] = self.id
        log_data["datetime"] = str(datetime.utcnow())
        logdata = {"DataTransferPayload": log_data}
        print(logdata)
        return value

    async def request_handler(self, msg, charge_point_id):
        values = list(msg.values())
        if charge_point_id in values:
            if "reset" in values:
                if msg["reset_type"] == "hard":
                    request = call.ResetPayload(type=ResetType.hard)
                else:
                    request = call.ResetPayload(type=ResetType.soft)
                payload = {"payload": "ResetPayload"}

            if "get_config" in values:
                if msg["key"][0] == "all":
                    key = key_list
                else:
                    key = msg["key"]
                payload = {"payload": "GetConfigurationPayload"}
                request = call.GetConfigurationPayload(key=key)

            if "change_config" in values:
                key = msg["key"]
                value = msg["value"]
                payload = {"payload": "ChangeConfigurationPayload"}
                request = call.ChangeConfigurationPayload(key=key, value=value)

            if "get_diagnostic" in values:
                request = call.GetDiagnosticsPayload(
                    location=msg["location"],
                    retries=msg["num_retry"],
                    retry_interval=msg["retry_interval"],
                    start_time=msg["startime"],
                    stop_time=msg["stoptime"],
                )
                payload = {"payload": "GetDiagnosticsPayload"}

            if "get_composite_schedule" in values:
                request = call.GetCompositeSchedulePayload(
                    connector_id=msg["connector_id"], duration=msg["duration"]
                )
                payload = {"payload": "GetCompositeSchedulePayload"}

            if "change_availability" in values:
                request = call.ChangeAvailabilityPayload(
                    connector_id=msg["connector_id"], type=msg["type_"]
                )
                payload = {"payload": "ChangeAvailabilityPayload"}

            if "clear_charging_profile" in values:
                request = call.ClearChargingProfilePayload(
                    id=msg["profile_id"],
                    connector_id=msg["connector_id"],
                    charging_profile_purpose=msg["ChargingProfilePurposeType"],
                    stack_level=msg["stack_level"],
                )
                payload = {"payload": "ClearChargingProfilePayload"}

            if "set_charging_profile" in values:
                request = call.SetChargingProfilePayload(
                    connector_id=msg["connector_id"],
                    cs_charging_profiles=msg["charging_profile"],
                )
                payload = {"payload": "SetChargingProfilePayload"}

            if "remote_start_transaction" in values:
                # try:
                #     chargingprofile = msg["charging_profile"]
                # except:
                #     chargingprofile = ""
                request = call.RemoteStartTransactionPayload(
                    id_tag=msg["id_tag"],
                    connector_id=msg["connector_id"]
                    # charging_profile=chargingprofile,
                )
                payload = {"payload": "RemoteStartTransactionPayload"}

            if "remote_stop_transaction" in values:
                request = call.RemoteStopTransactionPayload(
                    transaction_id=msg["transaction_id"]
                )
                payload = {"payload": "RemoteStopTransactionPayload"}

            if "trigger_message" in values:
                request = call.TriggerMessagePayload(
                    requested_message=msg["message_type"],
                    connector_id=msg["connector_id"],
                )
                payload = {"payload": "TriggerMessagePayload"}

            if "get_local_list_version" in values:
                request = call.GetLocalListVersionPayload()
                payload = {"payload": "GetLocalListVersionPayload"}

            if "send_local_list" in values:
                request = call.SendLocalListPayload(
                    list_version=msg["version"],
                    update_type=msg["update_type"],
                    local_authorization_list=msg["local_authorization_list"],
                )
                payload = {"payload": "SendLocalListPayload"}

            if "unlock_connector" in values:
                request = call.UnlockConnectorPayload(connector_id=msg["connector_id"])
                payload = {"payload": "UnlockConnectorPayload"}

            log_data = request.__dict__
            log_data["chargepoint_id"] = self.id
            log_data["datetime"] = str(datetime.utcnow())
            logdata = {str(payload["payload"]): log_data}
            print(logdata)
            response = await self.call(request)
            return response
        else:
            print({"status": "No requests sent"})
            return

    async def response_handler(self, msg, response, charge_point_id):
        print({"response": response})
        values = list(msg.values())
        if "reset" in values:
            if response.status == ResetStatus.accepted:
                print({"response status": "Reset Accepted!!"})
            else:
                print({"response status": "Reset Rejected!!"})
            data = {
                "key": "reset",
                "response": response.status,
                "chargepoint_id": charge_point_id,
            }

        if "get_config" in values:
            if response != None:
                print({"get config status": "Configuration received"})
                data = {
                    "key": "get_config",
                    "response": response.configuration_key,
                    "chargepoint_id": charge_point_id,
                }
            else:
                print({"get config status": "Configuration not received"})

        if "change_config" in values:
            if response.status == ConfigurationStatus.accepted:
                print({"change config status": "Configuration accepted!!"})
            elif response.status == ConfigurationStatus.reboot_required:
                print({"change config status": "Reboot required!!"})
            elif response.status == ConfigurationStatus.not_supported:
                print({"change config status": "Not supported!!"})
            else:
                print({"change config status": "Configuration not received!!"})
            data = {
                "key": "change_config",
                "response": response.status,
                "chargepoint_id": charge_point_id,
            }

        if "get_diagnostic" in values:
            if "file_name" in response:
                print({"diagnostic file status": "Diagnostics file name received"})
            else:
                print({"diagnostic file status": "No diagnostics file name received"})
            data = {
                "key": "get_diagnostic",
                "response": response,
                "chargepoint_id": charge_point_id,
            }

        if "get_composite_schedule" in values:
            if response.status == GetCompositeScheduleStatus.accepted:
                print({"composite schedule status": response.status})
            elif response.status == GetCompositeScheduleStatus.rejected:
                print({"composite schedule status": response.status})
            data = {
                "key": "get_composite_schedule",
                "response": response.status,
                "chargepoint_id": charge_point_id,
            }

        if "change_availability" in values:
            if response.status == AvailabilityStatus.accepted:
                print({"availability status": response.status})
            elif response.status == AvailabilityStatus.rejected:
                print({"availability status": response.status})
            elif response.status == AvailabilityStatus.scheduled:
                print({"availability status": response.status})
            data = {
                "key": "change_availability",
                "response": response.status,
                "chargepoint_id": charge_point_id,
            }

        if "clear_charging_profile" in values:
            if response.status == ClearChargingProfileStatus.accepted:
                print({"clear charging status": response.status})
            elif response.status == ClearChargingProfileStatus.unknown:
                print({"clear charging status": response.status})
            data = {
                "key": "clear_charging_profile",
                "response": response.status,
                "chargepoint_id": charge_point_id,
            }

        if "remote_start_transaction" in values:
            if response.status == RemoteStartStopStatus.accepted:
                print({"remote status": response.status})
            elif response.status == RemoteStartStopStatus.rejected:
                print({"remote start status": response.status})
            data = {
                "key": "remote_start_transaction",
                "response": response.status,
                "chargepoint_id": charge_point_id,
            }

        if "remote_stop_transaction" in values:
            if response.status == RemoteStartStopStatus.accepted:
                print({"remote stop status": response.status})
            elif response.status == RemoteStartStopStatus.rejected:
                print({"remote stop status": response.status})
            data = {
                "key": "remote_stop_transaction",
                "response": response.status,
                "chargepoint_id": charge_point_id,
            }

        if "trigger_message" in values:
            if response.status == TriggerMessageStatus.accepted:
                print({"trigger message status": response.status})
            elif response.status == TriggerMessageStatus.rejected:
                print({"trigger message status": response.status})
            elif response.status == TriggerMessageStatus.not_implemented:
                print({"trigger message status": response.status})
            data = {
                "key": "trigger_message",
                "response": response.status,
                "chargepoint_id": charge_point_id,
            }

        if "send_local_list" in values:
            if response.status == UpdateStatus.accepted:
                print({"send local list": response.status})
            elif response.status == UpdateStatus.rejected:
                print({"send local list": response.status})
            elif response.status == UpdateStatus.not_supported:
                print({"send local list": response.status})
            elif response.status == UpdateStatus.version_mismatch:
                print({"send local list": response.status})
            data = {
                "key": "send_local_list",
                "response": response.status,
                "chargepoint_id": charge_point_id,
            }

        if "get_local_list_version" in values:
            if len(response.list_version) != 0:
                print({"local list version": response.list_version})
            else:
                print({"local list version": response.list_version})
            data = {
                "key": "get_local_list_version",
                "response": response.list_version,
                "chargepoint_id": charge_point_id,
            }

        if "unlock_connector" in values:
            print({"unlock connector": response.status})
            data = {
                "key": "unlock_connector",
                "response": response.status,
                "chargepoint_id": charge_point_id,
            }

        print(data)
        try:
            topic = kafkatopics.OCPP_CMD_RESP
            producer_send(topic, json.dumps(data))
        except Exception as e:
            print(e)

    async def server_call(self, charge_point_id, websocket, is_reset=False):
        # Consumer object to subscribe to the kafka configuration
        # Consumer object call to subscribe to a particular topic
        # print({"status":"Entered async kafka"})
        try:

            context = create_ssl_context(
                certfile=None,  # Signed certificate
                keyfile=None,  # Private Key file of `certfile` certificate
                password=kafka_config["sasl_plain_password"],
            )
            consumer = AIOKafkaConsumer(
                kafkatopics.OCPP_CMD_REQST,
                bootstrap_servers=kafka_config["bootstrap_servers"],
                security_protocol=kafka_config["security_protocol"],  # If sasl is setup
                sasl_mechanism=kafka_config["sasl_mechanism"],  # If sasl is setup
                sasl_plain_username=kafka_config["sasl_plain_username"],  # If sasl is setup
                sasl_plain_password=kafka_config["sasl_plain_password"],
                auto_offset_reset=kafka_config["auto_offset_reset"],
                enable_auto_commit=kafka_config["enable_auto_commit"],
                ssl_context=context,
            )
            # Get cluster layout and join group `my-group`
            await consumer.start()
            while 1:
                try:
                    # Consuming the data from kafka
                    async for msg in consumer:
                        msg = json.loads(msg.value.decode("utf-8"))
                        print({"consumed_msg": msg})
                        response = await self.request_handler(msg, charge_point_id)
                        if response:
                            await self.response_handler(msg, response, charge_point_id)
                except:
                    print({"Exception": "Didn't receive any data yet"})
        except Exception as e:
            print(e)
        # finally:
        #     # Will leave consumer group; perform autocommit if enabled.
        #     await consumer.stop()


async def on_connect(websocket, path):
    """For every new charge point that connects, create a ChargePoint
    instance and start listening for messages.
    """
    # print("Try connecting now")
    try:
        requested_protocols = websocket.request_headers["Sec-WebSocket-Protocol"]
    except KeyError:
        print(
            {"protocol": "Client hasn't requested any Subprotocol.Closing Connection"}
        )
    if websocket.subprotocol:
        print({"protocol": "Protocols Matched", "protocol": websocket.subprotocol})
    else:
        # In the websockets lib if no subprotocols are supported by the
        # client and the server, it proceeds without a subprotocol,
        # so we have to manually close the connection.
        print(
            {
                "status": "Protocols Mismatched",
                "expected Subprotocols": websocket.available_subprotocols,
                "supported Protocol": requested_protocols,
                "result": "Closing connection",
            }
        )
        return await websocket.close()

    print({"protocol": "Protocols checked"})
    charge_point_id = path.strip("/")
    # print({"chargepoint": charge_point_id})

    cp = ChargePoint(charge_point_id, websocket)

    #db_conn = NebulaMySQL(db_config, logger)
    try:
        charger_present = Session.query(Charger.service_device_id
                                        ).filter(Charger.service_device_id==charge_point_id
                                        ).all()
        Session.commit()
        
    except:
        Session.rollback()
    finally:
        Session.remove()
    
    # charger_present = db_conn.fetchall(
    #     table.DEVICE,
    #     select_columns=["service_device_id"],
    #     filters=[
    #         db_conn.get_filter_object(
    #             "service_device_id",
    #             charge_point_id,
    #             constants.EQ,
    #         ),
    #     ],
    # )
    try:
        charger_status = Session.query(ChargerState.state,ChargerState.chargepoint_id
                                    ).join(Charger,ChargerState.chargepoint_id==Charger.service_device_id
                                        ).filter(charge_point_id==Charger.service_device_id
                                        ).all()
        Session.commit()
        
    except:
        Session.rollback()
    finally:
        Session.remove()


    
    # charger_status = db_conn.fetchall(
    #     table.DEVICE,
    #     joins=[
    #         {
    #             "type": constants.INNER_JOIN,
    #             "with_table": {
    #                 "name": table.DEVICE,
    #                 "on": "service_device_id",
    #             },
    #             "join_table": {
    #                 "name": table.DEVICE_STATE,
    #                 "on": "chargepoint_id",
    #                 "select_columns": [{"col": "state"}],
    #             },
    #         }
    #     ],
    #     filters=[
    #         db_conn.get_filter_object(
    #             "service_device_id",
    #             charge_point_id,
    #             constants.EQ,
    #         ),
    #     ],
    # )

    print({"status": "Chargepoint Id connected", "chargerpoint_id": charge_point_id})

    flag = False
    try:
        if charger_present:
            if charger_status:
                if charger_status[0]["state"] == "offline":
                    flag = True
                else:
                    print(
                        {
                            "charger": charge_point_id,
                            "status": "cannot connect  already connected.",
                        }
                    )
            else:
                flag = True
        else:
            print(
                {
                    "charger": charge_point_id,
                    "status": "cannot connect not in database.",
                }
            )
        if flag:
            try:
                server_task = asyncio.create_task(
                    cp.server_call(charge_point_id, websocket)
                )
                await asyncio.gather(cp.start())

            except websockets.exceptions.ConnectionClosed:
                connected.remove(websocket)
                print({"status": "Charge Point disconnected"})
    except Exception as e:
        print(e)


async def main():
    server = await websockets.serve(
        on_connect,
        "0.0.0.0",
        9091,
        subprotocols=["ocpp1.6"],
        ping_interval=None,
        ping_timeout=None,
    )
    print({"status": "WebSocket Server Started", "started_on": server})
    await server.wait_closed()
