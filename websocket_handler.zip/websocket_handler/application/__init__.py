import os
from config import config,db_config
from flask import Flask, request
from flask import session
import uuid
from flask_sqlalchemy import SQLAlchemy
#from .utilities.response import final_response
from sqlalchemy.orm import sessionmaker,scoped_session
import sqlalchemy
from dependencies.logger_utility.logger import NebulaLogger
from decouple import config
from sqlalchemy import  create_engine, MetaData
from sqlalchemy.ext.declarative import declarative_base


logger = NebulaLogger(rule_name='connector_status', handlers=['console', ])
DB_URI = f"mysql+pymysql://{db_config['user']}:{db_config['password']}@{db_config['host']}:{db_config['port']}/{db_config['database']}"


engine = create_engine(DB_URI,pool_size=2, pool_recycle=29, pool_pre_ping=True,max_overflow=10,echo=False)


session_factory = sessionmaker(bind=engine)
Session = scoped_session(session_factory)
