from datetime import datetime
import time
import os
file = open(f"{int(time.time())}-logs","a")
print(file.name)
file.write("testing")
f_size = os.path.getsize(file.name)
if f_size>2097152:
    #logic to push into s3 bucket

    file.close()



 global current_file
                    
                    if current_file is None:
                        current_file = f"{int(time.time())}-logs"
                    file = open(current_file,"a")
                    file.write(json.dumps(raw_data))
                    file.flush()
                    file.close()
                    f_size = os.path.getsize(file.name)
                    if f_size>1024:
                        #logic to push into s3 bucket
                        print("file create")
                        current_file = f"{int(time.time())}-logs"