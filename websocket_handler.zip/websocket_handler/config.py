from decouple import config

from dependencies.kafka_utility.constants import (LATEST, SASL_PLAINTEXT, SASL_SSL,
                                                  SCRAM_SHA_512)

kafka_config = {
    "bootstrap_servers": config("BOOTSTRAP_SRVR"),
    "security_protocol": SASL_SSL,  # If sasl is setup
    "sasl_mechanism": SCRAM_SHA_512,  # If sasl is setup
    "sasl_plain_username": config("KAFKA_USERNAME"),  # If sasl is setup
    "sasl_plain_password": config("KAFKA_PASSWORD"),  # If sasl is setup
    "auto_offset_reset": LATEST,
    "enable_auto_commit": True,  # Enable or disable autocommit, Default us disabled, # Optional
}

db_config = {
    "host": config("SQL_HOST"),
    "user": config("SQL_USER"),
    "password": config("SQL_PASSWORD"),
    "database": config("SQL_DATABASE"),
    "port": config("SQL_PORT", cast=int),
}
