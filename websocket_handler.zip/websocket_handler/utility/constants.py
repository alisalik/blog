class table:
    COMMAND_APPROVAL = "tbl_command_approval"
    DEVICE = "tbl_device"
    DEVICE_STATE = "tbl_device_state"

class kafkatopics:
    OCPP_CMD_REQST = "wennstrom-stream-ocpp-cmd-request-dev"
    OCPP_CMD_RESP = "wennstrom-stream-ocpp-cmd-response-dev"


class param:
    COMMAND_NAME = "command_name"
    FLAG = "flag"
    CHARGEPOINT_ID = "chargepoint_id"


key_list = [
    "AllowOfflineTxForUnknownId",
    "AuthorizationCacheEnabled",
    "AuthorizeRemoteTxRequests",
    "BlinkRepeat",
    "ClockAlignedDataInterval",
    "ConnectionTimeOut",
    "GetConfigurationMaxKeys",
    "HeartbeatInterval",
    "LightIntensity",
    "LocalAuthorizeOffline",
    "LocalPreAuthorize",
    "MaxEnergyOnInvalidId",
    "MeterValuesAlignedData",
    "MeterValuesAlignedDataMaxLength",
    "MeterValuesSampledData",
    "MeterValuesSampledDataMaxLength",
    "MeterValueSampleInterval",
    "MinimumStatusDuration",
    "NumberOfConnectors",
    "ResetRetries",
    "ConnectorPhaseRotation",
    "ConnectorPhaseRotationMaxLength",
    "StopTransactionOnEVSideDisconnect",
    "StopTransactionOnInvalidId",
    "StopTxnAlignedData",
    "StopTxnAlignedDataMaxLength",
    "StopTxnSampledData",
    "StopTxnSampledDataMaxLength",
    "SupportedFeatureProfiles",
    "SupportedFeatureProfilesMaxLength",
    "TransactionMessageAttempts",
    "TransactionMessageRetryInterval",
    "UnlockConnectorOnEVSideDisconnect",
    "WebSocketPingInterval",
]
