from config import kafka_config
from dependencies.kafka_utility.producer import NebulaKafkaProducer
from dependencies.logger_utility.logger import NebulaLogger

logger = NebulaLogger(rule_name="occp_websocket", handlers="all")
import logging
producer = None
try:
    producer = NebulaKafkaProducer(kafka_config, logger)

except Exception as e:
    logging.exception(e)
#print({"Producer Object": producer})


def producer_send(topic, data):
    try:
        global producer
        if producer is None:
            producer =  NebulaKafkaProducer(kafka_config, logger)
        try:
            ack = producer.send_to_topic(topic, data)
        except:
            producer = None
    except Exception as e:
        logging.exception(e)
    #print({"data sent":data})
