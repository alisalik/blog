#!/bin/sh

# Start main.py program in background
python /app/async_job_executor/main.py &

# Start Django server in foreground
python manage.py runserver 0.0.0.0:8000