import traceback

from core.exceptions import ApplicationError, ApplicationErrorJsend
from django.core.exceptions import PermissionDenied
from django.core.exceptions import ValidationError as DjangoValidationError
from django.http import Http404
from rest_framework import exceptions
from rest_framework.response import Response
from rest_framework.serializers import as_serializer_error
from rest_framework.views import exception_handler


def drf_default_with_modifications_exception_handler(exc, ctx):
    if isinstance(exc, DjangoValidationError):
        exc = exceptions.ValidationError(as_serializer_error(exc))

    if isinstance(exc, Http404):
        exc = exceptions.NotFound()

    if isinstance(exc, PermissionDenied):
        exc = exceptions.PermissionDenied()

    response = exception_handler(exc, ctx)

    # If unexpected error occurs (server error, etc.)
    if response is None:
        return response

    if isinstance(exc.detail, (list, dict)):
        response.data = {"detail": response.data}

    return response


def hacksoft_proposed_exception_handler(exc, ctx):
    """
    FAIL(HTTP response - 4**)-
    {
        "status" : "fail",
        "data" : { "title" : "A title is required" }
    }
    ERROR (HTTP response - 5**)
    {
        "status" : "error",
        // A meaningful, end-user-readable (or at the least log-worthy) message, explaining what went wrong.
        "message" : "Unable to communicate with database",
        // optional
        "code": A numeric code corresponding to the error, if applicable,
        "data": A generic container for any other information about the error, i.e. the conditions that caused the error, stack traces, etc.
    }
    """
    if isinstance(exc, DjangoValidationError):
        exc = exceptions.ValidationError(as_serializer_error(exc))

    if isinstance(exc, Http404):
        exc = exceptions.NotFound()

    if isinstance(exc, PermissionDenied):
        exc = exceptions.PermissionDenied()

    response = exception_handler(exc, ctx)

    # If unexpected error occurs (server error, etc.) this is our ERROR case
    if response is None:
        # for exception that aren't captured yet
        if isinstance(exc, ApplicationError):
            data = {"message": exc.message, "extra": exc.extra}
            return Response(data, status=400)
        if isinstance(exc, ApplicationErrorJsend):
            data = {
                "status": exc.status,
                "message": exc.message,
                "code": exc.code,
                "data": exc.data,
            }
            return Response(data, status=500)
        else:
            data = {
                "status": "error",
                "message": str(exc),
                "data": traceback.format_tb(exc.__traceback__),
                "code": str(type(exc)),
            }
        return Response(data, status=500)

    if isinstance(exc.detail, (list, dict)):
        response.data = {"detail": response.data}

    if isinstance(exc, exceptions.ValidationError):
        # TODO: pls adhere to JSend response schema
        response.data["data"] = {}
        response.data["data"]["message"] = "Validation error"
        response.data["data"]["extra"] = {"fields": response.data["detail"]}
    else:
        response.data["data"] = {}
        response.data["data"]["message"] = response.data["detail"]
        response.data["extra"] = {}
        response.data["extra"]["extra"] = {}

    response.data["status"] = "fail"
    del response.data["detail"]
    # marking as fail as per JSend standard.
    # response.data["status"] = "fail"
    # response.data["data"] = response.data
    return response
