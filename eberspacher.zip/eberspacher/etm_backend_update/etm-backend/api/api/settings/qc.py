"""Development environment config
"""
import os

# importing all elements from base setting module
from .base import *

INSTALLED_APPS += ["corsheaders"]
CORS_ORIGIN_ALLOW_ALL = True
MIDDLEWARE += [
    "corsheaders.middleware.CorsMiddleware",
]

SECRET_KEY = "django-insecure-&ph3&qlc%hrsyf-da4_78ft65trfdusoeq^ax-b3uvkco2w$u!8$=fr!c7s&13"
USE_TZ = False
DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.mysql",
        "NAME": os.environ.get("DB_NAME"),
        "USER": os.environ.get("DB_USER"),
        "PASSWORD": os.environ.get("DB_PASSWORD"),
        "HOST": "mysql.qc.orahi.com",
        "PORT": "3307",
        "CONN_MAX_AGE": 14400,
    }
}

EBERSPACHER_URL = 'https://etm.qc.orahi.com/'
AUTH_USER_MODEL = "users.UserProfile"


REDIS_HOST = "redis.dev.orahi.com"
REDIS_PORT = 6379
REDIS_PASSWORD = os.environ.get("REDIS_PASSWORD")
