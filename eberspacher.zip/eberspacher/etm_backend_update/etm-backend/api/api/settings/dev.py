"""Development environment config
"""
import os

# importing all elements from base setting module
from .base import *

INSTALLED_APPS += ["corsheaders"]
CORS_ORIGIN_ALLOW_ALL = True
MIDDLEWARE += [
    "corsheaders.middleware.CorsMiddleware",
]
USE_TZ = False
DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.mysql",
        "NAME": os.environ.get("DB_NAME"),
        "USER": os.environ.get("DB_USER"),
        "PASSWORD": os.environ.get("DB_PASSWORD"),
        "HOST": "mysql.dev.orahi.com",
        "PORT": "3306",
        "CONN_MAX_AGE": 14400
    }
    
   
}


AUTH_USER_MODEL = "users.UserProfile"


REDIS_HOST = 'redis.dev.orahi.com'
REDIS_PORT = 6379
REDIS_PASSWORD = os.environ.get("REDIS_PASSWORD")
EBERSPACHER_URL = 'https://etm.dev.orahi.com/'

S3_CAN_DUMP_FILE_OBJECT_KEY = "eberspacher/gateway/diagnostics/dev/%s/can_recordings/%s"