# TODO: create setting for local
"""Development environment config
"""
import os

# importing all elements from base setting module
from .base import *

INSTALLED_APPS += ["corsheaders"]
CORS_ORIGIN_ALLOW_ALL = True
MIDDLEWARE += [
    "corsheaders.middleware.CorsMiddleware",
]

DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.mysql",
        "NAME": os.environ.get("DB_NAME"),
        "USER": os.environ.get("DB_USER"),
        "PASSWORD": os.environ.get("DB_PASSWORD"),
        # "HOST": "mysql.dev.orahi.com",
        "HOST": "192.168.0.126",
        "PORT": "3306",
    }
}
