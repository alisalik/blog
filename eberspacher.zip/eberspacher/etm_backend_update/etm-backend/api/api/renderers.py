from rest_framework.renderers import BaseRenderer
from rest_framework.utils import json


class ApiRenderer(BaseRenderer):
    """
    https://stackoverflow.com/questions/53910545/how-overwrite-response-class-in-django-rest-framework-drf
    """

    media_type = "application/json"
    format = "json"

    def render(self, data, accepted_media_type=None, renderer_context=None):
        response_dict = {"status": "success", "data": {}}
        if data.get("data"):
            response_dict["data"] = data.get("data")
        elif data.get("status"):
            response_dict["status"] = data.get("status")
        elif data:
            response_dict["data"] = data

        data = response_dict
        return json.dumps(data)
