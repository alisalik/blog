import json
import os
from datetime import datetime
import pandas as pd
import pytz
from common.utils import (convert_to_druid_supported_timestamp,
                          extract_druid_data_rest_api, get_signal_id_from_name,
                          get_signal_name)
from core.jsend_response import JsendSuccessResponse
# from core.kafka import produce_to_kafka
from django.conf import settings
from django.db import transaction
from django.http import FileResponse, HttpResponse
from django.shortcuts import render
from drf_yasg import openapi
from drf_yasg.utils import swagger_auto_schema
from rest_framework import serializers
from rest_framework.exceptions import NotFound, ValidationError
from rest_framework.response import Response
from rest_framework.views import APIView
from vehicle.models import TblHvacVinGateway, TblVehicle
from dateutil.parser import parse
from rest_framework.permissions import IsAuthenticated
from core.pagination import CustomPagination
from core.permissions import AllowedToAccessVehicle , AllowedToUpdateAssests

from .models import TblDiagnostics, TblGateway, TblGatewayMaster , TblSimMaster
from .selectors import (gateway_components_status_get, gateway_get,
                        gateway_gps_get, gateway_last_signal_timestamp_get,
                        gateway_signal_get,daignostic_status, diagnostics_list, download_file_from_s3, master_gateway_list , master_sim_list, gateway_signals_values_get)
from .services import gateway_delete, gateway_register, gateway_update, diagnostics_create, diagnostic_delete, sim_master_create, gateway_master_create
from common.utils import extract_druid_data_rest_api,get_signal_name, convert_to_druid_supported_timestamp
from datetime import datetime
import pytz
from dateutil.parser import parse
import ast
from common.constants import index_error_code_desc

import csv
import sys
from core.permissions import AllowToAccessAdmin

class GatewayRegister(APIView):
    module = "gateway"
    action = "create"

    class InputSerializer(serializers.Serializer):
        vin = serializers.CharField(max_length=100, required=False)
        serial_number = serializers.CharField(max_length=100, required=True)

    class OutputSerializer(serializers.ModelSerializer):
        class Meta:
            model = TblGateway
            fields = "__all__"

    @transaction.atomic
    def post(self, request):
        
        # company = request.user.company.name
        user_id = request.auth["user_id"]
        serializer = self.InputSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        componenet = gateway_register(user_id = user_id,**serializer.validated_data)

        data = self.OutputSerializer(componenet).data
        # produce_to_kafka(request, msg=data, action=self.action, module=self.module)
        return JsendSuccessResponse(
            data=data, data_identifier="component"
        ).get_response()


class GatewayDelete(APIView):
    # TODO: perfrom solf delete
    def delete(self, request, serial_num: str):
        component = gateway_delete(serial_num=serial_num)
        return JsendSuccessResponse(
            data={
                "message": f"Serial_num of Gateway is:{serial_num} deleted successfully"
            }
        ).get_response()


class GatewayUpdateApi(APIView):
    permission_classes = [IsAuthenticated  & AllowedToUpdateAssests]
    class InputSerializer(serializers.Serializer):
        # NOTE:
        serial_number = serializers.CharField()
        sim_number = serializers.CharField()

        def validate(self,data):
            if "serial_number" not in data and "sim_number" not in data:
                # REVIEW: which exception to raise
                raise serializers.ValidationError(
                    "Must include either serial_number or sim_number"
                )
            if "serial_number" in data:
                data["serial_number"] = data.pop("serial_number")
            if "sim_number" in data:
                data["sim_number"] = data.pop("sim_number")

            return data

        class Meta:
            model = TblGateway
            fields = "__all__"

    class OutputSerializer(serializers.ModelSerializer):
        class Meta:
            model = TblGateway
            fields = "__all__"

    # def post(self, request, serial_num: str, sim_num: str, vin: str):
    def post(self, request, vin: str):
        serializer = self.InputSerializer(data=request.data, partial=True)
        serializer.is_valid(raise_exception=True)
        gateway = gateway_update(vin=vin, **serializer.validated_data)
        data = self.OutputSerializer(gateway).data
        return JsendSuccessResponse(data=data, data_identifier="gateway").get_response()


class GatewayGetAPI(APIView):
    """Get a Gateway Details"""

    class OutputSerializer(serializers.ModelSerializer):
        class Meta:
            model = TblGateway
            fields = "__all__"
    def get(self, request, vin: str):
        hvac_vin_gateway = TblHvacVinGateway.objects.all().filter(vin=vin).first()
        if hvac_vin_gateway.gateway_id is None:
            raise NotFound("No Gateway assocaited with this VIN.")
        gateway, cpu_number, company_name, manufacturer, serial_number = gateway_get(
            serial_number=hvac_vin_gateway.gateway_id
        )
        serializer = self.OutputSerializer(gateway)
        res_data = serializer.data
        res_data["cpu_number"] = cpu_number
        res_data["company_name"] = company_name
        res_data["manufacturer"] = manufacturer
        res_data["serial_number"] = serial_number
        # serializer.data[""]
        return JsendSuccessResponse(
            data=res_data, data_identifier="gateway_detail"
        ).get_response()


class GatewaySignalGetAPI(APIView):
    class OutputSerializer(serializers.Serializer):
        pass

    def get(self, request, vin: str, signal_name: str):
        if signal_name == "saloon":
            # If signal_name is salon, search for signals associated with room1 and room2 temperature
            valid_signals = [
                signal["name"] 
                for signal in settings.SIGNALS_METADATA 
                if signal["value_type"] == "FLOAT" and (
                    "Room1ReturnAirTemp" in signal["name"] or 
                    "Room2ReturnAirTemp" in signal["name"]
                )
            ]

            signal = []
            for valid_signal in valid_signals:
                signal_id = get_signal_id_from_name(signal_name=valid_signal)
                try:
                    signal_data = gateway_signal_get(signal_id=signal_id, vin=vin)
                    signal.append(signal_data)
                except:
                    pass
                
            
            if signal:                        
                if len(signal) == 1:
                
                    signal_detail = signal[0]
                    
                
                elif len(signal) == 2:
                    for signal in signal:
                        if signal["id"] == 101:
                            signal_detail = signal
                            break  # exit the loop early if the desired signal is found
                    else:
                        signal_detail = signal[1]
            else:
                raise ValidationError("No valid signals found for salon")
        else:
            if signal_name not in [
                signal["name"]
                for signal in settings.SIGNALS_METADATA
                if signal["value_type"] == "FLOAT"
            ]:
                raise ValidationError("Not a valid signal name")
            signal_id = get_signal_id_from_name(signal_name=signal_name)
            gateway_id = ""
            if bool(request.query_params.get('is_cpu_id')):
                gateway_id = vin
            signal = gateway_signal_get(signal_id=signal_id, vin=vin, gateway_cpu_id=gateway_id)
       
        

        # data = self.OutputSerializer(signal).data
        return JsendSuccessResponse(
            data=signal_detail, data_identifier="signal"
        ).get_response()


class GatewaySignalsValuesGetAPI(APIView):
    class OutputSerializer(serializers.Serializer):
        pass

    def get(self, request, vin: str):
        """
        # TODO[epic=api_optimization] create general signalsValuesGetAPI to get values for all the signals pased to it
        PSEUDO CODE
            - signal_names = request.query_params['names'].split(',')
            - resposne = {}
            - if `saloon` in signal_names:
                - signal_names.pop('saloon')
                - signal_names.push('Room1ReturnAirTemp', 'Room2ReturnAirTemp') (special handling for saloon)
            - signal_ids_names = {s.id: s.name for s in signal_names} ({map of signal_id and signal_values})
            - if any signal in signal_ids_names is None raise exception
            - signal_values <- gateway_signals_values_get(signal_ids_names.signal_ids) (signal_values = {signal_id: {value_dict},...})
            - if `saloon` in request.query_params['names'].split(','):
                - room1_return_air_temp_id, room2_return_air_temp_id = signal_ids_names["Room1ReturnAirTemp", "Room2ReturnAirTemp"]
                - if signal_values[room2_return_air_temp_id] exists 
                    response["saloon"] = signal_values[room2_return_air_temp_id]
                -  elif if signal_values[room1_return_air_temp_id] exists 
                    response["saloon"] = signal_values[room1_return_air_temp_id]
                signal_values.remove_ids(room1_return_air_temp_id, room2_return_air_temp_id)
            
            for signal_id, signal_value in signal_values.items():
                resposne[signal_ids_names[signal_id]] = signal_value

            return response
        """
        signal_names = request.query_params['names'].split(',')
        dispaly_type =  request.query_params.get('display_type') 
        response = {}
        if 'Saloon' in signal_names:
            #saloon in custom name should be removed from code
            signal_names.remove("Saloon") 
            # saloon calulcations depend on below 2 signals
            signal_names.append("Room1ReturnAirTemp")
            signal_names.append("Room2ReturnAirTemp")
        signal_name_id_mapping = {signal['name']: signal['id'] 
                                  for signal in settings.SIGNALS_METADATA 
                                #   if signal["value_type"] in ["FLOAT", "INT"] and
                                  if signal["name"] in signal_names or signal['display_type'] == dispaly_type}
        for sn in signal_names:
            if sn not in signal_name_id_mapping.keys():
                raise ValidationError(f"Signal Name:{sn} not valid!")
        signal_values = gateway_signals_values_get(list(signal_name_id_mapping.values()), vin)
        # special handling for saloon.
        if 'Saloon' in request.query_params['names'].split(','):
            r1_return_air_temp_id, r2_return_air_temp_id = signal_name_id_mapping["Room1ReturnAirTemp"], signal_name_id_mapping["Room2ReturnAirTemp"]
            if r2_return_air_temp_id in signal_values:
                # room2 is saloon
                response["saloon"] = signal_values[r2_return_air_temp_id]
            elif r1_return_air_temp_id in signal_values:
                response["saloon"] = signal_values[r1_return_air_temp_id]
            else:
                response["saloon"] = {}

        # signal names reponse
        for signal_name in signal_names:
            # loop all the signal that have been requested (note saloon is not here)
            signal_id = signal_name_id_mapping[signal_name]
            if signal_id in signal_values:
                response[signal_name] = signal_values[signal_id]
            else:
                response[signal_name] = {}
        # display name response
        if bool(dispaly_type):
            response[dispaly_type] = {}
            for signal in settings.SIGNALS_METADATA:
                if signal['display_type'] == dispaly_type:
                    # this signal matches the display_type
                    signal_name, signal_id, signal_display_name = signal['name'], signal['id'], signal['display_Name']
                    if signal_id in signal_values:
                        # value found for the signal
                        response[dispaly_type][signal_name] = signal_values[signal_id] | {"display_name": signal_display_name}
            
        # data = self.OutputSerializer(signal).data
        return JsendSuccessResponse(
            data=response, data_identifier="signal"
        ).get_response()

class GatewayComponentsStatusGetAPI(APIView):
    class OutputSerializer(serializers.Serializer):
        pass

    def get(self, request, vin: str):
        # pass id from signal_name
        components = gateway_components_status_get(vin=vin)
        # data = self.OutputSerializer(signal).data
        return JsendSuccessResponse(
            data=components, data_identifier="components"
        ).get_response()


class GatewayGPSGetAPI(APIView):
    class OutputSerializer(serializers.Serializer):
        pass

    def get(self, request, vin: str):
        # pass id from signal_name
        gps = gateway_gps_get(vin=vin)
        # data = self.OutputSerializer(signal).data
        return JsendSuccessResponse(data=gps, data_identifier="gps").get_response()


class GatewayLastSignalTimestampGetAPI(APIView):
    def get(self, request, vin: str):
        timestamp = gateway_last_signal_timestamp_get(vin=vin)
        return JsendSuccessResponse(
            data=timestamp, data_identifier="last_signal_timestamp"
        ).get_response()


class GatewayDiagnostic(APIView):
    permission_classes = [AllowToAccessAdmin]
    
    @transaction.atomic
    def post(self, request):
        data = request.data
        gateway_id = TblHvacVinGateway.objects.filter(vin=data["vin"]).values("gateway_id")
        stime = data['start_time']
        etime = data['end_time']

        if "convert_to_utc" in request.query_params:
            if request.query_params["convert_to_utc"] == '1':
                stime = convert_to_druid_supported_timestamp(datetime_string=data['start_time'])
                etime = convert_to_druid_supported_timestamp(datetime_string=data['end_time'])

        list_of_signals = "({})".format(",".join(str(num) for num in data['metadata']['filter']['signal_ids']))
       
        query2 = f'''SELECT __time,gateway_id,id,"value" FROM eber_gateways_sensors_data WHERE gateway_id = '{gateway_id[0]['gateway_id']}' AND __time BETWEEN '{stime}' AND '{etime}' AND id IN {list_of_signals}'''
       
        inputs = extract_druid_data_rest_api(query=query2)
        # Sort inputs in ascending order based on the "time" field
        inputs.sort(key=lambda x: x.get("time", ""))

        signals = get_signal_name()

        for dat in inputs:
            try:
                dat.update({"name": signals[dat["id"]]})
            except KeyError as e:
                dat.update({"name": f'signal {dat["id"]}'})
        
        json_df = pd.read_json(json.dumps(inputs))
        fname = "signal_history_" + stime + "_" + etime + ".csv"
        file = json_df.to_csv(fname, encoding='utf-8', index=False)

        # Read the input CSV file and extract latest values
        input_file = fname
        latest_values = {}
        output = []

        with open(input_file, 'r') as file:
            reader = csv.reader(file)
            count = 0
            for row in reader:
                if count > 0:
                    time = row[0]
                    val = row[3]
                    name = row[4]
                    latest_values[f"{name}"] = val
                    out_row = {"time": time}
                    for signal_name in latest_values:
                        latest_val = latest_values[f"{signal_name}"]
                        out_row[f"{signal_name}"] = latest_val
                    output.append(out_row)
                count += 1

        # Define CSV columns
        csv_columns = []
        csv_columns = ['time']
        for signal_name in latest_values:
            csv_columns.append(signal_name)

        # Write output to a new CSV file
        output_file = fname

        try:
            with open(output_file, 'w', newline='') as csvfile:
                writer = csv.DictWriter(csvfile, fieldnames=csv_columns)
                writer.writeheader()
                for data in output:
                    writer.writerow(data)
        except IOError:
            print("I/O error")
        
        obj = TblDiagnostics.objects.create(gateway_id=gateway_id[0]['gateway_id'],
                                            user_id=request.auth["user_id"],
                                            requested_start_time=parse(stime).replace(tzinfo=None),
                                            requested_end_time=parse(etime).replace(tzinfo=None),
                                            metadata= data,
                                            type="SIGNAL_HISTORY")
        obj.save()

        doc = open(output_file, 'rb')
        response = FileResponse(doc, content_type='text/csv')
        response['Content-Disposition'] = 'attachment; filename=testcsv.csv'
        os.remove(output_file)
        return response


class IndexCodeError(APIView):
    @transaction.atomic
    
    def post(self, request):
        gw_id = request.data["gateway_id"]
        gateway_id = TblGateway.objects.filter(serial_number=gw_id).first()
        index_error_code_obj = gateway_id.index_error_code_packet
        json_df = pd.read_json(json.dumps(index_error_code_obj))
        fname = "index_error_code.csv"
        file = json_df.to_csv(fname, encoding='utf-8', index=False)

        input_file = fname
        latest_values = {}
        output = []

        with open(input_file, 'r') as file:
            reader = csv.reader(file)
            count = 0
            for row in reader:
                if count > 0:
                    data_dict = ast.literal_eval(row[0])
                    date = data_dict['date']
                    index = data_dict['index']
                    code = data_dict['code']
                    description = index_error_code_desc.get(code, "")
                    
                    time = data_dict.get('time', '')
        
        # Check if 'occurence' key is present in data_dict, otherwise set it to an empty string
                    occurence = data_dict.get('occurence', '')

                    out_row = {'date': date, 'index': index, 'code': code, 'description': description,'time':time, 'occurence':occurence}
                    if 'time' not in data_dict:
                        out_row['time'] = ''
                    if 'occurrence' not in data_dict:
                        out_row['occurrence'] = ''
                    for cdi in latest_values:
                        latest_val = latest_values[cdi]
                        out_row[cdi] = latest_val
                    output.append(out_row)
                count += 1

        # Define CSV columns
        csv_columns = ['date', 'index', 'code', 'description','time','occurence']

        # Write output to a new CSV file
        output_file = "output.csv"

        try:
            with open(output_file, 'w', newline='') as csvfile:
                writer = csv.DictWriter(csvfile, fieldnames=csv_columns)
                writer.writeheader()
                writer = csv.writer(csvfile)
                # writer.writerow(csv_columns)
                for data in output:
                    writer.writerow([data['date'], data['index'], data['code'], data['description'], data['time'], data['occurence']])
        except IOError:
            print("I/O error")
            
           

        doc = open(output_file, 'rb')
        response = FileResponse(doc, content_type='text/csv')
        response['Content-Disposition'] = 'attachment; filename=testcsv.csv'

        return response


        



class DiagnosticsApi(APIView):
    permission_classes = [AllowToAccessAdmin]
    class OutputSerializer(serializers.ModelSerializer):
        class Meta:
            model = TblDiagnostics
            fields = "__all__"

    class InputSerializer(serializers.Serializer):
        def __init__(self, command, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.fields["vin"] = serializers.CharField()
            if command == "can_dump":
                self.fields["duration"] = serializers.CharField()
                
                self.fields["unit"] = serializers.ChoiceField(
                    choices=["second", "minute"], default="second"
                )
                # here m giving can1 channel in choice
                self.fields["can_channel"] = serializers.ChoiceField(
                    choices=["can0", "can1"], default="can0"
                )
                
            else:
                raise serializers.ValidationError("Invalid command")

        def convert_to_seconds(self, str_duration: str):
            mm, ss = list(map(lambda x: int(x), str_duration.split(":")))
            total_secs =  mm*60 + ss
            return total_secs


        def validate(self, data):
            # TODO: perform some calculation based on unit conver to sec
            # data.pop("unit")
            str_duration = data.pop("duration")
            data["duration"] = self.convert_to_seconds(str_duration)
            if data["duration"] <= 900:
                return data
            else:
                raise ValidationError("Time should not be more than 15 minutes")
            

    def post(self, request, command: str):
        serializer = self.InputSerializer(command, data=request.data)
        serializer.is_valid(raise_exception=True)
        obj = diagnostics_create(command, **serializer.validated_data, user_id = request.user.id)
        serializer = self.OutputSerializer(obj)
        return JsendSuccessResponse(
            serializer.data, data_identifier="diagnostics"
        ).get_response()
class GatewaySignalsGet(APIView):
    permission_classes = [AllowToAccessAdmin]
    @transaction.atomic
    def get(self,request):
        
        vin = request.query_params["vin"]
        stime = request.query_params["start_time"]
        etime = request.query_params["end_time"]
        gateway_id = TblHvacVinGateway.objects.filter(vin=vin).values("gateway_id")
        query1 = f"SELECT DISTINCT id FROM eber_gateways_sensors_data WHERE gateway_id = '{gateway_id[0]['gateway_id']}' AND id != -1 AND __time BETWEEN '{stime}' AND '{etime}'"
        inputs = extract_druid_data_rest_api(query=query1)
        signals = get_signal_name()
        for data in inputs:
            try:
                data.update({"name":signals[data["id"]]})
            except KeyError as e:
                data.update({"name":f'signal {data["id"]}'})
        
        return JsendSuccessResponse(data=inputs,data_identifier="signal").get_response()

        
class GetDaignosticList(APIView):
    
    permission_classes = [AllowToAccessAdmin]
    pagination_class = CustomPagination()

    class InputSerializer(serializers.Serializer):
        type = serializers.ChoiceField(["CAN_DUMP", "SIGNAL_HISTORY"], required=True)
        
    class OutputSerializer(serializers.ModelSerializer):
        # username = serializers.CharField(source='user.username', read_only=True)
        class Meta:
            model = TblDiagnostics
            fields = "__all__"
            
    def get(self, request):
        can_dump_status = request.query_params['can_dump_status']
        # type = request.query_params['type']
        
        serializer = self.InputSerializer(data=request.query_params.dict())
        serializer.is_valid(raise_exception=True)
        # if bool(can_dump_status):
        diagnostics = diagnostics_list(request,user_id=request.user.id, type=serializer.validated_data['type'])
        # else:
        #     diagnostics = diagnostics_list(user_id=request.user.id, type=serializer.validated_data['type'])
        for v in diagnostics:
           
           vin_obj = TblHvacVinGateway.objects.filter(gateway_id = v['gateway_id']).first()
           v['vin'] = vin_obj.vin.vin
           v['operator_name'] = vin_obj.vin.pto.name
        
           
        queryset = self.pagination_class.paginate_queryset(queryset=diagnostics, request=request, view=self)
        total_records = self.pagination_class.page.paginator.count
        total_pages = self.pagination_class.page.paginator.num_pages
        list_obj = list(queryset)
       
            
            
        
        pagination = {"page": request.GET.get('p'),
                      "pageSize": request.GET.get('page_size'),
                      "totalPages": total_pages, "totalRecords": total_records
                      }
        diagnostic_status = {'diagnostic_status': list_obj}
        return Response({"status": "success", "data": diagnostic_status, 'pagination': pagination})
        # return JsendSuccessResponse(data=diagnostics,data_identifier="signal").get_response()

class DiagnosticDelete(APIView):
    permission_classes = [AllowToAccessAdmin]
    def delete(self, request, diagnostic_id: int):
        data = diagnostic_delete(diagnostic_id)
        if data is not None:
            return JsendSuccessResponse("Deleted Successfully").get_response()
        else:
            return JsendSuccessResponse("Something went wrong").get_response()
        
class DiagnosticCanDumpDownloadAPI(APIView):
    # permission_classes = [AllowToAccessAdmin]
    def get(self, request, gw_id, file_name):
        download_fname = download_file_from_s3(gw_id, file_name)
        doc=open(download_fname,'rb')
        response = FileResponse(doc, content_type='application/zip')
        os.remove(download_fname)
        # response['Content-Disposition'] = 'attachment; filename=testcsv.csv'
        return response

class GatewayMasterRegister(APIView):
    permission_classes = [AllowToAccessAdmin]
    class InputSerializer(serializers.Serializer):
        manufacturer = serializers.CharField(max_length=100, required=False, allow_null=True)
        serial_number = serializers.CharField(max_length=100, required=True)
        cpu_number = serializers.CharField(max_length=100, required=True)
        company_name = serializers.CharField(max_length=100, required=False, allow_null=True)

   
    def post(self, request):
        
        serializer = self.InputSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        gateway_details = gateway_master_create(**serializer.validated_data)

        
        return JsendSuccessResponse(
            data={
                "message": "CPU id is registered succesfully"
            }
        ).get_response()
        
        
        
class SimMasterRegister(APIView):
    permission_classes = [AllowToAccessAdmin]
    class InputSerializer(serializers.Serializer):
        operator = serializers.CharField(max_length=100, required=False)
        imei_number = serializers.CharField(max_length=100, required=True)
        sim_number = serializers.CharField(max_length=100, required=True)
        country = serializers.CharField(max_length=100, required=False)
        country_code = serializers.CharField(max_length=100, required=False)
   
    def post(self, request):
        serializer = self.InputSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        sim_details = sim_master_create(**serializer.validated_data)

        
        return JsendSuccessResponse(
            data={
                "message": "Sim is registered succesfully"
            }
        ).get_response()
        
        
class ListMasterGateway(APIView):
    permission_classes = [AllowToAccessAdmin]
    pagination_class = CustomPagination()
    class OutputSerializer(serializers.ModelSerializer):
        class Meta:
            model = TblGatewayMaster
            fields = "__all__"
            
    def get(self, request):
        master_gateway_data = master_gateway_list()


    
        serializer = self.OutputSerializer(master_gateway_data , many = True)
        queryset = self.pagination_class.paginate_queryset(queryset=master_gateway_data, request=request, view=self)
        total_records = self.pagination_class.page.paginator.count
        total_pages = self.pagination_class.page.paginator.num_pages
        list_obj = list(queryset)
       
            
            
        
        pagination = {"page": request.GET.get('p'),
                      "pageSize": request.GET.get('page_size'),
                      "totalPages": total_pages, "totalRecords": total_records
                      }
        master_gateway_data = {'master_gateway_list': list_obj}
        return Response({"status": "success", "data": master_gateway_data, 'pagination': pagination})
        
       

      
        

class ListMasterSim(APIView):
    permission_classes = [AllowToAccessAdmin]
    pagination_class = CustomPagination()
    class OutputSerializer(serializers.ModelSerializer):
        class Meta:
            model = TblSimMaster
            fields = "__all__"
            
    def get(self, request):
        master_sim_data = master_sim_list()
        
        serializer = self.OutputSerializer(master_sim_data , many = True)
        queryset = self.pagination_class.paginate_queryset(queryset=master_sim_data, request=request, view=self)
        total_records = self.pagination_class.page.paginator.count
        total_pages = self.pagination_class.page.paginator.num_pages
        list_obj = list(queryset)
       
        pagination = {"page": request.GET.get('p'),
                      "pageSize": request.GET.get('page_size'),
                      "totalPages": total_pages, "totalRecords": total_records
                      }
        master_sim_data = {'master_sim_list': list_obj}
        return Response({"status": "success", "data": master_sim_data, 'pagination': pagination})
       
       