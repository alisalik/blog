from ast import operator

from core.models import BaseModel
from django.db import models


class TblGatewayMaster(models.Model):
    manufacturer = models.CharField(max_length=100, blank=True, null=True)
    serial_number = models.CharField(primary_key=True, max_length=100)
    cpu_number = models.CharField(unique=True, max_length=100, blank=True, null=True)
    company_name = models.CharField(max_length=100, blank=True, null=True)
    shipping_date = models.DateTimeField(blank=True, null=True)
    assiged_to_company = models.CharField(max_length=150, blank=True, null=True)
    installation_date = models.DateField(blank=True, null=True)
    installation_location = models.CharField(max_length=100, blank=True, null=True)
    created_on = models.DateTimeField(blank=True, null=True)
    created_by = models.CharField(max_length=100, blank=True, null=True)
    updated_on = models.DateTimeField(blank=True, null=True)
    updated_by = models.CharField(max_length=100, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'tbl_gateway_master'


class TblSimMaster(models.Model):
    operator = models.CharField(max_length=100, blank=True, null=True)
    imei_number = models.CharField(max_length=100, blank=True, null=True)
    sim_number = models.CharField(primary_key=True, max_length=100)
    country = models.CharField(max_length=100, blank=True, null=True)
    country_code = models.CharField(max_length=50, blank=True, null=True)
    assiged_to_name = models.CharField(max_length=100, blank=True, null=True)
    created_on = models.DateTimeField(blank=True, null=True)
    created_by = models.CharField(max_length=100, blank=True, null=True)
    updated_on = models.DateTimeField(blank=True, null=True)
    updated_by = models.CharField(max_length=100, blank=True, null=True)

    class Meta:
        managed = False
        db_table = "tbl_sim_master"

from django.utils import timezone
class TblGateway(models.Model):
    serial_number = models.OneToOneField('TblGatewayMaster', models.DO_NOTHING, db_column='serial_number', primary_key=True)
    sim_number = models.OneToOneField('TblSimMaster', models.DO_NOTHING, db_column='sim_number', blank=True, null=True)
    gateway_status = models.CharField(max_length=18, blank=True, null=True)
    status = models.CharField(max_length=1, blank=True, null=True)
    created_at = models.DateTimeField(db_index=True, default=timezone.now)
    created_by = models.CharField(max_length=100, blank=True, null=True)
    updated_at = models.DateTimeField(blank=True, null=True)
    updated_by = models.CharField(max_length=100, blank=True, null=True)
    last_seen = models.DateTimeField(blank=True, null=True)
    firmware_version = models.CharField(max_length=100, blank=True, null=True)
    last_system_info_packet = models.JSONField(blank=True, null=True)
    index_error_code_packet = models.JSONField(blank=True, null=True)
    can0_active = models.CharField(max_length=3, blank=True, null=True)
   
    class Meta:
        managed = False
        db_table = 'tbl_gateway'



class TblDiagnostics(models.Model):
    gateway = models.ForeignKey('TblGateway', models.DO_NOTHING, blank=True, null=True)
    user = models.ForeignKey('TblUser', models.DO_NOTHING, blank=True, null=True , related_name='diagnostics')
    file_name = models.CharField(max_length=100, blank=True, null=True)
    file_url = models.CharField(max_length=2028, blank=True, null=True)
    status = models.CharField(max_length=9, blank=True, null=True)
    requested_start_time = models.DateTimeField(blank=True, null=True)
    requested_end_time = models.DateTimeField(blank=True, null=True)
    remarks = models.CharField(max_length=2048, blank=True, null=True)
    metadata = models.JSONField(blank=True, null=True)
    type = models.CharField(max_length=14, blank=True, null=True)
    can_dump_start_time = models.DateTimeField(blank=True, null=True)
    can_dump_end_time = models.DateTimeField(blank=True, null=True)
    class Meta:
        managed = False
        db_table = 'tbl_diagnostics'

class TblUser(models.Model):
    username = models.CharField(max_length=100, blank=True, null=True)
    email = models.CharField(max_length=100, blank=True, null=True)
    contact = models.BigIntegerField(blank=True, null=True)
    company_id = models.IntegerField(blank=True, null=True)
    role_code = models.CharField(max_length=100, blank=True, null=True)
    mob_otp = models.IntegerField(blank=True, null=True)
    em_otp = models.IntegerField(blank=True, null=True)
    otp_time = models.DateTimeField(blank=True, null=True)
    password = models.IntegerField(blank=True, null=True)
    last_login = models.DateTimeField(blank=True, null=True)
    status = models.CharField(max_length=1, blank=True, null=True)
    created_by = models.CharField(max_length=100, blank=True, null=True)
    created_on = models.DateTimeField(blank=True, null=True)
    updated_by = models.CharField(max_length=100, blank=True, null=True)
    updated_on = models.DateTimeField(blank=True, null=True)
    designation = models.CharField(max_length=100, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'tbl_user'