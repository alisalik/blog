import datetime

from common.services import model_update
from common.utils import get_object
from django.core.exceptions import ValidationError as DjangoValidationError
from django.db import transaction
from django.utils.timezone import now
from integrations.kafka.producer_wrapper import KafkaProducerWrapper
# from hvac.models import TblHvacVinGateway
from rest_framework import exceptions, status
from vehicle.models import TblHvacVinGateway, TblVehicle
import os
from api.settings.base import MEDIA_ROOT
from .models import TblGateway, TblGatewayMaster, TblSimMaster, TblDiagnostics, TblSimMaster
from users.models import UserProfile
from common.utils import extract_druid_data_rest_api
from core.exceptions import CustomValidation


def gateway_register(*, vin: str, serial_number: str = "", user_id : int) -> TblGateway:
    username_obj = UserProfile.objects.filter(id = user_id).first()
    username = username_obj.username
    obj = TblGatewayMaster.objects.filter(serial_number=serial_number).first()
    
    if not obj:
        raise exceptions.ValidationError(f"This serial_number:{serial_number} is not registered with us ")
    cpu_number = obj.cpu_number
    
    # check will be updated on register gateway based on our db
    hvac_vin_gateway = TblHvacVinGateway.objects.all().filter(vin=vin).first()
    if not hvac_vin_gateway:
        raise exceptions.ValidationError(f"This VIN:{vin} is not registered with us ")
    elif hvac_vin_gateway.gateway_id is not None:
        raise exceptions.ValidationError(" gateway is already mapped with vin")
        # try to check existing vin in our db
    else:
        
        if cpu_number is not None:
                # try to map gateway id with vin
            if (
                TblHvacVinGateway.objects.all()
                .filter(gateway_id=cpu_number)
                .exists()
            ): 
                raise exceptions.ValidationError(
                    "serial_num is already registered with some vehicle"
                )
            else:
                obj = TblGateway(
                    serial_number_id=cpu_number,
                    gateway_status="CONNECTED_NOTVALID",
                    status="1",
                    created_by=username,
                    updated_by=username,
                )
                obj.save()
                # updating gatewayid in hvacvingateway table
                hvac_vin_gateway.gateway_id = cpu_number
                hvac_vin_gateway.save()
                return obj
        else:
            raise exceptions.ValidationError(
                "please check and enter correct serial number "
            )


@transaction.atomic
def gateway_delete(*, serial_number: str):
    gateway = TblGateway.objects.get(serial_number=serial_number)
    gateway.status = "0"
    # marking gateway inactive
    gateway.save()


@transaction.atomic
def gateway_update(*, vin: str, **kwargs) -> TblGateway:
    # get the g/w assigned to the vin
    hvac_vin_gateway = TblHvacVinGateway.objects.all().filter(vin=vin).first()
    gateway = (
        TblGateway.objects.all()
        .filter(serial_number=hvac_vin_gateway.gateway.serial_number_id)
        .first()
    )

    # model object we want to update
    # sim exists and not assigned to any gateway
    if "sim_number" in kwargs:
        if (
            not TblSimMaster.objects.all()
            .filter(sim_number=kwargs["sim_number"])
            .exists()
        ):
            raise exceptions.ValidationError("SIM number doesn't exist in our system.")
        # if kwargs["sim_number"] != gateway.sim_number:

        # trying to change the sim number check if sim number is already allocated to other gateway
        if TblGateway.objects.all().filter(sim_number=kwargs["sim_number"]).exists():
            raise exceptions.ValidationError(
                "This SIM is already associated with another gateway."
            )
    elif "serial_number" in kwargs:
        if (
            not TblGatewayMaster.objects.all()
            .filter(serial_number=kwargs["serial_number"])
            .exists()
        ):
            raise exceptions.ValidationError(
                "Gateway serial number doesn't exist in our system."
            )
        if kwargs["serial_number"] != gateway.serial_number:
            # trying to change the serial number check if any gateway with this serial number exists in our system.
            if (
                TblGateway.objects.all()
                .filter(serial_number=kwargs["serial_number"])
                .exists()
            ):
                raise exceptions.ValidationError(
                    "Another gateway with this serial number is already registered with us."
                )

    # only when trying to change serial number of gateway serial number exists and not assigned to any gateway

    non_side_effect_fields = [i for i in kwargs]
    if "sim_number" in kwargs:
        gateway.sim_number_id = kwargs["sim_number"]
        gateway.save()
    if "serial_number" in kwargs:
        gateway.delete()
        gateway.pk = kwargs["serial_number"]
        gateway.save()
    # gateway, status = model_update(
    #     instance=gateway, fields=non_side_effect_fields, data=kwargs
    # )

    hvac_vin_gateway.gateway_id = gateway.serial_number_id

    return gateway

@transaction.atomic
def diagnostics_create(type: str, **kwargs):
    # create diagnostics entry in the database 
    type = type.upper()
    user_id = kwargs.pop("user_id")
    vin = kwargs.pop("vin")
    current_datetime = datetime.datetime.now()
    gateway_id = TblHvacVinGateway.objects.filter(vin=vin).values("gateway_id").first()['gateway_id']
    query = (
        f"SELECT * FROM eber_gateways_sensors_data WHERE id='931' AND gateway_id='{gateway_id}'  ORDER BY __time DESC LIMIT 1"
    )
    signal = extract_druid_data_rest_api(query= query)[0] # get only first record. The func returns the response in list
    if signal["value"] == 0.0:
        raise exceptions.ValidationError(f"Vehicle is not connected to system! CANDump could not be started.")
    if type == "SIGNAL_HISTORY":
        # TODO: move ali's sensor history code here
        pass
    elif type == "CAN_DUMP":
        # also create column in the table
        obj = TblDiagnostics.objects.create(type=type,
                                            gateway_id=gateway_id,
                                            user_id=user_id,
                                            requested_start_time=datetime.datetime.now(),
                                            requested_end_time=current_datetime + datetime.timedelta(seconds=kwargs["duration"]),
                                            metadata=kwargs,
                                            status="PENDING")# default in pending state.
        obj.save()
        KafkaProducerWrapper().send_can_dump_request({"can_channel": kwargs["can_channel"], 
                                                      "duration": kwargs["duration"],
                                                      "db_id": obj.id, 
                                                      "gateway_id": gateway_id,})
    return obj
        # push the record in database. 
        # req fields, gw_id, type, requested_start_time, requested_end_time, metadata, user_id
        # get the id of newly created record
        # produce a message in kafka and wait for it to get published
        # return success response
        
@transaction.atomic
def diagnostic_delete(pk):
    try:
        obj = TblDiagnostics.objects.get(id=pk)
        
        if obj is not None:
            if obj.status == "COMPLETED":
                name = obj.file_name
                file_path = os.path.join(MEDIA_ROOT, obj.gateway_id, name)
                if os.path.exists(file_path):
                    os.remove(file_path)

                obj.delete()
                # obj.save()
                return obj
            else:
                # file doesn't exist just delete the entry.
                obj.delete()
                return obj
    except TblDiagnostics.DoesNotExist:
        pass
    
    
@transaction.atomic
def gateway_master_create(
                          serial_number: str,
                          cpu_number : str,
                          company_name : str= None,
                          manufacturer: str=None,
                          ) -> TblGatewayMaster:
    
    if TblGatewayMaster.objects.filter(serial_number=serial_number).exists():
        raise exceptions.ValidationError(
            f"Serial number '{serial_number}' already exists in our system. Please choose a different one."
        )
    if TblGatewayMaster.objects.filter(cpu_number=cpu_number).exists():
        raise exceptions.ValidationError(
            f"CPU number '{cpu_number}' already exists in our system. Please choose a different one."
        )
    
        
    else:
        
        obj = TblGatewayMaster(
                    manufacturer = manufacturer,
                    serial_number = serial_number,
                    cpu_number = cpu_number,
                    company_name = company_name
                    )
        obj.save()
    return obj


@transaction.atomic
def sim_master_create(sim_number: str, 
                        imei_number: str,
                        operator : str=None,
                        country : str= None,
                        country_code : str=None) -> TblSimMaster:
    
    if (TblSimMaster.objects.all().filter(sim_number=sim_number)
                .exists()):
        raise exceptions.ValidationError(
                    "This sim_number is already exist in our system. Try another one."
                )
        
    else:
        
        obj = TblSimMaster(
                    sim_number = sim_number,
                    imei_number = imei_number,
                    operator = operator,
                    country = country,
                    country_code = country_code
                    )
        obj.save()
    return obj


