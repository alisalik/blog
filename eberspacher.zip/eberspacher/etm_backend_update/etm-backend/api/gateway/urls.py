from django.urls import path

from .views import (
    GatewayComponentsStatusGetAPI,
    GatewayDelete,
    GatewayGetAPI,
    GatewayGPSGetAPI,
    GatewayLastSignalTimestampGetAPI,
    GatewayRegister,
    GatewaySignalGetAPI,
    GatewaySignalsValuesGetAPI,
    GatewayUpdateApi,
    GatewayDiagnostic,
    DiagnosticsApi,
    GatewaySignalsGet,
    GetDaignosticList,
    DiagnosticDelete,
    DiagnosticCanDumpDownloadAPI,
    GatewayMasterRegister,
    SimMasterRegister, 
    ListMasterGateway,
    ListMasterSim,
    IndexCodeError
)

urlpatterns = [
    path(
        "register",
        GatewayRegister.as_view(),
        name="gateway.register",
    ),
    path(
        "delete",
        GatewayDelete.as_view(),
        name="gateway.delete",
    ),
    path(
        "update",
        GatewayUpdateApi.as_view(),
        name="gateway.update",
    ),
    path(
        "",
        GatewayGetAPI.as_view(),
        name="gateway.get",
    ),
    path(
        "signals",
        GatewaySignalsValuesGetAPI.as_view(),
        name="gateway.multi.signals.get",
    ),
    path(
        "signals/<str:signal_name>",
        GatewaySignalGetAPI.as_view(),
        name="gateway.signals.get",
    ),
    path(
        "components/status",
        GatewayComponentsStatusGetAPI.as_view(),
        name="gateway.components.status.get",
    ),
    path(
        "gps",
        GatewayGPSGetAPI.as_view(),
        name="gateway.gps.get",
    ),
    path(
        "last_signal_timestamp",
        GatewayLastSignalTimestampGetAPI.as_view(),
        name="gateway.last.signal.timestamp.get",
    ),
    #diagnostics related endpoints
    path(
    "diagnostic_download",
    GatewayDiagnostic.as_view(),
    name = "gateway.diagnostic.download"
    ),
    
    path(
        "index_error_code",
        IndexCodeError.as_view(),
        name="index.error.code",
    ),
    path(
    "diagnostics/list",
    GetDaignosticList.as_view(),
    name = "get.diagnostics.status"
    ),
    path(
    "<str:gw_id>/diagnostics/can_dump/download/<str:file_name>",
    DiagnosticCanDumpDownloadAPI.as_view(),
    name = "gateway.diagnostic.candump.download"
    ),
    # diagnostics create endpoint
    path(
    "diagnostics/<str:command>",
    DiagnosticsApi.as_view(),
    name = "gateway.diagnostic.download"
    ),
    path(
    "signal_list",
    GatewaySignalsGet.as_view(),
    name = "get.signal.list"
    ),
    path(
        "diagnostics/<int:diagnostic_id>/delete",
        DiagnosticDelete.as_view(),
        name="gateway.diagnostic.delete",
    ),
    path(
        "master_gateway_register",
        GatewayMasterRegister.as_view(),
        name="master.gateway.register",
    ),
    
    path(
        "master_sim_register",
        SimMasterRegister.as_view(),
        name="master.sim.register",
    ),
    
    path(
        "master_gateway_list",
        ListMasterGateway.as_view(),
        name="master.gateway.list",
    ),
    
    path(
        "master_sim_list",
        ListMasterSim.as_view(),
        name="master.sim.list",
    ),
]

