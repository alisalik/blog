import datetime
import json
from typing import Iterable
from integrations.aws.connection import S3_ACCESS_KEY, S3_SECRET_ACCESS_KEY
import boto3

import django_filters
import redis
import requests
from common.utils import extract_druid_data_rest_api
from core.exceptions import CustomValidation
from django.conf import settings
from django.core.exceptions import ObjectDoesNotExist
from rest_framework import status
from rest_framework.exceptions import APIException, NotFound, ValidationError
from django.core.exceptions import ValidationError as DjangoValidationError
from vehicle.models import TblHvacVinGateway
from django.db.models import F
from company.models import TblCompany
from users.models import UserProfile
from common.constants import OEM

from .models import TblGateway, TblDiagnostics, TblGatewayMaster , TblSimMaster
import os

redis_instance = None
if os.environ.get("PUSH_TO_REDIS", "0") == "1":
# Connect to our Redis instance
    redis_instance = redis.StrictRedis(host=settings.REDIS_HOST,
                                    password=settings.REDIS_PASSWORD,
                                    port=settings.REDIS_PORT, db=0)

def gateway_get(serial_number: str) -> Iterable[TblGateway]:
    """get gateway details   supported by the system"""
  
    gateway = TblGateway.objects.filter(serial_number=serial_number).first()
    master_obj=TblGatewayMaster.objects.filter(cpu_number=gateway.serial_number_id).first()

  
    cpu_number = gateway.serial_number_id
    company_name = master_obj.company_name
    manufacturer = master_obj.manufacturer
    serial_number = master_obj.serial_number

    if gateway is None:
        raise NotFound("Gateway not found in our system")

    return gateway, cpu_number, company_name, manufacturer, serial_number


def gateway_signal_get(signal_id: int, vin: str, gateway_cpu_id = ""):
    if bool(gateway_cpu_id):
        gateway_id = gateway_cpu_id
    else:
        try:
            hvac_vin_gateway = TblHvacVinGateway.objects.filter(vin=vin).values("gateway_id").annotate(registration_date=F("vin__registration_date")).first()
        except ObjectDoesNotExist as err:
            raise CustomValidation(
                "No Hvac Attahced to Vin", "hvac", status_code=status.HTTP_406_NOT_ACCEPTABLE
            )
        if not bool(hvac_vin_gateway):
            raise DjangoValidationError("No Hvac Attahced to Vin", "hvac", status_code=status.HTTP_406_NOT_ACCEPTABLE)
        if hvac_vin_gateway["gateway_id"] is None:
            raise ValidationError("No gateway attached to the vin")
        gateway_id = hvac_vin_gateway["gateway_id"]
        vehicle_registration_date = hvac_vin_gateway["registration_date"].strftime("%Y-%m-%d")
    signal_metadata = [signal for signal in settings.SIGNALS_METADATA if signal["id"] == signal_id][0]
    query = (
        f"SELECT * FROM eber_gateways_sensors_data WHERE id='{signal_id}'"
        + f" AND gateway_id='{gateway_id}'  and __time > '{vehicle_registration_date}' ORDER BY __time DESC LIMIT 1"
    )
    if os.environ.get("PUSH_TO_REDIS", "0") == "1":
        redis_value= json.loads(redis_instance.get("eber:gateways#"+gateway_id+":signals:#"+ str(signal_id)))
        redis_value = {} if redis_value is None else redis_value
        if bool(redis_value):
            signal = {}
            signal["unit"] = signal_metadata["unit"]
            signal["timestamp"] = redis_value["timestamp"]
            signal["value"] = round(redis_value["value"], 2)
            signal["display_name"] = signal_metadata["display_Name"]
            return signal
    else:
        signals = extract_druid_data_rest_api(query=query)
        signal = signals[0]  # as it will return only 1 record.
        # renaming stuffs
        signal["unit"] = signal_metadata["unit"]
        signal["timestamp"] = signal["__time"]
        signal["value"] = round(signal["value"], 2)
        signal["display_name"] = signal_metadata["display_Name"]
        del signal["__time"]
        return signal
    
    return {}

def gateway_signals_values_get(signal_ids: list, vin: str):
    try:
        hvac_vin_gateway = TblHvacVinGateway.objects.filter(vin=vin).values("gateway_id").annotate(registration_date=F("vin__registration_date")).first()
    except ObjectDoesNotExist as err:
        raise CustomValidation(
            "No Hvac Attahced to Vin", "hvac", status_code=status.HTTP_406_NOT_ACCEPTABLE
        )
    if not bool(hvac_vin_gateway):
        raise DjangoValidationError("No Hvac Attahced to Vin", "hvac", status_code=status.HTTP_406_NOT_ACCEPTABLE)
    if hvac_vin_gateway["gateway_id"] is None:
        raise ValidationError("No gateway attached to the vin")
    str_ids = "(" + ",".join(str(num) for num in signal_ids) + ")"
    gateway_id = hvac_vin_gateway["gateway_id"]
    vehicle_registration_date = hvac_vin_gateway["registration_date"].strftime("%Y-%m-%d")
    query = (
        f"select * from eber_gateways_sensors_data where (id,__time) in (SELECT LATEST(id),MAX(__time) FROM eber_gateways_sensors_data WHERE id in {str_ids}"
        + f" AND gateway_id='{gateway_id}' and __time > '{vehicle_registration_date}' GROUP BY gateway_id, id)"
    )
    signals = extract_druid_data_rest_api(query=query)
    resp = {}
    for s in signals:
        resp[int(s["id"])] = s
    return resp

def gateway_components_status_get(vin: str):
    try:
        hvac_vin_gateway = TblHvacVinGateway.objects.filter(vin=vin).values("gateway_id").annotate(registration_date=F("vin__registration_date")).first()
    except ObjectDoesNotExist as err:
        raise CustomValidation("No Hvac Attahced to Vin", "hvac", status_code=status.HTTP_406_NOT_ACCEPTABLE)
    if not bool(hvac_vin_gateway):
        raise DjangoValidationError("No Hvac Attahced to Vin", "hvac", status_code=status.HTTP_406_NOT_ACCEPTABLE)
    if hvac_vin_gateway["gateway_id"] is None:
        raise ValidationError("No gateway attached to the vin")
    gateway_id = hvac_vin_gateway["gateway_id"]
    vehicle_registration_date = hvac_vin_gateway["registration_date"].strftime("%Y-%m-%d")
    query = (
        "select * from eber_vehicle_components_status where (id,__time ) "
        + "in( SELECT LATEST(id),MAX(__time) FROM eber_vehicle_components_status"
        + f" WHERE gateway_id='{gateway_id}' and __time > '{vehicle_registration_date}' GROUP BY id)"
    )
    if os.environ.get("PUSH_TO_REDIS", "0") == "1":
        redis_value= json.loads(redis_instance.get("eber:gateways#"+gateway_id+":signals:types#on_off"))
        redis_value = {} if redis_value is None else redis_value
        components = []
        for c_id, c_value in redis_value.items():
            c = {}
            c["timestamp"] = c_value["timestamp"]
            c["value"] = "ON" if c_value["value"] is True else "OFF"
            c["display_name"] = [
                s["display_Name"]
                for s in settings.SIGNALS_METADATA
                if s["id"] == int(c_id)
            ][
                0
            ]  # its float in druid at it doesn't support int type
            components.append(c)

    else:
        components = extract_druid_data_rest_api(query=query)
        for c in components:
            c["timestamp"] = c["__time"]
            c["value"] = "ON" if c["value"] == "true" else "OFF"
            c["display_name"] = [
                s["display_Name"]
                for s in settings.SIGNALS_METADATA
                if s["id"] == int(c["id"])
            ][
                0
            ]  # its float in druid at it doesn't support int type
            del c["__time"]
            del c["id"]
    sorted_components = sorted(components,
                               # key=lambda d: datetime.datetime.strptime(
                               #     d["timestamp"], "%Y-%m-%dT%H:%M:%S.%f%z"
                               # ),
                               key=lambda d: d["timestamp"],
                               reverse=True,)
    return sorted_components


def gateway_gps_get(vin: str):
    try:
        hvac_vin_gateway = TblHvacVinGateway.objects.filter(vin=vin).values("gateway_id").annotate(registration_date=F("vin__registration_date")).first()
    except ObjectDoesNotExist as err:
        raise CustomValidation("No Hvac Attahced to Vin", "hvac", status_code=status.HTTP_406_NOT_ACCEPTABLE)
    if not bool(hvac_vin_gateway):
        raise DjangoValidationError("No Hvac Attahced to Vin", "hvac", status_code=status.HTTP_406_NOT_ACCEPTABLE)
    
    if hvac_vin_gateway["gateway_id"] is None:
        raise ValidationError("No gateway attached to the vin")
    gateway_id = hvac_vin_gateway["gateway_id"]
    vehicle_registration_date = hvac_vin_gateway["registration_date"].strftime("%Y-%m-%d")
    query = f"SELECT * FROM eber_vehicles_gps WHERE gateway_id='{gateway_id}' and __time > '{vehicle_registration_date}' ORDER BY __time DESC LIMIT 1"
    
    if os.environ.get("PUSH_TO_REDIS", "0") == "1":
        redis_value= json.loads(redis_instance.get("eber:gateways#"+gateway_id+":gps"))
        redis_value = {} if redis_value is None else redis_value
        gps = {}
        if bool(redis_value):
            gps["timestamp"] = redis_value["timestamp"]
            gps["lat"] = round(redis_value["lat"], 2)
            gps["long"] = round(redis_value["long"], 2)
        return gps
    else:
        gps = extract_druid_data_rest_api(query=query)[0]  # limit to only 1
        gps["timestamp"] = gps["__time"]
        # gps["lat"] = round(gps["lat"], 2)
        # gps["long"] = round(gps["long"], 2)

        del gps["__time"]
        return gps


def gateway_last_signal_timestamp_get(vin: str):
    try:
        hvac_vin_gateway = TblHvacVinGateway.objects.filter(vin=vin).values("gateway_id").annotate(registration_date=F("vin__registration_date")).first()
    except ObjectDoesNotExist as err:
        raise CustomValidation("No Hvac Attahced to Vin", "hvac", status_code=status.HTTP_406_NOT_ACCEPTABLE)
    if not bool(hvac_vin_gateway):
        raise DjangoValidationError("No Hvac Attahced to Vin", "hvac", status_code=status.HTTP_406_NOT_ACCEPTABLE)
    if hvac_vin_gateway["gateway_id"] is None:
        raise ValidationError("No gateway attached to the vin")
    gateway_id = hvac_vin_gateway["gateway_id"]
    vehicle_registration_date = hvac_vin_gateway["registration_date"].strftime("%Y-%m-%d")
    query = f"SELECT __time FROM eber_gateways_sensors_data WHERE gateway_id='{gateway_id}' and __time > '{vehicle_registration_date}'  ORDER BY __time DESC LIMIT 1"
    if os.environ.get("PUSH_TO_REDIS", "0") == "1":
        redis_value= json.loads(redis_instance.get("eber:gateways#"+gateway_id+":last_data_point"))
        redis_value = {} if redis_value is None else redis_value
        dt = datetime.datetime.fromtimestamp(redis_value['timestamp']/1000.0)
        timestamp = {"timestamp": dt.strftime('%Y-%m-%dT%H:%M:%S.%fZ')} 
        return timestamp
    else:
        #TODO: handle no data found
        timestamp = extract_druid_data_rest_api(query=query)[0]  # limit to only 1
        timestamp["timestamp"] = timestamp["__time"]
        del timestamp["__time"]
        return timestamp
    
 
def daignostic_status(gateway_id: str, type={}):
    
    can_dump_data = TblDiagnostics.objects.filter(gateway_id = gateway_id, type = type["type"]).all().order_by("-requested_end_time")
    return can_dump_data
    

def diagnostics_list(request,user_id: int=None, type: str="", can_dump_status: str=""):
    
    
    if request.auth["company_name"].split(" ")[0] == OEM:
        hard_code_company_name = TblCompany.objects.filter(id = request.auth['company_id']).first()
        user_id_obj = UserProfile.objects.filter(company_id = hard_code_company_name.id).values("id")
        diags = TblDiagnostics.objects.filter(user_id__in = user_id_obj,type = type).values("id", "gateway_id","file_name",
                                "file_url", "status","requested_start_time","requested_end_time","remarks","metadata","type",
                                "can_dump_start_time","can_dump_end_time").annotate(user_name=F('user__username')).order_by("-requested_end_time")
        
    else:
        diags = TblDiagnostics.objects.filter(type = type).values("id", "gateway_id","file_name",
                                "file_url", "status","requested_start_time","requested_end_time","remarks","metadata","type",
                                "can_dump_start_time","can_dump_end_time").annotate(user_name=F('user__username')).order_by("-requested_end_time")
            
    return diags

def download_file_from_s3(gateway_id, file_name):
    #TODO: properly handle below configuration.
    s3 = boto3.resource('s3', aws_access_key_id=S3_ACCESS_KEY, aws_secret_access_key=S3_SECRET_ACCESS_KEY)
    bucket_name = 'consat'
    env = 'dev' if settings.ENV in ('DEV', 'QC') else 'uat' 
    object_key = settings.S3_CAN_DUMP_FILE_OBJECT_KEY %(gateway_id, file_name)
    filename = file_name
    with open(filename, 'wb') as f:
        # Get the file content from S3
        obj = s3.Object(bucket_name, object_key)
        file_content = obj.get()['Body'].read()
    
        # Write the file content to the local file
        f.write(file_content)
    return filename


def master_gateway_list():
    master_gateway_list = TblGatewayMaster.objects.values("manufacturer","serial_number","cpu_number","company_name")
    for gateway in master_gateway_list:
        cpu_number = gateway["cpu_number"]
        if TblHvacVinGateway.objects.filter(gateway_id=cpu_number).exists():
            gateway["status"] = "registered"
            gateway.update(TblHvacVinGateway.objects.filter(gateway_id=cpu_number).values("vin").first())
        else:
            gateway["status"] = "not registered"
   
    return master_gateway_list

def master_sim_list():
    master_sim_list = TblSimMaster.objects.values("imei_number","operator","sim_number","country","country_code")
    for s in master_sim_list:
        sim_no = s["sim_number"]
        if TblGateway.objects.filter(sim_number = sim_no).exists():
            s["status"] = "registered"
            s.update(TblGateway.objects.filter(sim_number=sim_no).values("serial_number").first())
            
        else:
            s["status"] = "not registered"
    return master_sim_list