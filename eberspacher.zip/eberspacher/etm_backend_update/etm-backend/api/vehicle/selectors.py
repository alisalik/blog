"""getting data out of database only bussiness logic goes here
"""
import collections
import datetime
from logging import exception
from pdb import post_mortem
from typing import Dict, Iterable

import django_filters
from common.constants import DUMMY_TOKEN_DATA
from company.models import TblCompanyTagAssoc, TblDepot
from django.conf import settings
from django.core.exceptions import ValidationError as DjangoValidationError
from django.db.models import Q
from hvac.models import TblHvacComponent
from .models import TblHvacVinGateway
from pymysql import NULL
from rest_framework import exceptions
from rest_framework.exceptions import NotFound
from vehicle.models import (TblCompanyVehicleTagAssoc, TblVehicle,
                            TblVehicleAlarms, TblVehicleTagAssoc, TblMaintenanceMaster)
from gateway.models import TblGatewayMaster , TblGateway
from company.models import TblCompanyRoleAssoc
from django.db.models import F
from common.constants import COMPANY_ROLE_TABLE_COLUMN_NAME_MAPPING, ROLE_COMPANY_MAPPING
from hvac.models import TblSerialNoMaster, TblHvacComponentSupplierDetail
from common.utils import extract_druid_data_rest_api


def vehicle_get(vin: str,company_id: int, company_role: str = "") -> Dict[str, str]:
    """get vechile data, hvac_id & gateway_id of a passed vin."""
    
    vehicle = TblVehicle.objects.filter(vin=vin,status ="1").first()
    if vehicle is None:
        raise NotFound("vehicle not found in our system")
    company_role = company_role.lower()
    if company_role == "admin":
        hvac_vin_gateway = vehicle.hvac_vin_gateway.first()
        hvac_id = hvac_vin_gateway.hvac_id
        gateway_id = hvac_vin_gateway.gateway_id

        return vehicle, hvac_id, gateway_id
   
    
    
    get_pto = TblCompanyRoleAssoc.objects.filter(company_id= company_id, role_id = "3").first()
    if company_role == "operator":
        vehicle = TblVehicle.objects.filter(pto_id=company_id, vin=vin,status ="1").first()

        if vehicle is None:
            raise exceptions.PermissionDenied(
                f" Access is denied for this vehicle {vin}"
            )

    elif company_role == "pta":
        
        vehicle =  TblVehicle.objects.filter(pto_id = get_pto.parent_company_id,pta_id = company_id, vin = vin , status = "1").first()
        if vehicle is None:
            raise exceptions.PermissionDenied(
                f" Access is denied for this vehicle {vin}"
            )

    elif company_role == "service_provider":
        
        vehicle =  TblVehicle.objects.filter(pto_id = get_pto.parent_company_id, service_provider_id = company_id , vin = vin , status = "1").first()

        if vehicle is None:
            raise exceptions.PermissionDenied(
                f" Access is denied for this vehicle {vin}"
            )


    hvac_vin_gateway = vehicle.hvac_vin_gateway.first()
    hvac_id = hvac_vin_gateway.hvac_id
    gateway_id = hvac_vin_gateway.gateway_id

    # TODO: assuming the tags stored are only system tags. this will change

    return (
        vehicle,
        hvac_id,
        gateway_id,
    )


def vehicles_get(company_role: int):
    """get all vehicle based on pta/operator/service_provider/fleet/depo"""
    pass


def company_tag_get(company_id: int):
    tag_name = (
        TblCompanyTagAssoc.objects.all()
        .filter(company_id=company_id)
        .values("tag", "description")
    )

    return tag_name


def vehicles_get_by(*, filters: dict = {}):
    # NOTE: the filters passed to this function is directly applied on model class
    # pls make sure to pass dict values appropriately. an example of filters is
    # filters = {"pta": 1, "operator": 2, "fleet_id": 3}
    vehicles = TblVehicle.objects.get(**filters).all()
    return vehicles






def vehicles_alarms_get(vin:str):
    
    con_alarms_list =[]
    
    
    queryset =TblVehicleAlarms.objects.filter(vin = vin).filter(~Q(triggered_by="system"), status ="1").values("id","status","triggered_at", "triggered_by", "closed_at","closed_by",
                "metadata", "vin").annotate(color = F("type__color"),type = F("type__name"),service_provider = F("vin__service_provider__name"), bus_num = F("vin__bus_num"))
    return queryset
       
    

    
def vehicle_alarm_checkpoints_get(vin: str, id: int):
    alarm = TblVehicleAlarms.objects.get(pk= id)
    alarm_data = alarm.metadata
    alarm_type = TblVehicleAlarms.objects.filter(id = id).values("type__name")
    alarm_type_id = alarm.type_id
    user_submissions = alarm.user_submissions
    
    
    
    response = []
    # first time
    default_input = {"comment": "null", "is_checked": False}

    if alarm_type.first()["type__name"] == "Preventive":
        level = alarm_data["level"]
        col_name = "level_" + level
        level_filter = {col_name:1}
        engine_type = TblVehicle.objects.get(pk=vin).engine_type
        checklist = TblMaintenanceMaster.objects.filter(engine_type= engine_type, **level_filter).values("id","sub_component_type","check_point","job_sheet", "remarks").annotate(task = F("position"))
        if user_submissions is None:
            # first time

            for c in checklist:

                # appending default inputs

               c_updated = {**c , ** default_input}
               response.append(c_updated)


        else:

            # user_checkpoints = user_submissions["checkpoints"]
            user_checkpoints = user_submissions
            for cp in user_checkpoints:
                for c in checklist:
                    if c["id"] == cp['id']:
                        del cp["id"]
                        data = {**cp, **c}

                        response.append(data)
                        break
            #  for global comment code add
            # user_checkpoints = user_submissions["checkpoints"]
            # user_checkpoints = user_submissions
            # cp_len = len(user_checkpoints)


            # for cp in user_checkpoints:
            #     for c in checklist:
            #         try:
            #             if c["id"] == cp["id"]:
            #                 del cp["id"]
            #                 data = {**cp, **c}
            #                 response.append(data)
            #                 break
            #         except Exception as e:
            #                 pass

            # response.append(user_checkpoints[cp_len-1])







    if alarm_type.first()["type__name"] ==  "Conditional":
        trigger_obj = alarm_data["display_name"]
        if trigger_obj.split(":")[0] == "ROOM1":
            trigger_val = trigger_obj.split(":")[1]
            trigger_val = {"trigger_value" :trigger_val }

        if trigger_obj.split(":")[0] == "ROOM2":
            trigger_val = trigger_obj.split(":")[1]
            trigger_val = {"trigger_value" :trigger_val }

        # else:
        #     trigger_val = {"trigger_value" :"null" }
        checklist = TblMaintenanceMaster.objects.filter(alarm_type=alarm_type_id).values("id").annotate(condition = F("sub_component_type"), possible_reason = F("check_point"), task = F("position"))
        

        if user_submissions is None:

            for c in checklist:
                # appending default inputs
                c_updated = {**c , ** default_input}
                # data_u = {**c_updated[0:3] , **trigger_val}
                data_u = {**c_updated , **trigger_val}
                response.append(data_u)
                

        else:

            # user_checkpoints = user_submissions["checkpoints"]
            user_checkpoints = user_submissions
            for cp in user_checkpoints:
                for c in checklist:
                    if c["id"] == cp['id']:
                        del cp["id"]
                        data = {**cp, **c}
                        data_u = {**data, **trigger_val}
                        response.append(data_u)
                        break
                    
           
            
                
                

            # for global comment
            # for cp in user_checkpoints:
            #     for c in checklist:
            #         try:
            #             if c["id"] == cp["id"]:
            #                 del cp["id"]
            #                 data = {**cp, **c}
            #                 response.append(data)
            #                 break
            #         except Exception as e:
            #                 pass
            # response.append(user_checkpoints[cp_len-1])

    return response


def alarm_checklist_get(alarm_type: str, filters: dict):
    # TODO:
    # alarm_type = "Preventive|Conditional|..."
    # filters
    pass



def create_vehicle_filter(jwt_token, filter_params={}):
    # input -> this function take company_role and company_id from jwt_token
    # output -> and give vins and Tbl_vehicle_objects according to the company role and company_id
    # filter_params -> filter anything from tbl_vehicle and get objects accordingly
    
    
    company_id = jwt_token["company_id"]
    company_role_id = jwt_token["company_role_id"]
    company_role_name = jwt_token["company_role_name"]
    # rcm -> ROLE_COMPANY_MAPPING
    
    if  ROLE_COMPANY_MAPPING[company_role_id] in ["admin","app_admin"]: # company is admin / app admin
        vehicle = TblVehicle.objects.filter(**filter_params)
        
    else:
        vehicle = TblVehicle.objects.filter(
        **{COMPANY_ROLE_TABLE_COLUMN_NAME_MAPPING[company_role_name]:company_id}, **filter_params)
    
    return vehicle
        
        
def vehicle_metadata(vin:str, *args, **kwargs):
    # we get metadata
    data= []
    vehicle_obj= TblVehicleAlarms.objects.filter(vin=vin, triggered_by="system", type_id=4).first()
    if vehicle_obj is not None:
        metadata= vehicle_obj.metadata
        data.append(metadata)
    return data        
        

def hvac_vin_gateway_details(vin):
    response = []
    vin_obj = TblHvacVinGateway.objects.filter(vin = vin).values("vin", "hvac_id", "gateway_id").annotate(vin_num = F("vin__vin"), body_number = F("vin__body_number"),vehicle_manufacturer = F("vin__manufacturer"),
                model = F("vin__model") , engine = F("vin__engine_type"),ignition = F("vin__ignition"),depot_name =  F("vin__depo__name") , fleet_name =  F("vin__fleet__name"),econtrol_version = F("vin__econtrol_version"), color_code = F("vin__color_code"),
               gateway = F("gateway__serial_number"), depot_city = F("vin__depo__city"), fleet_region = F("vin__fleet__region"))
    for obj in vin_obj:
        
        gateway_id = obj["gateway"]
        if gateway_id is not None:
            gateway_obj = TblGatewayMaster.objects.filter(cpu_number = gateway_id).first()
            obj["gateway_manufacturer"] = gateway_obj.manufacturer if gateway_obj else None
            obj["serial_number"] = gateway_obj.serial_number
            firmware_obj = TblGateway.objects.filter(serial_number = gateway_id).first()
            obj["firmware_version"] = firmware_obj.firmware_version if firmware_obj else None
            obj["last_system_info_packet"] = firmware_obj.last_system_info_packet if firmware_obj else None
            
            if firmware_obj and isinstance(firmware_obj.last_system_info_packet, dict):
            # Add ICCID key if it doesn't exist
                if "ICCID" not in firmware_obj.last_system_info_packet:
                    firmware_obj.last_system_info_packet["ICCID"] = None
        hvac_id = obj["hvac_id"]
    
        hvac_components = TblHvacComponent.objects.filter(hvac_id = hvac_id).all().filter(~Q(status=0))
    
        for c in hvac_components:
            
            if c.supplier_detail_id == 1:
            # this is eberspacher unit, extract model from serial number dump database
                c.supplier_detail.component = c.component_type.name
                dump_desc = (
                    TblSerialNoMaster.objects.filter(serial_number_1=c.serial_num)
                    .first()
                    .description
                )
                dump_desc = "" if dump_desc is None else dump_desc.split(" ")


                c.supplier_detail.unit_type = dump_desc[0] if len(dump_desc) > 1 else "NA"
            
        
        hvac_obj = TblHvacComponent.objects.filter(hvac_id = hvac_id).values("supplier_detail_id","component_type_id").annotate(component_name = F("component_type__name"), supplier_name = F("supplier_detail__name"),
                        component = F("supplier_detail__component")) 

        for o in hvac_obj:
            if o["supplier_detail_id"] == 1:
                o["unit_type"] = dump_desc[0] if len(dump_desc) > 1 else "NA"
            else:
                comp_obj = TblHvacComponentSupplierDetail.objects.filter(id = o["supplier_detail_id"]).first()
                o["unit_type"] = comp_obj.unit_type
        
        get_alarms = TblVehicleAlarms.objects.filter(vin=vin, status="1", type_id=1).exists()
        
        if gateway_id is None:
            obj["vehicle_status"] = None
            
        else:   
            
            if firmware_obj.can0_active  == "ON" and not get_alarms:
                obj["vehicle_status"] = "ONLINE"
            elif firmware_obj.can0_active  == "OFF" and get_alarms:
                obj["vehicle_status"] = "OFFLINE"
            elif  firmware_obj.can0_active == "OFF" and not get_alarms:
                obj["vehicle_status"] = "SLEEPING"
            else:
                obj["vehicle_status"] = "OFFLINE" # this case when can0_active is none
        
    response.append({"vehicle":vin_obj})
    response.append({"hvac_details":hvac_obj})
    return response
        
              
     