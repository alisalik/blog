import datetime
from telnetlib import STATUS
from urllib import request

import requests
from api.settings import base
from common.services import model_update
from common.utils import generate_hvac_id, get_object
from django.db import transaction
from django.template.defaultfilters import slugify
from rest_framework import exceptions
from rest_framework.exceptions import APIException, ValidationError

from django.core import serializers
from datetime import datetime as dt
import re

from .models import (
    TblCompanyVehicleTagAssoc,
    TblHvacVinGateway,
    TblVehicle,
    TblVehicleAlarms,
    
)
from hvac.models import TblHvacComponent , TblHvacComponentSupplier
from users.models import UserProfile
from vehicle.models import TblVehicleAlarmsType
from common.constants import color_coding


@transaction.atomic
def vehicle_tag_default_create(**kwargs):
    # TODO[epic=discussion] Not creating company for PTA, PTO, service_partner.. etc.
    # is it required to do so.
    company_id = kwargs.pop("company_id")
    vin = kwargs.pop("vin")
    for k, v in kwargs.items():
        tag_name = k
        description = k
        # tag = slugify(k + " " + v)
        tag = v
        vehicle_tag_create(
            company_id=company_id,
            vin=vin,
            tag=tag,
            tag_name=tag_name,
            description=description,
        )
    return


@transaction.atomic
def vehicle_tag_create(
    *, vin: str, company_id: int, tag: str, description: str = "", tag_name: str
):
    "create company level tag"
    tag = TblCompanyVehicleTagAssoc(
        company_id=company_id,
        tag_name=tag_name,
        tag=tag,
        status="1",
        vin_id=vin,
        description=description,
    )
    tag.save()

from typing import Optional
from company.models import TblCompany
@transaction.atomic
def vehicle_register(
    *,
    # competitor_id: int,
    vin: str,
    engine_type: str = "",
    manufacturer: str = None,
    model: str =  None,
    body_number: str = None,
    registration_date =datetime.datetime.utcnow(),
    city: str = None,
    climate_zone: str = None,
    # company: str =None,
    pta_id: str = None,
    pto_id: str = "",
    service_provider_id: str = None,
    depot_id: str = "",
    fleet_id: str = "",
    plate_num: str = None,
    bus_num: str = None,
    user_id : int
):
    
    username_obj = UserProfile.objects.filter(id = user_id).first()
    user_name = username_obj.username
    vin_validation_pattern = "[a-zA-Z0-9]{17}"
    if not re.match(vin_validation_pattern, vin):
        raise ValidationError("Invalid Vin No. Please try again!")
    if TblVehicle.objects.all().filter(vin=vin, status="1").exists():
        raise exceptions.ValidationError(
            f"{vin} already registered in our system! Please check VIN again."
        )
        
    if plate_num is not None and TblVehicle.objects.all().filter(plate_num = plate_num, status ="1").exists():
        raise exceptions.ValidationError(
            f"{plate_num} already registered in our system! Please check Plate Number again."
        )
        
        
   
    
    vehicle = TblVehicle(
        vin=vin.upper(),
        engine_type=engine_type,
        manufacturer=manufacturer,
        model=model,
        body_number=body_number,
        registration_date=registration_date,
        city=city,
        climate_zone=climate_zone,
        status="1",
        pta_id=pta_id,
        pto_id=int(pto_id),
        service_provider_id=service_provider_id,
        depo_id=int(depot_id),
        fleet_id=int(fleet_id),
        plate_num = plate_num,
        created_by = user_name,
        updated_by = user_name,
        bus_num = bus_num,
        
    )
    vehicle.save()

    hvac_id = generate_hvac_id(vin=vehicle.vin)
   
    hvac = TblHvacVinGateway(hvac_id=hvac_id, vin_id=vehicle.vin, status="1", created_by = user_name, updated_by = user_name)
    hvac.save()
    vehicle.hvac_id = hvac_id
    vehicle.gateway_id = hvac.gateway_id
   
    if service_provider_id is None:
        vehicle.service_provider = None

    return vehicle

from gateway.models import TblGateway, TblDiagnostics
from vehicle.models import TblVehicleTagAssoc
@transaction.atomic
def vehicle_delete(*,vin: str):
    vehicle = TblVehicle.objects.get(pk=vin)
    vehicle.status = "0"
    hvac_vin_gateway = vehicle.hvac_vin_gateway.first()
    daignostic_gateway_delete = TblDiagnostics.objects.filter(gateway_id = hvac_vin_gateway.gateway_id).first()
    daignostic_gateway_delete.active = "0"
    gateway_delete = TblGateway.objects.filter(serial_number = hvac_vin_gateway.gateway_id).delete() #hardcode deleting gateway
    hvac_vin_gateway.gateway_id = None 
    hvac_vin_gateway.status = "0"
    hvac_component_delete = TblHvacComponent.objects.filter(hvac_id = hvac_vin_gateway.hvac_id , status = "1")
    hvac_component_delete.update(status="0")
    alarms_delete = TblVehicleAlarms.objects.filter(vin = vin,status = "1").all()
    alarms_delete.update(status="0")
 
    vehicle_assoc_tag_delete = TblVehicleTagAssoc.objects.filter(vin = vin).all()
    
    vehicle_assoc_tag_delete.update(status = "0")
    
    vehicle.save()
    hvac_vin_gateway.save()
    
    return


@transaction.atomic
def vehicle_update(*, vin: str, **kwargs) -> TblVehicle:
    non_side_effect_fields = [i for i in kwargs]
    vehicle = TblVehicle.objects.filter(vin=vin).first()

    vehicle, status = model_update(
        instance=vehicle, fields=non_side_effect_fields, data=kwargs
    )
    vehicle.save()
    return vehicle



@transaction.atomic
def vehicle_alarm_update(request,alarm_id: int, **kwargs):
    kwargs["closed_at"] = datetime.datetime.utcnow()
    kwargs["closed_by"] = request._user.username
    kwargs["status"] = 0
    non_side_effect_fields = [i for i in kwargs]    
    alarm = TblVehicleAlarms.objects.get(pk=alarm_id , status = "1")
    alarm, status = model_update(
        instance=alarm, fields=non_side_effect_fields, data=kwargs
    )
    #TODO[epic=change_color_on_alarm_close]
    
    get_vin = alarm.vin.vin
    get_open_alarms = TblVehicleAlarms.objects.filter(vin = get_vin, status = "1").exclude(id=alarm_id) .exclude(triggered_by = "system").all()
    
    color = None
    if len(get_open_alarms) == 0:
        # No open alarms, color is green
        color = "green"
    else:
        for a in get_open_alarms:
            
            if a.type_id == 2:
            
                color = "red"
                break
            elif a.type_id == 1:  # Connectivity alarm
                color = "grey"
            else:
                color = "grey" if color == "grey" else "orange"
                
  
    if color != alarm.vin.color_name: # -> only change the color of vin if the color has changed
        alarm.vin.color_name = color
        alarm.vin.color_code = color_coding[color]
        alarm.vin.save()
    
    # vin = alarm.vin -> get vin of the alarm
    # open_alarms <- get all alarms for the vin
    # open_alarms.remove(alarm) - current alarm that is being closed shouldn't be considered for color calcualtion
    # start color calcuation logic
    # color = None
    # if len(open_alarms) == 0:
            # no open alarms marks color as green
            #  color = "green"
    # else:
        # for alarm in open_alarms:
        #   type = alarm.type_id
        #   if type_id == 2 --> conditional alarm:
        #       color = "red" 
        #       break
        #   elif alarm_type_id == 1:  # connectivity alarm
        #       color = "grey"
        #   else:
        #       color = "grey" if color == "grey" else "orange" 

    # if color != vin.color_name: -> only change the color of vin if the color has changed
    #   vin.color_name = color 
    #   vin.color_code = color_coding[color]
    #   vin.save()

    alarm.save()


@transaction.atomic
def check_checklist(*,id : int, submission: dict, request ):
    
    
    dict_ = {"company_role":request.user.role_code, "user_id":request.user.id, "company_id":request.user.company_id}
    submission_u = []
    for s in submission["checkpoints"]:
       sub ={**s,**dict_}
       submission_u.append(sub)
    
   
    
    alarm = TblVehicleAlarms.objects.filter( id = id).first()
    if alarm.type.name == 'Preventive':
       
        alarm.user_submissions = submission_u
        # alarm.comment = submission["global_comment"]
        # alarm.comment = submission["checkpoints"][-1]["global_comment"]
        alarm.save()
        return alarm
    
    elif alarm.type.name == 'Conditional':
        alarm.user_submissions = submission_u
        # alarm.comment = submission["global_comment"]
        alarm.save()
        return alarm
    



@transaction.atomic
def vehicles_metadata_create(request, vin: str):
    vin_obj = TblVehicle.objects.filter(vin=vin, status = "1").first()
    
    if not vin_obj:
        raise ValidationError(f' VIN {vin} does not exist with us.')
    else:

        # mode = request.data.get('mode', None)
        mode = request.data["mode"]
        level_data = {'mode': mode}
        for i in range(1, 6):
            level_key = 'level_' + chr(ord('a') + i - 1)
            level_value = request.data.get(level_key, None)
            if level_value is None:
                raise ValidationError(f'{level_key} value is missing.')
            level_data[level_key] = level_value
        
        vehicle_alarms = TblVehicleAlarms(
            vin=vin_obj,
            type_id=4,
            triggered_at = datetime.date.today(),
            triggered_by="system",
            status="1",
            metadata=level_data
        )
        maintenance_setup_count = TblVehicleAlarms.objects.filter(type_id = 4, triggered_by = "system" , status = "1").count()
        
        vehicle_alarms.save()
        return vehicle_alarms , maintenance_setup_count


 
        
             
@transaction.atomic
def vehicle_metadata_update(request, vin, *args, **kwargs):
    vin = vin
    vehicle_alarm_obj =  TblVehicleAlarms.objects.filter(vin= vin, triggered_by = "system", status = "1").first()
    mode = request.data.get('mode', None)
    if vehicle_alarm_obj is None:
        raise ValidationError('Vehicle is not registered') 
    else:    
        if mode == 'operating_hours':
            for i in range(1, 6):
                if request.data.get(f'level {i}'):
                    level_key= f'level-{i}'
                    level_value = request.data.get(f'level {i}', None)
                    vehicle_alarm_obj.metadata[level_key] = level_value
            vehicle_alarm_obj.save()
        elif mode == 'mileage':
            for i in range(1, 6):
                if request.data.get(f'level {i}'):
                    level_key= f'level-{i}'
                    level_value = request.data.get(f'level {i}', None)
                    vehicle_alarm_obj.metadata[level_key] = level_value
            vehicle_alarm_obj.save()
        else:
            raise ValidationError('Mode is invalid')              


@transaction.atomic
def mode_time_period_create(request, vin, *args, **kwargs):
    vin= vin
    vehicle_alarm_obj = TblVehicleAlarms.objects.filter(vin= vin, triggered_by = "system", status = "1").first()
    mode = request.data.get('mode', None)
    if vehicle_alarm_obj is None:
        raise ValidationError('Vehicle is not registered') 
    else:
        if mode == 'time_period_days':
            level_data= {'mode':'time_period_days'}
            for i in range(1, 6):
                level_key = f'level-{i}'
                level_value = request.data.get(f'level {i}', None)
                if level_value is None:
                    raise ValidationError(f'{level_key} value is missing.')
                level_data[level_key]=level_value
            vehicle_alarm_obj.metadata= level_data
            vehicle_alarm_obj.save()
        elif mode == 'operating_hours':
            if mode == 'operating_hours':
                level_data= {'mode':'operating_hours'}
                for i in range(1, 6):
                    level_key = f'level-{i}'
                    level_value = request.data.get(f'level {i}', None)
                    if level_value is None:
                        raise ValidationError(f'{level_key} value is missing.')
                    level_data[level_key]=level_value
                vehicle_alarm_obj.metadata= level_data
                vehicle_alarm_obj.save()
            else:
                raise ValidationError('Mode is Invalid')

        else:
            raise ValidationError(f'Mode is Invalid') 