"""entry point for vehicle related request"""

import datetime
import json
from functools import partial
from logging import *
from urllib import response

import jwt
from api.settings.base import SECRET_KEY
from common.constants import DUMMY_TOKEN_DATA, USER_ROLE_VEHICLE_MODEL_MAPPING
from common.utils import decode_jwt_token
from core.jsend_response import JsendSuccessResponse
from core.permissions import AllowedToAccessVehicle , AllowedToUpdateAssests
from rest_framework import serializers
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from django.core.serializers import json
from core.pagination import CustomPagination


from .models import TblCompanyVehicleTagAssoc, TblVehicle, TblVehicleAlarms, TblMaintenanceMaster
from company.models import TblDepot
from .selectors import vehicle_get, vehicles_alarms_get, vehicle_alarm_checkpoints_get, vehicle_metadata, hvac_vin_gateway_details
from django.core.paginator import Paginator

from .services import (
    vehicle_alarm_update,
    vehicle_delete,
    vehicle_register,
    vehicle_tag_create,
    vehicle_tag_default_create,
    vehicle_update,
    check_checklist,
    vehicles_metadata_create,
    vehicle_metadata_update,
    mode_time_period_create, 
)
from common.utils import access_to_admin

class VehicleTagCreate(APIView):
    """Create Default Tags"""
    permission_classes = [IsAuthenticated & AllowedToAccessVehicle]
    class InputSerializer(serializers.Serializer):
        tag_name = serializers.CharField(required=True)
        tag = serializers.CharField(required=True)
        description = serializers.CharField(required=True)

    def post(self, request, vin: str):

        # NOTE: creating everything from company eberspacher
        company_id = DUMMY_TOKEN_DATA["company_id"]
        serializer = self.InputSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        vehicle_tag_create(vin=vin, company_id=company_id, **serializer.validated_data)
        return JsendSuccessResponse(data={}, data_identifier="").get_response()


class VehicleGetAPI(APIView):
    """Get a Vehicle Details"""
    permission_classes = [IsAuthenticated & AllowedToAccessVehicle]
    class OutputSerializer(serializers.ModelSerializer):
       
        class Meta:
            model = TblVehicle
            exclude = ("pta", "pto", "service_provider", "depo", "fleet")

    def get(self, request, vin: str):
        company_id = request.user.company_id
        company_role = request.auth["company_role_name"]
        
  
        
        vehicle, hvac_id, gateway_id = vehicle_get(
            vin=vin,company_id=company_id, company_role = company_role)
            
        
        serializer = self.OutputSerializer(vehicle)
        resp = {"hvac_id": hvac_id, "gateway_id": gateway_id}
        resp.update(serializer.data)  # push vehicle object to resp object
        resp.update(
            {
                "pta_name": vehicle.pta.name if vehicle.pta else None,
                "operator_name": vehicle.pto.name if vehicle.pto else None,
                "service_provider": vehicle.service_provider.name if vehicle.service_provider else None,
                "depot_name": vehicle.depo.name if vehicle.depo else None,
                "fleet_name": vehicle.fleet.name if vehicle.fleet else None,
            }
        )
        # resp.update(
        #     {   
                
        #         "pta_name": vehicle.pta.name,
        #         "operator_name": vehicle.pto.name,
        #         "service_provider": vehicle.service_provider.name,
        #         "depot_name": vehicle.depo.name,
        #         "fleet_name": vehicle.fleet.name,
        #     }
        # )
        return JsendSuccessResponse(
            data=resp | {"hvac_id": hvac_id}, data_identifier="vehicle"
        ).get_response()


class VehicleTagsDefaultCreate(APIView):
    """Create Default Tags"""
    permission_classes = [IsAuthenticated & AllowedToAccessVehicle]
    class InputSerializer(serializers.Serializer):
        PTA = serializers.CharField()
        PTO = serializers.CharField()
        service_partner = serializers.CharField()
        depot_name = serializers.CharField()
        fleet_id = serializers.CharField()

    class OutputSerializer(serializers.ModelSerializer):
        class Meta:
            model = TblVehicle
            fields = "__all__"

    def post(self, request, vin: str):
        company_id = DUMMY_TOKEN_DATA["company_id"]
        serializer = self.InputSerializer(data=request.data, partial=True)
        serializer.is_valid(raise_exception=True)
        vehicle_tag_default_create(
            vin=vin, company_id=company_id, **serializer.validated_data
        )
        return JsendSuccessResponse(data={}, data_identifier="").get_response()


class Vin(APIView):
    class OutputSerializer(serializers.Serializer):
        class Meta:
            pass

    class InputSerializer(serializers.Serializer):
        vin = serializers.CharField()
        decoder = serializers.CharField()

    def get(self, request):
        serializer = self.InputSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        decoded = vehicle_get(**serializer.validated_data)
        return Response(decoded)


class VehicleDelete(APIView):
    # TODO: perfrom solf delete
    permission_classes = [IsAuthenticated & AllowedToAccessVehicle]
    def delete(self, request, vin: str):
        
        vehicle_delete(vin=vin)
        return JsendSuccessResponse(
            {"msg": "vehicle deleted successfully."}
        ).get_response()

from company.models import TblCompany
class VehicleRegister(APIView):
    permission_classes = (IsAuthenticated,)
    
    class InputSerializer(serializers.Serializer):
        engine_type = serializers.ChoiceField(["EV", "ICE"], required=False)
        manufacturer = serializers.CharField(required=False, allow_null=True)
        model = serializers.CharField(required=False, allow_null=True)
        body_number = serializers.CharField(required=False, allow_null=True)
        depot_id = serializers.CharField()
        fleet_id = serializers.CharField()
        pto_id = serializers.CharField()
        service_provider_id = serializers.CharField(required = False, allow_null=True)
        pta_id = pta_id = serializers.CharField(required=False, allow_null=True)
        vin = serializers.CharField()
        plate_num = serializers.CharField(required=False, allow_null=True)
        bus_num = serializers.CharField(required=False, allow_null=True)

    def post(self, request, vin: str):
        # company_id = request.user.company_id
        user_id = request.auth["user_id"]
        role = request.auth["company_role_name"]
        
        var = access_to_admin(request,role )
        
        serializer = self.InputSerializer(data=request.data | {"vin": vin})
        serializer.is_valid(raise_exception=True)
        vehicle = vehicle_register(
            user_id = user_id,
            **serializer.validated_data
            
        )
        return JsendSuccessResponse(
            data={"message": "vehicle registered successfully!"}
        ).get_response()


class VehicleUpdateApi(APIView):
    permission_classes = [IsAuthenticated & AllowedToAccessVehicle & AllowedToUpdateAssests]
    class InputSerializer(serializers.ModelSerializer):
        class Meta:
            model = TblVehicle
            fields = "__all__"

    class OutputSerializer(serializers.ModelSerializer):
        class Meta:
            model = TblVehicle
            fields = "__all__"

    def post(self, request, vin: str):
        serializer = self.InputSerializer(data=request.data, partial=True)
        serializer.is_valid(raise_exception=True)
        vehicle = vehicle_update(vin=vin, **serializer.validated_data)
        data = self.OutputSerializer(vehicle).data
        

        return JsendSuccessResponse(data=data, data_identifier="vehicle").get_response()


class VehicleTagUpdateApi(APIView):
    class InputSerializer(serializers.ModelSerializer):
        class Meta:
            model = TblCompanyVehicleTagAssoc
            fields = "__all__"

    class OutputSerializer(serializers.ModelSerializer):
        class Meta:
            model = TblCompanyVehicleTagAssoc
            fields = "__all__"

    def post(self, request, vin: str):
        serializer = self.InputSerializer(data=request.data, partial=True)
        serializer.is_valid(raise_exception=True)
        component = vehicle_tag_create(vin=vin, **serializer.validated_data)
        data = self.OutputSerializer(component).data
        return JsendSuccessResponse(
            data=data, data_identifier="component"
        ).get_response()


class VehicleAlarmUpdate(APIView):
    # class OutputSerializer(serializers.Serializer):

    #     class Meta:
    #     model = TblCompanyTagAssoc
    #
    permission_classes = [IsAuthenticated & AllowedToAccessVehicle]

    class InputSerializer(serializers.Serializer):
        # status = serializers.ChoiceField(["open", "close"])
        comment = serializers.CharField(required=True)

    def post(self, request, vin: str, alarm_id: int):

        serializer = self.InputSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        

        vehicle_alarm_update(request,alarm_id=alarm_id, **request.data)
        vin_obj = TblVehicle.objects.filter(vin = vin).first()
        # new_color_vehicle = vin_obj.color_code
        return JsendSuccessResponse(
            data={"message": "updated successfully!",
                  "new_color_vehicle": vin_obj.color_code},
        ).get_response()







from core.pagination import CustomPagination
class VehicleAlarmsGet(APIView):
    """get alarms on a vehicle"""
    
    
    permission_classes = [IsAuthenticated & AllowedToAccessVehicle]
    pagination_class = CustomPagination()

    class FilterSerializer(serializers.Serializer):
        # filter results on the basis of alarm status
        status = serializers.ChoiceField(["all", "open", "close"])

    class InputSerializer(serializers.Serializer):
        status = serializers.ChoiceField(["open", "close"], required=True)

    

        class Meta:
            model = TblVehicleAlarms
            fields = "__all__"
            # depth = 1

        

    def get(self, request, vin: str):
        queryset = vehicles_alarms_get(vin = vin)
        
        queryset = self.pagination_class.paginate_queryset(queryset=queryset, request=request, view=self)
        total_records = self.pagination_class.page.paginator.count
        total_pages = self.pagination_class.page.paginator.num_pages
        
        
        d = list(queryset)
        for a in d:
            a["status"] = "open" if a["status"] == "1" else "closed"
        
        
        
        for elapsed_mins in d:
            elapsed_mins ['elapsed_mins']=(datetime.datetime.utcnow() - elapsed_mins["triggered_at"].replace(tzinfo=None)).total_seconds()//60
            
        for c in d:
            if c["status"] == 1:
                c["serial_number"] = counter
                counter += 1
        pagination = {"page": request.GET.get('p'),
                      "pageSize": request.GET.get('page_size'),
                      "totalPages": total_pages, "totalRecords": total_records
                      }
        health = {'alarms': d}
        return Response({"status": "success", "data": health, 'pagination': pagination})
  

        

class AlarmChecklist(APIView):
    class OutputSerializer(serializers.ModelSerializer):
        class Meta:
            model = TblMaintenanceMaster
            fields = "__all__"
            

        
        
    def get(self, request, vin: str, alarm_id: int):
        
        response = vehicle_alarm_checkpoints_get(vin = vin , id = alarm_id)
        
        return JsendSuccessResponse(
            data=response, data_identifier="alarm_checklist"
        ).get_response()
        

class Check_Checklist(APIView):
    
    
    class InputSerializer(serializers.Serializer):
        
        # comment = serializers.CharField()
        submission =serializers.JSONField()
        

    def post(self, request, vin: str, alarm_id :int):
   
        serializer = self.InputSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        alarm = check_checklist(id = alarm_id, request= request , **serializer.validated_data )
        
        
        
        return JsendSuccessResponse(
            data={"message": " saved data successfully in our Database!"}, data_identifier="user_submission"
        ).get_response()



class VehicleMetadataCreate(APIView):
    #  create metadata
    def post(self,request,vin):
        
        metadata= vehicles_metadata_create(request=request, vin=vin)
        return JsendSuccessResponse(
            data= {'message': 'Data Saved Successfully',
                   "maitenance_setup_count" : metadata[1]}

        ).get_response()
        
        
class VehicleMetadataUpdate(APIView):
    # metadata update
    def post(self, request, vin):
        metadata= vehicle_metadata_update(request= request, vin=vin)
        return JsendSuccessResponse(
            data={'message':'Data updated Successfully'}
        ).get_response()


class VehicleMetadata(APIView):
    # metadata get
    def get(self,request, vin):
        metadata= vehicle_metadata(vin=vin)
        return JsendSuccessResponse(
            data= metadata, data_identifier="metadata"
        ).get_response()
        
        
class ModeTimePeriodCreate(APIView):
    #  create metadata
    def post(self,request,vin):
        
        metadata= mode_time_period_create(request=request, vin=vin)
        return JsendSuccessResponse(
            data= {'message': 'Data Saved Successfully'}
        ).get_response()


class HvacVinGatewayDetails(APIView):
    def get(self, request, vin: str):
        hvac_vin_gateway_obj = hvac_vin_gateway_details(vin  = vin )
        return JsendSuccessResponse(
            data=hvac_vin_gateway_obj
        ).get_response()