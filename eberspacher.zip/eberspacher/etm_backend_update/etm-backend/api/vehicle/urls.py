from django.urls import include, path, re_path

from .views import (
    VehicleAlarmsGet,
    VehicleAlarmUpdate,
    VehicleDelete,
    VehicleGetAPI,
    VehicleRegister,
    VehicleTagCreate,
    VehicleTagsDefaultCreate,
    VehicleUpdateApi,
    AlarmChecklist,
    Check_Checklist,VehicleMetadataCreate,
    VehicleMetadataUpdate,
    VehicleMetadata,
    ModeTimePeriodCreate, 
    HvacVinGatewayDetails
    )   

urlpatterns = [
    path(
        "<str:vin>/register",
        VehicleRegister.as_view(),
        name="vehicle.register",
    ),
    path(
        "<str:vin>/tags/create/defaults",
        VehicleTagsDefaultCreate.as_view(),
        name="vehicle.tags.create.default.",
    ),
    path(
        "<str:vin>/tags/create",
        VehicleTagCreate.as_view(),
        name="vehicle.tag.create",
    ),
    path(
        "<str:vin>",
        VehicleGetAPI.as_view(),
        name="vehicles",
    ),
    path(
        "<str:vin>/delete",
        VehicleDelete.as_view(),
        name="vehicle.delete",
    ),
    path(
        "<str:vin>/update",
        VehicleUpdateApi.as_view(),
        name="vehicle.update",
    ),
    # alarms related
    path(
        "<str:vin>/alarms/<int:alarm_id>/close",
        VehicleAlarmUpdate.as_view(),
        name="vehicle.alarm.close",
    ),
    path(
        "<str:vin>/alarms",
        VehicleAlarmsGet.as_view(),
        name="vehicle.alarms.get",
    ),
    
    path(
        "<str:vin>/alarm/<int:alarm_id>/checkpoints",
        AlarmChecklist.as_view(),
        name="vehicle.alarms.checklist",
    ),
    
    path(
        "<str:vin>/alarm/<int:alarm_id>/user_submission",
        Check_Checklist.as_view(),
        name="vehicle.alarms.checklist.user_submission",
    ),
    
    path(
        '<str:vin>/metadata/create',
        VehicleMetadataCreate.as_view(),
        name ='Vehicle.metadata.create'
    
    ),
    path(
        '<str:vin>/metadata/update',
        VehicleMetadataUpdate.as_view(),
        name ='Vehicle.metadata.update'
    
    ),
    
    path(
        "<str:vin>/metadata",
        VehicleMetadata.as_view(),
        name ='vehicle.alarms.metadata'
    ),
    
    path(
        "<str:vin>/metadata_time_period/create",
        ModeTimePeriodCreate.as_view(),
        name ='vehicle.alarms.timeperiod'
    ),
    
    path(
        "<str:vin>/hvac_vin_gateway_details",
        HvacVinGatewayDetails.as_view(),
        name="hvac.vin.gateway.details",
    ),
    
    # ---------------------routing to gateway-----------------------
    path("<str:vin>/gateway/", include("gateway.urls")),
]
