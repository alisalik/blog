from company.models import TblCompany
from core.models import BaseModel
from django.db import models


class TblVehicle(BaseModel):
    vin = models.CharField(primary_key=True, max_length=100)
    engine_type = models.CharField(max_length=3, blank=True, null=True)
    manufacturer = models.CharField(max_length=100, blank=True, null=True)
    model = models.CharField(max_length=100, blank=True, null=True)
    body_number = models.CharField(max_length=100, blank=True, null=True)
    registration_date = models.DateField(blank=True, null=True)
    climate_zone = models.CharField(max_length=100, blank=True, null=True)
    city = models.CharField(max_length=100, blank=True, null=True)
    pto = models.ForeignKey(
        "company.TblCompany",
        models.DO_NOTHING,
        blank=True,
        null=True,
        related_name="pto",
    )
    pta = models.ForeignKey(
        "company.TblCompany",
        models.DO_NOTHING,
        blank=True,
        null=True,
        related_name="pta",
    )
    service_provider = models.ForeignKey(
        "company.TblCompany",
        models.DO_NOTHING,
        blank=True,
        null=True,
        related_name="service_provider",
    )
    fleet = models.ForeignKey(
        "company.TblFleet",
        models.DO_NOTHING,
        blank=True,
        null=True,
        related_name="fleet",
    )
    depo = models.ForeignKey(
        "company.TblDepot",
        models.DO_NOTHING,
        blank=True,
        null=True,
        related_name="depo",
    )
    tag = models.ForeignKey(
        "company.TblCompanyTagAssoc", models.DO_NOTHING, blank=True, null=True
    )
    color_name = models.CharField(max_length=50, blank=True, null=True,)
    color_code = models.CharField(max_length=50, blank=True, null=True, default="A7AEB4")# NOTE: hardcoded gray color code
    status = models.CharField(max_length=1, blank=True, null=True)
    plate_num = models.CharField(max_length=50,blank = True , null = True)
    bus_num = models.CharField(max_length=50, blank=True, null=True)
    econtrol_version = models.CharField(max_length=100, blank=True, null=True)
    ignition = models.CharField(max_length=3, blank=True, null=True)

    class Meta:
        managed = False
        db_table = "tbl_vehicle"


class TblVehicleAlarmsType(models.Model):
    color = models.CharField(max_length=50, blank=True, null=True)
    name = models.CharField(max_length=100, blank=True, null=True)
    status = models.CharField(max_length=1, blank=True, null=True)

    class Meta:
        managed = False
        db_table = "tbl_vehicle_alarms_type"


class TblVehicleAlarms(models.Model):
    vin = models.ForeignKey(
        "TblVehicle",
        models.DO_NOTHING,
        db_column="vin",
        blank=True,
        null=True,
        related_name="vehicle_alarms",
    )
    type = models.ForeignKey(
        "TblVehicleAlarmsType", models.DO_NOTHING, blank=True, null=True
        )
    triggered_at = models.DateTimeField(blank=True, null=True)
    triggered_by = models.CharField(max_length=7, blank=True, null=True)
    closed_at = models.DateTimeField(blank=True, null=True)
    closed_by = models.CharField(max_length=50, blank=True, null=True)
    status = models.CharField(max_length=1, blank=True, null=True)
    metadata = models.JSONField(blank=True, null=True)
    comment = models.CharField(max_length = 1000, blank = True, null = True )
    user_submissions = models.JSONField(blank = True , null= True)
    comment = models.CharField(max_length=1000, blank=True, null=True)
    class Meta:
        managed = False
        db_table = "tbl_vehicle_alarms"


class TblHvacVinGateway(BaseModel):
    hvac_id = models.CharField(primary_key=True, max_length=100)
    vin = models.ForeignKey(
        "TblVehicle",
        models.DO_NOTHING,
        db_column="vin",
        blank=True,
        null=True,
        related_name="hvac_vin_gateway",
    )
    gateway = models.ForeignKey(
        "gateway.TblGateway", models.DO_NOTHING, blank=True, null=True
    )
    status = models.CharField(max_length=1, blank=True, null=True, default="1")

    class Meta:
        managed = False
        db_table = "tbl_hvac_vin_gateway"


class TblCompanyVehicleTagAssoc(BaseModel):
    company = models.ForeignKey(TblCompany, models.DO_NOTHING, blank=True, null=True)
    tag_name = models.CharField(max_length=100, blank=True, null=True)
    tag = models.CharField(max_length=100, blank=True, null=True)
    description = models.TextField(blank=True, null=True)
    status = models.CharField(max_length=1, blank=True, null=True)

    vin = models.ForeignKey(
        "TblVehicle", models.DO_NOTHING, db_column="vin", blank=True, null=True
    )

    class Meta:
        managed = False
        db_table = "tbl_company_tag_assoc"


class TblVehicleTagAssoc(BaseModel):
    vin = models.ForeignKey('TblVehicle', models.DO_NOTHING, db_column='vin', blank=True, null=True, related_name="vehicle_tags")
    tag = models.ForeignKey(
        "company.TblCompanyTagAssoc", models.DO_NOTHING, blank=True, null=True
    )
    company_id = models.IntegerField(blank=True, null=True)
    status = models.CharField(max_length=1, blank=True, null=True)
    

    class Meta:
        managed = False
        db_table = "tbl_vehicle_tag_assoc"

class TblMaintenanceMaster(models.Model):
    engine_type = models.CharField(max_length=3, blank=True, null=True)
    position = models.CharField(max_length=50, blank=True, null=True)
    sub_component_type = models.TextField(blank=True, null=True)
    check_point = models.TextField(blank=True, null=True)
    job_sheet = models.TextField(blank=True, null=True)
    remarks = models.TextField(blank=True, null=True)
    level_a = models.SmallIntegerField(blank=True, null=True)
    level_b = models.SmallIntegerField(blank=True, null=True)
    level_c = models.SmallIntegerField(blank=True, null=True)
    level_d = models.SmallIntegerField(blank=True, null=True)
    level_e = models.SmallIntegerField(blank=True, null=True)
    status = models.CharField(max_length=1, blank=True, null=True)
    created_at = models.DateTimeField(blank=True, null=True)
    created_by = models.CharField(max_length=100, blank=True, null=True)
    updated_at = models.DateTimeField(blank=True, null=True)
    updated_by = models.CharField(max_length=100, blank=True, null=True)
    alarm_type = models.ForeignKey('TblVehicleAlarmsType', models.DO_NOTHING, db_column='alarm_type', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'tbl_maintenance_master'


class TblMaintenanceDataset(models.Model):
    engine_type = models.CharField(max_length=3, blank=True, null=True)
    climate_zone = models.CharField(max_length=100, blank=True, null=True)
    level = models.CharField(max_length=50, blank=True, null=True)
    operating_hours = models.IntegerField(blank=True, null=True)
    time_period_days = models.IntegerField(blank=True, null=True)
    distance_covered_km = models.IntegerField(blank=True, null=True)
    status = models.CharField(max_length=1, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'tbl_maintenance_dataset'