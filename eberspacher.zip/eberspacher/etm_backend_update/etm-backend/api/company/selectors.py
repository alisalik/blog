import itertools
from collections import Counter
from functools import total_ordering
from itertools import chain, count
from typing import List
from django.db.models import F
from collections import Counter
import collections
from django.db.models import Count
from common.constants import ROLE_COMPANY_MAPPING
from common.utils import company_details , company_role_details
from django.db.models import Prefetch
import timeit
from common.utils import extract_druid_data_rest_api


import requests
from common.constants import USER_ROLE_VEHICLE_MODEL_MAPPING

from common.constants import ROLE_COMPANY_MAPPING, color_coding
from common.utils import access_to_admin
from django.db.models import Q
from hvac.models import (
    TblHvacComponent,
    TblHvacComponentSupplierDetail,
    
)
from rest_framework.exceptions import NotFound
from vehicle.models import (
    TblCompanyVehicleTagAssoc,
    TblVehicle,
    TblVehicleAlarms,
    TblVehicleAlarmsType,
    TblVehicleTagAssoc,
    TblHvacVinGateway
)
from vehicle.selectors import create_vehicle_filter
from .models import (
    TblCompany,
    TblCompanyRoleAssoc,
    TblCompanyTagAssoc,
    TblDepot,
    TblFleet,
    TblDepotColor,
    TblCompanyRole,
    TblUser
)
from core.pagination import CustomPagination


def get_all_vendors():
    roles = list(TblCompanyRole.objects.exclude(name='admin'))
    data = {}
    for i in roles:
        data[i.name] = TblCompanyRoleAssoc.objects.filter(role=i.id, parent_company=None, status='1').values(
            "status").annotate(name=F("company__name"), id=F("company__id"))
    return data


def get_company(company_id: int):
    """get company based on `by`"""

    company_details = TblCompany.objects.filter(id=company_id).first()
    company_role = TblCompanyRoleAssoc.objects.filter(company_id=company_id, parent_company_id__isnull=True).first()
    if company_details is None:
        raise NotFound("company not found in our system")

    return company_details, company_role


def company_asset_count_get(company_id: int):
    # TODO[epic=fix] optimize this
    counts = {}
    vehicles = (
        TblCompanyVehicleTagAssoc.objects.filter(company_id=company_id)
        .values("vin")
        .distinct()
    )
    # FIXME remove hardcodings
    counts["vehicles"] = len(vehicles)
    counts["hvacs"] = counts["vehicles"]
    counts["gateways"] = 0
    # for v in vehicles:
    #     counts["hvacs"] += len(TblHvacVinGateway.objects.filter(vin_id=v, status="1"))
    return counts


# TODO[epic=deprication.soon] use company_get_relationships_with_others
def company_get_associations(
        *,
        company_id: str,
        pta: str = "",
        operator: str = "",
        service_provider: str = "",
        fleet: str = "",
        admin: str = "",
):
    # trying to fetch all companies of PTO

    companies = []
    role = ""

    if operator == "*":
        role = "operator"
        operators = TblCompanyRoleAssoc.objects.filter(
            role_id=3, company_id=company_id
        ).values()  # pto_id fetch
        for o in operators:
            parent_id = o["parent_compnay_id"]
            company_name = TblCompany.objects.filter(pk=parent_id).first().name
            companies.append({"id": parent_id, "name": company_name})
        return {
            "role": role,
            "companies": companies,
        }

    # {"role": "pto", "companies": [{"id":2, "name":"xyz"}, {"id":2, "name":"xyz"}, {"id":2, "name":"xyz"}]

    if pta == "*":
        role = "pta"
        ptas = (
            TblCompanyRoleAssoc.objects.filter(role_id=4, company_id=company_id)
            .all()
            .filter(~Q(parent_compnay_id=0))
        )
        for p in ptas:
            parent_id = p.parent_company

            company_name = TblCompany.objects.filter(pk=parent_id).first().name
            companies.append({"id": parent_id, "name": company_name})
        return {
            "role": role,
            "companies": companies,
        }

    if service_provider == "*":
        role = "service_provider"
        service_providers = TblCompanyRoleAssoc.objects.filter(
            role_id=5, company_id=company_id
        ).values()
        for sp in service_providers:
            parent_id = sp["parent_compnay_id"]
            company_name = TblCompany.objects.filter(pk=parent_id).first().name
            companies.append({"id": parent_id, "name": company_name})
        return {
            "role": role,
            "companies": companies,
        }

    if operator != "*" and fleet == "*":
        # req from a user who belongs to fleet operator company and want to get all the fleets.
        role = "fleet"
        fleets = TblFleet.objects.filter(company_id=int(operator)).all()
        for f in fleets:
            fleet_name = f.name
            companies.append({"id": f.id, "name": fleet_name})
        return {
            "role": role,
            "companies": companies,
        }

    if fleet != "*":
        # give depot for a fleet
        depos = TblDepot.objects.filter(fleet_id=int(fleet))
        for d in depos:
            role = "depot"
            depot_name = d.name
            companies.append({"id": d.id, "name": depot_name})
        return {
            "role": role,
            "companies": companies,
        }

    return {
        "role": role,
        "companies": companies,
        "fleet": companies,
        "depot": companies,
    }


def company_get_relationships_with_others(
        *,
        company_id: int,
        company_role_code: str = "",
):
    query_set = (
        TblCompanyRoleAssoc.objects.filter(company_id=company_id)
        .all()
        # .exclude(parent_company_id__isnull=True)
    )
    # store relations in dict
    # ex- {'pta': [(24, 'PTA 2'), (21, 'PTA1'), (23, 'PTA 1')],
    #  'service_provider': [(25, 'SP 1'), (26, 'SP 2'), (27, 'SP 3')]}
    relations = {}
    for obj in query_set:
        role = obj.role.name
        
        if obj.parent_company_id:
            name = obj.parent_company.name
            id = obj.parent_company_id
            if role in relations:
                relations[role].append((id, name))
            else:
                relations[role] = []
                relations[role].append((id, name))
        else:
            id = obj.company_id
            relations[role] = []
            name = obj.company.name
            relations[role].append((id, name))
            

    role_wise = []
    for role, compaines in relations.items():
        rel_dict = {}
        rel_dict["role"] = role
        rel_dict["companies"] = []
        for c in compaines:
            rel_dict["companies"].append({"id": c[0], "name": c[1]})
        role_wise.append(rel_dict)

    return role_wise





def company_get_vehicles(company_id: int, company_role_id: int):
    """get all the vehicles manged by the company of a specific role"""
    # get list of all the vins that are associated with company for that role
    # for ex. if company_role_id = "pta" then all the vehicles for company_id is
    # pta then return list of all the company
    pass


def company_fleets_get(company_id, role, query_params):
    
    fleets = []

    # on the basis of admin and role  -> recived fleets
    if role == "admin":

        if ("pto_id" in query_params and query_params["pto_id"]) and (
                "service_provider_id" in query_params
                and query_params["service_provider_id"]
        ):
            get_service_provider = (
                TblCompanyRoleAssoc.objects.filter(
                    parent_company_id=query_params["service_provider_id"],
                    role_id=5,
                    status="1",
                )
                .all()
                .values_list("company_id")
            )
            get_pto = (
                TblCompanyRoleAssoc.objects.filter(
                    company_id__in=get_service_provider, role_id=3, status="1"
                )
                .exclude(parent_company_id__isnull=False)
                .all()
                .values_list("company_id")
            )
            if int(query_params["pto_id"]) in [x[0] for x in get_pto]:
                fleets = (
                    TblFleet.objects.filter(company_id=int(query_params["pto_id"]))
                    .all()
                    .values("name", "id")
                )

        elif ("pto_id" in query_params and query_params["pto_id"]) or (
                "pto_id" in query_params
                and query_params["pto_id"]
                and "service_provider_id" in query_params
                and query_params["service_provider_id"] == ""
        ):
            fleets = (
                TblFleet.objects.filter(company_id=int(query_params["pto_id"]))
                .all()
                .values("name", "id")
            )
            return fleets

        elif (
                "service_provider_id" in query_params
                and query_params["service_provider_id"]
        ) or (
                "service_provider_id" in query_params
                and query_params["service_provider_id"]
                and "pto_id" in query_params
                and query_params["pto_id"] == ""
        ):
            get_service_provider = (
                TblCompanyRoleAssoc.objects.filter(
                    parent_company_id=query_params["service_provider_id"],
                    role_id=5,
                    status="1",
                )
                .all()
                .values_list("company_id")
            )
            get_pto = (
                TblCompanyRoleAssoc.objects.filter(
                    company_id__in=get_service_provider, role_id=3, status="1"
                )
                .exclude(parent_company_id__isnull=False)
                .all()
                .values_list("company_id")
            )
            fleets = (
                TblFleet.objects.filter(company_id__in=get_pto)
                .all()
                .values("name", "id")
            )

        else:
            fleets = TblFleet.objects.filter(status="1").all().values("name", "id")
            return fleets

    if role == "operator":

        if "company_id" in query_params and query_params["company_id"] == "":
            fleets = (
                TblFleet.objects.filter(company_id=company_id)
                .all()
                .values("name", "id")
            )

        else:
            get_service_provider = (
                TblCompanyRoleAssoc.objects.filter(
                    parent_company_id=int(query_params["company_id"]),
                    role_id=5,
                    status="1",
                )
                .all()
                .values_list("company_id")
            )
            get_pto = (
                TblCompanyRoleAssoc.objects.filter(
                    company_id__in=get_service_provider, role_id=3, status="1"
                )
                .exclude(parent_company_id__isnull=False)
                .all()
                .values_list("company_id")
            )
            fleets = (
                TblFleet.objects.filter(company_id__in=get_pto)
                .all()
                .values("name", "id")
            )
          
    if role == "pta":
        get_pta = (
            TblCompanyRoleAssoc.objects.filter(
                parent_company_id=company_id, role_id=4, status="1"
            )
            .all()
            .values_list("company_id")
        )
        get_pto = (
            TblCompanyRoleAssoc.objects.filter(
                company_id__in=get_pta, role_id=3, status="1"
            )
            .exclude(parent_company_id__isnull=False)
            .all()
            .values_list("company_id")
        )
        if "company_id" in query_params or query_params["company_id"] == "":
            fleets = (
                TblFleet.objects.filter(company_id__in=get_pto)
                .all()
                .values("name", "id")
            )

        else:
            if int(query_params["company_id"]) in [x[0] for x in get_pto]:
                fleets = (
                    TblFleet.objects.filter(company_id=int(query_params["company_id"]))
                    .all()
                    .values("name", "id")
                )
    

    if role == "service_provider":
        get_service_provider = (
            TblCompanyRoleAssoc.objects.filter(
                parent_company_id=company_id, role_id=5, status="1"
            )
            .all()
            .values_list("company_id")
        )
        get_pto = (
            TblCompanyRoleAssoc.objects.filter(
                company_id__in=get_service_provider, role_id=3, status="1"
            )
            .exclude(parent_company_id__isnull=False)
            .all()
            .values_list("company_id")
        )
        if "company_id" in query_params or query_params["company_id"] == "":
            fleets = (
                TblFleet.objects.filter(company_id__in=get_pto)
                .all()
                .values("name", "id")
            )

        else:
            if int(query_params["company_id"]) in [x[0] for x in get_pto]:
                fleets = (
                    TblFleet.objects.filter(company_id=int(query_params["company_id"]))
                    .all()
                    .values("name", "id")
                )

    return fleets


def company_depots_get(company_id: int, fleet_id: int, query_params={}):
    get_depot_filter = TblFleet.objects.filter(**query_params).all().values_list("id")
    query_set = TblDepot.objects.filter(
        fleet_id__in=get_depot_filter, fleet_id=fleet_id
    )
    depots = []
    for d in query_set:
        fleet_name = d.name
        depots.append({"id": d.id, "name": fleet_name})
    return depots


def hvac_units_by_brands_get(
        company_id, role, depo_id, tag_filter={}, vehicle_filter={}
):
    get_vins = (
        TblVehicle.objects.filter(**vehicle_filter, depo_id=depo_id, status="1")
        .all()
        .values_list("vin")
    )
    if bool(tag_filter):
        get_tag_vins = (
            TblVehicleTagAssoc.objects.filter(
                vin__in=get_vins, tag_id=tag_filter["tag_id"] , status = "1",
            )
            .all()
            .values_list("vin")
        )
        get_hvac = (
            TblHvacVinGateway.objects.filter(vin__in=get_tag_vins , status = "1")
            .all()
            .values_list("hvac_id")
        )
        get_hvac_details = TblHvacComponent.objects.filter(hvac_id__in=get_hvac , status = "1").all()
        response = []
        supplier_name = []
        component_name = []
        for c in get_hvac_details:
            s_name = c.supplier_detail.name
            c_name = c.component_type.name
            supplier_name.append(s_name)
            component_name.append(c_name)
        total_supplier = len(supplier_name)
        total = total_supplier
        supplier_counter = Counter(supplier_name)
        supplier_counter = dict(supplier_counter)
        supplier_counter["total"] = total_supplier
        total_component = len(component_name)
        total = total_component
        component_counter = Counter(component_name)
        component_counter = dict(component_counter)
        component_counter["total"] = total_component
        supplier_name_type = {"type": "supplier_name", "values": supplier_counter}
        response.append(supplier_name_type)
        component_name_type = {"type": "component_name", "values": component_counter}
        response.append(component_name_type)

        return response

    else:

        get_hvac = (
            TblHvacVinGateway.objects.filter(vin__in=get_vins , status = "1")
            .all()
            .values_list("hvac_id")
        )
        get_hvac_details = TblHvacComponent.objects.filter(hvac_id__in=get_hvac , status = "1").all()
        response = []
        supplier_name = []
        component_name = []
        for c in get_hvac_details:
            s_name = c.supplier_detail.name
            c_name = c.component_type.name
            supplier_name.append(s_name)
            component_name.append(c_name)
        total_supplier = len(supplier_name)
        total = total_supplier
        supplier_counter = Counter(supplier_name)
        supplier_counter = dict(supplier_counter)
        supplier_counter["total"] = total_supplier

        total_component = len(component_name)
        total = total_component
        component_counter = Counter(component_name)
        component_counter = dict(component_counter)
        component_counter["total"] = total_component
        supplier_name_type = {"type": "supplier_name", "values": supplier_counter}
        response.append(supplier_name_type)
        component_name_type = {"type": "component_name", "values": component_counter}
        response.append(component_name_type)

        return response


def vehicle_with_gateway(company_id, role, depo_id, tag_filter={}, vehicle_filter={}):
    response = []
    get_vins = (
        TblVehicle.objects.filter(**vehicle_filter, depo_id=depo_id, status="1")
        .all()
        .values_list("vin")
    )
    if bool(tag_filter):
        get_tags_vins = (
            TblVehicleTagAssoc.objects.filter(
                vin__in=get_vins, tag_id=tag_filter["tag_id"], status="1"
            )
            .all()
            .values_list("vin")
        )
        get_tags_vins_count = get_tags_vins.count()
        total_vins = {"total_vehicles": get_tags_vins_count}
        response.append(total_vins)
        get_gateway_count = (
            TblHvacVinGateway.objects.filter(vin__in=get_tags_vins, status="1")
            .all()
            .exclude(gateway_id__isnull=True)
            .count()
        )
        total_gateway = {"vehicle_with_gateway": get_gateway_count}
        response.append(total_gateway)
        return response

    else:
        get_vins_count = get_vins.count()
        get_gateway_count = (
            TblHvacVinGateway.objects.filter(vin__in=get_vins, status="1")
            .all()
            .exclude(gateway_id__isnull=True)
            .count()
        )
        total_vins = {"total_vehicles": get_vins_count}
        response.append(total_vins)
        total_gateway = {"vehicle_with_gateway": get_gateway_count}
        response.append(total_gateway)
        return response


def depos_with_colorcode_vehicle(
        company_id, role,depo_id,tag_filter={}, vehicle_filter = {}
):
    response = []

    # TODO :

    get_vins = (
        TblVehicle.objects.filter(**vehicle_filter, depo_id=depo_id, status="1")
        .all()
        .values_list("vin")
    )
    if bool(tag_filter):
        get_tag_vins = (
            TblVehicleTagAssoc.objects.filter(
                vin__in=get_vins, tag_id=tag_filter["tag_id"], status="1"
            )
            .all()
            .values_list("vin")
        )
        get_tag_vins_count = get_tag_vins.count()
        total_vins = {"total_vehicle": get_tag_vins_count}
        response.append(total_vins)
        get_color = (
            TblVehicle.objects.filter(vin__in=get_tag_vins, status="1")
            .all()
            .values_list("color_code")
        )
        get_color = list(itertools.chain(*get_color))
        vehicle_counter = Counter(get_color)
        vehicle_counter = dict(vehicle_counter)
        vehicle_type_with_color = vehicle_counter

        response.append(vehicle_type_with_color)
        return response

    else:

        get_vins_count = get_vins.count()
        total_vins = {"total_vehicle": get_vins_count}
        response.append(total_vins)
        get_color = (
            TblVehicle.objects.filter(vin__in=get_vins, status="1").all().values_list("color_code")
        )
        get_color = list(itertools.chain(*get_color))
        vehicle_counter = Counter(get_color)
        vehicle_counter = dict(vehicle_counter)
        vehicle_type_with_color = vehicle_counter
        response.append(vehicle_type_with_color)
        return response


def depo_vehicle_health_status(
        company_id, role, depo_id, tag_filter={}, vehicle_filter={}
):
    get_vins = (
        TblVehicle.objects.filter(**vehicle_filter, depo_id=depo_id)
        .all()
        .values_list("vin")
    )
    if bool(tag_filter):
        get_tag_vins = (
            TblVehicleTagAssoc.objects.filter(
                vin__in=get_vins, tag_id=tag_filter["tag_id"], status="1"
            )
            .all()
            .values_list("vin")
        )

        alarm_type = TblVehicleAlarms.objects.filter(vin__in=get_tag_vins, status="1").filter(~Q(triggered_by="system")).values("type__color").annotate(
            count=Count("type__name"), alarm_type=F("type__name"), color_code=F("type__color"))
        alarm_type_counts = TblVehicleAlarms.objects.filter(vin__in=get_tag_vins, status="1").values("type__name").count()
        alarm_type_count = {"total_count": alarm_type_counts, "alarms": alarm_type}
        return alarm_type_count


    else:

        alarm_type = TblVehicleAlarms.objects.filter(vin__in=get_vins, status="1").filter(~Q(triggered_by="system")).values("type__color").annotate(
            count=Count("type__name"), alarm_type=F("type__name"), color_code=F("type__color"))
        alarm_type_counts = TblVehicleAlarms.objects.filter(vin__in=get_vins, status="1").filter(~Q(triggered_by="system")).values("type__name").count()
        alarm_type_count = {"total_count": alarm_type_counts, "alarms": alarm_type}
        return alarm_type_count


def global_vehicle_health_status(company_id, role, vehicle_filter):
    get_vins = (
        TblVehicle.objects.filter(**vehicle_filter, status="1").all().values_list("vin")
    )

    alarm_type = TblVehicleAlarms.objects.filter(vin__in=get_vins, status="1").filter(~Q(triggered_by="system")).values("type__color").annotate(
        count=Count("type__name"), alarm_type=F("type__name"), color_code=F("type__color"))
    alarm_type_counts = TblVehicleAlarms.objects.filter(vin__in=get_vins, status="1").filter(~Q(triggered_by="system")).count()
    alarm_type_count = {"total_count": alarm_type_counts, "alarms": alarm_type}
    
    return alarm_type_count


def global_with_colorcode_vehicle(company_id, role, vehicle_filter):
    response = []

    get_vins = (
        TblVehicle.objects.filter(**vehicle_filter, status="1").all().values_list("vin")
    )
    get_vins_count = (
        TblVehicle.objects.filter(**vehicle_filter, status="1")
        .all()
        .values_list("vin")
        .count()
    )

    total_vins = {"total_vehicle": get_vins_count}
    response.append(total_vins)

    get_color = (
        TblVehicle.objects.filter(vin__in=get_vins).all().values_list("color_code")
    )

    get_color = list(itertools.chain(*get_color))

    vehicle_counter = Counter(get_color)
    vehicle_counter = dict(vehicle_counter)
    vehicle_type_with_color = vehicle_counter

    response.append(vehicle_type_with_color)
    return response


def global_depo_view(vehicle_filter, depot_filter={}):
    depot_list = TblVehicle.objects.filter(**vehicle_filter, status="1").values_list(
        "depo_id"
    )
    unique_depo_list = list(set(list(depot_list)))
    depot_color = {}

    vechile_count_objs = {}
    for depo_id in unique_depo_list:

        vins_list = TblVehicle.objects.filter(depo_id=depo_id, **vehicle_filter).all().values_list("color_name")
        vechile_count_objs[depo_id[0]] = {
            "total_vehicle_count": vins_list.count()
        }

        color = "grey"
        all_grey = True

        outlist = [item for t in list(vins_list) for item in t]
        # FIXME: hardcoded codes
        if "red" in outlist:
            color = "red"
            all_grey = False
        elif "orange" in outlist:
            all_grey = False
            color = "orange"
        elif "green" in outlist and "orange" not in outlist:
            color = "green"

        vehicle_color = "grey" if all_grey else color
        depot_color[depo_id[0]] = color

    depo_query_set = TblDepot.objects.filter(id__in=depot_list, status="1").all().values("id", "name", "fleet_id",
                                                                                         "city", "country", "lat",
                                                                                         "long", "status").annotate(
        fleet=F("fleet__name"))

    response = []
    for d in depo_query_set:
        d_id = d["id"]
        d_color = depot_color[d_id]
        v_count = vechile_count_objs[d_id]
        r = d | {"color_code": color_coding[d_color]} | {"vehicle_count": v_count}
        response.append(r)

    if bool(depot_filter):
        colorwise_response = []
        for i in response:

            if i["color_code"] == depot_filter["color_code"]:
                colorwise_response.append(i)

        return colorwise_response

    return response


def company_tags_get(company_id: int, role, **filters) -> List[TblCompanyTagAssoc]:
    
    if role == "admin":
        
        tags = TblCompanyTagAssoc.objects.filter(status="1", **filters).all()

    else:
        
        tags = TblCompanyTagAssoc.objects.filter(
            company_id=company_id, status="1", **filters
        )

    return tags


def vehicle_tag_get(vin: str, company_id: int):
    # REVIEW: refactor this
    """get all the company tags for this vehicle"""
    vehcile_tag_id = (
        TblVehicleTagAssoc.objects.all()
        .filter(vin=vin, company_id=company_id)
        .values("tag_id")
    )
    tag_ids = []
    for tag in vehcile_tag_id:
        tag_id = tag["tag_id"]
        tag_ids.append(tag_id)

    vehcile_tag_name = (
        TblCompanyTagAssoc.objects.all().filter(id__in=tag_ids).values("id","tag", "status")
    )
    tags = []
    for vehicle_tag in vehcile_tag_name:
        tag_name = vehicle_tag["tag"]
        tag_id = vehicle_tag["id"]
        tag_status = "ON" if vehicle_tag["status"] == "1" else "OFF"
        tags.append({"tag_id":tag_id,"name": tag_name, "status": tag_status})

    return tags


def get_by_depots(company_id, role, fleet_id: int, vehicle_filter):
    get_depots = (
        TblVehicle.objects.filter(Q(**vehicle_filter) | Q(fleet_id=fleet_id))
        .all()
        .values_list("depo_id")
    )
    get_depots_details = TblDepot.objects.filter(id__in=get_depots).all()
    return get_depots_details


def get_depot_based_company(company_id, role, vehicle_filter):
    get_depots_id = (
        TblVehicle.objects.filter(**vehicle_filter, status="1")
        .all()
        .values_list("depo_id")

    )
   
    depo_query_set = TblDepot.objects.filter(id__in=get_depots_id, status="1").values("id","name").annotate(
        fleet_id=F("fleet__id"), operator=F("fleet__company__name"), pto_id =F("fleet__company__id") ,fleet=F("fleet__name"))
    depot_color = {}                                                                               
    for obj in depo_query_set:
        depot_details = depos_with_colorcode_vehicle(company_id, role, obj["id"],vehicle_filter=vehicle_filter)
        vins_color = list(depot_details[1].keys())
        outlist = [i for i in vins_color]
        
        ''' dynamic color change of depot_status based on vins color'''
        
        color = "A7AEB4" # grey
        all_grey = True
        if "D21D26" in outlist: # red
            color = "D21D26" 
            all_grey = False
        elif "F57A08" in outlist: # orange
            all_grey = False
            color = "F57A08"
        elif "006B38" in outlist and "F57A08" not in outlist:
            color = "006B38"

        vehicle_color = "A7AEB4" if all_grey else color
      
       
        color_code = {"color_code" : color}
        
        obj.update(color_code)
        
       

        
        depot_open_alarm = depo_vehicle_health_status(company_id, role, obj["id"], vehicle_filter = vehicle_filter)
        color_code_counts = {k: v for d in depot_details for k, v in d.items()}
        depot_total_open_alarm = depot_open_alarm["total_count"]
        obj["vehicle_related_count"] = {"color_code_counts": color_code_counts,
                                        "open_alarms_counts": depot_total_open_alarm}

    return depo_query_set



       


def get_company_based_vehicle(company_id, role, search_string={}, vehicle_filter = {},is_gateway ={}):
    #search_string -> from this we can receive vin details from bus_number , plate_"number , body_numner and vehicles
    if bool(is_gateway) == True:
        get_vehicles = TblVehicle.objects.filter(Q(vin__icontains=search_string)|Q(body_number__icontains=search_string)
                                                 |Q(plate_num__icontains=search_string)
                                                 |Q(bus_num__icontains=search_string),status = "1", **vehicle_filter).all().values("vin")
        get_vehicles_s = TblHvacVinGateway.objects.filter(vin__in = get_vehicles).exclude(gateway_id__isnull = True).values("vin").annotate(body_number =F("vin__body_number"),plate_num = F("vin__plate_num"),bus_num = F("vin__bus_num"))
        
    else:  
        get_vehicles_s = (
            TblVehicle.objects.filter(
                Q(vin__icontains=search_string)
                | Q(body_number__icontains=search_string)
                | Q(plate_num__icontains=search_string)
                | Q(bus_num__icontains=search_string),status="1", **vehicle_filter,).all().values("vin", "body_number", "plate_num","bus_num"))
        
    
    for v in get_vehicles_s:
       gateway_id = TblHvacVinGateway.objects.filter( vin = v["vin"]).first()
       v["cpu_id"] = gateway_id.gateway_id


    return get_vehicles_s


def get_tag_basedon_depot(company_id, role, depo_id):
    get_vins = (
        TblVehicle.objects.filter(depo_id=depo_id, status="1").all().values_list("vin")
    )
    if role == "admin":
        get_tag_id = TblVehicleTagAssoc.objects.filter(
            vin__in=get_vins, status="1"
        ).values_list("tag_id")
        query_set_tag = TblCompanyTagAssoc.objects.filter(
            id__in=get_tag_id, status="1"
        ).all()

    else:

        get_tag_id = TblVehicleTagAssoc.objects.filter(
            vin__in=get_vins, status="1"
        ).values_list("tag_id")
        query_set_tag = TblCompanyTagAssoc.objects.filter(
            id__in=get_tag_id, status="1", company_id=company_id
        ).all()
    return query_set_tag


def depot_vehicle_status(
        company_id, role, depo_id: int, tag_filter={}, vehicle_filter={}
):
    get_vins = (
        TblVehicle.objects.filter(**vehicle_filter, depo_id=depo_id, status="1")
        .all()
        .values_list("vin")
    )
    if bool(tag_filter):
        #    on the basis of depot and tag_id -> fetch the details of vins
        vehicle_query_set = TblVehicleTagAssoc.objects.filter(vin__in=get_vins, tag_id=tag_filter["tag_id"]) \
            .values("vin").annotate(engine_type=F("vin__engine_type"), body_number=F("vin__body_number"),
                                    manufacturer=F("vin__manufacturer"), color_code=F("vin__color_code"),
                                    model=F("vin__model"), color_name=F("vin__color_name"), status=F("vin__status"),
                                    service_provider=F("vin__service_provider__name"), bus_num=F("vin__bus_num"),
                                    fleet=F("vin__fleet__name"), plate_num=F("vin__plate_num"),
                                    depo=F("vin__depo__name"), tag=F("vin__tag"))
    else:

        vehicle_query_set = TblVehicle.objects.filter(
            **vehicle_filter, depo_id=depo_id, status="1"
        ).values("vin", "engine_type", "manufacturer", "model", "body_number", "color_code", "color_name", "bus_num", "plate_num", "tag", "status" ,"ignition").annotate(
            service_provider=F("service_provider__name"), fleet=F("fleet__name"), depo=F("depo__name"))
        
    for a in vehicle_query_set:
        gateway_id = TblHvacVinGateway.objects.filter(vin = a["vin"]).first()
        a["cpu_id"] = gateway_id.gateway_id  if gateway_id else None
        get_alarms = TblVehicleAlarms.objects.filter(vin=a["vin"], status="1", type_id=1).exists()
        if gateway_id is None or gateway_id.gateway is None:
            a["vehicle_status"] = None
        
        else:    
            signals = extract_druid_data_rest_api(query=query)
            if gateway_id.gateway.can0_active == "ON" and not get_alarms:
                a["vehicle_status"] = "ONLINE"
            elif gateway_id.gateway.can0_active == "OFF" and get_alarms:
                a["vehicle_status"] = "OFFLINE"
            elif gateway_id.gateway.can0_active == "OFF" and not get_alarms:
                a["vehicle_status"] = "SLEEPING"
            else:
                a["vehicle_status"] = "OFFLINE" # this case when can0_active is none
        
        
        
        open_alarms = TblVehicleAlarms.objects.filter(vin=a["vin"], status="1").filter(~Q(triggered_by ="system")).all().count()
        open_alarms = {"open_alarm_count": open_alarms}
        a.update(open_alarms)
    
       
    return vehicle_query_set





def assets_count(company_id, role, vehicle_filter):
    response = []
    
    filter_vins = (
        TblVehicle.objects.filter(**vehicle_filter, status="1").all().values_list("vin")
    )
    get_vins = TblHvacVinGateway.objects.filter(vin__in=filter_vins, status = "1").all()
    get_vins_count = get_vins.values_list("vin").count()
    get_hvac = get_vins.values_list("hvac_id")
    get_hvac_components_count = (
        TblHvacComponent.objects.filter(hvac_id__in=get_hvac, status = "1")
        .values_list("component_type_id")
        .count()
    )
    get_gateway_count = get_vins.exclude(gateway_id__isnull=True).count()
    maintanence_setup_count = TblVehicleAlarms.objects.filter(vin__in = filter_vins,type_id = 4, triggered_by = "system" , status = "1").count()
    assest_count = {
        "vehicle_count": get_vins_count,
        "hvac_count": get_hvac_components_count,
        "gateway_count": get_gateway_count,
        "maintanence_setup_count":maintanence_setup_count
    }
    response.append(assest_count)
    return response


def health_status(company_id, role, vehicle_filter={}):
    get_vins = TblVehicle.objects.filter(**vehicle_filter, status="1")
    get_alarms = (
        TblVehicleAlarms.objects.filter(vin__in=get_vins)
        .exclude(triggered_by ="system")
        .all()
        .values("id", "vin", "triggered_at", "triggered_by", "metadata", "status", "closed_at", "closed_by").
        annotate(service_provider=F('vin__service_provider__name'), fleet=F('vin__fleet__name'),
                 depo=F("vin__depo__name"), bus_num = F("vin__bus_num"),
                 color=F("type__color"), type=F("type__name"))

    )

   
    return get_alarms


def fleet_get(*, company_id: int, fleet_id: int):
    fleet_obj = TblFleet.objects.filter(company_id=company_id, id=fleet_id).first()
    if fleet_obj is None:
        raise NotFound("fleet not found in our system")

    return fleet_obj


def depot_get(*, fleet_id: int, depot_id: int):
    depot_obj = TblDepot.objects.filter(fleet_id=fleet_id, id=depot_id).first()
    if depot_obj is None:
        raise NotFound("depot not found in our system")

    return depot_obj


def get_company_list(company_id):
    company_list = TblCompanyRoleAssoc.objects.filter(parent_company_id__isnull=True).all().values(
        "company_id").annotate(company_name=F("company__name"), role=F("role__description"))
    return company_list


def get_fleet_list(request,company_id):
    type_ = company_details(request, company_id)
    
    if type_ == 'global':
        get_ptos= TblCompanyRoleAssoc.objects.filter(company_id = company_id, role_id = 3).values_list("parent_company_id")
        
        fleet_list_1 = TblFleet.objects.filter(company_id__in = get_ptos).values("name", "id", "region").annotate(
        company_name=F("company__name"), climate_zone=F("climate_zone__name"))
        return fleet_list_1
    
   
    elif type_ == 'operator':
        fleet_list_2 = TblFleet.objects.filter(company_id = company_id).values("name", "id", "region").annotate(
        company_name=F("company__name"), climate_zone=F("climate_zone__name"))
        return fleet_list_2
    
#  if int(query_params["company_id"]) in [x[0] for x in get_pto]:
#                 fleets = (
#                     TblFleet.objects.filter(company_id=int(query_params["company_id"]))
#                     .all()
#                     .values("name", "id")
#                 )

def operatot_fleet_list(request,company_id): 
    '''assuming  here correct company_id is only operaror id in url which is  assosciated with loggedin company'''
    type_ = company_role_details(request, company_id)
    
    if type_ == 'global':
        get_ptos= TblCompanyRoleAssoc.objects.filter(company_id = request.auth["company_id"], role_id = 3).values_list("parent_company_id")
        get_pto = [x[0] for x in get_ptos]
        fleet_list_1 = TblFleet.objects.filter(company_id = company_id).values("name", "id", "region").annotate(
        company_name=F("company__name"), climate_zone=F("climate_zone__name"))
        return fleet_list_1
    
   
    elif type_ == 'operator':
        fleet_list_2 = TblFleet.objects.filter(company_id = company_id).values("name", "id", "region").annotate(
        company_name=F("company__name"), climate_zone=F("climate_zone__name"))
        return fleet_list_2
    
def get_depot_list(company_id, fleet_id):
    
    depot_list = TblDepot.objects.filter(fleet_id=fleet_id).values("name", "id")
    return depot_list


def system_settings_count(company_id):
    response = []

    # company_count = TblDepot.objects.all().values("id","fleet__id","fleet__company__id").aggregate(depot_count = Count("id"),fleet_count = Count("fleet__id", distinct = True),company_count = Count("fleet__company__id", distinct= True))

    company_count = TblCompany.objects.values("id").aggregate(total_company=Count("id"))
    response.append(company_count)
    fleet_count = TblFleet.objects.values("id").aggregate(total_fleet=Count("id"))
    response.append(fleet_count)
    depot_count = TblDepot.objects.values("id").aggregate(total_depot=Count("id"))
    response.append(depot_count)
    user_obj = TblUser.objects.values("id").aggregate(total_user=Count("id"))
    response.append(user_obj)
    role_obj = TblCompanyRole.objects.filter(scope = "USER").count()
    response.append({"user_role": role_obj})
    

    return response


def company_system_settimgs_count(request,company_id):
    type_ = company_details(request, company_id)
    response = []
    if type_ == 'operator':
        fleet_ids = TblFleet.objects.filter(company_id = company_id).values("id")
       
    elif type_ == 'global':
        get_ptos= TblCompanyRoleAssoc.objects.filter(company_id = company_id, role_id = 3).values_list("parent_company_id")
        fleet_ids = TblFleet.objects.filter(company_id__in = get_ptos).values("id")
    
    fleet_count = fleet_ids.aggregate(total_fleet = Count("id"))
    response.append(fleet_count)
    depot_count = TblDepot.objects.filter(fleet_id__in=fleet_ids).values("fleet_id").aggregate(total_depot=Count('id'))
    response.append(depot_count)
    user_obj = TblUser.objects.filter(company_id = company_id).values("id").aggregate(total_user=Count("id"))
    response.append(user_obj)
    role_obj = TblCompanyRole.objects.filter(scope = "USER").count()
    response.append({"user_role": role_obj})  
    return response



def depot_list_based_on_company(request,company_id: int):
    type_ = company_details(request, company_id)
   
    if type_ == 'global':
        get_ptos = TblCompanyRoleAssoc.objects.filter(company_id = company_id, role_id = 3).values_list("parent_company_id")
        fleet_id_list = TblFleet.objects.filter(company_id__in = get_ptos).values("id")
        depot_list1 = TblDepot.objects.filter(fleet_id__in = fleet_id_list).all().values("id", "name", "address","city").annotate(fleet_name=F("fleet__name"))
        return depot_list1
    
    elif type_ == 'operator':
        fleet_id_list = TblFleet.objects.filter(company_id = company_id).values("id")
        depot_list2 = TblDepot.objects.filter(fleet_id__in = fleet_id_list).all().values("id", "name", "address",
                                                                                    "city").annotate(fleet_name=F("fleet__name"))
        return depot_list2



def company_active_assoc_get(request, filters: dict= {}):
    vehicle_filter = create_vehicle_filter(request.auth.payload, filter_params=filters)
    qs =vehicle_filter.prefetch_related(Prefetch('fleet', queryset=TblFleet.objects.all()),
                                        Prefetch('service_provider', queryset=TblCompany.objects.all()),
                                        Prefetch('pto', queryset=TblCompany.objects.all()),
                                        Prefetch('depo', queryset=TblDepot.objects.all()),)
    fleets ={}
    service_providers= {}
    operators= {}
    depot = {}
    # for v in qs:
    #     fleets[v.fleet.id] = v.fleet.name
    #     service_providers[v.service_provider.id] = v.service_provider.name
    #     operators[v.pto.id] = v.pto.name
    #     depot[v.depo.id] = v.depo.name
    
    for v in qs:
        if v.fleet:
            fleets[v.fleet.id] = v.fleet.name
        if v.service_provider:
            service_providers[v.service_provider.id] = v.service_provider.name
        if v.pto:
            operators[v.pto.id] = v.pto.name
        if v.depo:
            depot[v.depo.id] = v.depo.name
    
    depot_list = vehicle_filter.values_list(
        "depo_id"
    )
    unique_depo_list = list(set(list(depot_list)))
    depot_color = {}

    vechile_count_objs = {}
    for depo_id in unique_depo_list:

        vins_list = TblVehicle.objects.filter(depo_id=depo_id, **filters).all().values_list("color_code")
        vechile_count_objs[depo_id[0]] = {
            "total_vehicle_count": vins_list.count()
        }

        color = "A7AEB4" #"grey"
        all_grey = True

        outlist = [item for t in list(vins_list) for item in t]
        # FIXME: hardcoded codes
        if "D21D26" in outlist: # red
            color = "D21D26"
            all_grey = False
        elif "F2AF13" in outlist: # orange
            all_grey = False
            color = "F2AF13"
        elif "006B38" in outlist and "F2AF13" not in outlist:
            color = "006B38" #green

        vehicle_color = "A7AEB4" if all_grey else color
        depot_color[depo_id[0]] = color
        
    return { "fleets": fleets,
            "service_providers": service_providers,
            "operators": operators,
            "depots": depot,
            "depot_color": depot_color}
    

def depots_taglist(depo_id):
    get_vins = TblVehicle.objects.filter(depo_id = depo_id).values("vin")
    get_tags_id = TblVehicleTagAssoc.objects.filter(vin__in = get_vins).values("tag_id")
    # get_tag_names = list(TblCompanyTagAssoc.objects.filter(id__in=get_tags_id).values_list("tag","id"))
    get_tag_names = TblCompanyTagAssoc.objects.filter(id__in=get_tags_id).annotate(tag_ = F("tag"), tag_id = F("id")).values("tag_" , "tag_id")
    return get_tag_names

    
    
