from rest_framework.permissions import BasePermission


class IsAdminPermission(BasePermission):
    def has_permission(self, request, view):

        if not request.user.is_authenticated:
            return False
        if not request.user.role_code in ['admin']:
            return False
        # if not request.auth["company_role_name"] in ['admin']:
        #     return False

