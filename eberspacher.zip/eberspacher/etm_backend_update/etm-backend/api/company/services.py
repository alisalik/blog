from datetime import datetime as dt
import time
import re

from common.services import model_update
from common.utils import get_object
from company.selectors import company_tags_get
from core.exceptions import CustomValidation
from django.core.exceptions import ValidationError as DjangoValidationError
from django.db import transaction
from django.utils.timezone import now
from rest_framework import exceptions, status
from rest_framework.exceptions import ValidationError
from rest_framework.response import Response
from users.models import UserProfile
from vehicle.models import TblVehicleTagAssoc , TblVehicle


from .models import (TblCompany, TblCompanyRole, TblCompanyRoleAssoc,
                     TblCompanyTagAssoc, TblDepot, TblFleet, TblUser)

from users.models import UserProfile
from django.db.models import Q

@transaction.atomic
def company_relation_api(data, base_company, base_comp_role_id):
    entries = []
    base_comp_role_id = TblCompanyRoleAssoc.objects.filter(company_id = base_company, parent_company_id__isnull=True).first()
    try:
        check_relation = TblCompanyRoleAssoc.objects.filter(company_id=base_company, parent_company_id__isnull=False)
        role_relation_id = [i.role_id for i in check_relation]
        check_relation_ids = [i.parent_company_id for i in check_relation]
        to_delete = list(set(check_relation_ids) - set(data))
        to_add = list(set(data) - set(check_relation_ids))
        if to_delete:
            delete_role_id=TblCompanyRoleAssoc.objects.filter(parent_company_id__in=to_delete).first().role_id
            TblCompanyRoleAssoc.objects.filter(company_id=base_company , parent_company_id__in=to_delete).delete()
            TblCompanyRoleAssoc.objects.filter(company_id__in = to_delete, parent_company_id = base_company).delete()
            
            TblVehicle.objects.filter(Q(pta_id__in=to_delete) | Q(service_provider_id__in=to_delete)).update(pta_id=None, service_provider_id=None)
            

        if to_add:
            to_add_query = TblCompanyRoleAssoc.objects.filter(company_id__in=to_add, parent_company_id__isnull=True)
            if to_add_query:
                entries += [
                    TblCompanyRoleAssoc(company_id=base_company, parent_company_id=i.company_id, role_id=i.role_id,
                                        status=1, created_by='admin') for i in to_add_query]
                entries += [TblCompanyRoleAssoc(company_id=i.company_id, parent_company_id=base_company,
                                                role_id=base_comp_role_id.role_id, status=1, created_by='admin') for i in
                            to_add_query]
                TblCompanyRoleAssoc.objects.bulk_create(entries)
        # else:
        #     return True, "Companie's relations already exists", status.HTTP_200_OK
    except Exception as e:
        return False, str(e), status.HTTP_400_BAD_REQUEST
    return True, 'Modifications Saved Successfully', status.HTTP_200_OK


@transaction.atomic
def company_role_assign(company_id: int, role_id: int):
    # TODO[epic=validation] is role_id & company_id correct?
    # is the role that we are trying to assign already assigned to the company
    company_role_assoc = TblCompanyRoleAssoc(
        company_id=company_id, role_id=role_id, status="1"
    )
    company_role_assoc.save()
    return company_role_assoc


@transaction.atomic
def vehicle_company_tag_assign(vin: str, company_id: int, user_id: int ,tag: str):
    """assign a tag to a vehicle"""
    username_obj= UserProfile.objects.filter(id = user_id).first()
    username = username_obj.username
    company_tag = TblCompanyTagAssoc.objects.filter(
        tag=tag, company_id=company_id
    ).first()
    if not company_tag:
        # tag doesn't exit create a tag
        company_tag = company_tag_create(company_id=company_id, tag=tag)
    else:
        # TODO: remove company_id from here as it can be fetched through foreign key

        # company tag exists check if it is already assigned to vin
        vehicle_company_tag = TblVehicleTagAssoc.objects.filter(
            vin=vin, tag=company_tag, company_id=company_id, status="1"
        )
        if vehicle_company_tag:
            # tag is already on the vin. skip it
            return vehicle_company_tag
    # assign the tag to vehicle
    vehicle_company_tag = TblVehicleTagAssoc(
        vin_id=vin, tag=company_tag, status="1", company_id=company_id,
        created_by = username, updated_by = username
    )  # NOTE: no check on vin as premission class will check it.
    vehicle_company_tag.save()
    return vehicle_company_tag


def vehicle_assoc_tag_remove(vin, tag_id):
    remove_tag = TblVehicleTagAssoc.objects.filter(vin = vin, tag_id = tag_id , status = "1").first()
    if remove_tag is None:
        raise ValidationError(f" tag_id {tag_id} is not associated with {vin}")
    tag_name = remove_tag.tag.tag
    remove_tag.delete() # we just remove the tag associated with vehicle and doing hard delete
    return remove_tag, tag_name
    
    


@transaction.atomic
def company_register(
        *, role_id: int, name: str, description: str = "", user_email: str
):
    # TODO[epic=fix] For deleted  company make sure we just set the value of status flag to 1
    # TODO[epic=validation] make sure that company we are trying to register is not already present in the system.
    company = TblCompany(
        name=name,
        description=description,
        status="1",
    )
    company.save()
    company_role_assoc = TblCompanyRoleAssoc(
        company_id=company.id, role_id=role_id, status="1"
    )
    company_role_assoc.save()
    # TODO[epic=discussion] What should be the primary key of the tbl_user column. and even if company has multiple roles
    # differnt default user should be created for the same.
    user = TblUser(
        username=user_email,
        email=user_email,
        password="1234",
        company_role_id=company_role_assoc.id,
        status="1",
    )
    user.save()
    return (company, user)


@transaction.atomic
def company_tag_create(
        *, company_id: int, company: str = "", tag: str, tag_name: str = "", description: str = "", role: str = ""
):
    tags = company_tags_get(company_id=company_id, role=role, tag=tag)
    if tags.exists():
        raise CustomValidation(
            "Resource already exists", "tag", status_code=status.HTTP_409_CONFLICT
        )
    tag = TblCompanyTagAssoc(
        tag=tag,
        tag_name=tag_name,
        description=description,
        status="1",
        company_id=company_id,
        created_by=company,
        updated_by=company
    )

    tag.save()
    return tag


@transaction.atomic
def company_delete(*, company_id: int):
    company_d = TblCompany.objects.get(pk=company_id)
    company_d.status = "0"
    company_d.save()

    return company_d


@transaction.atomic
def company_update(*, company_id: int = 0, **kwargs) -> TblCompany:
    non_side_effect_fields = [i for i in kwargs]

    company_u = TblCompany.objects.filter(id=company_id).first()
    if company_u is None:
        raise ValidationError("company is not registered with us")

    company = TblCompany.objects.filter(name=kwargs["name"])
    if len(company) > 1:
        raise ValidationError("company name should be unique")

    if len(company) == 1 and company.first().id == company_id:
        company_u = model_update(instance=company_u, fields=non_side_effect_fields, data=kwargs)

    elif len(company) == 0:
        company_u = model_update(
            instance=company_u, fields=non_side_effect_fields, data=kwargs)
    else:
        raise ValidationError("name should be unique")

    return company_u[0]

    

import re
@transaction.atomic
def company_onboarding(*, role_id: int,

                       name: str = "",
                       website: str,
                       address: str,
                       city: str = "",
                       country: str = "",
                       description: str = ""
                       ):
 
    
    name_regex = r'^[A-Z][\w&\-.: ]*[a-zA-Z\d]$'
    if not re.match(name_regex, name):
        raise ValidationError("Invalid company name")
    company_obj = TblCompany.objects.filter(name=name).first()
    if company_obj is not None:
        raise ValidationError("company is already registered with us ")

    else:
        company = TblCompany(name=name,
                             website=website,
                             address=address,
                             city=city,
                             status="1",
                             country=country,
                             description=description,
                             )

        company.save()

        company_role_assoc = TblCompanyRoleAssoc(
            company_id=company.id, role_id=role_id, status="1"
        )
        company_role_assoc.save()
        company_role_assoc = TblCompanyRoleAssoc(company_id=1, parent_company_id=company.id, role_id=role_id,
                                                 status="1")
        company_role_assoc.save()

    #    todo : make entry of company in tbl_user

    return company, company_role_assoc


@transaction.atomic
def fleet_register(*, company_id: int,user_id: int, name: str = "", climate_zone_id: int, description: str,region : str) -> TblFleet:
    username_obj = UserProfile.objects.filter(id = user_id).first()
    username = username_obj.username
    fleet = TblFleet.objects.filter(company_id=company_id).all()
    # trying to avoid the duplicacy of registred the fleet with the same name
    for f in fleet:
        if f.name == name:
            raise ValidationError("fleet is already registered with this company")
    else:
        fleet = TblFleet(company_id=company_id,
                         name=name,
                         climate_zone_id=climate_zone_id,
                         status="1",
                         region = region,
                         description=description,
                         created_by=username,
                         updated_by=username,
                         )
        fleet.save()
        return fleet


@transaction.atomic
def fleet_update(*, company_id: int, fleet_id: int, **kwargs) -> TblFleet:
    non_side_effect_fields = [i for i in kwargs]
    fleet_u = TblFleet.objects.filter(id=fleet_id, company_id=company_id).first()
    if fleet_u is None:
        raise ValidationError(" fleet is not registered with us")

    fleet = TblFleet.objects.filter(company_id=company_id, name=kwargs["name"])

    if len(fleet) > 1:
        raise ValidationError("name should be unique")

    if len(fleet) == 1 and fleet.first().id == fleet_id:
        fleet_u = model_update(
            instance=fleet_u, fields=non_side_effect_fields, data=kwargs)

    elif len(fleet) == 0:
        fleet_u = model_update(
            instance=fleet_u, fields=non_side_effect_fields, data=kwargs)
    else:
        raise ValidationError("name should be unique")
    
  

    return fleet_u[0]


@transaction.atomic
def fleet_delete(*, fleet_id: int):
    fleet_d = TblFleet.objects.get(pk=fleet_id)
    fleet_d.status = "0"
    fleet_d.save()

    return fleet_d


@transaction.atomic
def depot_register(*, request,
                   fleet_id: int,
                   name: str = "",
                   city: str = "",
                   country: str = "",
                   lat: float,
                   long: float,
                   address: str = "",
                   company_id):
    # company_name = request.user.username
    user_id = request.auth["user_id"]
    username_obj = UserProfile.objects.filter(id = user_id).first()
    username = username_obj.username

    fleet_obj = TblFleet.objects.filter(company_id=company_id).all()
    depot_obj = TblDepot.objects.filter(fleet_id=fleet_id).all()
    for f in fleet_obj:
        if f.id == fleet_id:
            for d in depot_obj:
                if d.name == name:
                    raise ValidationError("depot is already registered with this fleet")


            else:
                
                depot = TblDepot(fleet_id=fleet_id,
                                 name=name,
                                 city=city,
                                 country=country,
                                 lat=round(lat, 6),
                                 long=round(long, 6),
                                 address=address,
                                 status="1",
                                 created_by=username,
                                 updated_by=username,
                                 created_at = dt.utcnow(),
                                 updated_at = dt.utcnow())

                depot.save()
                return depot


    else:
        raise ValidationError("fleet is not registered in our system")


@transaction.atomic
def depot_update(*, depot_id: int, fleet_id: int, **kwargs) -> TblDepot:
    non_side_effect_fields = [i for i in kwargs]

    depot_u = TblDepot.objects.filter(fleet_id=fleet_id, id=depot_id).first()

    if depot_u is None:
        raise ValidationError("depot is not registered in our system")
    depot = TblDepot.objects.filter(fleet_id=fleet_id, name=kwargs["name"])

    if len(depot) > 1:
        raise ValidationError("name should be unique")

    if len(depot) == 1 and depot.first().id == depot_id:
        depot_u = model_update(
            instance=depot_u, fields=non_side_effect_fields, data=kwargs)

    elif len(depot) == 0:
        depot_u = model_update(
            instance=depot_u, fields=non_side_effect_fields, data=kwargs)
    else:
        raise ValidationError("name should be unique")

    return depot_u[0]



@transaction.atomic
def depot_delete(*, fleet_id: int, depot_id: int):
    depot_d = TblDepot.objects.filter(fleet_id=fleet_id, pk=depot_id).first()
    depot_d.status = "0"
    depot_d.save()
    return depot_d
