import datetime
import json
from dataclasses import field
from urllib import response
from core.permissions import AllowedToAccessCompanyResource, AllowToAccessAdmin , AllowToAccessFleet, AccessFleet

from common.constants import (DUMMY_TOKEN_DATA, ROLE_COMPANY_MAPPING,
                              USER_ROLE_VEHICLE_MODEL_MAPPING)
from common.utils import access_to_admin
from core.jsend_response import JsendSuccessResponse
from core.pagination import CustomPagination
from core.permissions import AllowedToAccessVehicle
from django.core.paginator import Paginator
from django.db.models import Q
from django.http import HttpResponse
from drf_yasg import openapi
from drf_yasg.utils import swagger_auto_schema
from requests import request
from rest_framework import serializers, status
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from users.models import UserProfile
from vehicle.models import TblVehicle, TblVehicleAlarms, TblVehicleTagAssoc
from vehicle.selectors import vehicles_alarms_get

from .models import (TblCompany, TblCompanyRole, TblCompanyRoleAssoc,
                     TblCompanyTagAssoc, TblDepot, TblDepotColor, TblFleet)
from .permissions import IsAdminPermission
from .selectors import (assets_count,
                        company_asset_count_get, company_depots_get,
                        company_fleets_get, company_get_associations,
                        company_get_relationships_with_others,
                        company_tags_get, depo_vehicle_health_status,
                        depos_with_colorcode_vehicle, depot_get,
                        depot_list_based_on_company, depot_vehicle_status,
                        fleet_get, get_all_vendors, get_by_depots, get_company,
                        get_company_based_vehicle, get_company_list,
                        get_depot_based_company, get_depot_list,
                        get_fleet_list, get_tag_basedon_depot,
                        global_depo_view, global_vehicle_health_status,
                        global_with_colorcode_vehicle, health_status,
                        hvac_units_by_brands_get, vehicle_tag_get,
                        vehicle_with_gateway , system_settings_count, company_active_assoc_get , company_system_settimgs_count, depots_taglist ,operatot_fleet_list)
from .services import (company_delete, company_onboarding, company_register,
                       company_relation_api, company_role_assign,
                       company_tag_create, company_update, depot_delete,
                       depot_register, depot_update, fleet_delete,
                       fleet_register, fleet_update,
                       vehicle_company_tag_assign , vehicle_assoc_tag_remove)
from core.perms.system_management import CompanyPermission 
from django.db.models import F


class CompanyRelationApi(APIView):
    """This API fetches all PTA'S, PTO'S and SP. It also writes relation between companies into db."""

    permission_classes = [CompanyPermission]

    class InputSerializer(serializers.Serializer):
        """Add the fields needed to be send in the response."""
        id = serializers.IntegerField()
        name = serializers.CharField()
        website = serializers.CharField()
        status = serializers.CharField()

    def get(self, request):
        data = get_all_vendors()
        return Response({'status': True, 'data': data}, status.HTTP_200_OK)

    def post(self, request):
        data = request.data.get('data')
        base_company = data['base_company']
        # data = {'pto_id': str(data['pto_id']), 'pta_id': str(data['pta_id']), 'sp_id': str(data['sp_id'])}
        base_company_role_id = data.get('base_company_role_id', '')
        data = data.get('all', '')
        relation = company_relation_api(data, base_company, base_company_role_id)
        return Response({'status': relation[0], 'data': relation[1]}, status=relation[2])


class CompanyRegisterApi(APIView):
    # TODO: work on populating competitor_id
    class InputSerializer(serializers.Serializer):
        role_id = serializers.IntegerField(required=True)
        name = serializers.CharField(max_length=100, required=True)
        description = serializers.CharField(max_length=1000, required=False)
        user_email = serializers.EmailField(required=True)

    class OutputSerializer(serializers.ModelSerializer):
        class Meta:
            model = TblCompany
            fields = "__all__"

    def post(self, request):
        # TODO[epic=authorization] below is hardcoded data, but this should come from
        # token
        assert (
                DUMMY_TOKEN_DATA["company_id"] == 1
                and DUMMY_TOKEN_DATA["role"] == "SUPERADMIN"
        )
        serializer = self.InputSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        company = company_register(
            **serializer.validated_data
            # brand_name="Nothing",
        )
        return JsendSuccessResponse(
            data={
                "msg": f"company registered successfully, password is sent to {serializer.validated_data['user_email']}",
            }
        ).get_response()


# Tag Related
class CompanyTagCreate(APIView):
    permission_classes = [IsAuthenticated]

    class InputSerilaizer(serializers.Serializer):
        tag = serializers.CharField(max_length=100, required=True)
        tag_name = serializers.CharField(max_length=100, required=False)
        description = serializers.CharField(max_length=100, required=False)

    class OutputSerializer(serializers.ModelSerializer):
        class Meta:
            model = TblCompanyTagAssoc
            fields = "__all__"

    def post(self, request, company_id: int):
        company_id = request.user.company_id
        
        company = request.user.company.name
        serializer = self.InputSerilaizer(data=request.data)
        serializer.is_valid(raise_exception=True)
        tag = company_tag_create(company_id=company_id, company=company, **serializer.validated_data)
        return JsendSuccessResponse(
            data={"message": "company tag created successfully"}
        ).get_response()


class CompanyTagsGet(APIView):
    permission_classes = [IsAuthenticated]

    class OutputSerializer(serializers.ModelSerializer):
        class Meta:
            model = TblCompanyTagAssoc
            fields = "__all__"

    def get(self, request, company_id: int):
        company_id = request.user.company_id
        role = request.auth["company_role_name"]

        tags = company_tags_get(company_id=company_id, role=role)
        data = self.OutputSerializer(tags, many=True).data
        return JsendSuccessResponse(data=data, data_identifier="tags").get_response()


class VehicleTagsList(APIView):
    # class OutputSerializer(serializers.Serializer):
    permission_classes = [IsAuthenticated & AllowedToAccessVehicle]

    #     class Meta:
    #     model = TblCompanyTagAssoc
    #
    def get(self, request, vin: str, company_id: int):
        tags = vehicle_tag_get(vin=vin, company_id=company_id)
        # serilaizer = self.OutputSerializer(tags)

        return JsendSuccessResponse(
            data=tags, data_identifier="vehicle_tags"
        ).get_response()


class VehicleCompanyTagAssisgn(APIView):
    """Assign a company tag to a vehicle"""

    permission_classes = [IsAuthenticated & AllowedToAccessVehicle]

    class InputSerializer(serializers.Serializer):
        tag = serializers.CharField(max_length=100, required=True)

    def post(self, request, company_id: int, vin: str):
        company_id = request.user.company_id
        user_id = request.auth["user_id"]
        
        serializer = self.InputSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        vehicle_company_tag = vehicle_company_tag_assign(
            vin, company_id,user_id, **serializer.validated_data
        )
        # outputSerializer = self.OutputSerializer(vehicle_tag_assoc, many=True)
        return JsendSuccessResponse(
            data=({"message": "tag successfully assigned to vehicle."}),
            data_identifier="vehicle_tag_association",
        ).get_response()


class VehicleAssocTagRemove(APIView):
    permission_classes = [IsAuthenticated & AllowedToAccessVehicle]
    def delete(self, request, company_id: int,vin : str):
        tag_id = request.data["tag_id"]
        vehicle_tag_remove= vehicle_assoc_tag_remove(vin = vin , tag_id = tag_id)
        return JsendSuccessResponse(f"tag {vehicle_tag_remove[1]} remove  succesfully from this vin {vin}").get_response()
    
class CompanyOnboarding(APIView):
    permission_classes = [AllowToAccessAdmin]
    class InputSerializer(serializers.Serializer):

        role_id = serializers.IntegerField(required=True)
        name = serializers.CharField(required=True)
        website = serializers.CharField(required=True)
        address = serializers.CharField(required=False)
        description = serializers.CharField(required = True)
        city = serializers.CharField(required=True)
        country = serializers.CharField(max_length=100, required=False)

    def post(self, request):
        
        serializer = self.InputSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        company , company_role_assoc  = company_onboarding(**serializer.validated_data)
        return JsendSuccessResponse(
            data={
                "message": "Company Registered succesfully ",
                "company_id": f"{company.id}",
                "company_role_id" : f"{company_role_assoc.role_id}"
            }
        ).get_response()

      


class CompanyDelete(APIView):
    permission_classes = [AllowToAccessAdmin]
    # TODO: perfrom solf delete
    def delete(self, request, company_id: int):
        
        company_de = company_delete(company_id=company_id)
        return JsendSuccessResponse(f"company {company_id} deleted succesfully").get_response()
        


class CompanyUpdate(APIView):
    permission_classes = [AllowToAccessAdmin]
    class InputSerializer(serializers.ModelSerializer):
        class Meta:
            model = TblCompany
            fields = "__all__"

    class OutputSerializer(serializers.ModelSerializer):
        class Meta:
            model = TblCompany
            fields = "__all__"

    def post(self, request, company_id: int):
        
        serializer = self.InputSerializer(data=request.data, partial=True)
        serializer.is_valid(raise_exception=True)
        company_u = company_update(
            company_id=company_id,
            **serializer.validated_data,
        )
        data = self.OutputSerializer(company_u).data
        return JsendSuccessResponse(
            data=data, data_identifier="company_onboarding"
        ).get_response()

       


class CompanyGet(APIView):
    """Get a Company Details"""
    permission_classes = [AllowedToAccessCompanyResource]
    class OutputSerializer(serializers.ModelSerializer):
        class Meta:
            model = TblCompany
            fields = "__all__"

    def get(self, request, company_id: int):
        company_details, company_role = get_company(company_id=company_id)
        serializer = self.OutputSerializer(company_details)
        return_dict = serializer.data
        return_dict["company_id"] = company_id
        return_dict["company_type"] = company_role.role.description
        return_dict["role_id"] = company_role.role_id

        return JsendSuccessResponse(
            data=return_dict, data_identifier="company"
        ).get_response()

      

class CompanyAssignRole(APIView):
    class InputSerializer(serializers.Serializer):
        role_id = serializers.IntegerField(required=True)

    def post(self, request, company_id: int):
        serialier = self.InputSerializer(data=request.data)
        serialier.is_valid(raise_exception=True)
        company_role_assign(company_id=company_id, **serialier._validated_data)
        return JsendSuccessResponse(data={}).get_response()


class CompanyAssetsGetCount(APIView):
    def post(self, request, company_id: int):
        counts = company_asset_count_get(company_id=company_id)
        return JsendSuccessResponse(
            data=counts, data_identifier="counts"
        ).get_response()


class CompanyGetAssoc(APIView):
    # only allow authenticated users to make request
    permission_classes = [AllowedToAccessCompanyResource]

    class InputSerializer(serializers.Serializer):
        pta = serializers.CharField(required=False)
        service_provider = serializers.CharField(required=False)
        operator = serializers.CharField(required=False)
        fleet = serializers.CharField(required=False)

    def get(self, request, company_id: int):

        query_params = request.query_params.dict()
        # check if query_params is empty if yes it means request is to get all the
        # details of all the companies associated with requested users company.
        if bool(query_params) == False:
            company_assoc_obj = company_get_relationships_with_others(
                # FIXME: uncomment below once FE is ready
                # company_id=request.user.company_id,
                # company_role_code=request.user.role_code,
                company_id=company_id
            )

        else:
            if DUMMY_TOKEN_DATA["company_role"] == 3:
                # user belogs to a company which is PTO.
                query_params["operator"] = DUMMY_TOKEN_DATA["company_id"]
            serializer = self.InputSerializer(data=query_params)
            serializer.is_valid(raise_exception=True)
            company_assoc_obj = company_get_associations(
                company_id=company_id, **serializer.validated_data
            )
        return JsendSuccessResponse(
            data=company_assoc_obj, data_identifier="associations"
        ).get_response()


class CompanyFleetsGet(APIView):
    def get(self, request, company_id: int):
        role = request.auth["company_role_name"]
        
        company_id = request.user.company_id
        query_params = request.query_params.dict()

        
        
        fleets = company_fleets_get(company_id, role, query_params)
        return JsendSuccessResponse(
            data=fleets, data_identifier="fleets"
        ).get_response()


class CompanyDepotsGet(APIView):
    def get(self, request, company_id: int, fleet_id: int):
        role = request.auth["company_role_name"]
        company_id = request.user.company_id
        query_params = request.query_params.dict()
        if role == "admin":

            if "company_id" in query_params and query_params["company_id"]:
                query_params["company_id"] = int(query_params["company_id"])

        fleets = company_depots_get(company_id, fleet_id, query_params)
        return JsendSuccessResponse(
            data=fleets, data_identifier="depots"
        ).get_response()


class CompanyDepotVehicleAlarmsGet(APIView):
    permission_classes = (IsAuthenticated,)

    class OutputSerializer(serializers.ModelSerializer):
        status = serializers.SerializerMethodField()  # conver 1->open and 0->close
        type = serializers.SerializerMethodField()
        color = serializers.SerializerMethodField()
        service_provider = serializers.SerializerMethodField()
        elapsed_mins = serializers.SerializerMethodField()

        class Meta:
            model = TblVehicleAlarms
            fields = "__all__"
            # depth = 1

        def get_status(self, obj):
            return "open" if obj.status == "1" else "closed"

        def get_type(self, obj):
            return obj.type.name

        def get_color(self, obj):
            return obj.type.color

        def get_service_provider(self, obj):
            return obj.vin.service_provider.name

        def get_elapsed_mins(self, obj):
            return (
                    datetime.datetime.utcnow() - obj.triggered_at.replace(tzinfo=None)
            ).total_seconds() // 60

    def get(self, request, company_id: int, fleet_id: int, depot_id):
        alarms, con_alarms = vehicles_alarms_get(
            fleet_id=fleet_id,
            depo_id=depot_id,
            **{
                USER_ROLE_VEHICLE_MODEL_MAPPING[request.user.role_code]: company_id
            },  # getting model column from role_code
        )
        serializers = self.OutputSerializer(alarms, many=True)
        data = list(serializers.data) + con_alarms
        counter = 1
        for a in data:
            if a["status"] == "open":
                a["id"] = counter
                counter += 1
        return JsendSuccessResponse(
            data=list(serializers.data) + con_alarms, data_identifier="alarms"
        ).get_response()


class HvacUnitsByBrandGet(APIView):
    def get(self, request, fleet_id: int, depo_id: int, company_id: int):
        
        role = request.auth["company_role_name"]
        company_id = request.user.company_id
        query_params = request.query_params.dict()
        vehicle_filter = {}
        var = access_to_admin(request, role)

        if bool(query_params):
            response = hvac_units_by_brands_get(company_id, role, depo_id=depo_id, tag_filter=query_params,
                                                vehicle_filter=var)

        else:
            response = hvac_units_by_brands_get(company_id, role, depo_id=depo_id, vehicle_filter=var)
        return JsendSuccessResponse(
            data=response, data_identifier="counts"
        ).get_response()


class VehicleWithGatewayGet(APIView):
    def get(self, request, fleet_id: int, depo_id: int, company_id: int):

        
        role = request.auth["company_role_name"]
        company_id = request.user.company_id
        query_params = request.query_params.dict()
        vehicle_filter = {}
        var = access_to_admin(request, role)

        if bool(query_params):
            response = vehicle_with_gateway(company_id, role, depo_id=depo_id, tag_filter=query_params,
                                            vehicle_filter=var)
          

        else:
            response = vehicle_with_gateway(company_id, role, depo_id=depo_id, vehicle_filter=var)

        return JsendSuccessResponse(
            data=response, data_identifier="counts"
        ).get_response()


class VehicleWithColorCode(APIView):
    def get(self, request, fleet_id: int, depo_id: int, company_id: int):
    
        role = request.auth["company_role_name"]
        company_id = request.user.company_id
        query_params = request.query_params.dict()
        vehicle_filter = {}

        var = access_to_admin(request, role)

        if bool(query_params):
            response = depos_with_colorcode_vehicle(company_id, role, depo_id=depo_id, tag_filter=query_params,
                                                    vehicle_filter=var)

        else:
            response = depos_with_colorcode_vehicle(company_id, role, depo_id=depo_id, vehicle_filter = var)
        return JsendSuccessResponse(
            data=response, data_identifier="total_vehicles"
        ).get_response()


class DepoVehicleHealthStatus(APIView):
    # color_code = serializers.SerializerMethodField()
    class OutputSerializer(serializers.ModelSerializer):
        class Meta:
            model = TblVehicleAlarms
            exclude = "metadata"

    def get(self, request, fleet_id: int, depo_id: int, company_id: int):
      
        role = request.auth["company_role_name"]
        company_id = request.user.company_id
        vehicle_filter = {}
        var = access_to_admin(request, role)

        query_params = request.query_params.dict()
        if bool(query_params):
            alarms_type_counts = depo_vehicle_health_status(company_id, role, depo_id=depo_id, tag_filter=query_params,
                                                            vehicle_filter=var)

        else:
            alarms_type_counts = depo_vehicle_health_status(company_id, role, depo_id=depo_id, tag_filter=query_params,
                                                            vehicle_filter=var)

        return JsendSuccessResponse(
            data=alarms_type_counts, data_identifier="health_status"
        ).get_response()


class GlobalVehicleHealthStatus(APIView):
    class OutputSerializer(serializers.ModelSerializer):
        class Meta:
            model = TblVehicleAlarms
            exclude = "metadata"

    def get(self, request, company_id: int):
        
        role = request.auth["company_role_name"]
        company_id = request.user.company_id
        vehicle_filter = {}
        var = access_to_admin(request, role)
        alarm_type_counts = global_vehicle_health_status(company_id, role, vehicle_filter=var)
        return JsendSuccessResponse(
            data=alarm_type_counts, data_identifier="health_status_summary"
        ).get_response()


class GlobalVehicleWithColorCode(APIView):
    def get(self, request, company_id: int):
        
        role = request.auth["company_role_name"]
        company_id = request.user.company_id
        vehicle_filter = {}

        var = access_to_admin(request, role)
        response = global_with_colorcode_vehicle(company_id, role, vehicle_filter=var)
        return JsendSuccessResponse(
            data=response, data_identifier="global_total_vehicles"
        ).get_response()


class GlobalDepoView(APIView):
    permission_classes = [IsAuthenticated]

    class OutputSerializer(serializers.ModelSerializer):
    
        class Meta:
            # model = TblDepot
            model = TblDepot
            fields = "__all__"

        def get_fleet(self, obj):
            return obj.fleet.name

        def get_fleet_id(self, obj):
            return obj.fleet.id

        def get_vehicle_count(self, obj):
            vehicle_filter = self.context.get("vehicle_filter")
            total_count = TblVehicle.objects.filter(depo_id=obj.id, **vehicle_filter, status="1").values_list(
                "vin").count()
            return {"total_vehicle_count": total_count}


    def get(self, request, company_id: int):
      
        role = request.auth["company_role_name"]# operator/service_provider/pta
        company_name = request.auth["company_name"]
        query_params = request.query_params.dict()  # {'fleet_id': 2, 'server_provider_id|operator_id':3, 'depot_color':'32c3c'}
        depot_filter = {k: v for k, v in query_params.items() if k in ['color_code'] and query_params["color_code"]}
       

        vehicle_filter = {}

        var = access_to_admin(request, role)
        
        response = global_depo_view(vehicle_filter=var, depot_filter=depot_filter)
        for c in response:
            # c["company_name"] = company_name
            operator_name = TblFleet.objects.filter(id = c["fleet_id"]).annotate(operator_name = F("company__name"),pto_id = F("company_id")).first()
            c["operator_name"] = operator_name.company.name
            c["pto_id"] = operator_name.company.id
        
            

        return JsendSuccessResponse(
            data=response, data_identifier="global_depots_vins_count"
        ).get_response()


class GetDepotDetails(APIView):
    class OutputSerializer(serializers.ModelSerializer):
        class Meta:
            model = TblDepot
            exclude = ("created_at", "updated_at", "created_by", "updated_by")

    def get(self, request, company_id: int, pto_id: int, fleet_id: int):
        
        role = request.auth["company_role_name"]
        company_id = request.user.company_id
        vehicle_filter = {}

        var = access_to_admin(request, role)

        get_depots = get_by_depots(company_id, role, fleet_id=fleet_id, vehicle_filter=var)
        serializer = self.OutputSerializer(get_depots, many=True)
        return JsendSuccessResponse(
            data=list(serializer.data), data_identifier="depots_details"
        ).get_response()


class GetDepoBasedCompany(APIView):
    class OutputSerializer(serializers.ModelSerializer):
        

        class Meta:
            model = TblDepot
            exclude = (
                "lat", "long", "address", "city", "country", "created_at", "created_by", "updated_at", "updated_by")

        

       
    pagination_class = CustomPagination()

    def get(self, request, company_id):
        company_id = request.user.company_id
      
        role = request.auth["company_role_name"]
        vehicle_filter = {}

        var = access_to_admin(request, role)
        depo_query_set = get_depot_based_company(company_id, role, vehicle_filter=var)

        depo_query_set = self.pagination_class.paginate_queryset(queryset=depo_query_set, request=request, view=self)
        total_records = self.pagination_class.page.paginator.count
        total_pages = self.pagination_class.page.paginator.num_pages

        d = list(depo_query_set)

        pagination = {"page": request.GET.get('p'),
                      "pageSize": request.GET.get('page_size'),
                      "totalPages": total_pages, "totalRecords": total_records
                      }
        depots_details = {'depots_details': d}
        return Response({"status": "success", "data": depots_details, 'pagination': pagination})

       


class GetCompanyVehicle(APIView):

    def get(self, request, company_id: int, ):
        
        role = request.auth["company_role_name"]
        query_params = request.query_params.dict()
        vehicle_filter = {}
        var = access_to_admin(request, role)
        is_gateway = query_params["is_gateway"]
        #search_string -> get the details of vins by body_num, plate_num,bus_num and vehicles
     
        if bool(is_gateway):
            get_vehicles = get_company_based_vehicle(company_id, role, vehicle_filter=var, is_gateway = is_gateway,search_string= query_params["search_string"] )
            
        else:      
            get_vehicles = get_company_based_vehicle(company_id, role, search_string= query_params["search_string"], vehicle_filter=var )

        return JsendSuccessResponse(data=get_vehicles, data_identifier="vins").get_response()


class GetTagBasedCompany(APIView):
    class OutputSerializer(serializers.ModelSerializer):
        class Meta:
            model = TblCompanyTagAssoc
            exclude = ("created_at", "created_by", "updated_at", "updated_by")

    def get(self, request, depo_id):
        company_id = request.user.company_id
        
        role = request.auth["company_role_name"]

        query_set_tag = get_tag_basedon_depot(company_id, role, depo_id)
        serializer = self.OutputSerializer(query_set_tag, many=True)
        return JsendSuccessResponse(
            data=serializer.data, data_identifier="tag_details"
        ).get_response()


class DepoVehicleHealth(APIView):
    class OutputSerializer(serializers.ModelSerializer):

        class Meta:
            model = TblVehicle
            fields = "__all__"

    pagination_class = CustomPagination()

    def get(self, request, company_id: int, depo_id: int):
        company_id = request.user.company_id
       
        role = request.auth["company_role_name"]
        query_params = request.query_params.dict()
        vehicle_filter = {}
        var = access_to_admin(request, role)

        if bool(query_params["tag_id"]) and "tag_id" in query_params:
            vehicle_query_set = depot_vehicle_status(company_id, role, depo_id=depo_id, tag_filter=query_params,

                                                     vehicle_filter=var)
        else:
            vehicle_query_set = depot_vehicle_status(company_id, role, depo_id=depo_id, vehicle_filter=var)

        vehicle_query_set = self.pagination_class.paginate_queryset(queryset=vehicle_query_set, request=request,
                                                                    view=self)
        total_records = self.pagination_class.page.paginator.count
        total_pages = self.pagination_class.page.paginator.num_pages
        # serializer = self.OutputSerializer(vehicle_query_set, many=True).data
        d = list(vehicle_query_set)
        pagination = {"page": request.GET.get('p'),
                      "pageSize": request.GET.get('page_size'),
                      "totalPages": total_pages, "totalRecords": total_records
                      }

        vehicles = {'vehicles': d}
        return Response({"status": "success", "data": vehicles, 'pagination': pagination})


class AssestCount(APIView):
    def get(self, request, company_id: int):
        company_id = request.user.company_id
    
        role = request.auth["company_role_name"]
        vehicle_filter = {}

        var = access_to_admin(request, role)

        response = assets_count(company_id, role, vehicle_filter=var)
        return JsendSuccessResponse(
            data=response, data_identifier="assest_count"
        ).get_response()


class HealthStatus(APIView):
    class OutputSerializer(serializers.ModelSerializer):
       

        class Meta:
            model = TblVehicleAlarms
            fields = "__all__"
       

    pagination_class = CustomPagination()

    def get(self, request, company_id: int):
        company_id = request.user.company_id
       
        role = request.auth["company_role_name"]
        vehicle_filter = {}
        var = access_to_admin(request, role)

        get_alarms = health_status(company_id, role, vehicle_filter=var)
        
        get_alarms = self.pagination_class.paginate_queryset(queryset=get_alarms, request=request, view=self)
        total_records = self.pagination_class.page.paginator.count
        total_pages = self.pagination_class.page.paginator.num_pages
      
        d = list(get_alarms)

        for a in d:
            a["status"] = "open" if a["status"] == "1" else "closed"
        pagination = {"page": request.GET.get('p'),
                      "pageSize": request.GET.get('page_size'),
                      "totalPages": total_pages, "totalRecords": total_records
                      }
        health = {'health_status': d}
        return Response({"status": "success", "data": health, 'pagination': pagination})


class Fleet_Register(APIView):
    permission_classes = [AllowToAccessFleet]
    class InputSerializer(serializers.Serializer):

        name = serializers.CharField(required=True)
        climate_zone_id = serializers.IntegerField(required=True)
        description = serializers.CharField(required=False)
        region = serializers.CharField(required=False)

    def post(self, request, company_id):
        # company_name = request.auth["company_name"]
        user_id = request.auth["user_id"]
      
        serializer = self.InputSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        fleet = fleet_register(company_id= company_id,user_id = user_id, **serializer.validated_data)

        return JsendSuccessResponse(
            data={"message": "fleet registered successfully!"}
        ).get_response()

       

class FleetUpdate(APIView):
    permission_classes = [AllowToAccessFleet]
    class InputSerializer(serializers.ModelSerializer):
        class Meta:
            model = TblFleet
            fields = "__all__"

    class OutputSerializer(serializers.ModelSerializer):
        class Meta:
            model = TblFleet
            fields = "__all__"

    def post(self, request, company_id, fleet_id: int):
        

        serializer = self.InputSerializer(data=request.data, partial=True)
        serializer.is_valid(raise_exception=True)
    
        fleet_u = fleet_update(
            company_id=company_id,
            fleet_id=fleet_id,
            **serializer.validated_data,
        )
        data = self.OutputSerializer(fleet_u).data
        return JsendSuccessResponse(
            data=data, data_identifier="fleet_update"
        ).get_response()
        
       
       


class FleetDelete(APIView):
    permission_classes = [AllowToAccessFleet]
    # TODO: perfrom solf delete
    def delete(self,request, company_id: int ,fleet_id: int):
        fleet_d = fleet_delete(fleet_id=fleet_id, company_id=company_id)
        return JsendSuccessResponse(f"Fleet {fleet_id} deleted succesfully").get_response()


class DepotRegister(APIView):
    permission_classes = [AllowToAccessFleet]
    class InputSerializer(serializers.Serializer):
        name = serializers.CharField(required=True)
        lat = serializers.FloatField(required=True)
        long = serializers.FloatField(required=True)
        city = serializers.CharField(required=True)
        address = serializers.CharField(required=False)
        country = serializers.CharField(required = False)

    def post(self, request, company_id, fleet_id):
       

        
        serializer = self.InputSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        depot = depot_register(request=request, fleet_id=fleet_id, company_id=company_id,
                                **serializer.validated_data)

        return JsendSuccessResponse(
            data={"message": "depot registered successfully!"}
        ).get_response()

        


class DepotUpdate(APIView):
    permission_classes = [AllowToAccessFleet]
    class InputSerializer(serializers.ModelSerializer):
        class Meta:
            model = TblDepot
            fields = "__all__"

    class OutputSerializer(serializers.ModelSerializer):
        class Meta:
            model = TblDepot
            fields = "__all__"

    def post(self, request, company_id: int, fleet_id: int, depot_id: int):
        

       
        serializer = self.InputSerializer(data=request.data, partial=True)
        serializer.is_valid(raise_exception=True)
        depot_u = depot_update(
            depot_id=depot_id,
            fleet_id=fleet_id,
            **serializer.validated_data,
        )
        data = self.OutputSerializer(depot_u).data
        return JsendSuccessResponse(
            data=data, data_identifier="depot_update"
        ).get_response()

 


class DepotDelete(APIView):
    permission_classes = [AllowToAccessFleet]

    def delete(self, request, company_id: int, fleet_id: int, depot_id: int):
        token_access_id = request.user.company_id
        
        depot_d = depot_delete(fleet_id=fleet_id, depot_id=depot_id)
        return JsendSuccessResponse(f"Depot {depot_id} deleted succesfully").get_response()
      


class FleetGet(APIView):
    """Get a Fleet Details"""
    permission_classes = [AllowToAccessFleet]
    class OutputSerializer(serializers.ModelSerializer):
        class Meta:
            model = TblFleet
            fields = "__all__"

    def get(self, request, company_id: int, fleet_id: int):

      
        fleet_obj = fleet_get(company_id=company_id, fleet_id=fleet_id)
        serializer = self.OutputSerializer(fleet_obj)
        return_dict = serializer.data
        return_dict["climate_zone_name"] = fleet_obj.climate_zone.name
        return JsendSuccessResponse(
            data=return_dict, data_identifier="fleet"
        ).get_response()

      


class DepotGet(APIView):
    """Get a Depot Details"""
    permission_classes = [AllowToAccessFleet]
    class OutputSerializer(serializers.ModelSerializer):
        class Meta:
            model = TblDepot
            fields = "__all__"

    def get(self, request, company_id: int, fleet_id: int, depot_id: int):

        

        # trying to give access to admin and depot of particular operator company
        
        depot_obj = depot_get(fleet_id=fleet_id, depot_id=depot_id)
        serializer = self.OutputSerializer(depot_obj)
        return_dict = serializer.data
        return_dict["fleet_name"] = depot_obj.fleet.name
        return JsendSuccessResponse(
            data=return_dict, data_identifier="depot"
        ).get_response()

        


class CompanyList(APIView):
    permission_classes = [AllowToAccessAdmin]
    class OutputSerializer(serializers.ModelSerializer):
        class Meta:
            model = TblCompany
            fields = "__all__"

    def get(self, request, company_id):
        # no need to take company_id in url  -> need to ask
       
        company_list = get_company_list(company_id)

        return JsendSuccessResponse(
        data=company_list, data_identifier="company_list"
        ).get_response()

       


class FleetList(APIView):
    permission_classes = [AllowToAccessFleet]
    class OutputSerializer(serializers.ModelSerializer):

        class Meta:
            model = TblFleet
            fields = "__all__"

    def get(self, request, company_id):
        
        fleet_list = get_fleet_list(request, company_id)

        return JsendSuccessResponse(
            data=fleet_list, data_identifier="fleet_list"
        ).get_response()

class OperatorFleetList(APIView):
    # permission_classes = [AccessFleet]
    class OutputSerializer(serializers.ModelSerializer):

        class Meta:
            model = TblFleet
            fields = "__all__"

    def get(self, request, company_id):
        
        fleet_list = operatot_fleet_list(request, company_id)

        return JsendSuccessResponse(
            data=fleet_list, data_identifier="fleet_list"
        ).get_response() 


class DepotList(APIView):
    permission_classes = [AllowToAccessFleet]
    class OutputSerializer(serializers.ModelSerializer):

        class Meta:
            model = TblDepot
            fields = "__all__"

    def get(self, request, company_id, fleet_id):
        
        depot_list = get_depot_list(company_id, fleet_id)

        return JsendSuccessResponse(
            data=depot_list, data_identifier="depot_list"
        ).get_response()



class System_Settings_Count(APIView):
    permission_classes = [AllowToAccessAdmin]
    class OutputSerializer(serializers.ModelSerializer):
        class Meta:
            model = TblCompany
            fields = "__all__"

    def get(self, request, company_id):
        
        response = system_settings_count(company_id=company_id)
       
        return JsendSuccessResponse(
            data=response, data_identifier="system_settings_asset_counts"
        ).get_response()
        

class Company_System_Settings_Count(APIView):
    permission_classes = [AllowedToAccessCompanyResource]
    class OutputSerializer(serializers.ModelSerializer):
        class Meta:
            model = TblCompany
            fields = "__all__"

    def get(self, request, company_id):
      
        
        response = company_system_settimgs_count(request,company_id=company_id)
       
        return JsendSuccessResponse(
            data=response, data_identifier="company_system_settings_counts"
        ).get_response()


class DepotListBasedCompany(APIView):
    permission_classes = [AllowToAccessFleet]
    class OutputSerializer(serializers.ModelSerializer):

        class Meta:
            model = TblDepot
            fields = "__all__"

    def get(self, request, company_id):
      
        depot_list = depot_list_based_on_company(request, company_id)

        return JsendSuccessResponse(
            data=depot_list, data_identifier="depot_list"
        ).get_response()

      
class CompanyGetActiveAssoc(APIView):
    # this will give association when when there is atleast 1 vehicle under it. 

    permission_classes = (IsAuthenticated,)

    class InputSerializer(serializers.Serializer):
        pta = serializers.CharField(required=False)
        service_provider = serializers.CharField(required=False)
        operator = serializers.CharField(required=False)
        fleet = serializers.CharField(required=False)

    def get(self, request):

        query_params = request.query_params.dict()
        assocations = company_active_assoc_get(request, filters = query_params)
        # check if query_params is empty if yes it means request is to get all the
        # details of all the companies associated with requested users company.
        
        return JsendSuccessResponse(
            data=assocations, data_identifier="associations"
        ).get_response()


class DepotTagList(APIView):
    
    def get(self , request, depo_id):
        tag_list = depots_taglist(depo_id)
        return JsendSuccessResponse(
            data=tag_list, data_identifier="depot_taglist"
        ).get_response()