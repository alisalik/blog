from django.urls import path

from .views import CompanyAssignRole  # Tags Related
from .views import (CompanyAssetsGetCount, CompanyDelete, CompanyDepotsGet,
                    CompanyDepotVehicleAlarmsGet, CompanyFleetsGet, CompanyGet,
                    CompanyGetAssoc, CompanyRegisterApi, CompanyRelationApi, CompanyTagCreate,
                    CompanyTagsGet, DepoVehicleHealth, DepoVehicleHealthStatus,
                    GetCompanyVehicle, GetDepoBasedCompany, GetDepotDetails,
                    GetTagBasedCompany, GlobalDepoView,
                    GlobalVehicleHealthStatus, GlobalVehicleWithColorCode,
                    HvacUnitsByBrandGet, VehicleCompanyTagAssisgn,
                    VehicleTagsList, VehicleWithColorCode,
                    VehicleWithGatewayGet,AssestCount, HealthStatus, CompanyOnboarding, CompanyUpdate, Fleet_Register, FleetDelete,
                    DepotRegister, DepotDelete, FleetUpdate , DepotUpdate, FleetGet, DepotGet, CompanyList, System_Settings_Count, FleetList,OperatorFleetList,
                    DepotList , DepotListBasedCompany, CompanyGetActiveAssoc, Company_System_Settings_Count , DepotTagList, VehicleAssocTagRemove)

urlpatterns = [
    path(
        "register",
        CompanyRegisterApi.as_view(),
        name="company.register",
    ),
    path(
        "companies/fetch",
        CompanyRelationApi.as_view(),
        name="company.fetch"
    ),
    path(
        "<int:company_id>/roles/assign",
        CompanyAssignRole.as_view(),
        name="company.role.assign",
    ),
    
    path(
        "company/register",
        CompanyOnboarding.as_view(),
        name="company_onboarding",
    ),
    
    path(
        "<int:company_id>/delete",
        CompanyDelete.as_view(),
        name="company.delete",
    ),
    
    path(
        "company/<int:company_id>/update",
        CompanyUpdate.as_view(),
        name="company.delete",
    ),
     
    path(
        "company/<int:company_id>/fleet/register",
        Fleet_Register.as_view(),
        name="fleet.register",
    ),
    
    path(
        "company/<int:company_id>/fleet/<int:fleet_id>/update",
        FleetUpdate.as_view(),
        name="fleet.update",
    ),
    
    path(
        "company/<int:company_id>/fleet/<int:fleet_id>/get",
        FleetGet.as_view(),
        name="fleet.get",
    ),
    
    path(
        "company/<int:company_id>/fleet/<int:fleet_id>/delete",
        FleetDelete.as_view(),
        name="fleet.delete",
    ),
    path(
        "company/<int:company_id>/fleet/<int:fleet_id>/depot/register",
        DepotRegister.as_view(),
        name="depot.register",
    ),
    
    path(
        "company/<int:company_id>/fleet/<int:fleet_id>/depot/<int:depot_id>/update",
        DepotUpdate.as_view(),
        name="depot.update",
    ),
     
    path(
        "company/<int:company_id>/fleet/<int:fleet_id>/depot/<int:depot_id>/delete",
        DepotDelete.as_view(),
        name="depot.delete",
    ),
    
     path(
        "company/<int:company_id>/fleet/<int:fleet_id>/depot/<int:depot_id>/get",
        DepotGet.as_view(),
        name="depot.get",
    ),
    
     
    path(
        "<int:company_id>",
        CompanyGet.as_view(),
        name="company",
    ),
    path(
        "<int:company_id>/assets/count",
        CompanyAssetsGetCount.as_view(),
        name="company.assets.count",
    ),
    path(
        "<int:company_id>/associations",
        CompanyGetAssoc.as_view(),
        name="company_assoc",
    ),
    path(
        "associations/actives",
        CompanyGetActiveAssoc.as_view(),
        name="company_assoc",
    ),
    path(
        "operators/<int:company_id>/fleets",
        CompanyFleetsGet.as_view(),
        name="company.fleets",
    ),
    path(
        "operators/<int:company_id>/fleets/<int:fleet_id>",
        CompanyDepotsGet.as_view(),
        name="company.depots",
    ),
    path(
        "<int:company_id>/fleets/<int:fleet_id>/depots/<int:depot_id>/vehicles/alarms",
        CompanyDepotVehicleAlarmsGet.as_view(),
        name="company.depots.vehicle.alarms",
    ),
    path(
        "<int:company_id>/fleets/<int:fleet_id>/depots/<int:depo_id>/counts/hvac_units_by_brand",
        HvacUnitsByBrandGet.as_view(),
        name="depos.hvac_units_by_brand",
    ),
    path(
        "<int:company_id>/fleets/<int:fleet_id>/depots/<int:depo_id>/counts/gateways",
        VehicleWithGatewayGet.as_view(),
        name="depos.gateways",
    ),
    path(
        "<int:company_id>/fleets/<int:fleet_id>/depots/<int:depo_id>/counts/vehicles",
        VehicleWithColorCode.as_view(),
        name="depos.vehicles",
    ),
    # Tag related
    path(
        "<int:company_id>/tags/create", 
        CompanyTagCreate.as_view(), name="company.tags"
    ),
    
    path("<int:company_id>/tags", 
         CompanyTagsGet.as_view(), name="company.tags.list"
         ),
    
    path(
        "<int:company_id>/vehicles/<str:vin>/tags",
        VehicleTagsList.as_view(),
        name="vehicle.tags.list",
    ),
    path(
        "<int:company_id>/vehicles/<str:vin>/tags/assign",
        VehicleCompanyTagAssisgn.as_view(),
        name="vehicle.tags.assign",
    ),
    path(
        "<int:company_id>/fleets/<int:fleet_id>/depots/<int:depo_id>/healthstatusvehicle",
        DepoVehicleHealthStatus.as_view(),
        name="depos.healthstatus",
    ),
    path(
        "<int:company_id>/healthstatusvehicle",
        GlobalVehicleHealthStatus.as_view(),
        name="global.healthstatus",
    ),
    path(
        "<int:company_id>/counts/vehicles",
        GlobalVehicleWithColorCode.as_view(),
        name="global.vehicles",
    ),
    path(
        "<int:company_id>/dashboards/global/views/depot",
        GlobalDepoView.as_view(),
        name="global.depots",
    ),
    path(
        "<int:company_id>/pto_id/<int:pto_id>/fleet/<int:fleet_id>/depots",
        GetDepotDetails.as_view(),
        name="depots.details",
    ),
    path(
        "<int:company_id>/depots/get_depots",
        GetDepoBasedCompany.as_view(),
        name="get.depots",
    ),
    path(
        "<int:company_id>/vehicles/get_vins",
        GetCompanyVehicle.as_view(),
        name="get.vehicles",
    ),
    path(
        "depo_id/<int:depo_id>/get_tags/",
        GetTagBasedCompany.as_view(),
        name="get.tags",
    ),
    
    path(
        "vehicle_group/company_id/<int:company_id>/depo_id/<int:depo_id>",
        DepoVehicleHealth.as_view(),
        name="vehicle.status.get",
    ),
    path(
        "company_id/<int:company_id>",
        AssestCount.as_view(),
        name="assest_count",
    ),
    
    path(
        "company_id/<int:company_id>/health_status",
        HealthStatus.as_view(),
        name="health_status",
    ),
  
    path(
        "company_id/<int:company_id>/get_companies",
        CompanyList.as_view(),
        name="company_list",
    ),
    
    path(
        "company_id/<int:company_id>/get_fleet_list",
        FleetList.as_view(),
        name="fleet_list",
    ),
    
    path(
        "company_id/<int:company_id>/operator_fleet_list",
        OperatorFleetList.as_view(),
        name="fleet_list",
    ),
     
    path(
        "company_id/<int:company_id>/fleet_id/<int:fleet_id>",
        DepotList.as_view(),
        name="depot_list",
    ),
     
    path(
        "company_id/<int:company_id>/system_settings_count",
        System_Settings_Count.as_view(),
        name="companies_count",
    ),
    
    path(
        "company_id/<int:company_id>/company_system_settings_count",
        Company_System_Settings_Count.as_view(),
        name="companies_system_assest_count",
    ),
    
    path(
        "company_id/<int:company_id>/depots_list",
        DepotListBasedCompany.as_view(),
        name="depots_list",
    ),
    
    path(
        "depo_id/<int:depo_id>/tag_list",
        DepotTagList.as_view(),
        name="depot_taglist",
    ),
    
    path(
        "company_id/<int:company_id>/vin/<str:vin>/vehicle_assoc_tag_remove",
        VehicleAssocTagRemove.as_view(),
        name="vehicle_assoc_tag_remove",
    ),
]
