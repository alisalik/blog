# Company related models

from core.models import BaseModel
from django.db import models


# Create your models here.
class TblCompany(models.Model):
    name = models.CharField(max_length=255, blank=True, null=True)
    website = models.CharField(max_length=100, blank=True, null=True)
    address = models.CharField(max_length=100, blank=True, null=True)
    city = models.CharField(max_length=100, blank=True, null=True)
    country = models.CharField(max_length=100, blank=True, null=True)
    phone_no = models.CharField(max_length=100, blank=True, null=True)
    subscriber = models.CharField(max_length=3, blank=True, null=True)
    sub_package = models.CharField(max_length=4, blank=True, null=True)
    licenses = models.CharField(max_length=100, blank=True, null=True)
    description = models.TextField(blank=True, null=True)
    status = models.CharField(max_length=1, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'tbl_company'


class TblCompanyRole(models.Model):
    name = models.CharField(max_length=100, blank=True, null=True)
    description = models.TextField(blank=True, null=True)
    status = models.CharField(max_length=1, blank=True, null=True)
    scope = models.CharField(max_length = 100 , blank = False , null = False)

    class Meta:
        managed = False
        db_table = "tbl_company_role"


class TblCompanyRoleAssoc(BaseModel):
    company = models.ForeignKey(
        "TblCompany", models.DO_NOTHING, blank=True, null=True, related_name="company"
    )
    parent_company = models.ForeignKey(
        "TblCompany", models.DO_NOTHING, blank=True, null=True
    )
    role = models.ForeignKey("TblCompanyRole", models.DO_NOTHING, blank=True, null=True)
    status = models.CharField(max_length=1, blank=True, null=True)
    

    class Meta:
        managed = False
        db_table = "tbl_company_role_assoc"


class TblUser(models.Model):
    username = models.CharField(max_length=100, blank=True, null=True)
    email = models.CharField(max_length=100, blank=True, null=True)
    contact = models.BigIntegerField(blank=True, null=True)
    company_id = models.IntegerField(blank=True, null=True)
    role_code = models.ForeignKey('TblUserRole', models.DO_NOTHING, db_column='role_code', blank=True, null=True)
    mob_otp = models.IntegerField(blank=True, null=True)
    em_otp = models.IntegerField(blank=True, null=True)
    otp_time = models.DateTimeField(blank=True, null=True)
    password = models.IntegerField(blank=True, null=True)
    last_login = models.DateTimeField(blank=True, null=True)
    status = models.CharField(max_length=1, blank=True, null=True)
    created_by = models.CharField(max_length=100, blank=True, null=True)
    created_on = models.DateTimeField(blank=True, null=True)
    updated_by = models.CharField(max_length=100, blank=True, null=True)
    updated_on = models.DateTimeField(blank=True, null=True)
    designation = models.CharField(max_length=100, blank=True, null=True)
    password_expires_at = models.DateTimeField(blank=True, null=True)
    state = models.CharField(max_length=18, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'tbl_user'
        
class TblUserRole(models.Model):
    role_code = models.CharField(primary_key=True, max_length=100)
    description = models.CharField(max_length=100, blank=True, null=True)
    priority = models.IntegerField(blank=True, null=True)
    status = models.CharField(max_length=100, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'tbl_user_role'
        



class TblClimateZone(models.Model):
    name = models.CharField(max_length=100, blank=True, null=True)
    description = models.TextField(blank=True, null=True)
    status = models.CharField(max_length=1, blank=True, null=True)

    class Meta:
        managed = False
        db_table = "tbl_climate_zone"


class TblFleet(models.Model):
    company = models.ForeignKey("TblCompany", models.DO_NOTHING, blank=True, null=True)
    climate_zone = models.ForeignKey(
        "TblClimateZone", models.DO_NOTHING, blank=True, null=True
    )
    name = models.CharField(max_length=100, blank=True, null=True)
    description = models.TextField(blank=True, null=True)
    region = models.CharField(max_length=100, blank=True, null=True)
    status = models.CharField(max_length=1, blank=True, null=True)
    created_by = models.CharField(max_length=100, blank=True, null=True)
    updated_at = models.DateTimeField(blank=True, null=True)
    updated_by = models.CharField(max_length=100, blank=True, null=True)
   
    

    class Meta:
        managed = False
        db_table = "tbl_fleet"


class TblCompanyTagAssoc(BaseModel):
    company = models.ForeignKey("TblCompany", models.DO_NOTHING, blank=True, null=True)
    tag = models.CharField(max_length=100, blank=True, null=True)
    tag_name = models.CharField(max_length=100, blank=True, null=True)
    description = models.TextField(blank=True, null=True)
    status = models.CharField(max_length=1, blank=True, null=True)

    class Meta:
        managed = False
        db_table = "tbl_company_tag_assoc"


class TblDepot(models.Model):
    fleet = models.ForeignKey("TblFleet", models.DO_NOTHING, blank=True, null=True)
    name = models.CharField(max_length=100, blank=True, null=True)
    address = models.TextField(blank=True, null=True)
    city = models.CharField(max_length=100, blank=True, null=True)
    country = models.CharField(max_length=100, blank=True, null=True)
    lat = models.FloatField(blank=True, null=True, default=None)
    long = models.FloatField(blank=True, null=True,default=None)
    color_name = models.CharField(max_length=20, blank=True, null=True)
    status = models.CharField(max_length=1, blank=True, null=True)
    created_at = models.DateTimeField(blank=True, null=True)
    created_by = models.CharField(max_length=100, blank=True, null=True)
    updated_at = models.DateTimeField(blank=True, null=True)
    updated_by = models.CharField(max_length=100, blank=True, null=True)
    color_code = models.CharField(max_length=6, blank=True, null=True)

    class Meta:
        managed = False
        db_table = "tbl_depot"


class TblDepotColor(models.Model):
    depot = models.ForeignKey('TblDepot', models.DO_NOTHING, blank=True, null=True)
    company = models.ForeignKey('TblCompany', models.DO_NOTHING, blank=True, null=True)
    color_code = models.CharField(max_length=6, blank=True, null=True)
    color_name = models.CharField(max_length=6, blank=True, null=True)
    company_role = models.ForeignKey('TblCompanyRole', models.DO_NOTHING, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'tbl_depot_color'
        
        # {
#                 "id": 10,
#                 "vehicle_count": {
#                     "total_vehicle_count": 14
#                 },
#                 "fleet": "Fleet7",
#                 "fleet_id": 7,
#                 "name": "Depo10",
#                 "address": "german",
#                 "city": "german",
#                 "country": "german",
#                 "lat": 57.71,
#                 "long": 11.97,
#                 "color_name": "red",
#                 "status": "1",
#                 "color_code": "D21D26"
#             },


        

