from django.contrib import admin

# Register your models here.
from .models import TblCompany, TblCompanyRole, TblCompanyRoleAssoc

# Register your models here.
admin.site.register(TblCompany)
admin.site.register(TblCompanyRole)
admin.site.register(TblCompanyRoleAssoc)