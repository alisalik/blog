"""getting data out of database only bussiness logic goes here
"""
from http.client import UNSUPPORTED_MEDIA_TYPE
from typing import Iterable

import django_filters
from django.db.models import Q
from gateway.models import TblGatewayMaster
from rest_framework import exceptions

from .models import (
    TblHvacComponent,
    TblHvacComponentSupplier,
    TblHvacComponentSupplierDetail,
    TblHvacComponentType,
    TblHvacVinGateway,
   
    TblSerialNoMaster,
)




def eberspacher_component_get(*, by: dict) -> Iterable[TblSerialNoMaster]:
    # TODO: follow naming convention
    """get serial number object from sap dump"""
    # a = 1 / 0
    # raise exceptions.ValidationError(
    #     {
    #         "error": "Some message",
    #     }
    # )
    component = TblSerialNoMaster.objects.filter(**by).first()

    return component


def get_component_list(*, by: dict = None) -> Iterable[TblHvacComponentType]:
    """get list of component types supported by the system"""
    # TODO: follow naming convention
    if len(by) == 0:
        components = TblHvacComponentType.objects.all()
    else:
        components = TblHvacComponentType.objects.filter(**by).all()
    return components


def hvac_components_detail_get(*, hvac_id: int):
    hvac_components = (
        TblHvacComponent.objects.filter(hvac_id=hvac_id).all().filter(~Q(status=0))
    )
    for c in hvac_components:
        if c.supplier_detail_id == 1:
            # this is eberspacher unit, extract model from serial number dump database
            c.supplier_detail.component = c.component_type.name
            dump_desc = (
                TblSerialNoMaster.objects.filter(serial_number_1=c.serial_num)
                .first()
                .description
            )
            dump_desc = "" if dump_desc is None else dump_desc.split(" ")


            c.supplier_detail.unit_type = dump_desc[0] if len(dump_desc) > 1 else "NA"

    return hvac_components


def hvac_component_get(*, by: dict = None) -> TblHvacComponent:
    component = TblHvacComponent.objects.filter(**by).first()
    return component


def hvac_components_get_count(hvac_id: int) -> dict:
    # TODO: rename columns
    components = hvac_components_detail_get(hvac_id=hvac_id)
    count = {"category": {}, "component_type": {}}
    for c in components:
        ct = c.component_type
        if ct.type not in count["category"]:
            count["category"][ct.type] = 1
        else:
            count["category"][ct.type] += 1
        if ct.name not in count["component_type"]:
            count["component_type"][ct.name] = 1
        else:
            count["component_type"][ct.name] += 1
    return count


def hvac_components_suppliers_get() -> dict:
    suppliers = TblHvacComponentSupplier.objects.all()
    return suppliers


def hvac_component_supplier_detail(supplier_id: int) -> dict:
    supplier = TblHvacComponentSupplierDetail.objects.filter(
        supplier_id=supplier_id
    ).all()
    return supplier


class HvacComponentSupplierDetailFilter(django_filters.FilterSet):
    class Meta:

        model = TblHvacComponentSupplierDetail
        fields = ("vehicle_engine_type", "name", "component")


def hvac_component_supplier_detail_list(*, filters=None):
    filters = filters or {}
    qs = TblHvacComponentSupplierDetail.objects.all()
    return HvacComponentSupplierDetailFilter(filters, qs).qs






    
    
    
    
    
    
    
    
    
    
    
