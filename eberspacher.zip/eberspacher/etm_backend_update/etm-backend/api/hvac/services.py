import datetime

from common.services import model_update
from common.utils import get_object
from django.core.exceptions import ValidationError as DjangoValidationError
from django.db import transaction
from rest_framework import exceptions

from .models import (
    TblHvacComponent,  
    TblHvacComponentType,
    TblHvacVinGateway,
    TblSerialNoMaster,
)
from vehicle.models import TblHvacVinGateway
from users.models import UserProfile



@transaction.atomic
def hvac_component_add(
    *,
    hvac_id: int,
    # competitor_id: int,
    serial_num: str = "",
    # brand_name: str = "",
    # dip_date: datetime.date = datetime.date.today(),
    component_type: int,
    supplier_detail: int,
   
    user_id : int
    
):
    username_obj = UserProfile.objects.filter(id = user_id).first()
    username = username_obj.username

    if supplier_detail.id == 1:  # trying to add eberspacher's unit
        if not serial_num.isnumeric():
            raise exceptions.ValidationError(
                "This eberspacher's unit is not present in our system"
            )
        if len(TblSerialNoMaster.objects.filter(serial_number_1=serial_num).all()) == 0:
            raise exceptions.ValidationError(
                "This eberspacher's unit is not present in our system"
            )
            
    serial_num_obj = TblHvacComponent.objects.filter(hvac_id = hvac_id, component_type_id = component_type, supplier_detail_id = supplier_detail,status = "1").exists()
    if serial_num_obj:
        raise exceptions.ValidationError("Serial number already attached with another component.")

    obj = TblHvacComponent(
        hvac_id=hvac_id,
        serial_num=serial_num,
        # brand_name=brand_name,
        # dip_date=dip_date,
        component_type=component_type,
        supplier_detail=supplier_detail,
        status = "1",
        created_by = username,
        updated_by = username,
    )
    obj.save()
    return obj


@transaction.atomic
def hvac_delete_component(*, hvac_id:str,id: int):
    # TODO: perform soft delete
    # component = get_object(TblHvacComponent, component_type_id=component_id)
    component = TblHvacComponent.objects.filter(hvac_id = hvac_id, id = id, status = "1").first()
    component.status = "0"
    component.save()
    # component.delete()


def hvac_component_get(*, by: dict):
    pass


@transaction.atomic
def hvac_component_update(
    *, hvac_id: str, id: int, **kwargs
) -> TblHvacComponent:
    non_side_effect_fields = [i for i in kwargs]
    # component = get_object(TblHvacComponent, id=component_id)
    # component = TblHvacComponent.objects.filter(hvac_id = hvac_id, component_type_id = component_id).first()
    component = TblHvacComponent.objects.filter(hvac_id = hvac_id, id = id, status ="1").first()
    
    if component is None:
        pass
    component, status = model_update(
        instance=component, fields=non_side_effect_fields, data=kwargs
    )

    # Side-effect fields update here (e.g. username is generated based on first & last name)

    # ... some additional tasks with the user ...

    return component
