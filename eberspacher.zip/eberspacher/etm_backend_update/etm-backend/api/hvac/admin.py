from django.contrib import admin

from .models import (TblHvacComponent, TblHvacComponentType, TblHvacVinGateway,
                     TblSerialNoMaster)

# Register your models here.
admin.site.register(TblHvacVinGateway)
admin.site.register(TblHvacComponent)
admin.site.register(TblHvacComponentType)
admin.site.register(TblSerialNoMaster)
