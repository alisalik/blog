from django.urls import path

from . import views
from .views import (
    ComponentTypeList,
    EberspacherComponentLookup,
    HvacComponentAdd,
    HvacComponentDelete,
    HvacComponentDetail,
    HvacComponentList,
    HvacComponentsCount,
    HvacComponentSupplierDetailApi,
    HvacComponentSupplierDetailListApi,
    HvacComponentSupplierListApi,
    HvacComponentUpdateApi,
    HvacCreateAPi,
    VinDecoder,
)

# TODO: rearrange
urlpatterns = [
    path(
        "",
        HvacCreateAPi.as_view(),
        name="hvac.create",
    ),
    # path(
    #     "<str:vin>/components/eberspacher/<int:serial_num>",
    #     EberspacherComponentLookup.as_view(),
    #     name="components.eber.lookup",
    # ),
    path(
        "components/eberspacher/<str:serial_num>",
        EberspacherComponentLookup.as_view(),
        name="components.eber.lookup",
    ),
    path(
        "<str:vin>/vin/decode",
        VinDecoder.as_view(),
        name="vehicle.vin.decoder",
    ),
    
    path(
        "vin/decode",
        VinDecoder.as_view(),
        name="vehicle.vin.decoder",
    ),
    path("component", views.index, name="index"),
    path(
        "<str:vin>/<str:hvac_id>/components/list",
        ComponentTypeList.as_view(),
        name="components.list",
    ),
    
    path(
        "components/list",
        ComponentTypeList.as_view(),
        name="components.list",
    ),
    path(
        "<str:vin>/<str:hvac_id>/components",
        HvacComponentList.as_view(),
        name="hvac.components.list",
    ),
    path(
        "<str:hvac_id>/components",
        HvacComponentList.as_view(),
        name="hvac.components.list",
    ),
    path(
        "<str:vin>/<str:hvac_id>/components/add",
        HvacComponentAdd.as_view(),
        name="hvac.components.add",
    ),
    
    path(
        "<str:hvac_id>/components/add",
        HvacComponentAdd.as_view(),
        name="hvac.components.add",
    ),
    path(
        "<str:vin>/<str:hvac_id>/components/<int:component_id>/update",
        HvacComponentUpdateApi.as_view(),
        name="hvac.components.update",
    ),
    
    path(
        "<str:hvac_id>/components/<int:component_id>/update",
        HvacComponentUpdateApi.as_view(),
        name="hvac.components.update",
    ),
    path(
        "<str:vin>/<str:hvac_id>/components/<int:component_id>/delete",
        HvacComponentDelete.as_view(),
        name="hvac.componenet.delete",
    ),
    path(
        "<str:hvac_id>/components/<int:component_id>/delete",
        HvacComponentDelete.as_view(),
        name="hvac.componenet.delete",
    ),
    path(
        "<str:vin>/<str:hvac_id>/components/<int:component_id>",
        HvacComponentDetail.as_view(),
        name="hvac.componenet.udpate",
    ),
    
    path(
        "<str:hvac_id>/components/<int:component_id>",
        HvacComponentDetail.as_view(),
        name="hvac.componenet.udpate",
    ),
    path(
        "<str:vin>/<str:hvac_id>/components/get_count",
        HvacComponentsCount.as_view(),
        name="hvac.componenet.count",
    ),
    path(
        "<str:hvac_id>/components/get_count",
        HvacComponentsCount.as_view(),
        name="hvac.componenet.count",
    ),
    path(
        "components/suppliers",
        HvacComponentSupplierListApi.as_view(),
        name="hvac.componenet.suppliers",
    ),
    path(
        "<str:vin>/<str:hvac_id>/components/suppliers/<int:supplier_id>",
        HvacComponentSupplierDetailApi.as_view(),
        name="hvac.componenet.supplier.detail",
    ),
     path(
        "components/suppliers/<int:supplier_id>",
        HvacComponentSupplierDetailApi.as_view(),
        name="hvac.componenet.supplier.detail",
    ),
    path(
        "<str:vin>/<str:hvac_id>/components/suppliers/details",
        HvacComponentSupplierDetailListApi.as_view(),
        name="hvac.componenet.supplier.detail",
    ),
    
    path(
        "components/suppliers/details",
        HvacComponentSupplierDetailListApi.as_view(),
        name="hvac.componenet.supplier.detail",
    ),
]
