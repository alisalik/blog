import requests
from django.conf import settings


class NHTSADecoder:
    """VIN decoder using NHTSA free API"""

    def __init__(self, vin: str) -> None:
        self.cfg = getattr(settings, "VIN_DECODER_SERVICE_CONFIG", None)
        self.manufacturer_name = None
        self.fuel_type = None
        self.model = None
        self.vin = vin
        url = f"{self.cfg['NHTSA_URL']}/decodevinvalues/{vin}?format=json"
        self.vin_decode_response = requests.get(url=url).json()
        # as per now we have seen 2 different schema of response object is returned
        if "VIN:" in self.vin_decode_response["SearchCriteria"]:
            for item in self.vin_decode_response["Results"]:
                if item["VariableId"] == 27:  # for manufacturere name
                    self.manufacturer_name = item["Value"]
                if item["VariableId"] == 28:  # for model
                    self.model = item["Value"]
                if item["VariableId"] == 24:  # for variable
                    self.fuel_type = item["Value"]
                if item["VariableId"] == 26:  # for make
                    self.make_id = item["Value"]
                if item["VariableId"] == 149:
                    self.bus_type = item["Value"]
                if item["VariableId"] == 26:
                    self.error_text = item["Value"]

        elif "VIN(s)" in self.vin_decode_response["SearchCriteria"]:
            for item in self.vin_decode_response["Results"]:
                (
                    self.manufacturer_name,
                    self.model,
                    self.fuel_type,
                    self.make_id,
                    self.bus_type,
                    self.error_text,
                ) = (
                    item["Manufacturer"],
                    item["Model"],
                    item["FuelTypePrimary"],
                    item["MakeID"],
                    item["BusType"],
                    item["ErrorText"],
                )
        else:
            raise Exception("NHTSA not able to decode VIN")

    def decode(self) -> None:
        """based on vin decoding output decode all objects"""
        if (self.model == "" or self.model is None) and (
            self.make_id != "" and self.make_id is not None
        ):
            # if model is none the try to find by makeid
            url = (
                f"{self.cfg['NHTSA_URL']}/GetModelsForMakeId/{self.make_id}?format=json"
            )
            models = []
            res = requests.get(url=url).json()
            for item in res["Results"]:
                models.append(item["Model_Name"])
            self.model = models
        elif self.make_id == "":
            raise Exception(self.error_text)
        return {
            "vin": self.vin,
            "bus_type": self.bus_type,
            "manufacturer_name": self.manufacturer_name,
            "primary_fuel_type": self.fuel_type,
            "model": self.model,
        }
