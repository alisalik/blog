import hashlib

import requests
from django.conf import settings
from pyvin import VIN

from .vin_decoders import NHTSADecoder


def decode_vin(decoder: str, vin: str) -> dict:
    """decode vin using 3rd party libs"""
    cfg = getattr(settings, "VIN_DECODER_SERVICE_CONFIG", None)
    if decoder == "pyvin":
        decoded = VIN(vin)
    elif decoder == "vindecoder":
        controlsum = hashlib.sha1(
            f"{vin}|{cfg['ID']}|{cfg['API_KEY']}|{cfg['API_SECRET']}".encode()
        ).hexdigest()[0:10]
        url = f"{cfg['BASE_URL']}/{cfg['API_KEY']}/{controlsum}/decode/{vin}.json"
        resp = requests.get(url=url)
        decoded = resp.json()
        return decoded  # already a dict
    elif decoder == "nhtsa":
        try:
            d = NHTSADecoder(vin)
            decoded = d.decode()
            del d
        except Exception as err:
            return {"error": str(err)}
        return decoded
    return decoded.__dict__


if __name__ == "__main__":
    pass
