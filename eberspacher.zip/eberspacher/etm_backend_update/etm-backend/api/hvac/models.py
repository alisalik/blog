"""hvac related model classes"""
from core.models import BaseModel
from django.core.validators import MinLengthValidator
from django.db import models


class TblVehicle(BaseModel):
    vin = models.CharField(primary_key=True, max_length=100)
    engine_type = models.CharField(max_length=3, blank=True, null=True)
    manufacturer = models.CharField(max_length=100, blank=True, null=True)
    model = models.CharField(max_length=100, blank=True, null=True)
    body_number = models.CharField(max_length=100, blank=True, null=True)
    registration_date = models.DateField(blank=True, null=True)
    climate_zone = models.CharField(max_length=100, blank=True, null=True)
    city = models.CharField(max_length=100, blank=True, null=True)
    status = models.CharField(max_length=1, blank=True, null=True, default="0")

    class Meta:
        managed = False
        db_table = "tbl_vehicle"


# This is an auto-generated Django model module.
# You'll have to do the following manually to clean this up:
#   * Rearrange models' order
#   * Make sure each model has one field with primary_key=True
#   * Make sure each ForeignKey and OneToOneField has `on_delete` set to the desired behavior
#   * Remove `managed = False` lines if you wish to allow Django to create, modify, and delete the table
# Feel free to rename the models, but don't rename db_table values or field names.


class TblSerialNoMaster(models.Model):
    instruction = models.BigIntegerField(
        db_column="Instruction", blank=True, null=True
    )  # Field name made lowercase.
    position_number_1 = models.BigIntegerField(
        db_column="Position_number_1", blank=True, null=True
    )  # Field name made lowercase.
    serial_number_1 = models.BigIntegerField(blank=True, null=True)
    delivery = models.BigIntegerField(blank=True, null=True)
    types = models.BigIntegerField(blank=True, null=True)
    kind = models.CharField(max_length=255, blank=True, null=True)
    plant_1 = models.BigIntegerField(
        db_column="Plant_1", blank=True, null=True
    )  # Field name made lowercase.
    material2_part_number = models.CharField(
        db_column="Material2_Part_number", max_length=255, blank=True, null=True
    )  # Field name made lowercase.
    position_number_2 = models.BigIntegerField(
        db_column="Position_number_2", blank=True, null=True
    )  # Field name made lowercase.
    customer_order_fauf = models.BigIntegerField(
        db_column="customer_order_FAUF", blank=True, null=True
    )  # Field name made lowercase.
    command = models.BigIntegerField(blank=True, null=True)
    material = models.CharField(max_length=255, blank=True, null=True)
    client = models.CharField(max_length=255, blank=True, null=True)
    receiver_of_goods = models.CharField(max_length=255, blank=True, null=True)
    sales_receipt_for_delivery = models.IntegerField(
        db_column="Sales_receipt_for_delivery", blank=True, null=True
    )  # Field name made lowercase.
    vart = models.CharField(
        db_column="VArt", max_length=255, blank=True, null=True
    )  # Field name made lowercase.
    sales_org = models.IntegerField(blank=True, null=True)
    vway = models.IntegerField(
        db_column="Vway", blank=True, null=True
    )  # Field name made lowercase.
    order_fee = models.CharField(max_length=255, blank=True, null=True)
    position_1 = models.IntegerField(
        db_column="Position_1", blank=True, null=True
    )  # Field name made lowercase.
    goods_group = models.CharField(max_length=255, blank=True, null=True)
    description = models.CharField(max_length=255, blank=True, null=True)
    ptyp = models.CharField(max_length=255, blank=True, null=True)
    template = models.BigIntegerField(blank=True, null=True)
    lfp = models.CharField(
        db_column="LFP", max_length=255, blank=True, null=True
    )  # Field name made lowercase.
    fcrel = models.CharField(
        db_column="FcRel", max_length=255, blank=True, null=True
    )  # Field name made lowercase.
    product_hierarchy = models.CharField(
        db_column="Product_Hierarchy", max_length=255, blank=True, null=True
    )  # Field name made lowercase.
    plant_2 = models.IntegerField(
        db_column="Plant_2", blank=True, null=True
    )  # Field name made lowercase.
    vat = models.IntegerField(
        db_column="VAT", blank=True, null=True
    )  # Field name made lowercase.
    position_2 = models.IntegerField(
        db_column="Position_2", blank=True, null=True
    )  # Field name made lowercase.
    caused = models.CharField(max_length=255, blank=True, null=True)
    req_date_fauf = models.CharField(
        db_column="Req_Date_fauf", max_length=255, blank=True, null=True
    )  # Field name made lowercase.
    basic_deadline = models.CharField(max_length=255, blank=True, null=True)
    basic_start_date = models.CharField(max_length=255, blank=True, null=True)
    actual_start_date = models.CharField(max_length=255, blank=True, null=True)
    angel_am = models.CharField(
        db_column="Angel_am", max_length=255, blank=True, null=True
    )  # Field name made lowercase.
    inconsistent = models.IntegerField(blank=True, null=True)
    counter = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = "tbl_serialno_master"


class TblHvacComponentType(models.Model):
    vehicle_engine_type = models.CharField(max_length=3, blank=True, null=True)
    type = models.CharField(max_length=6, blank=True, null=True)
    name = models.CharField(max_length=255, blank=True, null=True)
    description = models.TextField(blank=True, null=True)
    icon_file = models.CharField(max_length=255, blank=True, null=True)
    status = models.CharField(max_length=1, blank=True, null=True)

    class Meta:
        managed = False
        db_table = "tbl_hvac_component_type"


class TblHvacComponentSupplier(models.Model):
    name = models.CharField(max_length=255, blank=True, null=True)
    descritpion = models.CharField(max_length=255, blank=True, null=True)
    status = models.CharField(max_length=1, blank=True, null=True)

    class Meta:
        managed = False
        db_table = "tbl_hvac_component_supplier"


class TblGateway(models.Model):
    serial_number = models.CharField(primary_key=True, max_length=100)
    # manufacturer = models.CharField(max_length=100, blank=True, null=True)
    # model_num = models.CharField(max_length=100, blank=True, null=True)
    sim_number = models.CharField(max_length=100, blank=True, null=True)
    # icon = models.CharField(max_length=100, blank=True, null=True)
    gateway_status = models.CharField(max_length=18, blank=True, null=True)
    status = models.CharField(max_length=1, blank=True, null=True)
    created_at = models.DateTimeField(blank=True, null=True)
    created_by = models.CharField(max_length=100, blank=True, null=True)
    updated_at = models.DateTimeField(blank=True, null=True)
    updated_by = models.CharField(max_length=100, blank=True, null=True)
    can0_active = models.CharField(max_length=3 , blank = True , null = True)
    class Meta:
        managed = False
        db_table = "tbl_gateway"


class TblHvacVinGateway(BaseModel):
    hvac_id = models.CharField(primary_key=True, max_length=100)
    vin = models.ForeignKey(
        "TblVehicle",
        models.DO_NOTHING,
        db_column="vin",
        blank=True,
        null=True,
        related_name="hvac_vin_gateway",
    )
    gateway = models.ForeignKey("TblGateway", models.DO_NOTHING, blank=True, null=True)
    status = models.CharField(max_length=1, blank=True, null=True, default="1")

    class Meta:
        managed = False
        db_table = "tbl_hvac_vin_gateway"


class TblHvacComponentSupplierDetail(models.Model):
    supplier = models.ForeignKey(
        "TblHvacComponentSupplier", models.DO_NOTHING, blank=True, null=True
    )
    name = models.CharField(max_length=255, blank=True, null=True)
    component = models.CharField(max_length=200, blank=True, null=True)
    unit_type = models.CharField(max_length=200, blank=True, null=True)
    description = models.CharField(max_length=255, blank=True, null=True)
    status = models.CharField(max_length=1, blank=True, null=True)
    vehicle_engine_type = models.CharField(max_length=3, blank=True, null=True)
    build_year = models.CharField(max_length=100, blank=True, null=True)
    application = models.CharField(max_length=100, blank=True, null=True)

    class Meta:
        managed = False
        db_table = "tbl_hvac_component_supplier_detail"


class TblHvacComponent(models.Model):
    component_type = models.ForeignKey(
        "TblHvacComponentType",
        models.DO_NOTHING,
        blank=True,
        null=True,
        related_name="component_type",
    )
    serial_num = models.CharField(
        max_length=9, blank=True, null=True, validators=[MinLengthValidator(4)]
    )
    # brand_name = models.CharField(max_length=100, blank=True, null=True)
    # type = models.CharField(max_length=100, blank=True, null=True)
    # dip_date = models.DateField(blank=True, null=True)
    supplier_detail = models.ForeignKey(
        "TblHvacComponentSupplierDetail",
        models.DO_NOTHING,
        blank=True,
        null=True,
        related_name="supplier_detail",
    )

    status = models.CharField(max_length=1, blank=True, null=True)
    created_on = models.DateTimeField(auto_now_add=True, blank=True, null=True)
    created_by = models.CharField(max_length=100, blank=True, null=True)
    updated_by = models.CharField(max_length=100, blank=True, null=True)
    updated_on = models.DateTimeField(auto_now=True, blank=True, null=True)
    hvac = models.ForeignKey(
        "TblHvacVinGateway", models.DO_NOTHING, blank=True, null=True
    )

    class Meta:
        managed = False
        db_table = "tbl_hvac_component"
