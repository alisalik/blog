"""entry point for hvac related request"""
from ssl import VERIFY_X509_PARTIAL_CHAIN
from common.constants import DUMMY_TOKEN_DATA
from core.jsend_response import JsendSuccessResponse
from django.http import HttpResponse
from drf_yasg import openapi
from drf_yasg.utils import swagger_auto_schema
from rest_framework import serializers
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.permissions import IsAuthenticated
from core.permissions import AllowedToAccessVehicle
from .models import (
    TblHvacVinGateway,
    TblHvacComponent,
    TblHvacComponentSupplier,
    TblHvacComponentSupplierDetail,
    TblHvacComponentType,
    TblSerialNoMaster,
)
from rest_framework.exceptions import APIException, ValidationError

from .selectors import (
    eberspacher_component_get,
    get_component_list,
    hvac_component_get,
    hvac_component_supplier_detail,
    hvac_component_supplier_detail_list,
    hvac_components_detail_get,
    hvac_components_get_count,
    hvac_components_suppliers_get,
)
from .services import hvac_component_add, hvac_component_update, hvac_delete_component
from .utils import decode_vin
from core.permissions import AllowedToUpdateAssests


def index(request, serial_num: int):
    """Test"""
    eberspacher_component_get(by={"serial_number_1": serial_num})
    return HttpResponse("Hello, world. You're at the polls index.")


class EberspacherComponentLookup(APIView):
    # permission_classes = [IsAuthenticated & AllowedToAccessVehicle] 
    class OutputSerializer(serializers.ModelSerializer):
        # TODO: what is model_number in datatabase?
        serial_number = serializers.IntegerField(source="serial_number_1")
        position_number = serializers.IntegerField(source="position_number_1")
        # material = serializers.CharField(source="material")
        # model_number = serializers.CharField()

        class Meta:
            model = TblSerialNoMaster
            fields = (
                "serial_number",
                "position_number",
                
                
            )

    def get(self, request, serial_num: str):
        if not serial_num.isnumeric():
            raise ValidationError("serial number cannot be string")
        serial_num = int(serial_num)
        component = eberspacher_component_get(by={"serial_number_1": serial_num })
        
        if component is None:
            # raise 
            # return Response({"msg": "No records found! Pls check input serial number"})
            raise ValidationError("No records found! Please check input serial number")
        else:
            if TblHvacComponent.objects.filter(serial_num=serial_num, status = "1").exists():
                raise ValidationError("serial number already attached to another component")
                
        serializer = self.OutputSerializer(component)
        return JsendSuccessResponse(
            data=serializer.data, data_identifier="eberspacher_component"
        ).get_response()


class HvacCreateAPi(APIView):
    class InputSerializer(serializers.ModelSerializer):
        class Meta:
            model = TblHvacVinGateway
            fields = "__all__"

    def post(self, request):
        serializer = self.InputSerializer(data=request.data)
        return Response({"hi"})


class VinDecoder(APIView):
    # permission_classes = [IsAuthenticated & AllowedToAccessVehicle]
    class OutputSerializer(serializers.Serializer):
        pass

    class InputSerializer(serializers.Serializer):
        vin = serializers.CharField()
        decoder = serializers.CharField()

    def get(self, request, vin =""):
        serializer = self.InputSerializer(data=request.query_params.dict())
        serializer.is_valid(raise_exception=True)
        decoded = decode_vin(**serializer.validated_data)
        return JsendSuccessResponse(
            data=decoded, data_identifier="vehicle"
        ).get_response()


class ComponentTypeList(APIView):
    # permission_classes = [IsAuthenticated & AllowedToAccessVehicle]
    # TODO: filter on the basis of type also.
    # /hvac/components/list?bus_type=ICE&type=Battery Conditioning
    bus_type = openapi.Parameter(
        "bus_type", in_=openapi.IN_QUERY, type=openapi.TYPE_STRING
    )

    class OutputSerializer(serializers.ModelSerializer):
        class Meta:
            model = TblHvacComponentType
            fields = "__all__"

    class InputSerializer(serializers.Serializer):
        bus_type = serializers.ChoiceField(["EV", "ICE"], required=False)
        type = serializers.CharField(required=False)

    @swagger_auto_schema(
        operation_description="partial_update description override",
        manual_parameters=[bus_type],
    )
    def get(self, request, vin = "", hvac_id =""):
        components = []
        # if len(request.query_params.dict()) == 0:
        # query parameters are passed!
        # components = get_component_list()
        # else:
        serializer = self.InputSerializer(data=request.query_params.dict())
        serializer.is_valid(raise_exception=True)
        by = request.query_params.dict()
        if "bus_type" in request.query_params.dict():
            by["vehicle_engine_type"] = by.pop("bus_type")
        components = get_component_list(by=by)
        serializer = self.OutputSerializer(components, many=True)
        return JsendSuccessResponse(
            serializer.data, data_identifier="component_types"
        ).get_response()


class InputSerializer(serializers.ModelSerializer):
    class Meta:
        model = TblHvacComponent
        fields = (
            "serial_num",
            # "brand_name",
            "type",
            # "dip_date",
            "component_type",
            "supplier_detail",
            # "type",
        )


class HvacComponentAdd(APIView):
    # permission_classes = [IsAuthenticated & AllowedToAccessVehicle]
    # TODO: work on populating competitor_id
    # TODO: add check of serial number if unit is of eberspacher.
    serializer_class = InputSerializer

    class InputSerializer(serializers.ModelSerializer):
        class Meta:
            model = TblHvacComponent
            fields = (
                "serial_num",
                # "brand_name",
                # "type",
                # "dip_date",
                "component_type",
                "supplier_detail",
                # "type",
            )

    class OutputSerializer(serializers.ModelSerializer):
        class Meta:
            model = TblHvacComponent
            fields = "__all__"

    def post(self, request,hvac_id: str):
        company_id = request.user.company_id
        user_id  = request.auth["user_id"]
        
        
        company = request.user.company.name
        serializer = self.InputSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        componenet = hvac_component_add( user_id = user_id,
            hvac_id=hvac_id,
            **serializer.validated_data
            # brand_name="Nothing",
            # dip_date=None
        )
        serializer = self.OutputSerializer(componenet)
        return JsendSuccessResponse(
            data=serializer.data, data_identifier="component"
        ).get_response()


class HvacComponentUpdateApi(APIView):
    permission_classes = [IsAuthenticated & AllowedToUpdateAssests]
    class InputSerializer(serializers.ModelSerializer):
        class Meta:
            model = TblHvacComponent
            fields = "__all__"

    class OutputSerializer(serializers.ModelSerializer):
        class Meta:
            model = TblHvacComponent
            fields = "__all__"

    def post(self, request, hvac_id: str, component_id: int,vin =""):
        serializer = self.InputSerializer(data=request.data, partial=True)
        serializer.is_valid(raise_exception=True)
        component = hvac_component_update(
            hvac_id=hvac_id, id= component_id, **serializer.validated_data
        )
        data = self.OutputSerializer(component).data
        return JsendSuccessResponse(
            data=data, data_identifier="component"
        ).get_response()


class HvacComponentDelete(APIView):
    # permission_classes = [IsAuthenticated & AllowedToAccessVehicle]
    # TODO: perfrom solf delete
    def delete(self, request, hvac_id: str, component_id: int,vin=""):
        component = hvac_delete_component(hvac_id = hvac_id,id=component_id)
        return JsendSuccessResponse(
            data={"message": f"Component id:{component_id} deleted successfully"}
        ).get_response()


class HvacComponentDetail(APIView):
    # permission_classes = [IsAuthenticated & AllowedToAccessVehicle]
    class OutputSerializer(serializers.ModelSerializer):
        class Meta:
            model = TblHvacComponent
            fields = "__all__"

    def get(self, request ,hvac_id: str, component_id: int,vin=""):
        component = hvac_component_get(by={"component_type_id": component_id})
        serializer = self.OutputSerializer(component)
        return JsendSuccessResponse(
            data=serializer.data, data_identifier="component"
        ).get_response()


class HvacComponentsCount(APIView):
    # permission_classes = [IsAuthenticated & AllowedToAccessVehicle]
    class CountObjectSerializer(serializers.Serializer):
        pass

    class OutputSerializer(serializers.Serializer):
        pass

    def get(self, request,hvac_id: str,vin=""):
        counts = hvac_components_get_count(hvac_id)
        return JsendSuccessResponse(
            data=counts,
            data_identifier="count",
        ).get_response()


class HvacComponentSupplierListApi(APIView):
    # permission_classes = [IsAuthenticated & AllowedToAccessVehicle]
    class OutputSerializer(serializers.ModelSerializer):
        class Meta:
            model = TblHvacComponentSupplier
            fields = "__all__"

    def get(self,request):
        suppliers = hvac_components_suppliers_get()
        serializer = self.OutputSerializer(suppliers, many=True)
        return JsendSuccessResponse(
            data=serializer.data, data_identifier="suppliers"
        ).get_response()


class HvacComponentSupplierDetailApi(APIView):
    # permission_classes = [IsAuthenticated & AllowedToAccessVehicle]
    class OutputSerializer(serializers.ModelSerializer):
        class Meta:
            model = TblHvacComponentSupplierDetail
            fields = "__all__"

    class InputSerializer(serializers.Serializer):
        pass

    def get(self, request,supplier_id: int,vin="",hvac_id =""):
        supplier = hvac_component_supplier_detail(supplier_id)
        serializer = self.OutputSerializer(supplier, many=True)
        return JsendSuccessResponse(
            data=serializer.data, data_identifier="suppliers"
        ).get_response()


class HvacComponentSupplierDetailListApi(APIView):
    # permission_classes = [IsAuthenticated & AllowedToAccessVehicle]
    class OutputSerializer(serializers.ModelSerializer):
        unit_type = serializers.SerializerMethodField()

        def get_unit_type(self, obj):
            if obj.build_year is not None:
                return "{} ({})".format(obj.unit_type, obj.build_year)
            else:
                return obj.unit_type

        class Meta:
            model = TblHvacComponentSupplierDetail
            exclude = ("build_year",)

    class FilterSerializer(serializers.Serializer):
        """validate query parameters
        vehicle_engine_type: str
        name: str
        """

        vehicle_engine_type = serializers.ChoiceField(["EV", "ICE"], required=False)
        name = serializers.CharField(required=False)
        component = serializers.CharField(required=False)

        def __init__(self, *args, **kwargs):
            component_type = kwargs["data"].pop("component_type", None)
            if component_type is not None:
                kwargs["data"]["component"] = component_type
            # Instantiate the superclass normally
            super().__init__(*args, **kwargs)

    def get(self, request, hvac_id ="",vin =""):
        serializer = self.FilterSerializer(data=request.query_params.dict())
        serializer.is_valid(raise_exception=True)
        supplier = hvac_component_supplier_detail_list(
            filters=serializer.validated_data
        )
        serializer = self.OutputSerializer(supplier, many=True)
        return JsendSuccessResponse(
            data=serializer.data, data_identifier="suppliers"
        ).get_response()


class HvacComponentList(APIView):
    """get list of all the components attached to the HVAC"""
    # permission_classes = [IsAuthenticated & AllowedToAccessVehicle]

    class OutputSerializer(serializers.ModelSerializer):
        component_type_object = ComponentTypeList.OutputSerializer(
            source="component_type"
        )
        supplier_detail_object = HvacComponentSupplierDetailApi.OutputSerializer(
            source="supplier_detail"
        )

        class Meta:
            model = TblHvacComponent
            extra_fields = ["component_type_object", "supplier_detail_object"]
            exclude = (
                "supplier_detail",
                "component_type",
            )

        def get_field_names(self, declared_fields, info):
            """for extra_fields"""
            expanded_fields = super(
                HvacComponentList.OutputSerializer, self
            ).get_field_names(declared_fields, info)
            if getattr(self.Meta, "extra_fields", None):
                return expanded_fields + self.Meta.extra_fields
            else:
                return expanded_fields

    def get(self, request,hvac_id: str,vin=""):
        hvac_components = hvac_components_detail_get(hvac_id=hvac_id)
        serializer = self.OutputSerializer(hvac_components, many=True)
        return JsendSuccessResponse(
            serializer.data, data_identifier="components"
        ).get_response()


class HvacComponentSupplierEberspacherDetailApi(serializers.Serializer):
    pass
