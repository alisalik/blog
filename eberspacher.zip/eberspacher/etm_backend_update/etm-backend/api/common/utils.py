import json
from datetime import datetime
import time
from functools import wraps
import jwt
import requests
import pytz

requests.adapters.DEFAULT_RETRIES = 5
import operator
from common.constants import OEM

from common.constants import COMPANY_ROLE_TABLE_COLUMN_NAME_MAPPING
from django.conf import settings
from django.core.exceptions import ImproperlyConfigured
from django.db.models import Q
from django.http import Http404
from django.shortcuts import get_object_or_404
from rest_framework import serializers
from rest_framework.exceptions import APIException, ValidationError
from vehicle.models import TblHvacVinGateway, TblVehicle

from api.settings.base import SECRET_KEY
from company.models import TblCompanyRoleAssoc
from common.constants import ROLE_COMPANY_MAPPING , ROLE_COMPANY_REV_MAPPING


def make_mock_object(**kwargs):
    return type("", (object,), kwargs)


def get_object(model_or_queryset, **kwargs):
    """
    Reuse get_object_or_404 since the implementation supports both Model && queryset.
    Catch Http404 & return None
    """
    try:
        return get_object_or_404(model_or_queryset, **kwargs)
    except Http404:
        return None


def create_serializer_class(name, fields):
    return type(name, (serializers.Serializer,), fields)


def inline_serializer(*, fields, data=None, **kwargs):
    serializer_class = create_serializer_class(name="", fields=fields)

    if data is not None:
        return serializer_class(data=data, **kwargs)

    return serializer_class(**kwargs)


def assert_settings(required_settings, error_message_prefix=""):
    """
    Checks if each item from `required_settings` is present in Django settings
    """
    not_present = []
    values = {}

    for required_setting in required_settings:
        if not hasattr(settings, required_setting):
            not_present.append(required_setting)
            continue

        values[required_setting] = getattr(settings, required_setting)

    if not_present:
        if not error_message_prefix:
            error_message_prefix = "Required settings not found."

        stringified_not_present = ", ".join(not_present)

        raise ImproperlyConfigured(
            f"{error_message_prefix} Could not find: {stringified_not_present}"
        )

    return


def generate_hvac_id(*, vin: str):
    """generate hvac HVAC-DDMMYY - 0001"""
    obj = (
        TblHvacVinGateway.objects.all().only("hvac_id").order_by("-created_at").first()
    )  # hvac_22_01_0001

    if obj is None:
        hvac_id = f"HVAC_{datetime.utcnow().today().strftime('%d%m%y')}_0001"
        return hvac_id

    hvac_id = "HVAC_{cur_date}_{seq}"

    pre_seq = obj.hvac_id.split("_")[2]
    curr_seq = str(int(pre_seq) + 1).zfill(4)
    hvac_id = hvac_id.format(
        cur_date=datetime.utcnow().today().strftime("%d%m%y"), seq=curr_seq
    )

    return hvac_id


import functools
from functools import wraps


def add_static_token_context(func):
    context = {
        "company_code": "EB",
        "user_id": 1,
        "role": "SUPERADMIN",
        "company_role": "OWNER",
    }

    @wraps(func)
    def inner(*args, **kwargs):
        func(*args, cnt=context, **kwargs)

    return inner


@add_static_token_context
def dummy_request(some, request):
    print("test")


if __name__ == "__main__":
    # generate_hvac_id(engine_type="EV", vehicle_id=1)
    dummy_request(1, 2)


def decode_jwt_token(token: str):
    decoded = jwt.decode(token, SECRET_KEY, algorithms=["HS256"])
    return decoded


def extract_druid_data_rest_api(*, query: str, timeout: int = 2) -> dict:
    """assumes proper value of envs are set"""
    endpoint = settings.DRUID_REST_API_ENDPOINT
    request_body = {"query": query}
    for count in range(5):
        try:
            response = requests.post(
                endpoint,
                headers={"Content-Type": "application/json"},
                data=json.dumps(request_body).encode("utf-8"),
                timeout=timeout,
            )
            status_code = response.status_code
            if status_code in range(200, 300):
                return response.json()
        except Exception as e:
            pass

    raise APIException(
        detail=f"Error from upstream druid server: {response.json()['errorMessage']}",
        code=503,
    )


def get_signal_id_from_name(*, signal_name: str) -> int:
    try:
        signal_id = [
            signal["id"]
            for signal in settings.SIGNALS_METADATA
            if signal["name"] == signal_name
        ][
            0
        ]  # extracting 1st as only one signal with matching name will be present.
    except IndexError:
        raise ValidationError("No id for this signal found pls check the signal name.")
    return signal_id




def get_company_filter_on_vehicle(company_id: int, company_role: str):
    filter = {}
    if company_role == "admin":
        return filter  # its eberspacher no filter to be applied
    else:
        filter[COMPANY_ROLE_TABLE_COLUMN_NAME_MAPPING[company_role]] = company_id
    return filter


def access_to_admin(request, role):
    role =  request.auth["company_role_name"] # operator/service_provider/pta
    
    query_params = request.query_params.dict()
    depot_filter = {
        k: v
        for k, v in query_params.items()
        if k in ["color_code"] and query_params["color_code"]
    }
    vehicle_filter = {}

    if role == "admin":

        if "pto_id" in query_params and query_params["pto_id"]:
            vehicle_filter["pto_id"] = int(query_params["pto_id"])
        if (
            "service_provider_id" in query_params
            and query_params["service_provider_id"]
        ):
            vehicle_filter["service_provider_id"] = int(
                query_params["service_provider_id"]
            )
        if "fleet_id" in query_params and query_params["fleet_id"]:
            vehicle_filter["fleet_id"] = int(query_params["fleet_id"])

    if role == "operator":

        vehicle_filter["pto_id"] = request.user.company_id
        if (
            "service_provider_id" in query_params
            and query_params["service_provider_id"]
        ):
            vehicle_filter["service_provider_id"] = int(
                query_params["service_provider_id"]
            )
        if "fleet_id" in query_params and query_params["fleet_id"]:
            vehicle_filter["fleet_id"] = int(query_params["fleet_id"])
            
    
    
    elif role =="pta":
        vehicle_filter["pta_id"] = request.user.company_id
        
        if "pto_id" in query_params and query_params["pto_id"]:
            vehicle_filter["pto_id"] = int(query_params["pto_id"])
        if (
            "service_provider_id" in query_params
            and query_params["service_provider_id"]
        ):
            vehicle_filter["service_provider_id"] = int(
                query_params["service_provider_id"]
            )
        if "fleet_id" in query_params and query_params["fleet_id"]:
            vehicle_filter["fleet_id"] = int(query_params["fleet_id"])
        
        
        
    elif role == "service_provider":
        vehicle_filter["service_provider_id"] = request.user.company_id
        if "pto_id" in query_params and query_params["pto_id"]:
            vehicle_filter["pto_id"] = int(query_params["pto_id"])
        if "fleet_id" in query_params and query_params["fleet_id"]:
            vehicle_filter["fleet_id"] = int(query_params["fleet_id"])

    elif "fleet_id" in query_params and query_params["fleet_id"]:
        vehicle_filter["fleet_id"] = query_params["fleet_id"]

    return vehicle_filter


def get_signal_name():
    signals={}
    for data in settings.SIGNALS_METADATA:
        signals.update({data["id"]:data["name"]})
    return signals
    
def convert_to_druid_supported_timestamp(*,datetime_string: str = ""):
    tz_start_index = datetime_string.rfind("(")  # find index of last '('
    if tz_start_index != -1:
        timestamp_string_without_tz = datetime_string[:tz_start_index].strip()
    else:
        timestamp_string_without_tz = datetime_string
    dt = datetime.strptime(timestamp_string_without_tz, '%a %b %d %Y %H:%M:%S GMT%z')
    utc_tz = pytz.timezone('UTC')
    dt_utc = dt.astimezone(utc_tz)
    return dt_utc.strftime('%Y-%m-%dT%H:%M:%SZ')
    
def convert_to_utc_and_remove_tz(*, datetime_string: str = ""):
    dt = datetime.strptime(datetime_string, '%a %b %d %Y %H:%M:%S GMT%z')
    utc_tz = pytz.timezone('UTC')
    return dt.astimezone(utc_tz)


def company_details(request, company_id):
    role = request.auth["company_role_name"]
    user_role = request.auth["user_role"]
    # cmpid = request.auth["company_id"]
    cmptype = (TblCompanyRoleAssoc.objects.filter(company_id = company_id, parent_company_id__isnull = True).values("role_id"))[0]['role_id']
    if role in ["pta" ,"service_provider" , 'admin'] and cmptype in [ROLE_COMPANY_REV_MAPPING['pta'], ROLE_COMPANY_REV_MAPPING['service_provider'],ROLE_COMPANY_REV_MAPPING['admin']] and user_role == "company_admin" :
        return 'global'
    elif role in ["operator",'admin'] and cmptype == ROLE_COMPANY_REV_MAPPING['operator'] and user_role == "company_admin":
        return 'operator'
    else: 
        return 'not defined'
    
def company_role_details(request, company_id):
    role = request.auth["company_role_name"]
    user_role = request.auth["user_role"]
    # cmpid = request.auth["company_id"]
    cmptype = (TblCompanyRoleAssoc.objects.filter(company_id = request.auth["company_id"], parent_company_id__isnull = True).values("role_id"))[0]['role_id']
    if role in ["pta" ,"service_provider" , 'admin'] and cmptype in [ROLE_COMPANY_REV_MAPPING['pta'], ROLE_COMPANY_REV_MAPPING['service_provider'],ROLE_COMPANY_REV_MAPPING['admin']] :
        return 'global'
    elif role in ["operator",'admin'] and cmptype == ROLE_COMPANY_REV_MAPPING['operator']:
        return 'operator'
    else: 
        return 'not defined'


def retry_on_exception(exceptions, max_retries=3, delay=1):
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            retries = 0
            while retries < max_retries:
                try:
                    return func(*args, **kwargs)
                except exceptions as e:
                    retries += 1
                    print(f"Exception caught: {type(e)}")
                    if retries >= max_retries:
                        raise
                    time.sleep(delay)
        return wrapper
    return decorator

def redis_value_get(redis_connection, key):
    return redis_connection.get("eber:gateways#"+gateway_id+":gps")

from common.constants import ROLE_COMPANY_MAPPING as rcm
class VehicleSelector():
    def create_vehicle_filter(self,jwt_token, filter_params={}):
        # input -> this function take company_role and company_id from jwt_token
        # output -> and give vins and Tbl_vehicle_objects according to the company role and company_id
        # filter_params -> filter anything from tbl_vehicle and get objects accordingly
        
        
        company_id = jwt_token["company_id"]
        company_role = jwt_token["company_role"]
        # rcm -> ROLE_COMPANY_MAPPING
        
        if  rcm[0] or rcm[4]:
            vehicle = TblVehicle.objects.filter(**filter_params).all()
            
        else:
            vehicle = TblVehicle.objects.filter(
            **{COMPANY_ROLE_TABLE_COLUMN_NAME_MAPPING[company_role]:company_id}, **filter_params).all()
        
        return vehicle


def hard_code_company(request):
    if request.auth["company_name"].split(" ")[0] == OEM:
        return True
    else:
        False