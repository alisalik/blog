DUMMY_TOKEN_DATA = {
    "company_id": 22,
    "company_role": "PTO",
    "user_id": 1,
    "role": "PTO",
}

# used to lookup for vehicle model columns based on user role.
USER_ROLE_VEHICLE_MODEL_MAPPING = {
    "operator": "pto_id",
    "admin": "admin",
    "pta": "pta_id",
    "service_provider": "service_provider_id",
}

ROLE_COMPANY_MAPPING ={
    2: "admin",
    3: "operator",
    4: "pta",
    5:"service_provider",
    6:"app_admin"
    
}

ROLE_COMPANY_REV_MAPPING ={
    "admin" : 2,
    "operator":3,
    "pta":4,
    "service_provider":5,
    "app_admin":6
    
}

OEM = "OEM"

color_coding = {
    "orange": "F57A08",
    "grey": "A7AEB4",
    "green": "006B38",
    "red": "D21D26",
}

COMPANY_ROLE_TABLE_COLUMN_NAME_MAPPING = {
    "operator": "pto_id",
    "admin": "admin",
    "pta": "pta_id",
    "service_provider": "service_provider_id",
}
from django.conf import settings
eberspacher_url = settings.EBERSPACHER_URL
SOURCE = "noreply@bus.e-connected.com"

INVITATION_TEMPLATE = """
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>

<head>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin="">
    <link href="https://fonts.googleapis.com/css2?family=Barlow:wght@400;500;600&amp;display=swap" rel="stylesheet">
    <style>
        .whiteText td {
            color: white;
        }

        body,
        table tr,
        table td,
        a,
        table.MsoNormalTable,
        p {
            font-family: Arial, Helvetica, sans-serif !important;
            color: #70868E;
        }

        a {
            text-decoration: none;
        }

        p.MsoNormal {
            margin: 0px !important;
        }
    </style>
    
    <script>
    function setDynamicLink() {
      var dynamicLink = eberspacher_url;  // Replace with your dynamic link variable

      var linkElement = document.getElementById("dynamicLink");
      linkElement.href = dynamicLink;
    }
  </script>
</head>

<body style="margin: 0;width: 100%;font-family: 'Barlow','Segoe UI',sans-serif;color: #70868E;margin: auto;">
    <table cellpadding="0" cellspacing="0" align="center" border="0" width="600"
        style="border-collapse: collapse; margin: 0 auto; width: 600px;">
        <tr>
            <td>
                <table cellspacing="0" cellpadding="0" style="padding: 25px;width: 100%;">
                    <tr>
                        <td>
                            <table style="margin:0px;" width="100%" cellspacing="0" cellpadding="0">
                                <tr>
                                    <td align="left"> <span
                                            style="text-transform: uppercase; font-size: small; font-weight: bold;">A
                                            World of Comfort</span> </td>
                                    <td align="right"> <img width="150" height="43.703" alt="Eberspächer Logo"
                                            src="https://coolandtrack-mail.s3.eu-central-1.amazonaws.com/Logo_standard_RGB.png">
                                    </td>
                                </tr>
                            </table>
                            <table width="100%" cellspacing="0" cellpadding="0">
                                <tr>
                                    <td align="left"> <img width="300" height="36.656" alt="E-CONNECTED"
                                            src="https://coolandtrack-mail.s3.eu-central-1.amazonaws.com/Logo.png"
                                            style="margin: 50px 0px 25px 0px;"> </td>
                                </tr>
                                <tr>
                                    <td align="left"
                                        style="background: url(https://coolandtrack-mail.s3.eu-central-1.amazonaws.com/Alert-Grid.png);background-repeat: no-repeat;background-size: contain; height: 165px; vertical-align: top; padding-top: 16px;">
                                        <span
                                            style="color: #37baeb;font-size: 25px;font-weight: 500; margin-bottom: 30px;">Welcome
                                            to e-connected!</span> </td>
                                </tr>
                                <tr>
                                    <td align="left">
                                        <table style="padding: 20px;width: 100%;background-color: #37baeb;">
                                            <tr>
                                                <td>
                                                    <table width="100%" class="whiteText">
                                                        <tr>
                                                            <td style="font-weight: 600;" width="125">Username:</td>
                                                            <td> __email__</td>
                                                        </tr>
                                                        <tr>
                                                            <td style="font-weight: 600;">Password:</td>
                                                            <td>__password__</td>
                                                        </tr>
                                                        <tr height="125px">
                                                            <td width="150"> Click here to view the details: </td>
                                                            <td align="right">
                                                                <table cellspacing="0" cellpadding="0">
                                                                    <tr>
                                                                        <td bgcolor="#FFFFFF"
                                                                            style="padding: 5px 50px;"> <a
                                                                                href= __eberspacher_url__
                                                                                target="_blank" style="color: #37baeb;">
                                                                                Start </a> </td>
                                                                    </tr>
                                                                </table>
                                                            </td>
                                                        </tr>
                                                    </table>
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                            </table>
                            <hr style="margin: 30px 0px;border: #70868E solid 1px;">
                            <table style="margin:0px; font-size: small" width="100%" cellspacing="0" cellpadding="0">
                                <tr>
                                    <td align="left">
                                        <font size="2">
                                            <p style="font-weight: bold; margin: 0;">Contact us</p>
                                            <p style="font-weight: bold;">Eberspächer Climate Control Systems GmbH <br>
                                                Eberspächerstrasse 24,
                                                73730 Esslingen,
                                                GERMANY | www. eberspächer.com | </p>
                                            <p>Company information about Eberspächer in accordance with German legal
                                                requirements as well as our privacy policy for business partners can be
                                                found at: <a href="http://www.eberspaecher.com/unternehmensdaten"
                                                    target="_blank"
                                                    style="color: inherit;">http://www.eberspaecher.com/unternehmensdaten</a>,
                                                (German language only). </p>
                                        </font>
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</body>

</html>"""

        
RSESND_TEMP_PASS_TEMPLATE = """
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>

<head>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin="">
    <link href="https://fonts.googleapis.com/css2?family=Barlow:wght@400;500;600&amp;display=swap" rel="stylesheet">
    <style>
        .whiteText td {
            color: white;
        }

        body,
        table tr,
        table td,
        a,
        table.MsoNormalTable,
        p {
            font-family: Arial, Helvetica, sans-serif !important;
            color: #70868E;
        }

        a {
            text-decoration: none;
        }

        p.MsoNormal {
            margin: 0px !important;
        }
    </style>
</head>

<body style="margin: 0;width: 100%;font-family: 'Barlow','Segoe UI',sans-serif;color: #70868E;margin: auto;">
    <table cellpadding="0" cellspacing="0" align="center" border="0" width="600"
        style="border-collapse: collapse; margin: 0 auto; width: 600px;">
        <tr>
            <td>
                <table cellspacing="0" cellpadding="0" style="padding: 25px;width: 100%;">
                    <tr>
                        <td>
                            <table style="margin:0px;" width="100%" cellspacing="0" cellpadding="0">
                                <tr>
                                    <td align="left"> <span
                                            style="text-transform: uppercase; font-size: small; font-weight: bold;">A
                                            World of Comfort</span> </td>
                                    <td align="right"> <img width="150" height="43.703" alt="Eberspächer Logo"
                                            src="https://coolandtrack-mail.s3.eu-central-1.amazonaws.com/Logo_standard_RGB.png">
                                    </td>
                                </tr>
                            </table>
                            <table width="100%" cellspacing="0" cellpadding="0">
                                <tr>
                                    <td align="left"> <img width="300" height="36.656" alt="E-CONNECTED"
                                            src="https://coolandtrack-mail.s3.eu-central-1.amazonaws.com/Logo.png"
                                            style="margin: 50px 0px 25px 0px;"> </td>
                                </tr>
                                <tr>
                                    <td align="left"
                                        style="background: url(https://coolandtrack-mail.s3.eu-central-1.amazonaws.com/Alert-Grid.png);background-repeat: no-repeat;background-size: contain; height: 165px; vertical-align: top; padding-top: 16px;">
                                        <span
                                            style="color: #37baeb;font-size: 25px;font-weight: 500; margin-bottom: 30px;">Your
                                            Temporary password arrived!</span> </td>
                                </tr>
                                <tr>
                                    <td align="left">
                                        <table style="padding: 20px;width: 100%;background-color: #37baeb;">
                                            <tr>
                                                <td>
                                                    <table width="100%" class="whiteText">
                                                        <tr>
                                                            <td style="font-weight: 600;">Temprory Password:</td>
                                                            <td>__password__</td>
                                                        </tr>
                                                    </table>
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                            </table>
                            <hr style="margin: 30px 0px;border: #70868E solid 1px;">
                            <table style="margin:0px; font-size: small" width="100%" cellspacing="0" cellpadding="0">
                                <tr>
                                    <td align="left">
                                        <font size="2">
                                            <p style="font-weight: bold; margin: 0;">Contact us</p>
                                            <p style="font-weight: bold;">Eberspächer Climate Control Systems GmbH <br>
                                                Eberspächerstrasse 24,
                                                73730 Esslingen,
                                                GERMANY | www. eberspächer.com | </p>
                                            <p>Company information about Eberspächer in accordance with German legal
                                                requirements as well as our privacy policy for business partners can be
                                                found at: <a href="http://www.eberspaecher.com/unternehmensdaten"
                                                    target="_blank"
                                                    style="color: inherit;">http://www.eberspaecher.com/unternehmensdaten</a>,
                                                (German language only). </p>
                                        </font>
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</body>

</html>"""                                



index_error_code_desc = {
0 :"NULL",
1 :"ND1",
2 :"ND2",
3 :"ND3",
4 :"HD1",
5 :"HD2",
6 :"HD3",
7 :"KG1",
8 :"KG2",
9 :"KG3",
10:"NDT1",
11:"NDT2",
12:"NDT3",
13:"HDT1",
14:"HDT2",
15:"HDT3",
16:"AFO",
17:"AFK",
18:"IFO1",
19:"IFO2",
20:"IFO3",
21:"IFO4",
22:"IFK1",
23:"IFK2",
24:"IFK3",
25 :"IFK4",
26 :"ZFO1",
27 :"ZFO2",
28 :"ZFO3",
29 :"ZFO4",
30 :"ZFK1",
31 :"ZFK2",
32 :"ZFK3",
33 :"ZFK4",
34 :"BFO1",
35 :"BFO2",
36 :"BFO3",
37 :"BFO4",
38 :"BFK1",
39 :"BFK2",
40 :"BFK3",
41 :"BFK4",
42 :"EFO1",
43 :"EFO2",
44 :"EFO3",
45 :"EFO4",
46 :"EFK1",
47 :"EFK2",
48 :"EFK3",
49 :"EFK4",
50 :"FFO",
51 :"FFK",
52 :"WFO",
53 :"WFK",
54 :"KL1",
55 :"KL2",
56 :"KL3",
57 :"KL4",
58 :"KLK1",
59 :"KLK2",
60 :"KLK3",
61 :"KLK4",
62 :"VG1",
63 :"VG2",
64 :"VG3",
65 :"VG4",
66 :"VGK1",
67 :"VGK2",
68 :"VGK3",
69 :"VGK4",
70 :"DHV1",
71 :"DHV2",
72 :"DHV3",
73 :"DHV4",
74 :"BHV1",
75 :"BHV2",
76 :"BHV3",
77 :"BHV4",
78 :"FL1A",
79 :"FL2A",
80 :"FL3A",
81 :"FL4A",
82 :"FL1B",
83 :"FL2B",
84 :"FL3B",
85 :"FL4B",
86 :"LVK",
87 :"EH1",
88 :"EH2",
89 :"EH3",
90 :"EH4",
91 :"SH",
92 :"CAN1",
93 :"CAN2",
94 :"CIF",
95 :"CSL1",
96 :"CSL2",
97 :"CSL3",
98 :"CSL4",
99 :"CSL5",
100 :"CSL6",
101 :"MPE1",
102 :"MPE2",
103 :"MPE3",
104 :"ULWL",
105 :"UHT",
106 :"UVE",
107 :"ULPA",
108 :"UGE",
109 :"UAC",
110 :"UDC",
111 :"UCAN",
112 :"COIF",
113 :"COS1",
114 :"COS2",
115 :"COS3",
116 :"COS4",
117 :"COS5",
118 :"COS6",
119 :"WPFE",

}


