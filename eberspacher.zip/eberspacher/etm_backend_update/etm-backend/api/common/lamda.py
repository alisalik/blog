import boto3

from integrations.aws.connection import region_name,AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY,user_pool_id , client_secret , client_id , S3_SECRET_ACCESS_KEY

ses_client = boto3.client('ses', region_name=region_name,aws_access_key_id = AWS_ACCESS_KEY_ID, aws_secret_access_key = AWS_SECRET_ACCESS_KEY)




def lambda_handler(event, context):
    # Set up the SES client
    
    ses_client = boto3.client('ses', region_name= "eu-central-1",aws_access_key_id = "AKIA3IGFCH5Y7UFYQUNC", aws_secret_access_key = "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")
    template_subject = "A WORLD OF COMFORT"
    template_html = "<html><body><h1> Eberspeacher!</h1><p>Welcome to E.connected!.</p></body></html>"
    template_text = "A WORLD OF COMFORT."
    template_name = "Welcome"

   
   

    response = ses_client.update_template(
        Template={
            'TemplateName': template_name,
            'SubjectPart': template_subject,
            'HtmlPart': template_html,
            'TextPart': template_text
        }
    )

   

  
    return {
        'statusCode': 200,
        'body': 'Email template created successfully.',
        'message': 'Email template created successfully.'
    }
    
    
    


def lambda_handler(event, context):
    
    ses_client = boto3.client('ses', region_name='us-west-2')  

   
    sender_email = 'sender@example.com'
    recipient_email = 'smriti.sharma@orahi.com'
    subject = 'A WORLD OF COMFORT!'
    body_text = 'This is the plain text version of the email.'
    body_html = "<html><body><h1> Eberspeacher!</h1><p>Welcome to E.connected!.</p></body></html>"

    
    response = ses_client.send_email(
        Source=sender_email,
        Destination={'ToAddresses': [recipient_email]},
        Message={
            'Subject': {'Data': subject},
            'Body': {
                'Text': {'Data': body_text},
                'Html': {'Data': body_html}
            }
        }
    )

   
    print(response)

  
    return {
        'statusCode': 200,
        'body': 'Email sent successfully.'
    }


    
 
