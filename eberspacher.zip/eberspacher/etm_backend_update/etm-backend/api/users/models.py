from core.models import BaseModel
from django.contrib.auth.models import AbstractBaseUser, BaseUserManager
from django.db import models

# Create your models here.


class UserProfileManager(BaseUserManager):
    def create(self, email, username, contact):
        if not email:
            raise ValueError("User must have a valid email")
        if not contact:
            raise ValueError("User must have a valid contact")
        email = self.normalize_email(email)
        user = self.model(email=email, username=username, contact=contact)
        user.save()
        return user


class UserProfile(AbstractBaseUser):
    class State(models.TextChoices):
        ACTIVE = 'ACTIVE'
        FORGOTTEN_PASSWORD = 'FORGOTTEN_PASSWORD'
        VERIFY_PENDING = 'VERIFY_PENDING'
        VERIFIED = 'VERIFIED'
        UNVERIFIED = 'UNVERIFIED'
    email = models.EmailField(unique= True)
    username = models.CharField(max_length=100)
    company = models.ForeignKey("company.TblCompany", on_delete=models.CASCADE)
    last_login = models.DateTimeField(blank=True, null=True)
    contact = models.CharField(max_length=20, unique=True ,blank=True, null=True)
    em_otp = models.IntegerField(null=True, blank=True)
    mob_otp = models.IntegerField()
    password = models.CharField(max_length=10, blank=True, null=True)
    otp_time = models.DateTimeField(null=True, blank=True)
    role_code = models.CharField(max_length=100)
    last_login = models.DateTimeField(blank=True, null=True)
    status = models.CharField(max_length=1, blank=True, null=True)
    created_by = models.CharField(max_length=100, blank=True, null=True)
    created_on = models.DateTimeField(blank=True, null=True)
    updated_by = models.CharField(max_length=100, blank=True, null=True)
    updated_on = models.DateTimeField(blank=True, null=True)
    designation = models.CharField(max_length=100, blank=True, null=True)
    password_expires_at = models.DateTimeField(blank=True, null=True)
    state = models.CharField(max_length=18, blank=True, null=True, choices=State.choices)
    class Meta:
        managed = False
        db_table = "tbl_user"

    objects = UserProfileManager()

    USERNAME_FIELD = "email"
    REQUIRED_FIELDS = ["username","contact", "company_id"]

    def __str__(self):
        return self.email


class TblUserRole(models.Model):
    role_code = models.CharField(primary_key=True, max_length=100)
    description = models.CharField(max_length=100, blank=True, null=True)
    priority = models.IntegerField(blank=True, null=True)
    status = models.CharField(max_length=100, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'tbl_user_role'
        
class TblRefreshToken(models.Model):
    app_refresh_token = models.CharField(primary_key=True, max_length=3000)
    cognito_refresh_token = models.CharField(max_length=3000)

    class Meta:
        managed = False
        db_table = 'tbl_refresh_token'