import requests

from .models import UserProfile, TblRefreshToken
from company.models import TblUser , TblCompanyRole , TblCompanyRoleAssoc
from rest_framework.exceptions import NotFound
from django.db.models import F
from django.db.models import Count
from integrations.aws.connection import client as aws
from rest_framework_simplejwt.authentication import JWTAuthentication
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework.exceptions import APIException, NotAuthenticated, NotFound
from api.settings.base import SECRET_KEY
from integrations.aws.connection import client_id, public_key_bytes
from django.core.exceptions import ValidationError 
import datetime 
from integrations.aws.connection import  region_name

import jwt
import botocore
from integrations.aws.utils import generate_secrete_hash, generate_secrete_hash_aws
import boto3




def get_company_user_list(company_id):
    users_queryset = UserProfile.objects.filter(company_id = company_id, status = "1").values("username" , "id" , "designation", "email", "state", "password_expires_at", "role_code").annotate(company_name = F("company__name"))
    for u in users_queryset:
        if u["role_code"] == "company_admin":
            u["role_code"] = "Admin"
    users_list = list(users_queryset)
    for u in users_list:
        u["password_expired"] = False
        if (u["password_expires_at"] is not None) and (u["password_expires_at"] < datetime.datetime.utcnow()):
            u["password_expired"] = True
    return users_list


def get_user(company_id : int,user_id: int):
    """get user based on `company`"""
    user_obj = UserProfile.objects.filter(company_id = company_id , pk = user_id).first()
    if user_obj is  None:
        raise NotFound("user not found with this company")
    return user_obj



import json
import time

def user_tokens(aws, email: str , password: str):
    #NOTE: @smriti please modify this function to store the app_refresh_token and cognito
    # refresh token on tbl_refresh_token.
    secret_hash=generate_secrete_hash_aws(email)
    
    # try:
    response = aws.initiate_auth(
    ClientId=client_id,
    AuthFlow='USER_PASSWORD_AUTH',
    AuthParameters={
        'USERNAME': email,
        'PASSWORD': password,
        'SECRET_HASH': secret_hash
    })  

    user_details = TblUser.objects.filter(email = email).first()
    if user_details.password_expires_at is not None and datetime.datetime.utcnow() > user_details.password_expires_at:
        raise ValidationError("Your temporary password has expired.")

    
    
    if "ChallengeName" in response and response["ChallengeName"] == 'NEW_PASSWORD_REQUIRED':
        return {
            "reset_req": True
        }
        
    
        
    else:
        refresh_token = response["AuthenticationResult"]["RefreshToken"]
        time_=response['AuthenticationResult']['ExpiresIn']
        user_details = TblUser.objects.filter(email = email).first()
        company = TblCompanyRoleAssoc.objects.filter(company_id = user_details.company_id, parent_company_id__isnull=True).first()
        refresh = RefreshToken.for_user(user_details)
        epoch_time = int(time.time()) + time_
        access_token = refresh.access_token
        
        access_token['exp'] = epoch_time
        
        
        
        decode_jwt = jwt.decode(
            str(access_token),
            SECRET_KEY, 
            algorithms=["HS256"],)
        
        decode_jwt["company_id"] = user_details.company_id
        decode_jwt["user_id"] = user_details.id
        decode_jwt["user_role"] = user_details.role_code.role_code
        decode_jwt["company_name"] = company.company.name
        decode_jwt["company_role_id"] = company.role_id
        decode_jwt["company_role_name"] = company.role.name
        
        encoded = jwt.encode(
                        decode_jwt,
                        SECRET_KEY,
                        algorithm="HS256",
                    )
        
        
        
        print(encoded)
        return {
            "reset_req": False,
            "tokens": {
                "access": encoded,
                "refresh": refresh
            }}
            
           
    # except:
        # raise ValidationError("Email or password are incorrect")   
  
        
 
        
            

def app_refresh_token(refresh_token): # token of us
    
    refresh_token_obj = TblRefreshToken.objects.filter(app_refresh_token = refresh_token).first()
    cognito_refresh_token = refresh_token_obj.cognito_refresh_token

    # Use the Cognito refresh token to get a new access token
    client = boto3.client('cognito-idp', region_name=region_name)
    response = client.initiate_auth(
        AuthFlow='REFRESH_TOKEN_AUTH',
        AuthParameters={
            'REFRESH_TOKEN': cognito_refresh_token,
        },
        ClientId=client_id
    )
    new_refresh_token = response['AuthenticationResult']['RefreshToken']
    new_access_token = response['AuthenticationResult']['AccessToken']

    # Create a new entry in the model with the new tokens
    RefreshToken.objects.create(
        app_refresh_token=new_refresh_token,
        cognito_refresh_token=cognito_refresh_token,
        
    )

   
    refresh_token_obj.delete()

    # Return the new refresh token for the app
    return new_refresh_token
   
   
   # NOTE: the function should have refresh_token passed by website as an argument.add()
    # get the cognito refresh token from table- tbl_refresh_token on the basis of refresh token passed by
    # user. Once we have the cognito refresh token we can try below piece of code to get new access token from 
    # the refresh token
   
    # we should get the new refresh token and access token from AuthenticationResult object.
    # Now create new app token that will be shared to frontend. 
    # insert new entry in tbl_refresh_token for app's refresh token and cognito refresh token
    # delete the old entry.
      

      

             
  
    
    
    
  

    
    