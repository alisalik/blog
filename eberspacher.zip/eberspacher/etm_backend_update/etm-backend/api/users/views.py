import random
from datetime import datetime as dt

import jwt
from core.jsend_response import JsendSuccessResponse
from core.utils import OTP

# from decouple import config
from rest_framework import status, viewsets
from rest_framework.decorators import action
from rest_framework.exceptions import APIException, NotAuthenticated, NotFound
from rest_framework.generics import get_object_or_404
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework_simplejwt.authentication import JWTAuthentication
from rest_framework_simplejwt.tokens import RefreshToken
from users.models import UserProfile
from company.models import TblUser
from requests import request
from rest_framework import serializers, status
from core.permissions import AllowedToAccessCompanyResource, AllowToAccessAdmin , AllowedToAccessCompanyResourceUser

from api.settings.base import SECRET_KEY
from company.models import TblCompany , TblCompanyRoleAssoc
from .models import UserProfile
from .serializers import UserSerializer
from .services import user_onboarding, user_update, user_delete,create_aws_user , delete_aws_user , verify_code, reset_password, forgot_password,resend_temp_pass
from .selectors import get_company_user_list, get_user , app_refresh_token


# Create your views here.
class LoginViewset(viewsets.ModelViewSet):
    queryset = UserProfile.objects.all()
    serializer_class = UserSerializer
    permission_classes = [IsAuthenticated]
    #authentication_classes = [JWTAuthentication]

    @action(detail=False, methods=["post"], url_path="send_otp")
    def sendotp(self, request):
        print(request.headers)
        user_email = request.data.get("email_id")
        user_contact = request.data.get("mobile_number")
        if user_email is None or user_contact is None:
            return Response({"error": "Please provide email and contact"})
        user_queryset = UserProfile.objects.filter(
            email=user_email, contact=user_contact
        )
        if user_queryset:
            cotp = str(random.randint(10000, 99999))
            emotp = str(random.randint(10000, 99999))
            # cotp = str(54321)
            # emotp = str(12345)

            user = UserProfile.objects.get(email=user_email)
            user.otp_time = dt.utcnow()
            user.mob_otp = cotp
            user.em_otp = emotp
            # user.save()
            if OTP.sendotp(user_email, user_contact, emotp=emotp, cotp=cotp):
                # request.session['sendotp_time']=dt.now()
                # request.session['mobile']=user_contact
                return JsendSuccessResponse(
                    data={
                        "message": " OTP sent successfully",
                        "otps": {"mobile": cotp, "email": emotp},
                    }
                ).get_response()
        else:
            raise NotFound("User not found in our system")

    @action(methods=["post"], detail=False, url_path="verify_otp")
    def validateOTP(self, request):
        try:
            uemotp = request.data.get("email_otp")
            ucotp = request.data.get("mobile_otp")
            queryset = get_object_or_404(UserProfile, mob_otp=ucotp, em_otp=uemotp)
            print(queryset.mob_otp)
            if not queryset:
                raise NotAuthenticated()
            time_elapsed = dt.utcnow() - queryset.otp_time.replace(tzinfo=None)
            # if time_elapsed.seconds > 70000:
            #     raise NotAuthenticated()

            if (
                    int(ucotp) == queryset.mob_otp
                    and int(uemotp) == queryset.em_otp
                    and request.data.get("email_id") == queryset.email
            ):
                refresh = RefreshToken.for_user(queryset)
                access_token = refresh.access_token
                decode_jwt = jwt.decode(
                    str(access_token),
                    SECRET_KEY,
                    algorithms=["HS256"],
                )
                user = UserProfile.objects.filter(
                    email=request.data.get("email_id")
                ).first()
                company = TblCompanyRoleAssoc.objects.filter(company_id = user.company_id, parent_company_id__isnull=True).first()

                decode_jwt["company_id"] = user.company_id
                decode_jwt["user_role"] = user.role_code
                decode_jwt["company_name"] = user.company.name
                decode_jwt["company_role_id"] = company.role_id
                decode_jwt["company_role_name"] = company.role.name
                

                encoded = jwt.encode(
                    decode_jwt,
                    SECRET_KEY,
                    algorithm="HS256",
                )

                # todo add extra claims in jwt token
                return JsendSuccessResponse(
                    data={
                        "message": "Authenciated successfully!",
                        "refresh_token": str(refresh),
                        "access_token": str(encoded),
                    }
                ).get_response()
            else:
                return Response("OTP incorrect provided. Please try again later")
        except Exception as e:
            raise NotAuthenticated()


class UserOnboarding(APIView):
    permission_classes = [AllowedToAccessCompanyResource]
    class InputSerializer(serializers.Serializer):

        username = serializers.CharField(required=True)
        email = serializers.CharField(required=True)
        contact = serializers.IntegerField(required=True)
        role_code = serializers.CharField(required=True)
        designation = serializers.CharField(required=True)

    def post(self, request, company_id):
        
        serializer = self.InputSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user_obj = user_onboarding(request=request, company_id=company_id, **serializer.validated_data )
        return JsendSuccessResponse(
            data={
                "message": "User Registered succesfully ",
                "user_id": f"{user_obj.id}"
            }
        ).get_response()

       


class UserUpdate(APIView):
    permission_classes = [AllowedToAccessCompanyResource]
    class InputSerializer(serializers.ModelSerializer):
        class Meta:
            model = TblUser
            fields = "__all__"

    class OutputSerializer(serializers.ModelSerializer):
        class Meta:
            model = TblUser
            fields = "__all__"

    def post(self, request, company_id, user_id: int):
       
        serializer = self.InputSerializer(data=request.data, partial=True)
        serializer.is_valid(raise_exception=True)
        user_u = user_update(company_id=company_id,
                                user_id=user_id,
                                **serializer.validated_data,
                                )
        data = self.OutputSerializer(user_u).data
        return JsendSuccessResponse(
            data=data, data_identifier="user_update"
        ).get_response()

     


class UserDelete(APIView):
    permission_classes = [AllowedToAccessCompanyResource]
    # TODO: perfrom solf delete
    def delete(self, request, company_id: int, user_id):
       
        user_d = user_delete(user_id=user_id)
        return JsendSuccessResponse(f"user {user_id} deleted succesfully").get_response()
       






class CompanyUserList(APIView):
    permission_classes = [AllowedToAccessCompanyResource]
    class OutputSerializer(serializers.ModelSerializer):
        class Meta:
            model = UserProfile
            fields = "__all__"

    def get(self, request, company_id):

      
        user_list = get_company_user_list(company_id=company_id)

        return JsendSuccessResponse(
            data=user_list, data_identifier="users"
        ).get_response()

       


class GetUser(APIView):
    permission_classes = [AllowedToAccessCompanyResource]
    class OutputSerializer(serializers.ModelSerializer):
        class Meta:
            model = UserProfile
            fields = "__all__"

    def get(self, request, company_id, user_id):

       
        user_obj = get_user(company_id=company_id, user_id=user_id)
        if user_obj.role_code == "company_admin":
            user_obj.role_code = "Admin"
        else:
            user_obj.role_code = "View"
            
        data = self.OutputSerializer(user_obj).data

        return JsendSuccessResponse(
            data=data, data_identifier="user_detail"
        ).get_response()
        
from integrations.aws.connection import client as aws
from .selectors import user_tokens      
class UserLogin(APIView):
    def post(self,client):
        email = client.data["email"]
        # temp_password = client.data["temp_pass"]
        password = client.data["password"]
        # encoded = user_tokens(aws, email = email, password=password)
        response = user_tokens(aws, email = email, password=password)
        
        if response["reset_req"] == True:
            return JsendSuccessResponse(
                        data={
                            "message": "Please reset your password",
                            
                        }
                    ).get_response()
        else:
            refresh_token = response["tokens"]["refresh"]
            access_token = response["tokens"]["access"]
            return JsendSuccessResponse(
                        data={
                            "message": "Authenciated successfully!",
                            "refresh_token":str(refresh_token),
                            "access_token": access_token,
                        }
                    ).get_response()
    
        

class UserCreateAWS(APIView):
    # permission_classes = [AllowedToAccessCompanyResource]
    class InputSerializer(serializers.Serializer):

        username = serializers.CharField(required = False, allow_null=True)
        email = serializers.CharField(required=True)
        contact = serializers.CharField(required = False, allow_null=True)
        role_code = serializers.CharField(required=True)
        designation = serializers.CharField(required = False, allow_null=True)

    def post(self,client, company_id):
        
        serializer = self.InputSerializer(data=client.data)
        serializer.is_valid(raise_exception=True)
        user_obj = create_aws_user(client,company_id= company_id ,**serializer.validated_data)
        return JsendSuccessResponse(
            data={
                "message": "User Registered succesfully ",
                "user_id": f"{user_obj.id}"
            }
        ).get_response()      
        

class UserDeleteAWS(APIView):
    def delete(self,client , company_id: int,):
        
        username = client.data["username"]
        user_d = delete_aws_user(client,username)
        return JsendSuccessResponse("user deleted succesfully").get_response()


class UserVerifyAWS(APIView):
    def post(self,client, company_id: int):
        verification_code = client.data["verification_code"]
        
        username = client.data["user_name"]
       
        user_verify = verify_code(client,username,verification_code)
        return JsendSuccessResponse({"message": "Authenciated successfully!"}).get_response()
    

    

    
class AppRefreshToken(APIView):
   
    def post(self,request):
        refresh_token = request.data["refresh_token"] # token of us
       
        encoded_refresh_token = app_refresh_token(refresh_token)
      
        
        return JsendSuccessResponse(
                    data={
                        "message": "Authenciated successfully!",
                        "refresh_token":str(refresh_token),
                        
                    }
                ).get_response()


class ResetPassword(APIView):
    
    def post(self,request):
       
        username = request.data["username"]
        temp_pass = request.data["temp_pass"]
        new_pass = request.data["new_pass"]
        #FIXME - what is the aws parameters passed to reset_password function? and the response of the function is stored in password
        # which i never used.
        password = reset_password(aws,username = username,temp_pass = temp_pass,new_pass = new_pass )
        
        
        return JsendSuccessResponse(
                    data={
                        "message": "Password Reset successfully!",
                        
                    }
                ).get_response()

class ForgetPassword(APIView):
     def post(self,request):
        username = request.data["username"]
        forgot_password(username)
        return JsendSuccessResponse(
                    data={
                        "message": "Temporary password has been sent to your email address.",
                        
                    }
                ).get_response()
   

class ForgetPasswordAws(APIView):
     def post(self,request):
        username = request.data["username"]
        forgot_password(username)
        return JsendSuccessResponse(
                    data={
                        "message": "Temporary password has been sent to your email address.",
                        
                    }
                ).get_response()


class ResendTempPassword(APIView):
    permission_classes = [AllowedToAccessCompanyResourceUser]
    def post(self, request, company_id):
        username = request.data["username"]
        # temp_pass = request.data["temp_pass"]
        resend_temp_pass(username)
        return JsendSuccessResponse(
                    data={
                        "resend_temp_pass": "Temporary password has been sent to your email address.",
                        
                    }
                ).get_response()
        
        