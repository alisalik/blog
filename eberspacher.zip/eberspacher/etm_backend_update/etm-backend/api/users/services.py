from django.db import transaction
from core.exceptions import CustomValidation
from django.core.exceptions import ValidationError as DjangoValidationError
from rest_framework.exceptions import  ValidationError
from django.utils.timezone import now
from rest_framework import exceptions, status
from .models import UserProfile
from company.models import TblUser
import random
from common.services import model_update
import datetime
from django.db.models import Q
import boto3
from integrations.aws.connection import  region_name , user_pool_id , client_id, client_secret , AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY
from common.constants import eberspacher_url
from integrations.aws.utils import generate_password, generate_secrete_hash, generate_secrete_hash_aws
from botocore.exceptions import ClientError
import os

@transaction.atomic 
def user_onboarding(*,request,
                    company_id: int,
                    username: str ="",
                    email: str ="",
                    contact: str ="",
                    role_code: str ="",
                    designation: str ="",
                    
                    ):
    
    
    
    role = request.auth["company_role_name"]
    user_role = request.auth['user_role']
    
    user_obj = UserProfile.objects.filter(Q(email=email, username=username, contact=contact, _connector=Q.OR)).first()
    if user_obj is not None:
        raise ValidationError("user is already registered in our system")
    
        
        
        
    else:
        
       user_obj = UserProfile(
            username = username,
            email = email,
            contact = contact,
            company_id = company_id,
            role_code = user_role,
            designation = designation,
            mob_otp = random.randint(10000, 99999),
            em_otp = random.randint(10000, 99999),
            status = "1",
            created_by = role,
            updated_by = role,
            otp_time = datetime.datetime.utcnow(),
            created_on = datetime.datetime.utcnow(),
            updated_on = datetime.datetime.utcnow(),
            
        )
        
    user_obj.save()
    return user_obj
        
        

@transaction.atomic
def user_update(*, company_id : int , user_id: int, **kwargs) -> UserProfile:
    non_side_effect_fields = [i for i in kwargs]
    email_and_contact = ["email", "contact"]
    rem_list = set(non_side_effect_fields) - set(email_and_contact)
    rem_list = list(rem_list)
    user_u = TblUser.objects.filter(id = user_id, company_id = company_id).first()
    
    
    email_query = TblUser.objects.filter(email = kwargs["email"])
    contact_query = TblUser.objects.filter(contact = kwargs["contact"])
   
   
    
    if len(email_query) >1 or len(contact_query) > 1: # duplicay check
        raise ValidationError("email_id or contact are already exist. Please enter another email id or contact number")
    
    if (len(email_query) == 1 and email_query.first().id == user_id) and (len(contact_query)==1 and contact_query.first().id == user_id): # email id exist but remaining field need to be update
        user_u = model_update(
                instance=user_u, fields=rem_list, data=kwargs
                )
        return user_u[0]
    if len(email_query) == 0 or len(contact_query) == 0: # if email id or contact no.doesnt exist before(need to be update)
        user_u = model_update(
                instance=user_u, fields=non_side_effect_fields, data=kwargs
                )
        return user_u[0]
    if len(email_query) == 1 or len(contact_query)==1:
        raise ValidationError("email_id or contact number already exist with us . Try another one")



# @transaction.atomic
# def user_update(*, company_id: int, user_id: int, **kwargs) -> UserProfile:
#     non_side_effect_fields = [i for i in kwargs]
#     email_and_contact = ["email", "contact"]
#     rem_list = set(non_side_effect_fields) - set(email_and_contact)
#     rem_list = list(rem_list)
#     user_u = TblUser.objects.filter(id=user_id, company_id=company_id).first()

#     email = kwargs.get("email")
#     contact = kwargs.get("contact")
    
#     if email:
#         email_query = TblUser.objects.filter(email=email).exclude(id=user_id)
#         if email_query.exists():
#             raise ValidationError("Email already exists. Please enter another email address.")
    
#     if contact:
#         # Remove non-digit characters from the contact number
#         contact = "".join(filter(str.isdigit, contact))
#         if not contact:
#             raise ValidationError("Invalid contact number. Please enter a valid integer.")
#         contact_query = TblUser.objects.filter(contact=contact).exclude(id=user_id)
#         if contact_query.exists():
#             raise ValidationError("Contact number already exists. Please enter another contact number.")
    
#     if len(email_query) == 1 and email_query.first().id == user_id:
#         # Email exists but remaining fields need to be updated
#         user_u = model_update(instance=user_u, fields=rem_list, data=kwargs)
#         return user_u[0]

#     if len(email_query) == 0:
#         # Email doesn't exist before (needs to be updated)
#         user_u = model_update(instance=user_u, fields=non_side_effect_fields, data=kwargs)
#         return user_u[0]

    raise ValidationError("Email or contact number already exists. Please try another one.")



 
        
@transaction.atomic
def user_delete(*, user_id: int):
    company_d = UserProfile.objects.get(pk= user_id)
    company_d.status = "0"
    company_d.save()

    return company_d
    

import boto3
from integrations.aws.connection import  region_name , user_pool_id , client_id, client_secret , AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY
from integrations.aws.utils import generate_password, generate_secrete_hash, generate_secrete_hash_aws
import hashlib
from botocore.exceptions import ClientError
import re
from common.constants import INVITATION_TEMPLATE , SOURCE , RSESND_TEMP_PASS_TEMPLATE

@transaction.atomic
def create_aws_user(client,company_id ,username: str = None, email: str = "", contact: str = None,
                    role_code: str = "", designation: str = None):
    #NOTE: @smriti: I have added a custom attribute of company_id in user_pool please try to save the value of
    # company_id to the user of aws_cognito as well, 
    # the name of custom attribute is company_id
    password = generate_password()
    # secrete_hash = generate_secrete_hash(username)
    
    client = boto3.client('cognito-idp', region_name=region_name,aws_access_key_id = AWS_ACCESS_KEY_ID, aws_secret_access_key = AWS_SECRET_ACCESS_KEY)
    
    # Check if a user with the given email already exists
    contact = str(contact) if contact else None
    contact_pattern = r'^\+?\d{1,4}?[-.\s]?(\d{1,3})?[-.\s]?\d{1,4}[-.\s]?\d{1,4}[-.\s]?\d{1,9}$'
    if contact and not re.match(contact_pattern, str(contact)):
        raise ValidationError("Invalid contact number. Please provide a valid contact number.")
    
    
    
    existing_user = UserProfile.objects.filter(email=email).exists() or \
                UserProfile.objects.exclude(contact = None).filter(contact=contact).exists()
    if existing_user:
        
        
        if UserProfile.objects.exclude(contact = None).filter(contact=contact).exists():
            raise ValidationError("Contact number is already registered in our system.")
        
        if UserProfile.objects.filter(email=email).exists():
            raise ValidationError("Email ID is already registered in our system. Please try another email ID.")

    
    else:
        attributes = [
        {
            'Name': 'email',
            'Value': email
        },
        ]

        try:
    # send the temp password of user's to email
            response = client.admin_create_user(
            UserPoolId=user_pool_id,
            Username=email,
            TemporaryPassword=password,
            UserAttributes=attributes,
            MessageAction='SUPPRESS'
        )
            print(response)

        # Create a new UserProfile object with the user's information
            user_obj = UserProfile(
            username=username,
            email=email,
            contact=re.sub(r'\D', '', contact) if contact else None,
            company_id = company_id,
            role_code= role_code,
            designation=designation,
            # password=password,
            status="1",
            state=UserProfile.State.VERIFY_PENDING,
            password_expires_at=datetime.datetime.utcnow() + datetime.timedelta(days=int(os.environ.get("AWS_COGNITO_TEMP_PWD_EXPIRY", "7")))
            )
            
            
            
            
        except client.exceptions.UsernameExistsException:
            user_obj = UserProfile(
            username=username,
            email=email,
            contact = re.sub(r'\D', '', contact) if contact else None,

            company_id=company_id,
            role_code=role_code,
            designation=designation,
            status="1",
            state=UserProfile.State.VERIFY_PENDING,
            password_expires_at=datetime.datetime.utcnow() + datetime.timedelta(days=int(os.environ.get("AWS_COGNITO_TEMP_PWD_EXPIRY", "7")))
        )
        
        # Save the user object to the database
        user_obj.save()


        ses_client = boto3.client('ses', region_name=region_name, aws_access_key_id=AWS_ACCESS_KEY_ID,
                                aws_secret_access_key=AWS_SECRET_ACCESS_KEY)
        response = ses_client.send_email(
            Source=SOURCE,
            Destination={
                'ToAddresses': [email]
            },
            Message={
                'Subject': {
                    'Data': 'Welcome',
                    'Charset': 'UTF-8'
                },
                'Body': {
                    'Html': {
                        'Data': INVITATION_TEMPLATE.replace("__email__", email).replace("__password__", password).replace(
                            "__eberspacher_url__", eberspacher_url),
                        'Charset': 'UTF-8'
                    }
                }
            }
        )
        print("Email sent successfully!")
        
        
    return user_obj


@transaction.atomic
def delete_aws_user(client,username):
    client = boto3.client('cognito-idp', region_name=region_name,aws_access_key_id = AWS_ACCESS_KEY_ID, aws_secret_access_key = AWS_SECRET_ACCESS_KEY )
    # deleting the user from AWS_Cognito
    try:
        response=client.admin_delete_user(
            UserPoolId=user_pool_id,
            Username=username
        )
        print(response)
        user_d = UserProfile.objects.filter(email = username, status = "1").delete()
        return user_d
    
    except client.exceptions.UserNotFoundException as e:
        raise ValidationError("User is already deleted")
    
@transaction.atomic   
def verify_code(client,username,verification_code):
    client = boto3.client('cognito-idp', region_name=region_name,aws_access_key_id = AWS_ACCESS_KEY_ID, aws_secret_access_key = AWS_SECRET_ACCESS_KEY )
    secrete_hash = generate_secrete_hash(username)
   # Call the confirm_forgot_password method to verify the code and reset the password
    response = client.confirm_sign_up(
        ClientId=client_id,
        Username=username,
        ConfirmationCode=str(verification_code),
        SECRET_HASH = secrete_hash
    )
    print(response)
    


     
   



def reset_password(client,username,temp_pass, new_pass):
  
    secrete_hash = generate_secrete_hash_aws(username)
    client = boto3.client('cognito-idp', region_name=region_name,aws_access_key_id = client_id, aws_secret_access_key = client_secret )

# Step 1: Initiate the authentication flow with the temporary password
    try:
        response = client.initiate_auth(
            ClientId=client_id,
            AuthFlow='USER_PASSWORD_AUTH',
            AuthParameters={
                'USERNAME': username,
                'PASSWORD': temp_pass,
                'SECRET_HASH': secrete_hash
            }
        )
    
    except ClientError as e:
        if e.response['Error']['Code'] == 'UserNotFoundException':
            raise ValidationError('User does not exist')
        
        
        else:
            return('Error: {}'.format(e))
        return
        
    # Step 2: Respond to the new password challenge with the new password
    response = client.respond_to_auth_challenge(
        ClientId=client_id,
        ChallengeName='NEW_PASSWORD_REQUIRED',
        ChallengeResponses={
            'USERNAME': username,
            'NEW_PASSWORD': new_pass,
            'SECRET_HASH': secrete_hash
        },
        Session=response['Session']
    )
    user = UserProfile.objects.filter(email = username).first()
    user.state = UserProfile.State.ACTIVE
    user.password_expires_at = None
    user.save()
    print(response)


def resend_temporary_password(username):
    client = boto3.client('cognito-idp', region_name=region_name)
    temp_password = generate_password()
    try:
        client.admin_create_user(
            UserPoolId= user_pool_id,
            Username= username,
            TemporaryPassword= temp_password,
            UserAttributes= [
                {
                    'Name': 'email',
                    'Value': username
                }
                ],
                MessageAction='RESEND'
                )
        pass
        user = UserProfile.objects.filter(email = username).first()
        user.state = UserProfile.State.ACTIVE
        user.password_expires_at = datetime.datetime.utcnow() + \
            datetime.timedelta(days=int(os.environ.get("AWS_COGNITO_TEMP_PWD_EXPIRY", "7")))
        user.password = temp_password
        user.save()
        
        

    except Exception as e:
        #TODO: @smriti enable proper exception handling i am catching all the exception which is not
        raise ValidationError("Details not provided correctly!")
    
    return 

def forgot_password(username):
    client = boto3.client('cognito-idp', region_name=region_name)
    temp_password = generate_password()
    
    user_exists = UserProfile.objects.filter(email=username, state='VERIFY_PENDING').exists()
    if user_exists:
        raise ValidationError("User doesn't exist") 
    
    update_params = {
        'UserPoolId': user_pool_id,
        'Username': username, 
        'UserAttributes': [
            {
                'Name': 'email_verified',
                'Value': 'true'
            },
        ]
    }
    
    response = client.admin_update_user_attributes(**update_params)
    
    user_obj = UserProfile.objects.filter(email=username, state='VERIFY_PENDING').exists()
    if user_obj:
        raise ValidationError("User doesn't exist")   
    
    user = UserProfile.objects.filter(email=username).first()
    user.state = UserProfile.State.FORGOTTEN_PASSWORD
    user.save()
    
    ses_client = boto3.client('ses', region_name=region_name, aws_access_key_id=AWS_ACCESS_KEY_ID, aws_secret_access_key=AWS_SECRET_ACCESS_KEY)
    response = ses_client.send_email(
        Source=SOURCE,    
        Destination={
            'ToAddresses': [username]
        },
        Message={
            'Subject': {
                'Data': 'Verification code arrived',
                'Charset': 'UTF-8'
            },
            'Body': {
                'Html': {
                    'Data': RSESND_TEMP_PASS_TEMPLATE.replace("__password__", temp_password),
                    'Charset': 'UTF-8'
                }
            }
        }
    )
    
    return response
    

def resend_temp_pass(username):
    

    client = boto3.client('cognito-idp', region_name=region_name,aws_access_key_id = AWS_ACCESS_KEY_ID, aws_secret_access_key = AWS_SECRET_ACCESS_KEY)
    temp_password = generate_password()
    
    res = None
    res =  client.admin_create_user(
        UserPoolId= user_pool_id,
        Username= username,
        TemporaryPassword= temp_password,
        UserAttributes= [
            {
                'Name': 'email',
                'Value': username
            }
            ],
            MessageAction='RESEND'
            )   
    user = UserProfile.objects.filter(email = username).first()
    # set the temp password expiry date
    user.password_expires_at = datetime.datetime.utcnow() + \
        datetime.timedelta(days=int(os.environ.get("AWS_COGNITO_TEMP_PWD_EXPIRY", "7")))
    # user.password_expires_at = datetime.datetime.utcnow()
    user.password = temp_password 
    user.save()
    
    ses_client = boto3.client('ses', region_name=region_name,aws_access_key_id = AWS_ACCESS_KEY_ID, aws_secret_access_key = AWS_SECRET_ACCESS_KEY)
    response = ses_client.send_email(
        Source= SOURCE,    
        Destination={
        'ToAddresses': [username]
    },
    Message={
        'Subject': {
            'Data': 'Verification code arrived',
            'Charset': 'UTF-8'
        },
        'Body': {
            'Html': {
                'Data': RSESND_TEMP_PASS_TEMPLATE.replace("__password__",temp_password),
                'Charset': 'UTF-8'
            }
        }
    })
    
    return res
    
        