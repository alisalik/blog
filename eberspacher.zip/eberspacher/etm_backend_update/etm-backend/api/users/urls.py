from django.urls import include, path
from rest_framework.routers import DefaultRouter

from .views import (LoginViewset, UserOnboarding , UserUpdate , UserDelete , 
                    CompanyUserList , GetUser , UserLogin, UserCreateAWS ,
                    UserDeleteAWS, UserVerifyAWS,ResetPassword, ForgetPassword,
                    AppRefreshToken, ForgetPasswordAws, ResendTempPassword)
                    

router = DefaultRouter()
router.register(r"auth", LoginViewset)
urlpatterns = [
    path("", include(router.urls)),
    
    path(
        "<int:company_id>/user_register",
        UserOnboarding.as_view(),
        name="user.register",
    ),
    
    path(
        "company/<int:company_id>/user_id/<int:user_id>/user_update",
        UserUpdate.as_view(),
        name="user.update",
    ),
    
    path("company/<int:company_id>/user_id/<user_id>/user_delete",
        UserDelete.as_view(),
        name="user.delete",
    ),
    
    path("company/<int:company_id>/user_id/<user_id>/user_delete",
        UserDelete.as_view(),
        name="user.delete",
    ),
    
    # path("company/<int:company_id>/get_user_list",
    #     AdminUserList.as_view(),
    #     name="user.list",
    # ),
    
    path("company/<int:company_id>/get_company_user_list",
        CompanyUserList.as_view(),
        name="user.list",
    ),
    
    path("company/<int:company_id>/user_id/<int:user_id>/get_user_detail",
        GetUser.as_view(),
        name="user.get",
    ),
    
    path("login",
        UserLogin.as_view(),
        name="user.login",
    ),
    
    path("<int:company_id>/user_aws_onboarding",
        UserCreateAWS.as_view(),
        name="userAWS.create",
    ),
    
    path("<int:company_id>/user_aws_delete",
        UserDeleteAWS.as_view(),
        name="userAWS.delete",
    ),
    
    path("<int:company_id>/verify_code",
        UserVerifyAWS.as_view(),
        name="userAWS.verify_code",
    ),

    path("<int:company_id>/refresh_access_token",
        AppRefreshToken.as_view(),
        name="userAWS.refresh.token",
    ),
    
    path("resetpassword",
        ResetPassword.as_view(),
        name="userAWS.reset.password",
    ),
    
    path("forget_password",
        ForgetPassword.as_view(),
        name="userAWS.reset.password",
    ),
    
    path("forget_password_aws",
        ForgetPasswordAws.as_view(),
        name="userAWS.forgot.password",
    ),
    
    path("<int:company_id>/resend_temp_pass",
        ResendTempPassword.as_view(),
        name="userAWS.resend.temppassword",
    ),
    
    
]
    



