"""All the custom exceptions that can be thrown by applicaiton"""

from django.utils.encoding import force_str
from rest_framework import status
from rest_framework.exceptions import APIException


class ApplicationError(Exception):
    def __init__(self, message, extra=None) -> None:
        super().__init__(message)
        self.message = message
        self.extra = extra or {}


class ApplicationErrorJsend(Exception):
    def __init__(self, message, code, data) -> None:
        super().__init__(data)
        self.status = "error"
        self.message = message
        self.code = code or None
        self.data = data or {}


class CustomValidation(APIException):
    status_code = status.HTTP_500_INTERNAL_SERVER_ERROR
    default_detail = "A server error occurred."

    def __init__(self, detail, field, status_code):
        if status_code is not None:
            self.status_code = status_code
        if detail is not None:
            self.detail = {field: force_str(detail)}
        else:
            self.detail = {"detail": force_str(self.default_detail)}
