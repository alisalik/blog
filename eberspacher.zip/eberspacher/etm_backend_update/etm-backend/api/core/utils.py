import json
from email import message
from time import sleep

import requests
from django.core.mail import send_mail

EXPIRY_TIME = 50


class OTP:
    @staticmethod
    def sendotp(user_email, user_contact, emotp=None, cotp=None):
        try:
            """msg = f"Your OTP for login is {cotp.now()}"
            url = "https://api.bulksms.com/v1/messages"
            headers = {
                "Authorization": "Basic OUU1OTMyRjU4NjEzNDM2MEJEQzYyNzI5NDUxMDdEMzUtMDItMzppWWxYT2R5Mktrb2REOGRiX3prX01La2xEOWIhUg==",
                "Content-Type": "application/json",
            }

            print(msg)
            payload = {"to": "+917355558381", "body": msg}
            result = requests.post(url, headers=headers, data=json.dumps(payload))
            OTP.sendEmail(emotp)
            print(result.json())"""
            return True
        except Exception as e:
            print(e)

    @staticmethod
    def utilverifyotp(ucotp=None, uemotp=None, emotp=None, cotp=None):

        if emotp.verify(str(uemotp)) and cotp.verify(str(ucotp)):
            return True
        return False
        # API to send otp to number

    @staticmethod
    def sendEmail(otp):
        try:
            subject = "LOGIN OTP"
            messages = f"Enter the following 4 digit OTP to login --- {otp.now()}"
            l = send_mail(
                subject, messages, "ali.salik@orahi.com", ["alisalik.work@gmail.com"]
            )
            print(l)
        except Exception as e:
            print(e)
