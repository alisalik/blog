operator_perms = ['Fleet_Register', 'FleetUpdate', 'FleetDelete']

ROLE_COMPANY_MAPPING = {
    2: "admin",
    3: "operator",
    4: "pta",
    5: "service_provider"
}
