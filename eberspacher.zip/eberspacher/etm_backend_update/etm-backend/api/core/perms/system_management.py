from rest_framework.permissions import BasePermission

from users.models import UserProfile
from api.settings.base import SECRET_KEY
import jwt
from core.perms.constants import ROLE_COMPANY_MAPPING as rcm
from core.perms import constants


class CompanyPermission(BasePermission):

    def has_permission(self, request, view):
        
        user_role = request.auth["company_role_name"]
        if user_role == rcm[2]:
            return True
        
        class_name = view.__class__.__name__
        operator_perms = constants.operator_perms
        if class_name in operator_perms and user_role == rcm[3]:
            return True
        return False

