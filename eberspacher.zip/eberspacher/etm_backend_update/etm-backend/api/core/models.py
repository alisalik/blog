from django.db import models
from django.utils import timezone



class BaseModel(models.Model):
    """some imp model fields that can be inheritend in other model classes"""

    created_at = models.DateTimeField(db_index=True, default=timezone.now)
    created_by = models.CharField(max_length=100)
    updated_at = models.DateTimeField(auto_now=True)
    updated_by = models.CharField(max_length=100, default="unassigned")

    class Meta:
        abstract = True
