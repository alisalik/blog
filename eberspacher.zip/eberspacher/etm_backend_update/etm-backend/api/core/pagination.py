from rest_framework.pagination import PageNumberPagination


class CustomPagination(PageNumberPagination):
    page_size = 10
    page = 1
    page_size_query_param = "page_size"
    max_page_size = 150
    page_query_param = "p"

    def paginate_queryset(self, queryset, request, view=None):
        # Apply sorting if a sort parameter is present in the request query parameters
        query_params = request.query_params
        sort_param = request.query_params.get("sort")
        filter_sort = []
        for key, value in query_params.items():
            if key.startswith('filter'):
                filter_sort.append({key: value})
                
        
        if filter_sort:
            queryset = self.filter_sort(queryset,filter_sort )
            
        # sort_param = request.query_params.get("sort")
        if sort_param:
            queryset = self.apply_sort(queryset, sort_param)
        
        

        return super().paginate_queryset(queryset, request, view)
    

    def apply_sort(self, queryset, sort_param):
        # Split the sort parameter into a list of fields to sort by
        sort_fields = sort_param.split(",")

        # Apply each field's sorting to the queryset
        for field in sort_fields:
            # Check if the field starts with a minus sign, which indicates descending order
            if field.startswith("-"):
                queryset = queryset.order_by(f"-{field[1:]}")
            else:
                queryset = queryset.order_by(field)

        return queryset
    
    def filter_sort(self,queryset , filter_sort):
        filtered_data = []
        for item in filter_sort:
            for key, value in item.items():
                if key.startswith('filter'):
                   
                    field = key.split('_' , 1)[1]
                    filtered_data.append({field: value})
        
        for field in filtered_data:
            
          
            queryset = queryset.filter(**field)
        return queryset

    def get_paginated_response(self, data):
        print(data, "i")
        response = data
        response["count"] = self.page.paginator.count
        response["next"] = self.get_next_link()
        response["previous"] = self.get_previous_link()
        return response
