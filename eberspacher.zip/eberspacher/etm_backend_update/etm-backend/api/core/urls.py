from django.urls import path

from .views import Role

urlpatterns = [
    path(
        "role",
        Role.as_view(),
        name="company.role",
    ),
    # path(
    #     "role/user",
    #     Role.as_view(),
    #     name="user.role",
    # ),
    
    
]
