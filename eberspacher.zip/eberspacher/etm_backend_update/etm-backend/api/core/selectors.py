




import requests



from rest_framework.exceptions import NotFound


from company.models import TblCompanyRole, TblUserRole

    
   





def get_role(role_scope: str =""):
    # fetching role ->  user and company 
    if role_scope == "COMPANY":
        role = TblCompanyRole.objects.filter(scope = role_scope).all()
        
    else:
        role = TblUserRole.objects.all()
        
    return role

    


    