from django.shortcuts import render


import json
from dataclasses import field
from urllib import response



from core.jsend_response import JsendSuccessResponse



from drf_yasg.utils import swagger_auto_schema
from requests import request
from rest_framework import serializers, status
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView


from company.models import TblCompanyRole, TblUserRole
from .selectors import get_role

class Role(APIView):
    permission_classes =  [IsAuthenticated]
    
   
    class CompanySerializer(serializers.ModelSerializer):
        
        class Meta:
            model = TblCompanyRole
            fields = "__all__"
            
    class UserSerializer(serializers.ModelSerializer):
        
        class Meta:
            model = TblUserRole
            fields = "__all__"
            
   
    
            
    def get(self,request):
        role_scope = request.query_params["role_scope"]
        
        role = get_role(role_scope)
        if role_scope =="USER":
            serializer = self.UserSerializer(role, many = True).data
        elif role_scope == "COMPANY":
            serializer = self.CompanySerializer(role, many = True).data
            
        return JsendSuccessResponse(
                data=serializer, data_identifier="roles"
            ).get_response()

