from common.constants import COMPANY_ROLE_TABLE_COLUMN_NAME_MAPPING
from rest_framework.exceptions import NotAuthenticated, NotFound
from rest_framework.permissions import (SAFE_METHODS, BasePermission,
                                        IsAuthenticated)
from rest_framework.response import Response
from rest_framework.views import APIView
from vehicle.models import TblVehicle
from rest_framework import exceptions
from common.utils import hard_code_company
from common.constants import OEM


class AllowedToAccessVehicle(BasePermission):
    def __init__(self):
        super().__init__()

    def has_permission(self, request, view):
        if not request.user.is_authenticated:
            raise NotAuthenticated()

        if request.auth["company_role_name"] == "admin" or request.auth["user_role"]== "company_admin":
            
            # admin has all access
            return True

        if "vin" in view.kwargs:
            vehicle = TblVehicle.objects.filter(
                vin=view.kwargs["vin"]

            ).first()
            if vehicle is None:
                raise NotFound(" not found in our system")

        if "vin" in view.kwargs:
            """vin is present in url"""
            vehicle = TblVehicle.objects.filter(
                pk=view.kwargs["vin"],
                **{
                    COMPANY_ROLE_TABLE_COLUMN_NAME_MAPPING[
                        request.auth["company_role_name"]
                    ]: request.user.company_id
                }
            ).first()
            if not vehicle:
                return False
                # raise exceptions.ValidationError("You don't have access for this vin!")


            else:
                return True


        else:
            return False  # TODO WIP


class AllowedToAccessCompanyResource(BasePermission):
    def __init__(self):
        super().__init__()

    def has_permission(self, request, view):
        if not request.user.is_authenticated:
            raise NotAuthenticated()

        if request.auth["company_role_name"] == "admin":
            # admin has all access
            return True

        if "company_id" in view.kwargs:
            """company_id is present in url"""
            if request.user.company_id == view.kwargs["company_id"]:
                return True
            
            else:
                return False
        else:
            return False  
        
        
        
class AllowToAccessFleet(BasePermission):
    def __init__(self):
        super().__init__()
        

    def has_permission(self , request ,view):
        if not request.user.is_authenticated:
            raise NotAuthenticated()
        
        if request.auth["company_role_name"] == "admin":
            # admin has all access
            return True
        
        if "company_id" in view.kwargs:
            """company_id is present in url"""
            if request.user.company_id == view.kwargs["company_id"]:
            
                return True
        # and  request.auth["company_role_name"] == "operator"
        else:
            return False
        
class AccessFleet(BasePermission):
    def __init__(self):
        super().__init__()
        

    def has_permission(self , request ,view, company_id):
        if not request.user.is_authenticated:
            raise NotAuthenticated()
        
        if request.auth["company_role_name"] == "admin":
            # admin has all access
            return True
        
        if "company_id" in view.kwargs:
            """company_id is present in url"""
            if company_id == view.kwargs["company_id"]:
            
                return True
        # and  request.auth["company_role_name"] == "operator"
        else:
            return False
        


        
class AllowToAccessAdmin(BasePermission):
    def __init__(self):
        super().__init__()
    
        
    def has_permission(self , request ,view):
        
        if not request.user.is_authenticated:
            raise NotAuthenticated()
        

        if request.auth["company_role_name"] == "admin" or hard_code_company(request):
            # admin has all access
            return True
        
        
      
        
        else:
            return False
        

class AllowToAccessOEM(BasePermission):
    
    def has_permission(self , request ,view):
        
        if not request.user.is_authenticated:
            raise NotAuthenticated()
        
    def hard_code_company(request):
        if request.auth["company_name"].split(" ")[0] == OEM:
            return True
        else:
            False
        

from users.models import UserProfile
class AllowedToAccessCompanyResourceUser(BasePermission):
    def __init__(self):
        super().__init__()

    def has_permission(self, request, view):
        if not request.user.is_authenticated:
            raise NotAuthenticated()

        if request.auth["company_role_name"] == "admin":
            # admin has all access
            return True
        user_obj = UserProfile.objects.filter(username=request.data["username"]).first()
        
        if user_obj.company_id == request.auth["company_id"] and user_obj.role_code =="company_admin":
            return True
            
            
            
        else:
            return False

  
class AllowedToUpdateAssests(BasePermission):
    def __init__(self):
        super().__init__()

    def has_permission(self, request, view):
        if not request.user.is_authenticated:
            raise NotAuthenticated()

        if request.auth["company_role_name"] == "admin":
            
            # admin has all access
            return True
        

        else:
            False
                
            
                
           
                
           