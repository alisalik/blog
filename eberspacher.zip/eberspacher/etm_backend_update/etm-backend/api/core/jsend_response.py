from rest_framework.response import Response


class JsendSuccessResponse:
    def __init__(self, data, data_identifier: str = ""):
        if data_identifier == "":
            self.response = {"status": "success", "data": data}
        else:
            self.response = {"status": "success", "data": {data_identifier: data}}

    def get_response(self):
        return Response(self.response)


