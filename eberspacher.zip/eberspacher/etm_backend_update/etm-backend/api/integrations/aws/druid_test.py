import json
import requests


def extract_druid_data_rest_api_and_send_to_kafka( query: str, limit: int, timeout: int = 2) -> None:
    endpoint = "https://druid.dev.orahi.com/druid/v2/sql/"
    offset = 0
    while True:
        request_body = {"query": query, "limit": limit, "offset": offset}
        try:
            response = requests.post(
                endpoint,
                headers={"Content-Type": "application/json"},
                data=json.dumps(request_body).encode("utf-8"),
                timeout=timeout
            )
            status_code = response.status_code
            if status_code in range(200, 300):
                data = response.json()
                # print(data)
                if not data:
                    break
                return data
            else:
                raise ValueError(f"Unexpected response status code: {status_code}")
        except Exception as e:
            print(e)

query1 = "SELECT * from locate_mks_demo"

data= extract_druid_data_rest_api_and_send_to_kafka(query=query1,limit=1000 ,timeout=5)
print(data)