import boto3
import hashlib
import hmac
import base64
import requests
import json
import base64

from cryptography.hazmat.primitives.asymmetric.rsa import RSAPublicNumbers
import cryptography
from os import environ
from django.conf import settings






# client_id =  '7t1m4qltpuphdmk398nikbjusu'
client_id = environ.get("AWS_COGNITO_CLIENT_ID")
# client_secret = '1j01bc9otpsiis8v5kp6016ir4fbh8vhvg5q3vemqe35b2l5gco3'
client_secret = environ.get("AWS_COGNITO_CLIENT_SECRET")
# user_pool_id = 'eu-central-1_icB3K8SP6'
user_pool_id = environ.get("AWS_COGNITO_USER_POOL_ID")
# username = 'harish.singh@orahi.com'
# password = 'Amazon.None@1994'
region_name =  environ.get("AWS_COGNITO_REGION_NAME")
AWS_ACCESS_KEY_ID= environ.get("AWS_COGNITO_ACCESS_KEY")
AWS_SECRET_ACCESS_KEY= environ.get("AWS_COGNITO_SECRET_ACCESS_KEY")

S3_ACCESS_KEY= environ.get("S3_ACCESS_KEY")
S3_SECRET_ACCESS_KEY= environ.get("S3_SECRET_ACCESS_KEY")

# eberspacher_url =environ.get("eberspacher_url")


client = boto3.client('cognito-idp', region_name=region_name)

jwks_url = f'https://cognito-idp.{region_name}.amazonaws.com/{user_pool_id}/.well-known/jwks.json'

response = requests.get(jwks_url)
jwks = json.loads(response.text)

jwks = response.json()

keys = jwks['keys'][1]


n = int.from_bytes(base64.urlsafe_b64decode(keys['n'] + '=='), 'big')
e = int.from_bytes(base64.urlsafe_b64decode(keys['e'] + '=='), 'big')
public_numbers = RSAPublicNumbers(e=e, n=n)
public_key = public_numbers.public_key()

public_key_bytes = public_key.public_bytes(
    encoding=cryptography.hazmat.primitives.serialization.Encoding.PEM,
    format=cryptography.hazmat.primitives.serialization.PublicFormat.SubjectPublicKeyInfo)



