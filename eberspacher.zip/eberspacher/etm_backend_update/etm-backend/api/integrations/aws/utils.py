import boto3
import hashlib
import hmac
import base64
import requests

import base64

from os import environ





# client_id =  '7t1m4qltpuphdmk398nikbjusu'
# client_secret = '1j01bc9otpsiis8v5kp6016ir4fbh8vhvg5q3vemqe35b2l5gco3'
# user_pool_id = 'eu-central-1_icB3K8SP6'



client_id = environ.get("AWS_COGNITO_CLIENT_ID")

client_secret = environ.get("AWS_COGNITO_CLIENT_SECRET")
user_pool_id = environ.get("AWS_COGNITO_USER_POOL_ID")
region_name =  environ.get("AWS_COGNITO_REGION_NAME")
AWS_ACCESS_KEY_ID= environ.get("AWS_COGNITO_ACCESS_KEY")
AWS_SECRET_ACCESS_KEY= environ.get("AWS_COGNITO_SECRET_ACCESS_KEY")

# Compute the secret hash value


def generate_secrete_hash(username):
    # message = username + client_id
    message = username + AWS_ACCESS_KEY_ID
    digest = hmac.new(str(AWS_SECRET_ACCESS_KEY).encode('utf-8'), msg=str(message).encode('utf-8'), digestmod=hashlib.sha256).digest()
    secret_hash = base64.b64encode(digest).decode()
    return secret_hash


def generate_secrete_hash_aws(username):
    # message = username + client_id
    message = username + client_id
    digest = hmac.new(str(client_secret).encode('utf-8'), msg=str(message).encode('utf-8'), digestmod=hashlib.sha256).digest()
    secret_hash = base64.b64encode(digest).decode()
    return secret_hash


import random
import string

def generate_password(length=8):
    
    special_chars = "@_!&"
    # generate a random uppercase letter
    upper = random.choice(string.ascii_uppercase)
    
    # generate a random lowercase letter
    lower = random.choice(string.ascii_lowercase)
    
    # generate a random digit
    digit = random.choice(string.digits)
    
    # generate a random special character
    special = random.choice(special_chars)
    
    # concatenate the characters together
    password = upper + lower  + special + digit
    
    # generate the remaining characters
    remaining_chars = string.ascii_letters  + special_chars + string.digits
    for i in range(4):
        password += random.choice(remaining_chars)
    
    # shuffle the password to make it more random
    password_list = list(password)
    random.shuffle(password_list)
    password = "".join(password_list)
    
    return password









import boto3
from botocore.exceptions import ClientError

# Create an Amazon SES client
ses_client = boto3.client('ses', region_name='us-east-1')

# Send the temporary password to the user's email address
def send_temp_password(username, password):
    
    
        # Create the email message
    message = {
        'Subject': {
            'Data': "temporary password for the user's account."
        },
        'Body': {
            'Text': {
                'Data': f'Your temporary password is {password}'
            }
        }
    }

    # Send the email
    response = ses_client.send_email(
        Source='SignUp',
        Destination={
            'ToAddresses': [
                username,
            ]
        },
        Message=message
    )

    # Return the response
    return response

  










        
        

