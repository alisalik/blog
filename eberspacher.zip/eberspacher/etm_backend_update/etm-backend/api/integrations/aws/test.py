import boto3
import hashlib
import hmac
import base64
import requests
import json
import jwt
from os import environ


client_id= '46v8omr9l307i3br30k014qqrs'
client_secret= 'ai1bp87c0aih96k8sethieg8tu245kpm41hpu87rstufdgipsnk'
user_pool_id = 'eu-central-1_oR5B6BwNJ'
region_name = 'eu-central-1'
username = "smritisharma624@gmail.com"
password = 'Test@1230'
AWS_ACCESS_KEY_ID= 'AKIA3IGFCH5Y7UFYQUNC'
AWS_SECRET_ACCESS_KEY= '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' 

# Compute the secret hash value


# client = boto3.client('cognito-idp', region_name='eu-central-1')

# response = client.initiate_auth(
#     ClientId=client_id,
#     AuthFlow='USER_PASSWORD_AUTH',
#     AuthParameters={
#         'USERNAME': username,
#         'PASSWORD': password,
#         'SECRET_HASH': secret_hash
#     }
# )

# aws_token = response['AuthenticationResult']['AccessToken']
# print(aws_token)






# refresh_token = 'eyJjdHkiOiJKV1QiLCJlbmMiOiJBMjU2R0NNIiwiYWxnIjoiUlNBLU9BRVAifQ.nYQTzrbEEYa3MG9d3Mx7Pm1ETseXJEWSg6GKwvyhvpo9fWDasHAH9ToGqzYp48pgM_lVcd64TaCvTK1zUSENVioRv3ponOTo3CEJVAuZcNd9s0Sqg4sj_kAoWTCBqVinoCDVdm-RzT5xDccrp7WLlaLmZjMPWrukk4y7xjTRHvxx7EhYo-KYfYJFOijWiFarLLBmYwSOiPFjIK2DeAx-YDHEFHz6chWk9rmmnngOXpglqELvI-Eutq68HwzDDrOqKwrHL8NZESOp93-dGO4VzaIYchTVph9XeI5pKNsvweZu8J_oM2tkQYJgDpg3Xoiq7DZjVTecmeICuqANz1EtOQ.ebDetTxrLtCw7NBh.YXBade3jiF8GLe9rDjkzez64tB5D_NKJopk0HETAeN9cdd8SRg509zP8Rvv5EcE5NQ_zZ3j_VC847zmwVZrOJFcSgafTDF4_neISJPwbHVaE3P6kjI3L3CvDuoWQ1uQhKCyzrCDjDDo2Yov1jwZAEuZTdaYgyeOSvxNlrCxBtT5Qoy2bxw4kbQYCZghBdHkRDcM3iZZ3F16pPEA0z0uHDeVBIqfdcaN1919CTk_cu8FtwLBjFxEsC6YgQhI0PtNMxjVhtmYxkwggdUu_AZIEo1yQJaI66tmHbq3F2RF8Dt885-aXiPe97xhgek7lFd0HYFavyG2BIFHuf40LI7bTYl-zMPBzfxo8FEnAcSDH3L70WUjMKlFOwGJcZ0Sq-w6QHj6-5yxwz7VGHyHY80tnc0KcvEG7poICOYrXUZVXvXevn9pUAluj_-OqZJaj7j66qTFtlSBG231HfI2ittUCbLfeiw8f0rf3iYVUyLWg2oULiBl6TjHntk1_G4gLkk68LIX0z20dcO6C-kvNQvI_pN4jjjzjcIIsFt2FTG8v-39AmENPqJ5K7X2qtlWEcMzD2fRnOjKhJJQ8qfyB6xL3KfMWrZUFjCtR_Z_7koQsWzQpWvR6stFFBD6QkuULAHKCCAqFrvpFU9CPcYdoWV1cBivt0sk4KGq9tGXZPvXvAQycEqSD_OOpmGGlklyVBJqj5njI46Dt1j2Yl3th7jQD_c73H-FAR_dxGMZ0oHCTliLR6-UB7iX7f1ExtVWdFEKzp3n4bD1NqMxNRs_ZxgXZXk2tA4mpel8tzC9yhG0pzrD-Fcx89CIWuX8ObCZwrlKKp1x_mRPPU6ijUsk7WXyYabOoAbdJ8P9YucNBXjdqhWhA-GT1FuFuK862Q_xqdC7l44AcbhrNcisHutNC7X_9P9P9Acw5JvIAos_thXJEifC1H21B5-U-axgt40zcLoRBABavW3Nv8rm4oyBi5-Miq2JnSf2Y75wCnW0ZOmqz9aIiXunvQU2Kit--yzgwGFNtxoauoljxcyhFx3TUbkNJ6I3yOsMskV-H6c6kXknIyDfvi3X76cz-93vqEaPF0sHCyYG2Qt9brBcTPvy5yE77aXAXg8R8rGgrxyiMYJrPfXix0t5FU4UOy5ge63VKpqpprd-fiCrpKm9aT-pvelcFbYy9E_IpvnIbLv9nxfRr1FpHW2UNx4jUOLjZjIqokrSap9PQ1KBNBisJY6ukMDuDcLWjE72nHV6Pk2t4kt1RfBpDUUmGXzE9XHQsvpWtOCv1ycteuTUVM28POHQsu0nGoyjRL0YRBJYHZwY5M2KPupA3671NzLruJqvXbDjBTGJW_HNZiA.I7qFLBLlCH4ynjwlmETYQw'

# message = refresh_token + client_id


# def get_secret_hash(client_secret, message):
#     digest = hmac.new(str(client_secret).encode('utf-8'), msg=str(message).encode('utf-8'), digestmod=hashlib.sha256).digest()
#     secret_hash = base64.b64encode(digest).decode()
#     return secret_hash
# secret_hash = get_secret_hash(client_secret, refresh_token + client_id)





# client = boto3.client('cognito-idp',region_name=region_name)
# client = boto3.client('cognito-idp',region_name=region_name)
# response = client.initiate_auth(
#     AuthFlow='REFRESH_TOKEN_AUTH',
#     AuthParameters={
#         'REFRESH_TOKEN': refresh_token,
#         'SECRET_HASH': secret_hash
#     },
#     ClientId=client_id
# ) 
# print(response['AuthenticationResult']['RefreshToken'])


    
    

ses_client = boto3.client('ses', region_name=region_name,aws_access_key_id = AWS_ACCESS_KEY_ID, aws_secret_access_key = AWS_SECRET_ACCESS_KEY)


response = ses_client.send_email(
    Source='noreply@bus.e-connected.com',
    Destination={
        'ToAddresses': ['smriti.sharma@consat.com']
    },
    Message={
        'Subject': {
            'Data': 'Welcome to our application'
        },
        'Body': {
            'Html': {
                'Data': """
                    <html>
                    <head></head>
                    <body>
                        <h1>Hello Smriti</h1>
                        <p>Your temporary password is: Test@123</p>
                    </body>
                    </html>
                """
            }
        }
    }
)
print("Email sent successfully!")
