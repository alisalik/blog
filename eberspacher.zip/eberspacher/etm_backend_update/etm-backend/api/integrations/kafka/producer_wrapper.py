from kafka import KafkaProducer
from integrations.kafka.producer import producer as kafka_producer
from integrations.kafka import constants
import time 
import os
import json
class KafkaProducerWrapper:

    _instance = None
    producer = kafka_producer
    topic = os.environ.get("KAFKA_PRODUCE_TOPIC")

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
    
    def send_can_dump_request(self, task_data):
        # taska_data = gateway_id, interval, 
        headers = [("from-service", constants.FROM_SERVICE.encode('utf-8')),
                   ( "to-service", constants.TO_SERVICE.encode('utf-8')),
                   ("ttl", str(time.time()+constants.TTL_SECONDS).encode('utf-8')),]
        task_data["task_code"] = "eber.gateway.can.dump"
        # TODO[epic=can_dump_state_management] check if below logic is handled properly
        future = self.producer.send(KafkaProducerWrapper.topic, task_data, headers=headers)
        return future
    
    def send_object_info(self, obj_data):
        # Build object info message
        # ...
        
        # Send message to Kafka
        self.producer.send('object-info', value=obj_data, key='object')
        