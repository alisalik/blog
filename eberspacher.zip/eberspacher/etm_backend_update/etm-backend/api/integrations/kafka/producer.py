from kafka import KafkaProducer
import os
from django.conf import settings
import json

producer = None

if int(os.environ.get("PRODUCE_TO_KAFKA", "1")):
    producer = KafkaProducer(
        **settings.KAFKA_CONFIG,
        value_serializer=lambda x: json.dumps(x).encode("utf-8")
    )


def produce_to_kafka(request, action=None, module=None, msg=None):
    if producer is None:
        return  # Not using kafka
    service = settings.SERVICE_NAME
    topic_name = os.environ.get("KAFKA_PRODUCE_TOPIC", "")
    if action is None or module is None or not topic_name:
        raise ValueError(
            "action,module and topic name is required to push message to kafka"
        )

    headers = [
        ("service", service.encode("utf-8")),
        ("module", module.encode("utf-8")),
        ("action", action.encode("utf-8")),
    ]
    producer.send(
        topic_name,
        headers=headers,
        value=msg,
    )
