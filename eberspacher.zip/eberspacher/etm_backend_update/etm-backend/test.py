import hashlib

import requests

controlsum = hashlib.sha1(f"{vin}|{id}|{apikey}|{secretkey}".encode()).hexdigest()[0:10]

import http.cookiejar as cookielib

# some packages were renamed in Python 3
import urllib.request as urllib2


def file_get_contents(url):
    url = str(url).replace(" ", "+")  # just in case, no space in url
    hdr = {
        "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Charset": "ISO-8859-1,utf-8;q=0.7,*;q=0.3",
        "Accept-Encoding": "none",
        "Accept-Language": "en-US,en;q=0.8",
        "Connection": "keep-alive",
    }
    req = urllib2.Request(url, headers=hdr)
    try:
        page = urllib2.urlopen(req)
        return page.read()
    except urllib2.HTTPError as e:
        print(e.fp.read())
    return ""


data = file_get_contents(f"{apiPrefix}/{apikey}/{controlsum}/decode/{vin}.json")
print(data)
# $result = json_decode($data);
