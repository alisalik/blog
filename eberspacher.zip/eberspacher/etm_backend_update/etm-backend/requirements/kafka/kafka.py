import asyncio
import json
import time

import nats

gateway_id = "042fa1d75d48b311"  # gateway_id
current_timestamp = round(time.time() * 1000)  # timestamp in milis

messages = {
    "heartbeat": {"timestamp": current_timestamp, "topic_prefix": "heartbeat"},
    "data_alarm.create": {
        "timestamp": current_timestamp,
        "alarm_event": {
            "signal_id": 13,  # FIXME: change if want to create alarm for differnt signal
            "alarm_id": 1,  # FIXME: change if different alarm id is needed to create alarm
            "device": "can0",
            "cause": "MISSING_SIGNAL_VALUES",
            "alarm_created": current_timestamp,
            "alarm_cleared": 0,
            "value_last_updated": current_timestamp,
            "time_accumulation_trigger": "SIGNAL_IGNITION_ON",  
            "cleared": False,
        },
        "topic_prefix": "alarm-event",
    },
    "data_alarm.clear": {
        "timestamp": current_timestamp,
        "alarm_event": {
            "signal_id": 13,  # FIXME: change if want to create alarm for differnt signal
            "alarm_id": 1,  # FIXME: change if different alarm id is needed to create alarm
            "device": "can0",
            "cause": "MISSING_SIGNAL_VALUES",
            "alarm_created": 0,
            "alarm_cleared": current_timestamp,
            "value_last_updated": current_timestamp,
            "time_accumulation_trigger": "SIGNAL_IGNITION_ON",  # FIXME: change as per required
            "cleared": True,
        },
        "topic_prefix": "alarm-event",
    },
    "operating_minutes": {
        "timestamp": current_timestamp,
        "value": 9000,  # FIXME: update value
        "topic_prefix": "sensor-signal.930",
    },
    "room1_returnairtemp": {
        "timestamp": current_timestamp,
        "value": 12,  # FIXME: update value
        "topic_prefix": "sensor-signal.63",
    },
    "room1_supplayairtemp": {
        "timestamp": current_timestamp,
        "value": 4,  # FIXME: update value
        "topic_prefix": "sensor-signal.66",
    },
    "room2_returnairtemp": {
        "timestamp": current_timestamp,
        "value": 12,  # FIXME: update value
        "topic_prefix": "sensor-signal.101",
    },
    "room2_supplyairtemp": {
        "timestamp": current_timestamp,
        "value": 0,  # FIXME: update value
        "topic_prefix": "sensor-signal.104",
    },
}


if __name__ == "__main__":

    signal_to_test = [
        ("heartbeat", "Y"),
        ("data_alarm.create", "Y"),
        ("data_alarm.clear", "Y"),
        ("operating_minutes", "Y"),
        ("room1_returnairtemp", "Y"),
        ("room1_supplayairtemp", "Y"),
        ("room2_returnairtemp", "Y"),
        ("room2_supplyairtemp", "Y"),
    ]

    async def main():
        # nc = await nats.connect("nats://localhost:4222")
        nc = await nats.connect("nats.dev.orahi.com:4222")
        for s in signal_to_test:
            if s[1] == "N":
                continue
            await nc.publish(
                "eber.iw-G26." + gateway_id + "." + messages[s[0]].pop("topic_prefix"),
                json.dumps(messages[s[0]]).encode("utf-8"),
            )
            await asyncio.sleep(1)

    asyncio.run(main(), debug=True)