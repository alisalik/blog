import asyncio
import subprocess
from config import BaseConfig
from nats_conn import NatsSingleton
import constants
import logging
from config import get_config
from nats.errors import TimeoutError, Error
import json
import exceptions
from mysql_conn import MysqlConnectionPool, create_connection

config = get_config()


async def download_file_from_rsync_server(gw_id, file_name, dest_dir):
    command = f'mkdir -p {dest_dir} && rsync -e "ssh -i {config.RSYNC_KEY_PATH} -o StrictHostKeyChecking=accept-new" -av {config.RSYNC_USER}@{config.RSYNC_SERVER}:{config.RSYNC_MODULE}/{gw_id}/{file_name} {dest_dir}'
    process = await asyncio.create_subprocess_shell(command, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
    stdout, stderr = await process.communicate()
    if process.returncode != 0:
        raise subprocess.CalledProcessError(returncode=process.returncode, cmd=command, output=stdout, stderr=stderr)
    return stdout.decode().strip(), stderr.decode().strip()


async def request_can_dump(gw_id: str = None, duration: int = None, can_channel: str= "can0"):
    response = {}
    nats_conn = await NatsSingleton().connect(config.get_nats_config_dict()["server"])
    subject = f"eber.iw-G26.{gw_id}.request.candump"
    msg = {"can_channel": can_channel ,"record_duration": duration}
    try:
        gw_response = await nats_conn.request(subject, str.encode(json.dumps(msg)), duration + constants.CAN_DUMP_REQUEST_EXTRA_TIME_SEC) # timeout after duration + 10 seconds
        gw_response = gw_response.data.decode()
    except TimeoutError as e:
        logging.debug("Timeout! while waiting for response from gw: %s",(gw_id))
        response["is_success"],  response["info"]= False, "Timeout occured waiting for reply from gateway"
        return response
    
    
    if gw_response is not None and "resultCode" in gw_response:
        if gw_response["resultCode"] != 0:
            response["is_success"],  response["info"]= False, gw_response["info"]
        else:
            response["is_success"],  response["info"]= True, gw_response["info"]
    else:
        response["is_success"],  response["info"]= False, "response from gateway is not parsable!"
    return response


async def write_to_database(db_conn, query: str="", values: tuple=()):
    logging.debug("executing query %s", (query))
    # Create a cursor object to execute SQL queries
    async with db_conn.cursor() as cur:
        await cur.execute(query, values)
        # Commit the changes
        await db_conn.commit()


async def execute_db_query(query, args):
    conn = await create_connection()
    async with conn.cursor() as cursor:
        logging.debug("executing query %s", (query))
        # Create a cursor object to execute SQL queries
        async with conn.cursor() as cur:
            await cur.execute(query, args)
            # Commit the changes
            await conn.commit()
    conn.close()

async def read_from_db(query, values):
    conn = await create_connection()
    async with conn.cursor() as cur:
        # Execute the query with the given values
        await cur.execute(query, values)

        # Fetch the results of the query
        result = await cur.fetchall()

        # Return the results
    conn.close()
    return result

async def request_can_status(nc, gateway_id, can_channel):
    """request can status from a gateway"""
    subject = f"eber.iw-G26.{gateway_id}.request.can-recorder-status"
    payload = {"can_channel": can_channel}
    # timeout after 5 seconds
    timeout_sec = 5 
    try:
        res = await nc.request(subject, str.encode(json.dumps(payload)), timeout_sec)
        res_data = json.loads(res.data)
        status = res_data["status"]
        return status
    except TimeoutError as te:
        raise Exception("Gateway not responding probably offline!")
    except Error as e:
        raise exceptions.NatsError()
    except Exception as e:
        raise e

async def request_s3_upload(nats_conn = None, gateway_id = "", file_name = "", copy_only=False):
    source = config.RSYNC_SOURCE
    s3_dest = config.S3_DEST
    try:
        nats_subject = "orahi.rsync.request.move-file-to-s3"
        payload = {
            "rsync_source": source%gateway_id,
            "file_name": file_name,
            "s3_destination": s3_dest%gateway_id,
            "copy_only": copy_only
        }
        await message_nats_server(nats_conn=nats_conn, type="request", payload=payload, subject=nats_subject, timeout_sec=20)
    except Exception as e:
        raise e
    
async def message_nats_server(nats_conn = None, type = "publish", payload = {}, subject= "", timeout_sec= 10):
    try:
        resp = await nats_conn.request(subject, str.encode(json.dumps(payload)), timeout_sec)
    except TimeoutError as te:
        logging.exception(te)
        raise te
    except Error as e:
        logging.exception(e)
        raise exceptions.NatsError()
    except Exception as e:
        logging.exception(e)
        raise e

async def main():
    # --- NATS candump flow
    # nats_server = config.get_nats_config_dict()["server"]
    # nats_conn = await NatsSingleton().connect(nats_server)
    # gw_id = "113aa1d75d48b311"

    # can_channel = "can0"
    # await request_can_status(nats_conn, gw_id, can_channel)
    ignition_on = True
    state = "Online"
    conn_alarm = await read_from_db("SELECT * from db_etm.tbl_vehicle_alarms tva inner join db_etm.tbl_hvac_vin_gateway \
                              thvg ON tva.vin = thvg.vin and tva.type_id = 1 and thvg.gateway_id = %s and tva.status='1' ", values=('5632',))
    if not bool(conn_alarm) and ignition_on:
        state = "Online"
    elif bool(conn_alarm):
        state = "Offline"
    elif not bool(conn_alarm) and not ignition_on:
        state = "Sleeping"
    # listen to this header
    headers = [
        ("service", b"NATS_CONNECTOR"),
        ("module", b"gateway"),
        ("action", action.encode("utf-8")),
    ]
    await execute_db_query("UPDATE db_etm.tbl_vehicle set state = %s where vin = %s", (state, conn_alarm[0][1]))
    pass

if __name__ == '__main__':
    can_file = "canrecordings_113aa1d75d48b311_2023-03-14_06-54-41.zip"
    # dest = "/Users/anton/orahi.projects/eberspacher/modules/web.apis/async_job_executor/dest/rsync/" + gw_id

    try:
        asyncio.run(main())
    except Exception as e:
        print(e)


