import nats 
from config import get_config

config = get_config()

class NatsSingleton:
    _instance = None
    
    def __new__(cls, *args, **kwargs):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance.nats = None
        return cls._instance

    async def connect(self, server):
        if self.nats is None:
            self.nats = await nats.connect(server, nkeys_seed=config.NATS_SEED_FILE_LOCATION)
        return self.nats