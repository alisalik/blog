# config.py
import logging
from os import environ

from dotenv import load_dotenv

if environ.get("ENV_FILE_PATH"):
    # read env var from file
    load_dotenv(dotenv_path=environ.get("ENV_FILE_PATH"))
ENV = environ.get("ENV")
if environ.get("LOGGING_LEVEL") == "DEBUG":
    logging.basicConfig(level=logging.DEBUG)


class BaseConfig:
    MYSQL_HOSTNAME = "mysql.dev.orahi.com"
    MYSQL_PORT = 3306
    MYSQL_USERNAME = environ.get("DB_USER")
    MYSQL_PASSWORD = environ.get("DB_PASSWORD")
    MYSQL_DBNAME = environ.get("DB_NAME")

    LOGGING_LEVEL = environ.get("LOGGING_LEVEL")

    KAFKA_CONSUMER_TOPIC = environ.get("KAFKA_COMSUME_TOPIC")
    KAFKA_BOOTSTRAP_SERVER = environ.get("KAFKA_BOOTSTRAP_SERVERS")
    KAFKA_USERNAME = environ.get("KAFKA_USERNAME")
    KAFKA_PASSWORD = environ.get("KAFKA_PASSWORD")
    # constants
    KAFKA_SASL_MECHANISM = "SCRAM-SHA-512"
    KAFKA_AUTO_OFFSET_RESET = "latest"
    KAFKA_ENABLE_AUTO_COMMIT = True
    KAFKA_SECURITY_PROTOCOL = environ.get("KAFKA_SECURITY_PROTOCOL", "SASL_SSL")

    # nats
    NATS_SERVER = environ.get("NATS_SERVER", "nats.dev.orahi.com:4222")
    NATS_TOPIC_COMPANY_NAMESPACE = environ.get("NATS_TOPIC_COMPANY_NAMESPACE", "eber")
    NATS_CAN_DUMP_FILE_UPLOAD_REQ_TIMEOUT_FACTOR = 3
    NATS_SEED_FILE_LOCATION = "/app/async_job_executor/nkeyseed"

    RSYNC_SERVER = "ec2-16-16-22-143.eu-north-1.compute.amazonaws.com"
    RSYNC_USER = "gateway"
    RSYNC_MODULE = "rsync/eber-iwave-diag"
    RSYNC_SOURCE = "/home/gateway/rsync/eber-iwave-diag/%s"
    S3_DEST = "s3://consat/eberspacher/gateway/diagnostics/%s/can_recordings"
    USE_S3 = 1
    RSYNC_KEY_PATH = "/Users/anton/orahi.projects/eberspacher/modules/web.apis/gateway.pem"
    
    CAN_DUMP_FILE_DOWNLOAD_LOCATION = "/Users/anton/orahi.projects/eberspacher/modules/web.apis/async_job_executor/dest/rsync/"

    DJANGO_MEDIA_FILES_BASE_URL = "http://localhost:8000/hello"
    DJANGO_CAN_DUMP_ENDPOINT = "http://localhost:8000/api/v1/gateway/%s/diagnostics/can_dump/download"

    def get_kafka_config_dict(self):
        return {
            "bootstrap_servers": self.__class__.KAFKA_BOOTSTRAP_SERVER,
            "auto_offset_reset": BaseConfig.KAFKA_AUTO_OFFSET_RESET,
            "enable_auto_commit": BaseConfig.KAFKA_ENABLE_AUTO_COMMIT,
            "security_protocol": BaseConfig.KAFKA_SECURITY_PROTOCOL,
            "sasl_plain_username": BaseConfig.KAFKA_USERNAME,
            "sasl_plain_password": BaseConfig.KAFKA_PASSWORD,
            "sasl_mechanism": BaseConfig.KAFKA_SASL_MECHANISM,
        }
    
    def get_mysql_config_dict(self):
        return {
            "host": self.__class__.MYSQL_HOSTNAME,
            "port": self.__class__.MYSQL_PORT,
            "user": self.__class__.MYSQL_USERNAME,
            "password": self.__class__.MYSQL_PASSWORD,
            "db": self.__class__.MYSQL_DBNAME,
        }
    def get_nats_config_dict(self):
        return {
            "server": self.__class__.NATS_SERVER,
            "topic_company_namespace": self.__class__.NATS_TOPIC_COMPANY_NAMESPACE}

class LocalConfig(BaseConfig):
    NATS_SERVER = "nats.dev.orahi.com:4222"
    # NATS_SERVER = "tls://natsk8.dev.orahi.com:4222"
    NATS_SEED_FILE_LOCATION = "/Users/anton/orahi.projects/eberspacher/modules/web.apis/async_job_executor/nkeyseed"



class DevelopmentConfig(BaseConfig):
    CAN_DUMP_FILE_DOWNLOAD_LOCATION = "/media_files"
    MYSQL_HOSTNAME = "mysql.dev.orahi.com"
    MYSQL_PORT = 3306
    RSYNC_KEY_PATH = "/app/async_job_executor/gateway.pem"
    DJANGO_MEDIA_FILES_BASE_URL = "https://eberspacher-web-api-etm.dev.orahi.com/media"
    DJANGO_CAN_DUMP_ENDPOINT = "https://eberspacher-web-api-etm.dev.orahi.com/api/v1/gateway/%s/diagnostics/can_dump/download"
    NATS_SERVER = "tls://natsk8.dev.orahi.com:4222"
    RSYNC_SOURCE = "/home/gateway/rsync/diag/%s"
    S3_DEST = "s3://consat/eberspacher/gateway/diagnostics/dev/%s/can_recordings"

class QCConfig(BaseConfig):
    MYSQL_HOSTNAME = "mysql.qc.orahi.com"
    MYSQL_PORT = 3307
    
    KAFKA_SASL_MECHANISM = "SCRAM-SHA-512"
    KAFKA_AUTO_OFFSET_RESET = "latest"
    KAFKA_ENABLE_AUTO_COMMIT = True

    CAN_DUMP_FILE_DOWNLOAD_LOCATION = "/media_files"
    RSYNC_KEY_PATH = "/app/async_job_executor/gateway.pem"
    DJANGO_MEDIA_FILES_BASE_URL = "https://eberspacher-web-api-etm.qc.orahi.com/media"
    DJANGO_CAN_DUMP_ENDPOINT = "https://eberspacher-web-api-etm.qc.orahi.com/api/v1/gateway/%s/diagnostics/can_dump/download"

class ProductionConfig(BaseConfig):
    MYSQL_HOSTNAME = "mysql.uat.orahi.com"
    MYSQL_PORT = 3308
    
    KAFKA_SASL_MECHANISM = "SCRAM-SHA-512"
    KAFKA_AUTO_OFFSET_RESET = "latest"
    KAFKA_ENABLE_AUTO_COMMIT = True

    CAN_DUMP_FILE_DOWNLOAD_LOCATION = "/media_files"

    RSYNC_KEY_PATH = "/app/async_job_executor/gateway.pem"
    DJANGO_MEDIA_FILES_BASE_URL = " https://eberspacher-web-api-etm.uat.orahi.com/media"
    DJANGO_CAN_DUMP_ENDPOINT = "https://eberspacher-web-api-etm.uat.orahi.com/api/v1/gateway/%s/diagnostics/can_dump/download"


config = {
    "development": DevelopmentConfig,
    "production": ProductionConfig,
    "default": DevelopmentConfig,
}


def get_config():
    def dump(obj):
        for attr in dir(obj):
            print("obj.%s = %r" % (attr, getattr(obj, attr)))

    config = None
    if ENV == "DEV":
        config = DevelopmentConfig()
    elif ENV == "LOCAL":
        config = LocalConfig()
    elif ENV == "PROD":
        config = ProductionConfig()
    elif ENV == "QC":
        config = QCConfig()
    else:
        raise ValueError(f"Invalid value of ENV:{ENV}")
    logging.info("running with below configuraitons")
    logging.info(dump(config))
    return config
