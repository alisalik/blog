import aiomysql
from config import get_config
config= get_config()
class MysqlConnectionPool:
    __instance = None

    def __new__(cls):
        if cls.__instance is None:
            cls.__instance = super().__new__(cls)
            cls.__instance.pool = None
        return cls.__instance

    async def get_pool(self, loop, config):
        if self.pool is None:
            self.pool = await aiomysql.create_pool(loop=loop, **config)
        return self.pool

    async def close_pool(self):
        if hasattr(self, 'pool'):
            self.pool.close()
            await self.pool.wait_closed()
            del self.pool
    
    async def execute_query(self, query, *args):
        async with self.pool.acquire() as conn:
            async with conn.cursor() as cur:
                await cur.execute(query, args)
                return await cur.fetchall()
            

async def create_connection():
    conn = await aiomysql.connect(
        **config.get_mysql_config_dict()
    )
    return conn