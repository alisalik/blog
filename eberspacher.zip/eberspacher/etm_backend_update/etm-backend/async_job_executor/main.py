from config import get_config
import asyncio
from aiokafka import AIOKafkaConsumer
import os
from aiokafka.helpers import create_ssl_context
from mysql_conn import MysqlConnectionPool, create_connection
import random
from nats_conn import NatsSingleton
import json 
from nats.errors import TimeoutError
import constants
import time
config = get_config()
import logging
from datetime import datetime
from utils import request_can_dump, download_file_from_rsync_server, request_can_status, execute_db_query, request_s3_upload
import sys

logging.getLogger().setLevel(logging.DEBUG)
logging.getLogger("aiokafka").setLevel(logging.INFO)
logging.critical("Testing critial msg")
async def handle_message(payload):

    loop = asyncio.get_event_loop()
    gateway_id = payload["gateway_id"]
    
    mysql_config = config.get_mysql_config_dict()
    nats_server = config.get_nats_config_dict()["server"]
    nats_conn = await NatsSingleton().connect(nats_server)
    # check with gateway if it can start recording can_dump
    #FIXME: hardcoded this should come from dropdown when designs are ready!
    try:
        status = await request_can_status(nats_conn, gateway_id, "can0")
        if status == "READY":
            await execute_db_query("UPDATE db_etm.tbl_diagnostics SET can_dump_start_time=%s where id=%s",(datetime.utcnow(),payload["db_id"],))
        else:
            await execute_db_query("UPDATE db_etm.tbl_diagnostics SET status='FAILED', remarks=%s where id=%s",("Gateway is busy",payload["db_id"],))
            return
    except Exception as e:
        logging.exception(e)
        await execute_db_query("UPDATE db_etm.tbl_diagnostics SET status='FAILED', remarks=%s where id=%s",(str(e),payload["db_id"],))
        return 
    can_dump_msg = {"can_channel": payload['can_channel'] ,"record_duration": payload["duration"]}
    subject = f"eber.iw-G26.{gateway_id}.request.candump"
    
    
    nats_msg_payload = json.dumps(can_dump_msg)

    status = constants.DIAGNOSTICS_STATUSES[1] #default status of completed
    remark = ""
    gw_response = None
    try:
        gw_response =  await nats_conn.request(subject, str.encode(nats_msg_payload), 
                                               payload["duration"]*config.NATS_CAN_DUMP_FILE_UPLOAD_REQ_TIMEOUT_FACTOR) # timeout after duration*10 seconds
    except TimeoutError:
        logging.debug("Timeout! while waiting for response from gw: %s",(gateway_id))
        status = constants.DIAGNOSTICS_STATUSES[2] # failed status
        remark = constants.DIAGNOSTICS_REMARKS_TEMPLATE["candump"][status] %"No reply received for start can_dump request from gateway on nats server."
    if gw_response is not None:
        response = json.loads(gw_response.data.decode())
        """ resp from gateway
        {
            "timestamp":1679734674046,
            "successful":true,
            "file_name":"canrecordings_113aa1d75d48b311_2023-03-25_08-58-14.zip",
            "info":"candump completed successfully, file uploaded successfully
        }
        """
        if not response["successful"]:
            remark = response["info"]
            status = constants.DIAGNOSTICS_STATUSES[2]
        else:
            if config.USE_S3 == 1:
                try:
                    await request_s3_upload(nats_conn=nats_conn, gateway_id=gateway_id, file_name=response["file_name"], copy_only=False)
                except Exception as e:
                    status = constants.DIAGNOSTICS_STATUSES[2]
                    remakr = str(e)

            filename = response["file_name"]
            file_url = config.DJANGO_CAN_DUMP_ENDPOINT %(gateway_id)
            
    if status == constants.DIAGNOSTICS_STATUSES[2]: #failed
        query = "UPDATE db_etm.tbl_diagnostics SET status=%s, remarks=%s where id=%s"
        values = (status, remark, payload["db_id"])
        await execute_db_query(query, values)
    else:
        values = (datetime.utcnow(), status, remark, filename, file_url, payload["db_id"])
        query = "UPDATE db_etm.tbl_diagnostics SET can_dump_end_time=%s, status=%s, remarks=%s, file_name=%s, file_url=%s where id=%s"
        await execute_db_query(query, values)

async def lively_job():
    sec = 0
    while True:
        await asyncio.sleep(100)
        sec += 100
        logging.info(f"{sec} seconds passed i am still alive!!")
async def consume_kafka():
    running_tasks = set()
    consumer = AIOKafkaConsumer(
        config.KAFKA_CONSUMER_TOPIC,
        **config.get_kafka_config_dict(),
        ssl_context=create_ssl_context(),
    )
    await consumer.start()
    first_run = True
    try:
        async for msg in consumer:
            # The ensure_future function is used to schedule the execution 
            # of a coroutine in an asynchronous context. It schedules the 
            # coroutine to run as soon as possible, but does not block the 
            # calling code. Instead, it returns a Task object immediately 
            # that can be used to track the progress of the coroutine and 
            # obtain its result when it completes.
            if first_run:
                asyncio.ensure_future(lively_job())
                first_run = False
            try:
                headers = {k: v.decode("utf-8") for (k, v) in dict(msg.headers).items()}
                
                if ("to-service" not in headers or headers["to-service"] != "ASYNC-JOB-EXECUTOR"):
                    continue
                else:
                    payload = json.loads(msg.value.decode('utf-8'))
                    if ("task_code" not in payload or payload["task_code"] != "eber.gateway.can.dump"):
                    # packet not intended for this service/ only supporting eber.gateway.can.dump task
                        continue
            except Exception as err:
                logging.error(f"while parsing message {msg.values()}")
                logging.exception(err)
            asyncio.ensure_future(handle_message(payload))        
    finally:
        await consumer.stop()
        sys.exit(0)

asyncio.run(consume_kafka())