
class Error(Exception):
    pass



class NatsError(Error):

    def __str__(self) -> str:
        return "something went wrong while interating with nats server"


class StaleConnectionError(Error):

    def __str__(self) -> str:
        return "nats: stale connection"
