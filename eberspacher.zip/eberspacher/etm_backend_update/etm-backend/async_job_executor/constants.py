DIAGNOSTICS_STATUSES = ["PENDING", "COMPLETED", "FAILED"]

DIAGNOSTICS_REMARKS_TEMPLATE = {
    "candump": {
        "COMPLETED": "completed: in %s seconds",
        "FAILED": "reason: %s"
    }
}

CAN_DUMP_REQUEST_EXTRA_TIME_SEC = 10


GW_DIR_TO_UPLOAD_CAN_DUMP = "/var/co/canrecordings"

NATS_REQ_UPLOAD_WAIT_SECS = 3600 #waiting for 1 hour
