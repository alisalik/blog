# todos
- 

# useful links
## misc
- https://stackoverflow.com/questions/17803829/how-to-customize-a-requirements-txt-for-multiple-environments
- https://stackoverflow.com/questions/43654656/dockerfile-if-else-condition-with-external-arguments
- https://stackoverflow.com/questions/31181588/how-can-i-exclude-a-sub-directory-with-a-dockerignore-file
- https://stackoverflow.com/questions/59183863/in-python-how-to-tweak-black-formatter-if-possible
- https://stackoverflow.com/questions/17194301/is-there-any-way-to-show-the-dependency-trees-for-pip-packages

## django
### best practice
- https://django-best-practices.readthedocs.io/en/latest/
- https://github.com/lincolnloop/django-layout


# Installation
1. clone the repo
2. make sure the .vscode folder is installed on the system, this folder contains workspace level settings of this project
3. create virtualenv using tool of your choice
4. install requirements using 
```

pip install -r requirements/dev.txt
```
5.  



```sh

export $(grep -v '^#' ./api/settings/.env.local | xargs)

```

# pending queries
```sql
ALTER TABLE db_etm.tbl_diagnostics ADD can_dump_start_time DATETIME NULL COMMENT 'The time when can_dump started';
ALTER TABLE db_etm.tbl_diagnostics ADD can_dump_end_time DATETIME NULL COMMENT 'the time when can_dump finished';


```