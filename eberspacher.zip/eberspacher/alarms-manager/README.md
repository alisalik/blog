### TODOS
- package dependencies
```md
pip install pipdeptree
pipdeptree -fl
pipdeptree --freeze  --warn silence | grep -P '^[\w0-9\-=.]+'
```
- docker commands
```sh
docker build -t eber.backend/alarms-management:pilot .
docker run -it --rm --name bubble \
    --env-file .env.dev.docker \
    eber.backend/alarms-management:pilot
docker run -it --rm --entrypoint /bin/bash --name bubble \
    --env-file .env.dev.docker \
    eber.backend/alarms-management:pilot                             

apt-get install net-tools
apt-get install netcat-traditional
```


