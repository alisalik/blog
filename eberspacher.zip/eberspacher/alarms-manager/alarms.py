import datetime
import logging
import os
import sys
import time
from email import message
from inspect import trace
from signal import alarm

from database import DatabaseState

try:
    IN_MEM_DB = DatabaseState()
    from utils import SIGNAL_METADATA, get_signal
except Exception as e:
    logging.exception(e)
    os.remove("already_running")
    sys.exit(0)


class Alarm:
    """interface for common alarm related operations"""

    """will be used by all types of alarms"""

    def create(self, alarm_dict: dict):
        IN_MEM_DB.add_records_in_mem(
            "vehicle_alarms",
            alarm_dict,
        )

    def update(self, index: int, alarm_dict: dict):
        IN_MEM_DB.update_records_in_mem("vehicle_alarms", index, data=alarm_dict)

    def get_gateway_data(self, gw_id):
        gw_data = IN_MEM_DB.get_records_in_mem("gateway_data", gateway_id=[gw_id])
        if gw_data is None:
            # raise ValueError(f"no gateway data found for gw:{gw_id}, lookup was done" + f" on in-mem dataaset query was {IN_MEM_DB.get_query_from_name('gateway_data')}")
            logging.warning(f"no gateway data found for gw:{gw_id}, lookup was done" + f" on in-mem dataaset query was {IN_MEM_DB.get_query_from_name('gateway_data')}")
        return gw_data

    def get_alarms(self, **kwargs):
        alarms_recs = IN_MEM_DB.get_records_in_mem(
            "vehicle_alarms",
            vin=[self.vin],
            metadata=[{"alarm_id": alarm_id}],
        )
        return alarms_recs


class DataAlarm(Alarm):
    TYPE_ID = 3  # database id for data alarm
    TRIGGERED_BY = "gateway"

    def __init__(self, raw_msg):
        logging.debug(f"data alarm got message ==> {raw_msg}")
        alarm_event = raw_msg["alarm_event"]
        self.gateway_id = raw_msg["gateway_id"]
        self.metadata = {
            k.replace("-", "_"): v  # for consistent naming
            for (k, v) in alarm_event.items()
            # if k
            # in [
            #     "alarm-id",
            #     "signal-name",
            # ]  # NOTE: only selecting these data points from mesage
        }
        # read vin from gateway_id
        gw_data = self.get_gateway_data(self.gateway_id)
        # rec = IN_MEM_DB.get_records_in_mem("gateway_data", gateway_id=[self.gateway_id])
        self.vin = gw_data["vin"]
        # get records for alarm-id
        rec = self.get_alarm_data_by_id(self.metadata["alarm_id"])
        if alarm_event["cleared"] == False:
            """This is new alarm create one"""
            display_name = (
                self.metadata["device"].lower() + ":" + self.metadata["cause"].lower()
                if self.metadata["signal_id"] == 0
                else get_signal(self.metadata["signal_id"])["display_Name"] + ":" + self.metadata["cause"].lower()
            )

            if rec is not None:
                # TODO: if gateway reflash happens then the alarm id will again start from 0. so for same gateway
                # same alarm with same id might come. After discussion with firmware team a good thing would be to use
                # alarm_id and created_at to check the uniqueness.
                raise ValueError(f"alarm with id {self.metadata['alarm_id']} already exists ==> {rec}")
            self.create(
                alarm_dict={
                    "vin": self.vin,
                    "type_id": DataAlarm.TYPE_ID,
                    "status": "1",
                    "metadata": self.metadata | {"display_name": display_name},  # FIXME: hardcoded
                    "state": "new",
                    "triggered_at": datetime.datetime.fromtimestamp(alarm_event["alarm_created"] / 1000),
                    "triggered_by": self.__class__.TRIGGERED_BY,
                }
            )
        else:
            if rec is None:
                # alarm doesn't exist message from kafka partiions are read out of order
                display_name = (
                    self.metadata["device"].lower() + ":" + self.metadata["cause"].lower()
                    if self.metadata["signal_id"] == 0
                    else get_signal(self.metadata["signal_id"])["display_Name"] + ":" + self.metadata["cause"].lower()
                )
                self.create(
                    alarm_dict={
                        "vin": self.vin,
                        "type_id": DataAlarm.TYPE_ID,
                        "status": "0",
                        "metadata": self.metadata | {"display_name": display_name},  # FIXME: hardcoded
                        "state": "new",
                        "triggered_at": datetime.datetime.fromtimestamp(alarm_event["alarm_created"] / 1000),
                        "triggered_by": self.__class__.TRIGGERED_BY,
                        "closed_at": datetime.datetime.fromtimestamp(alarm_event["alarm_cleared"] / 1000),
                        "closed_by": "gateway",
                    }
                )
                pass
            else:
                display_name = (
                    self.metadata["device"].lower() + ":" + self.metadata["cause"].lower()
                    if self.metadata["signal_id"] == 0
                    else get_signal(self.metadata["signal_id"])["display_Name"] + ":" + self.metadata["cause"].lower()
                )
                # alarm with this id already exists
                df_index = rec["index"]  # used for update api
                self.update(
                    df_index,
                    alarm_dict={
                        "status": "0",  # closing alarm
                        "closed_at": datetime.datetime.fromtimestamp(alarm_event["alarm_cleared"] / 1000),
                        "closed_by": "gateway",
                        "state": "updated" if rec["state"] != "new" else "new",
                        "metadata": self.metadata | {"display_name": display_name},
                    },
                )

    def get_alarm_data_by_id(self, alarm_id):
        """get data alarm object data based on unique alarm id assigned by gw"""
        rec = IN_MEM_DB.get_records_in_mem(
            "vehicle_alarms",
            vin=[self.vin],
            metadata=[{"alarm_id": alarm_id}],
        )
        return rec


class PreventiveAlarm(Alarm):
    ALLOWED_MODES = ["operating_hours", "time_period_days", "distance_covered_km"]
    TYPE_ID = 4  # database id for data alarm
    TRIGGERED_BY = "backend"

    # TODO: add logic to process mode_wise for ex if mode is time_period_days then any packet not for that mode should be dropped
    def __init__(self, raw_msg, mode="operating_hours"):
        logging.debug(f"preventive alarm got message ==> {raw_msg}")
        self.gateway_id = raw_msg["gateway_id"]  # extract g/w id from msg

        # get vin, engine_type and climate_zone from in_mem_db, populated from tbl_gateway, tbl_hvac_vin_gateway,
        # tbl_vehicle, tbl_fleet .etc.
        # rec = IN_MEM_DB.get_records_in_mem("gateway_data", gateway_id=[self.gateway_id])
        rec = self.get_gateway_data(self.gateway_id)
        if rec is None:
            raise ValueError(f"no gateway data found for gw:{self.gateway_id}, lookup was done on in-mem dataaset query was {IN_MEM_DB.get_query_from_name('gateway_data')}")
        self.vin = rec["vin"]
        self.engine_type = rec["engine_type"]
        self.climate_zone = rec["climate_zone"]
        # get maintaince mode for vehicle. it will be the initial entry in the table.
        self.mode = self.get_vehicle_alarm_config(requested_mode=mode)["mode"]
        if self.mode != mode:
            logging.info(f"Not performing preventive tasks for {self.mode} for gw{self.gateway_id}")
            return
        # TODO: the initial value will be present in self.get_vehicle_alarm_config() object itself, no need of extracting it from
        # initial value attribute, Do proper handling here if the values are not present then what to do.
        # also initial_value will be a dict now so need to change it in all the places
        # if some level's data is not there assume it zero
        # initial_value is the dict that stores mode and initial values
        self.initial_values = self.get_vehicle_alarm_config()
        for v in self.initial_values:
            if v in ["level_a", "level_b", "level_c", "level_d", "level_e"]:
                self.initial_values[v] = int(self.initial_values[v])
        # assuming data related to same mode is coming from upstream
        self.level_intervals = self.get_level_intervals()
        # get last triggered alarms for each level
        self.latest_level_wise_alarms = self.get_level_wise_latest_alarm()
        logging.debug(f"extracted following details ==> {self.__dict__}")
        # process
        self.process(raw_msg[self.mode])  # process the operating hours reported by gateway

    def process(self, reported_val):
        """for a given operating hours from g/w create alarm is threashold is reached"""
        logging.debug(f"should preventive/maintaince alarm be triggered for reporte val: {reported_val}??")
        for level, interval in self.level_intervals.items():
            if interval == 0:
                logging.debug(f"interval is zero so processing for level {level} is skipping")
                continue  # zero means that level should not be considered
            if level in self.latest_level_wise_alarms:
                # some maintainenace alarm has already been raised, so last one will be reference for the calculations
                last_trigger = self.latest_level_wise_alarms[level]
                last_trigger_pt = last_trigger[self.mode]
                sum_already_processed = last_trigger_pt

            else:
                # NO maintainenace alarm has been raised, so initial value will be reference in case of operating hours
                # initial values will be zero if not filled by the gateway.
                # TODO: read initial value level wise
                # TODO: read initial value based on level now
                last_trigger_pt = self.initial_values["level_" + level]
                if self.mode == "time_period_days":
                    sum_already_processed = last_trigger_pt
                elif self.mode == "operating_hours":
                    sum_already_processed = 0
            sum_to_check = reported_val - sum_already_processed
            s = interval
            if sum_to_check <= 0:
                raise ValueError(f"this value of operating alarm has already been processed" "same value should not have come again pls check upstream message flow")
            while s <= sum_to_check:
                metadata = {
                    "level": level,
                    self.mode: last_trigger_pt + s,
                    "display_name": f"Level {level.upper()}",  # FIXME: hardcoded
                }
                if self.mode == "time_period_days":
                    metadata["human_readable_date_of_alarm"] = datetime.date.fromtimestamp((last_trigger_pt + s) * 24 * 60 * 60).strftime("%Y-%m-%d %H:%M:%S")
                alarm_dict = {
                    "vin": self.vin,
                    "type_id": PreventiveAlarm.TYPE_ID,
                    "status": "1",
                    "triggered_by": PreventiveAlarm.TRIGGERED_BY,
                    "triggered_at": datetime.datetime.utcnow(),
                    "metadata": metadata,
                }
                logging.debug(f"creating this alarm ==> {alarm_dict}")

                self.create(alarm_dict=alarm_dict)
                s += interval
        pass

    def get_vehicle_alarm_config(self, requested_mode="operating_hours"):
        # TODO: get_records_in_mem function with pick_specific can be used
        # NOTE: hardcoded tirggeredby system
        """
        # NOTE: new -> {"mode": "time_period_days", "level-1": "01-aug-2022", "level-2": "08-sep-2022", "level-3": "06-oct-2022", "level-4": "11-nov-2022", "level-5": "23-nov-2022"}
        # {"mode": "operating_hours", "level-1": "10", "level-2": "20", "level-3": "30", "level-4": "44", "level-5": "55"}
        returns {'mode': 'operating_hours', 'initial_value': 310}"""
        rec = IN_MEM_DB.get_records_in_mem(
            "vehicle_alarms",
            vin=[self.vin],
            type_id=[PreventiveAlarm.TYPE_ID],
            dataframe=False,  # need dict
            unique=True,
            pick_specific={"triggered_at": "min"},  # first record will always have config
            # pick_specific={"triggered_by": "system"},  # triggered by system will always have alarm configs
        )
        if rec is None:
            raise ValueError(f"No initial value preventive maintaince value found for VIN:{self.vin}")
            if requested_mode == "operating_hours":
                # if no operating hours are specified then all the trigger levels should be zero
                return {"mode": "operating_hours", "level_a": "0", "level_b": "0", "level_c": "0", "level_d": "0", "level_e": "0"}
        elif rec["triggered_by"] != "system":
            # this rec is not for initial value
            return
            return {"mode": "operating_hours", "level_a": "0", "level_b": "0", "level_c": "0", "level_d": "0", "level_e": "0"}
        return rec["metadata"]

    def get_last_alarm_trigger(self):
        alarm_data = IN_MEM_DB.get_records_in_mem(
            "vehicle_alarms",
            vin=[self.vin],
            type_id=[PreventiveAlarm.TYPE_ID],
            dataframe=True,
            unique=False,
            pick_specific={"triggered_by": "system"},
        )
        pass

    def get_level_intervals(self):
        levels = IN_MEM_DB.get_records_in_mem(
            "maintenance_dataset",
            unique=False,
            dataframe=False,
            engine_type=[self.engine_type],
            climate_zone=[self.climate_zone],
        )
        return {elm["level"]: elm[self.mode] for elm in levels}

    def get_level_wise_latest_alarm(self):
        """retuns the latest preventive alarm raised per level

        Returns:
            dict: {"a": {"level": "a", "display_name": "Level A", "operating_hours": 45} }
        """
        alarm_list = []

        for l in self.level_intervals:
            alarms = IN_MEM_DB.get_records_in_mem(
                "vehicle_alarms",
                unique=False,  # at same time multiple alarm might have be raised.
                dataframe=False,
                pick_specific={"triggered_at": "max"},
                vin=[self.vin],
                type_id=[PreventiveAlarm.TYPE_ID],
                metadata=[{"level": l}],
                keep_columns=["metadata", "id"],
            )
            if alarms is not None:
                alarm_list = alarm_list + alarms
        latest_alarms = {}
        for a in alarm_list:
            # get objects with maximun operating hours
            level = a["metadata"]["level"]
            if level not in latest_alarms:
                latest_alarms[level] = a["metadata"]
                # latest_alarms[level].pop("level")
            else:
                # check if current mode number is gt.
                if latest_alarms[level][self.mode] < a["metadata"][self.mode]:
                    # a["metadata"].pop("level")
                    latest_alarms[level] = a["metadata"]
                    # latest_alarms[level].pop("level")

        return latest_alarms


if __name__ == "__main__":

    import time

    from tests import generate_message

    messages = [
        # generate_message(
        #     "DA",
        #     {
        #         "alarm_event": {
        #             "signal_id": 10,
        #             "cleared": False,
        #             "alarm_id": 3,
        #             "alarm_created": int((time.time() - 20) * 1000),
        #         }
        #     },
        #     "02091994adbdcd11",
        # ),
        generate_message(
            "DA",
            {
                "alarm_event": {
                    "signal_id": 10,
                    "cleared": False,
                    "alarm_id": 3,
                    "alarm_created": int((time.time() - 20) * 1000),
                }
            },
            "02091994adbdcd11",
        ),
        generate_message(
            "DA",
            {
                "alarm_event": {
                    "signal_id": 10,
                    "cleared": True,
                    "alarm_id": 3,
                    "alarm_cleared": int(time.time() * 1000),
                    "alarm_created": int((time.time() - 20) * 1000),
                }
            },
            "02091994adbdcd11",
        )
        # Preventive Alarm Messages
        # generate_message("PA", {"operating_hours": 1000}, "harishtest123"),
        # generate_message("PA", {"operating_hours": 50.0}, "042fa1d75d48b311"),
        # generate_message("PA", {"operating_hours": 50.0}, "042fa1d75d48b311"),
        # generate_message("PA", {"operating_hours": 100.0}, "042fa1d75d48b311"),
        # generate_message("PA", {"operating_hours": 150.0}, "042fa1d75d48b311"),
        # generate_message("PA", {"operating_hours": 150.0}, "042fa1d75d48b311"),
        # generate_message("PA", {"operating_hours": 0.0}, "042fa1d75d48b311"),
        # generate_message("PA", {"operating_hours": 150.0}, "042fa1d75d48b311"),
        # generate_message("PA", {"operating_hours": 500}, "042fa1d75d48b311"),
        # generate_message("PA", {"operating_hours": 30}, "5d48b311042fa1d7"),
        # generate_message("PA", {"operating_hours": 100}, "5d48b311042fa1d7"),
        # generate_message("Heartbeat", {}, "400001"),
    ]
    logging.getLogger().setLevel(logging.DEBUG)
    for m in messages:
        try:
            if "alarm_event" in m:
                DataAlarm(m)
            elif m["id"] == 930:
                PreventiveAlarm(m)
        except ValueError as err:
            import sys
            import traceback

            error_type, error_instance, traceback = sys.exc_info()
            # logging.error(str(err))
            logging.exception(err)
            # logging.
    active_alarms_recs = IN_MEM_DB.get_records_in_mem(
        "vehicle_alarms",
        type_id=[1],
        status=["1"],  # open alarms
        unique=False,  # REVIEW: is it needed?
    )
    # PreventiveAlarm({"gateway_id": "02091994adbdcd11", "time_period_days": 19515}, mode="time_period_days")
    IN_MEM_DB.persist_changes("vehicle_alarms")
