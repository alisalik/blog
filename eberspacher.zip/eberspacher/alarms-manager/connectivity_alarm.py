import datetime
import logging
from email import message
from inspect import trace
from signal import alarm

from config import get_config
from database import DatabaseState

IN_MEM_DB = DatabaseState()
config = get_config()

from alarms import Alarm
from utils import extract_druid_data_rest_api, get_name_from_signal_id


class ConnectivityAlarmManager(Alarm):
    TYPE_ID = 1
    TRIGGERED_BY = "backend"

    # NOTE: raw_msg should have gateway_id and timestamp at the top level of json.

    def __init__(self, raw_msg, action=None):

        logging.debug(f"connectivity alarm module message ==> {raw_msg}")
        self.gateway_id = raw_msg["gateway_id"]

        logging.debug("trying to get backend state of gateway")
        # REVIEW: gateway data holds all the gateway that meets certian conditions like
        # attached to vin having a fleet with some value of climate zone is this assumption correct?
        gw_data = self.get_gateway_data(self.gateway_id)
        if gw_data is None:
            return  # this gateway is not attached to a vehicle
        self.vin = self.vin = gw_data["vin"]
        if action == "create":
            logging.debug(f"gateway created event received inside connectivity alarm manager ==> {raw_msg}")

        elif action == "heartbeat":  # the gateway heartbeat message
            # check if any open connectivity alarm for gateway
            # if yes close the alarm -> mark state as `updated`
            # if no skip

            # mark the state for this gateway as got_heartbeat (needed to persist changes)
            active_alarms = IN_MEM_DB.get_records_in_mem(
                "vehicle_alarms",
                vin=[self.vin],
                type_id=[ConnectivityAlarmManager.TYPE_ID],
                status=["1"],  # open alarms
                unique=False,  # REVIEW: is it needed?
            )

            # No open alarms for the gateway found
            IN_MEM_DB.update_records_in_mem(
                "gateway_data",
                gw_data["index"],
                data={"state": "got_heartbeat"},
            )
            if active_alarms is None:
                return
            # closing the alarm
            for a in active_alarms:
                self.update(
                    a["index"],
                    alarm_dict={
                        "status": "0",  # closing alarm
                        "closed_at": raw_msg["timestamp"],
                        "closed_by": "gateway",
                        "state": "updated" if a["state"] != "new" else "new",  # set state to updated used while persisting changes
                    },
                )

            pass

        elif action == "":
            pass

    @staticmethod
    def process():
        active_alarms_recs = IN_MEM_DB.get_records_in_mem(
            "vehicle_alarms",
            type_id=[1],
            status=["1"],  # open alarms
            unique=False,  # REVIEW: is it needed?
        )
        gw_with_heartbeats = extract_druid_data_rest_api(query=config.CONNECTIVITY_ALARM_QUERY)
        for alive_gw in gw_with_heartbeats:
            for aa in active_alarms_recs:
                if alive_gw["gateway_id"] == aa["gateway_id"]:
                    # open alarm for the gateway whose heartbeat is present so remove it
                    pass

    @staticmethod
    def persist_changes():
        # call at the end of job.
        # gateways_with_alarms = Get all_gateways(gateway_data.all()) - active_alarms(type_id=1, status=open) - heartbeat one(state=got_heartbeat)
        # gateways_with_alarms.create connectivity alarms.
        all_gws = IN_MEM_DB.get_in_mem_table("gateway_data")
        gws_with_heartbeat = all_gws[all_gws["state"] == "got_heartbeat"]
        all_alarms = IN_MEM_DB.get_in_mem_table("vehicle_alarms")
        open_connectivity_alarms = all_alarms[(all_alarms.type_id == 1) & (all_alarms.status == "1")]
        gw_no_open_alarms = all_gws[~all_gws.vin.isin(open_connectivity_alarms.vin)]
        gw_new_alarms = gw_no_open_alarms[~gw_no_open_alarms.vin.isin(gws_with_heartbeat.vin)].to_dict("records")
        for g in gw_new_alarms:
            alarm_dict = {
                "vin": g["vin"],
                "status": "1",
                "triggered_at": datetime.datetime.utcnow(),
                "triggered_by": "backend",
                "type_id": ConnectivityAlarmManager.TYPE_ID,
                "metadata": {"display_name": "Connectivity Alarm"},
            }
            IN_MEM_DB.add_records_in_mem(
                "vehicle_alarms",
                alarm_dict,
            )
        pass


if __name__ == "__main__":
    import time

    from tests import generate_message

    messages = [
        # generate_message(
        #     "Heartbeat", {"timestamp": round(time.time() * 1000)}, "testharish48b301"
        # ),
        generate_message("Heartbeat", {"timestamp": round(time.time() * 1000)}, "testharish48b302"),
        generate_message("Heartbeat", {"timestamp": round(time.time() * 1000)}, "testharish48b303"),
        generate_message("Heartbeat", {"timestamp": round(time.time() * 1000)}, "testharish48b304"),
    ]
    for m in messages:
        # ConnectivityAlarmManager(m, action="heartbeat")
        pass
    # ConnectivityAlarmManager.persist_changes()

    #  ---- TEST CONNECTIVITY ALARM-----
    GW_WITH_HEARTBEATS = extract_druid_data_rest_api(query=config.CONNECTIVITY_ALARM_QUERY)

    for gw in GW_WITH_HEARTBEATS:
        msg = {}
        msg["gateway_id"] = gw["gateway_id"]
        msg["timestamp"] = datetime.datetime.strptime(gw["__time"], "%Y-%m-%dT%H:%M:%S.%fZ")
        try:
            ConnectivityAlarmManager(msg, action="heartbeat")
        except Exception as e:
            logging.error(f"Error occured while processing connectivity alarms msg:{msg}")
            logging.exception(e)

    ConnectivityAlarmManager.persist_changes()
    IN_MEM_DB.persist_changes("vehicle_alarms")
