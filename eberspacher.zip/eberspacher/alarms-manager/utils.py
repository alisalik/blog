import json
import os

import requests

from config import get_config
from database import DatabaseState

config = get_config()


def get_can_signals_metadata():
    urls = config.GITLAB_API_ENDPOINTS
    signal_jsons = []
    for u in urls:
        headers = {"PRIVATE-TOKEN": os.environ.get("GITLAB_ACCESS_TOKEN")}
        response = requests.get(u, headers=headers)
        signal_jsons.append(json.loads(response.text))

    signals_metadata = {}

    for sj in signal_jsons:
        frames = [f for f in sj["frames"]]
        for f in frames:
            for s in f["signals"]:
                # signals hashmap id->signal_data
                signals_metadata[s.pop("id")] = s

    return signals_metadata


SIGNAL_METADATA = get_can_signals_metadata()


def get_signal(signal_id):
    global SIGNAL_METADATA
    return SIGNAL_METADATA[signal_id]


def get_name_from_signal_id(id):
    global SIGNAL_METADATA
    return SIGNAL_METADATA[id]["name"]


def extract_druid_data_rest_api(*, query: str) -> dict:
    """assumes proper value of envs are set"""
    timeout = 10
    factor = 10
    endpoint = config.DRUID_REST_API_ENDPOINT
    request_body = {"query": query}
    for count in range(5):
        try:
            response = requests.post(endpoint, headers={"content-type": "application/json"}, data=json.dumps(request_body).encode("utf-8"), timeout=timeout)
            status_code = response.status_code
            if status_code in range(200, 300):
                return response.json()
        except Exception as e:
            timeout = timeout + factor


def get_gateway_of_vin(vin: str):
    ds = DatabaseState().get_records_in_mem("gateway_data", vin=[vin])
    return ds


if __name__ == "__main__":
    gw = get_gateway_of_vin("YV3T2U820A8976")
    print(gw)
