"""module to apply color code on vehicles and depots"""

import logging

from sqlalchemy.sql import text

from database import DatabaseState

# from depot_color_code_manager import DepotColorCodeManager #FIXME

color_coding = {
    "orange": "F57A08",
    "grey": "A7AEB4",
    "green": "006B38",
    "red": "D21D26",
}


class ColorCodeManager:
    def __init__(self, stratergy="#TODO: "):
        self.vehicle_alarms_df = DatabaseState().get_in_mem_table("vehicle_alarms")
        # TODO[epic=bugfix] use below piece of code for ignoring the system generated alarms as these data values are
        # needed for some other purpose
        self.vehicle_alarms_df = self.vehicle_alarms_df[(self.vehicle_alarms_df.status == "1") & (self.vehicle_alarms_df.triggered_by != "system")]
        # self.vehicle_alarms_df = self.vehicle_alarms_df[self.vehicle_alarms_df.status == "1"]
        # sort values`                                                                                                                          `
        self.vehicle_alarms_df.sort_values(by=["vin"], inplace=True)  # sort to process same vin at a time
        self.vehicle_color_depot_df = DatabaseState().get_in_mem_table("vehicle_color_depot")
        self.depot_color_df = DatabaseState().get_in_mem_table("depot_color")
        self.company_role_df = DatabaseState().get_in_mem_table("company_role")
        # self.depot_color_code_manager = DepotColorCodeManager() #FIXME

    def vehicle_color_generate(self, vin, open_alarms, index):
        color = None
        if len(open_alarms) == 0:
            # no open alarms marks color as green
            color = "green"
        else:
            for _, row in open_alarms.iterrows():
                alarm_type_id = row["type_id"]
                # FIXME: hardcoded ids
                if alarm_type_id == 2:  # conditional alarm
                    color = "red"
                    break
                elif alarm_type_id == 1:  # connectivity alarm
                    color = "grey"
                else:
                    color = "grey" if color == "grey" else "orange"
        self.vehicle_color_depot_df.loc[index, ["color_name", "color_code", "state"]] = [
            color,
            color_coding[color],
            "updated",
        ]

    def depot_color_generator(self, depot_id, vehicles, index):
        logging.debug(f"computing color code for depot: {depot_id}")
        color = "grey"
        for _, row in vehicles.iterrows():
            vehicle_color = row["color_name"]
            # FIXME: hardcoded codes
            if vehicle_color == "red":
                color = "red"
                all_grey = False
                break
            elif vehicle_color == "orange":
                all_grey = False
                color = "orange"
            elif vehicle_color == "green" and color != "orange":
                color = "green"
        # vehicle_color = "grey" if all_grey else vehicle_color
        self.depot_color_df.loc[index, ["color_name", "color_code", "state"]] = [
            color,
            color_coding[color],
            "updated",
        ]

    def apply_color(self):
        """
        PSEUDO CODE
        for vin in all_vins:
            open_alarms = vin.open_alarms
            apply_vin_color(vin, open_alarms)
        for d in depots:
            apply_depot_color(depot, vins)
        """
        for index, row in self.vehicle_color_depot_df.iterrows():
            # NOTE: iterrows returns a copy
            vin = row["vin"]
            open_alarms = self.vehicle_alarms_df[self.vehicle_alarms_df["vin"] == vin]
            logging.debug(f"vin: {vin}, open_alarms: {open_alarms.to_string()}")
            self.vehicle_color_generate(vin, open_alarms, index)
        # self.depot_color_code_manager.compute_color() #FIXME
        # return #FIXME:
        return  # NOTE: not computing depot_color as this is generated dynamically by the API.
        for index, row in self.depot_color_df.iterrows():
            depot_id = row["id"]
            # company_
            vehicles = self.vehicle_color_depot_df[self.vehicle_color_depot_df["depo_id"] == depot_id]
            self.depot_color_generator(depot_id, vehicles, index)
        pass

    def flush_changes(self):
        # flushing updates
        connection = DatabaseState().connection
        logging.debug("flushing vehicle color changes into database")
        df = self.vehicle_color_depot_df[self.vehicle_color_depot_df["state"] == "updated"]
        statement = text("""UPDATE tbl_vehicle""" + """ tva SET color_code = :color_code, color_name = :color_name WHERE vin= :vin""")
        with connection.connect() as con:
            for vehicle in df.to_dict("records"):
                con.execute(statement, **vehicle)

        # self.depot_color_code_manager.flush_changes() #FIXME
        # return #FIXME:
        return  # NOTE: not computing depot_color as this is generated dynamically by the API.
        logging.debug("flushing depot color changes into database")
        df = self.depot_color_df[self.depot_color_df["state"] == "updated"]
        statement = text("""UPDATE tbl_depot""" + """ tva SET color_code = :color_code, color_name = :color_name WHERE id= :id""")
        with connection.connect() as con:
            for depot in df.to_dict("records"):
                con.execute(statement, **depot)


if __name__ == "__main__":
    color_manager = ColorCodeManager()
    color_manager.apply_color()
    color_manager.flush_changes()
