import datetime
import logging
import time

from dateutil.parser import parse

from alarms import IN_MEM_DB, Alarm
from config import get_config
from constants import CONDITION_ALARMS_QUERY
from database import DatabaseState
from utils import extract_druid_data_rest_api, get_name_from_signal_id

config = get_config()


class ConditionalAlarmsManager(Alarm):

    TYPE_ID = 2
    TRIGGERED_BY = "backend"

    def get_room_and_signal_name(self, signal_id):
        if signal_id in (
            13,  # Compressor1Release
            63,  # Room1ReturnAirTemp
            66,  # Room1SupplyAirTemp
            65,  # Room1SetPoint
        ):
            room = "ROOM1"
            signal_type = "returnairtemp" if signal_id == 63 else ("supplyairtemp" if signal_id == 66 else ("setpoint" if signal_id == 65 else "compressor"))

        elif signal_id in (
            20,  # Compressor2Release
            101,  # Room2ReturnAirTemp
            104,  # Room2SupplyAirTemp
            103,  # Room2SetPoint
        ):
            room = "ROOM2"
            signal_type = "returnairtemp" if signal_id == 101 else ("supplyairtemp" if signal_id == 104 else ("setpoint" if signal_id == 103 else "compressor"))

        return (room, signal_type)
        # signal_name = get_name_from_signal_id(signal_id)
        # room_name, signal_type = signal_name[:5], signal_name[5:]
        # return (room_name.upper(), signal_type.lower())  # lower or upper makes sense but both ???

    def get_latest_signal_values(self) -> list:
        try:
            signals = extract_druid_data_rest_api(query=CONDITION_ALARMS_QUERY)
        except Exception as e:
            logging.critical("not able to extract data from DRUID pls check")
            logging.exception(e)
            raise e
        try:
            for s in signals:
                s["timestamp"] = round(parse(s.pop("__time")).timestamp() * 1000)
        except Exception as e:
            pass
        return signals

    def __init__(self, signal_list: list = []):
        # process list of all the signals related to conditional alarms and create
        # dict[gateway_id] -> {"room{n}": "value"}* + {"ignition": "value"}
        if len(signal_list) == 0:
            signal_list = self.get_latest_signal_values()
        self.gateways_to_process = {}
        for signal in signal_list:
            gw_id, signal_id, value, timestamp = (signal["gateway_id"], signal["id"], signal["value"], signal["timestamp"])
            # NOTE 931- Can0Active signal currently stored against every room.
            if signal_id in (
                13,  # Compressor1Release
                63,  # Room1ReturnAirTemp
                65,  # Room1SetPoint
                66,  # Room1SupplyAirTemp
                20,  # Compressor2Release
                101,  # Room2ReturnAirTemp
                103,  # Room2SetPoint
                104,  # Room2SupplyAirTemp
            ):  # handle roomtemp signals
                room_name, signal_type = self.get_room_and_signal_name(signal_id)
                if gw_id not in self.gateways_to_process:
                    self.gateways_to_process[gw_id] = {}
                    self.gateways_to_process[gw_id][room_name] = {}
                    self.gateways_to_process[gw_id][room_name][signal_type] = {"value": value, "timestamp": timestamp}
                else:
                    if room_name not in self.gateways_to_process[gw_id]:
                        self.gateways_to_process[gw_id][room_name] = {}
                        self.gateways_to_process[gw_id][room_name][signal_type] = {"value": value, "timestamp": timestamp}
                    else:
                        self.gateways_to_process[gw_id][room_name][signal_type] = {"value": value, "timestamp": timestamp}
                try:
                    self.gateways_to_process[gw_id][room_name][signal_type] = {"value": value, "timestamp": timestamp}
                except KeyError as e:
                    pass
            elif signal_id == 32:  # ignition signal
                if gw_id not in self.gateways_to_process:
                    self.gateways_to_process[gw_id] = {}
                    self.gateways_to_process[gw_id]["IGNITION"] = signal  # storing ignition signal
                else:
                    self.gateways_to_process[gw_id]["IGNITION"] = signal
            elif signal_id == 931:  # can0_active signal
                if gw_id not in self.gateways_to_process:
                    self.gateways_to_process[gw_id] = {}
                    self.gateways_to_process[gw_id]["CAN_0_ACTIVE"] = signal  # storing can_0_active signal
                else:
                    self.gateways_to_process[gw_id]["CAN_0_ACTIVE"] = signal
        for gw in self.gateways_to_process:
            for k in self.gateways_to_process[gw].keys():
                if k == "ROOM1" or k == "ROOM2":
                    self.gateways_to_process[gw][k]["is_cooling"] = None
                    try:
                        if self.gateways_to_process[gw][k]["returnairtemp"]["value"] > self.gateways_to_process[gw]["ROOM1"]["setpoint"]["value"]:
                            self.gateways_to_process[gw][k]["is_cooling"] = True
                        else:
                            self.gateways_to_process[gw][k]["is_cooling"] = False
                    except Exception as err:
                        pass  # maybe a key error -returnairtemp, setpoint doesn't exists maybe.

        # self.gateways_to_process
        # signals to consider for conditional alarms

        self.delta_t_threshold = 7

    def delta_t_calculation(self):
        self.alarms_to_be_generated = []
        for gw, params in self.gateways_to_process.items():
            if "CAN_0_ACTIVE" not in params:
                logging.warning(f"CAN0_Active value not present in the system! dropping condition alarm for gw:{gw}")
                continue
            else:
                can_0_active_signal = params["CAN_0_ACTIVE"]
                if not bool(can_0_active_signal["value"]):  #  gw not connected to econtrol
                    logging.warning(f"Gw not connected to CAN not calculating condition alarm for gw:{gw}")
                    continue
                else:  # gw connected to can
                    can_0_active_ts_sec = round(can_0_active_signal["timestamp"] / 1000)
                    cur_ts_sec = round(time.time())
                    threshold_sec = config.ALARMS_CONDITIONAL_IGNITION_OFFSET_MINS * 60
                    if cur_ts_sec - can_0_active_ts_sec < threshold_sec:  # desired time has not passed since last can_o_active on
                        logging.warning(
                            f"Not enough time passed {config.ALARMS_CONDITIONAL_IGNITION_OFFSET_MINS} since can_0active signal is on so not calculating condition alarm for gw:{gw}"
                        )
                        continue
            for name, values in params.items():
                # to get the vin we use gateway_data in-mem table.
                gw_data = IN_MEM_DB.get_records_in_mem("gateway_data", gateway_id=[gw], unique=True)
                if gw_data is None:
                    logging.warning(f"gw:{gw} is not attached to any VIN")
                    continue
                vin = gw_data["vin"]
                if name.startswith("ROOM"):  # TODO regx probably
                    # conditional alarms against the vin for specific room.
                    existing_alarm = IN_MEM_DB.get_records_in_mem(
                        "vehicle_alarms",
                        type_id=[2],
                        metadata=[{"for": name}],
                        vin=[vin],
                        status=["1"],
                    )
                    if existing_alarm is not None:
                        logging.info(f"conditional alarm already exists: {gw}:{params}")
                        logging.info(f"alarm is->{existing_alarm}")
                        continue
                    try:
                        if values["supplyairtemp"]["timestamp"] < params["CAN_0_ACTIVE"]["timestamp"] or values["returnairtemp"]["timestamp"] < params["CAN_0_ACTIVE"]["timestamp"]:
                            logging.error("room temperature's timestamp older than CAN_0_ACTIVE ON timestamp this shouldn't have happened! check with firmware team")
                            continue
                        elif values["compressor"]["timestamp"] < params["CAN_0_ACTIVE"]["timestamp"]:
                            logging.debug(f"compressor's timestamp older than CAN_0_ACTIVE ON timestamp this shouldn't have happened! check with firmware team: {gw}")
                            continue
                        elif values["setpoint"]["timestamp"] < params["CAN_0_ACTIVE"]["timestamp"]:
                            logging.debug(f"setpoint's timestamp older than CAN_0_ACTIVE ON timestamp this shouldn't have happened! check with firmware team: {gw}")
                            continue
                        elif not bool(values["compressor"]["value"]):  # compressor should be on for alarms to be generated
                            logging.debug(f"compressor is off for room: {name} not calcuating conditional alarm for {gw}")
                            continue
                        elif values["is_cooling"] is False:
                            logging.debug(f"not cooling {gw}, so not calculating conditional alarm")
                            continue
                        delta = values["returnairtemp"]["value"] - values["supplyairtemp"]["value"]
                    except KeyError as key:
                        logging.debug(f"{key.args} not present!")
                        logging.debug(f"gateway:{gw}: name:{name} values: {values}")
                        continue
                    # delta = delta * (-1) if delta < 0 else delta
                    if 0 < delta <= 7.5:
                        logging.debug("delta t condition satisfted for below")
                        logging.debug(f"gateway:{gw}: name:{name} values: {values}")
                        # self.alarms_to_be_generated.append({gw: {name: values | {"delta": delta}}})
                        self.alarms_to_be_generated.append({"gateway_id": gw, "type": "delta_t", "room": name, "delta": delta} | values | {"can_0_active": params["CAN_0_ACTIVE"]})

    def push_to_df(self):
        for a in self.alarms_to_be_generated:
            gw_id = a["gateway_id"]
            gw_data = self.get_gateway_data(gw_id)
            if gw_data is None:
                continue  # gateway not attached to vin
            if a["type"] == "delta_t":
                metadata = {
                    "display_name": f"{a['room']}:{a['delta']}(cooling)",
                    "for": a["room"],
                    "return_air_temp": a["returnairtemp"]["value"],
                    "return_air_temp_timestamp": a["returnairtemp"]["timestamp"],
                    "supply_air_temp": a["supplyairtemp"]["value"],
                    "supply_air_temp_timestamp": a["supplyairtemp"]["timestamp"],
                    "can_0_active_timestamp": a["can_0_active"]["timestamp"],
                    "can_0_active_value": a["can_0_active"]["value"],
                    "setpoint_value": a["setpoint"]["value"],
                    "setpoint_timestamp": a["setpoint"]["timestamp"],
                    "compressor_value": a["compressor"]["value"],
                    "compressor_timestamp": a["compressor"]["timestamp"],
                }
            alarm_dict = {
                "vin": gw_data["vin"],
                "type_id": self.__class__.TYPE_ID,
                "status": "1",
                "triggered_by": self.__class__.TRIGGERED_BY,
                "triggered_at": datetime.datetime.utcnow(),
                "metadata": metadata,  # FIXME: hardcoded
            }
            self.create(alarm_dict=alarm_dict)


if __name__ == "__main__":
    cur_ts = round(time.time() * 1000)
    signals = [
        {"timestamp": cur_ts, "value": 1.0, "id": 13, "gateway_id": "02091994adbdcd11"},  # r1_compressorrelease
        {"timestamp": cur_ts, "value": 15.820000, "id": 63, "gateway_id": "02091994adbdcd11"},  # r1_retrurnairtemp
        {"timestamp": cur_ts, "value": 10.0, "id": 66, "gateway_id": "02091994adbdcd11"},  # r1_supplyairtemp
        {"timestamp": 1686569310000, "value": 10.0, "id": 65, "gateway_id": "02091994adbdcd11"},  # r1_setpoint
        {"timestamp": cur_ts, "value": 1.0, "id": 20, "gateway_id": "02091994adbdcd11"},  # r2_compressorrelease
        {"timestamp": cur_ts, "value": 15.0, "id": 101, "gateway_id": "02091994adbdcd11"},  # r2_returnairtemp
        {"timestamp": cur_ts, "value": 10.0, "id": 104, "gateway_id": "02091994adbdcd11"},  # r2_supplyairtemp
        {"timestamp": cur_ts, "value": 20.0, "id": 103, "gateway_id": "02091994adbdcd11"},  # r2_setpoint
        {"timestamp": 1686569311000, "value": 1.0, "id": 931, "gateway_id": "02091994adbdcd11"},  # can_0_active
    ]
    parsed_signals = {
        "323244323": {
            "ROOM1": {"supplyairtemp": {"value": 321, "timestamp": 1662755868152}},
            "ROOM2": {"returnairtemp": {"value": 322, "timestamp": 1662755868152}, "supplyairtemp": {"value": 321, "timestamp": 1662755868152}},
        },
        "323244399": {
            "ROOM1": {"returnairtemp": 10, "supplyairtemp": 50},
            "ROOM2": {"returnairtemp": 50, "supplyairtemp": 100},
        },
        "0921a1d75d48b311": {
            "ROOM1": {"returnairtemp": 10, "supplyairtemp": 50, "compressorrelease": 1, "setpoint": 23, "state": "cooling", "can_0_active": 1},
            "ROOM2": {"returnairtemp": 50, "supplyairtemp": 100, "comporessorrelase": 0, "setpoint": 32, "state": "heating", "can_0_active": 0},
        },
    }

    import pprint

    ca = ConditionalAlarmsManager(signal_list=signals)
    # ca = ConditionalAlarmsManager()

    # ca = ConditionalAlarmsManager()
    # ca.get_latest_signal_values()
    pprint.pprint(ca.gateways_to_process)
    ca.delta_t_calculation()

    pprint.pprint(ca.alarms_to_be_generated)
    ca.push_to_df()
    IN_MEM_DB.persist_changes("vehicle_alarms")
    pass
    pass
