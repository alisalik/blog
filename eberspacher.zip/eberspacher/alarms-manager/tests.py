message_templates = {
    "DA": {
        "timestamp": 1662755869152,
        # "id": 10,
        "alarm_event": {
            "signal_id": 8,
            "alarm_id": 35,
            "device": "can0",
            "cause": "MISSING_SIGNAL_VALUES",
            "alarm_created": 1668084846741,
            "alarm_cleared": 0,
            "value_last_updated": 1668084746762,
            "time_accumulation_trigger": "SIGNAL_IGNITION_ON",
            "cleared": False,
        },
        "gateway_id": "5d48b311042fa1d7",
    },
    "PA": {
        "timestamp": 1662755869152,
        "id": 930,
        "gateway_id": "5d48b311042fa1d7",
    },
    "Heartbeat": {"gateway_id": "5d48b311042fa1d7", "timestamp": 1662755869152},
}

import copy


def generate_message(msg_code, value, gw_id):
    msg = copy.deepcopy(message_templates[msg_code])
    for (k, v) in value.items():
        if isinstance(v, dict):
            for (p, q) in v.items():
                msg[k][p] = q
        else:
            msg[k] = v
    msg["gateway_id"] = gw_id
    return msg
