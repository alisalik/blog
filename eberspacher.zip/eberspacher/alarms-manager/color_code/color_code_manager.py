from database import DatabaseState


class DepotColorCodeManager:
    def __init__(self):
        """fill local objects"""
        self.datasets = {
            "vehicle_color_depot": DatabaseState().get_in_mem_table("vehicle_color_depot"),
            "company_role": DatabaseState().get_in_mem_table("company_role"),
        }


if __name__ == "__main__":
    manager = DepotColorCodeManager()
    pass
