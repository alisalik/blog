# config.py
import logging
from os import environ

from dotenv import load_dotenv

ENV = environ.get("ENV")

if environ.get("ENV_FILE_PATH"):
    # read env var from file
    load_dotenv(environ.get("ENV_FILE_PATH"))

if environ.get("ONLY_GATEWAYS"):
    GATEWAY_FILTERS = environ.get("ONLY_GATEWAYS").split(",")
else:
    GATEWAY_FILTERS = []

if environ.get("LOGGING_LEVEL") == "DEBUG":
    logging.basicConfig(level=logging.DEBUG)


class BaseConfig:

    GITLAB_ACCESS_TOKEN = environ.get("GITLAB_ACCESS_TOKEN")
    GITLAB_API_ENDPOINTS = [
        "https://code.orahi.com:8929/api/v4/projects/468/repository/files/etc%2Feberspacher%2Fdefault_prod%2Fcan0_signals.json/raw?ref=master",
        "https://code.orahi.com:8929/api/v4/projects/468/repository/files/etc%2Feberspacher%2Fdefault_prod%2Fcan1_signals.json/raw?ref=master",
    ]

    MYSQL_HOSTNAME = environ.get("MYSQL_HOSTNAME")
    MYSQL_PORT = int(environ.get("MYSQL_PORT"))
    MYSQL_USERNAME = environ.get("MYSQL_USERNAME")
    MYSQL_PASSWORD = environ.get("MYSQL_PASSWORD")
    MYSQL_DBNAME = environ.get("MYSQL_DBNAME")

    MYSQL_DB_URI = ("mysql+pymysql://{username}:{password}@{hostname}:{port}/{dbname}").format(
        username=MYSQL_USERNAME,
        password=MYSQL_PASSWORD,
        hostname=MYSQL_HOSTNAME,
        port=MYSQL_PORT,
        dbname=MYSQL_DBNAME,
    )

    KAFKA_CONSUMER_TOPICS = environ.get("KAFKA_COMSUME_TOPICS")
    KAFKA_BOOTSTRAP_SERVER = environ.get("KAFKA_BOOTSTRAP_SERVER")
    KAFKA_USERNAME = environ.get("KAFKA_USERNAME")
    KAFKA_PASSWORD = environ.get("KAFKA_PASSWORD")
    LOGGING_LEVEL = environ.get("LOGGING_LEVEL")
    # constants
    KAFKA_SASL_MECHANISM = "SCRAM-SHA-512"
    KAFKA_AUTO_OFFSET_RESET = "earliest"
    KAFKA_ENABLE_AUTO_COMMIT = True
    KAFKA_SECURITY_PROTOCOL = environ.get("KAFKA_SECURITY_PROTOCOL", "SASL_SSL")

    ALARMS_CONDITIONAL_IGNITION_OFFSET_MINS = int(environ.get("ALARMS_CONDITIONAL_IGNITION_OFFSET", "30"))

    DRUID_REST_API_ENDPOINT = environ.get("DRUID_REST_API_ENDPOINT", "https://druid.dev.orahi.com/druid/v2/sql/")

    SILENT_CONNECTIVITY_ALARM = int(environ.get("SILENT_CONNECTIVITY_ALARM", "0"))
    SILENT_CONDITIONAL_ALARM = int(environ.get("SILENT_CONDITIONAL_ALARM", "0"))
    CONNECTIVITY_ALARM_QUERY = """select * from eber_gateways_sensors_data where (id,__time )in( SELECT LATEST(id),MAX(__time) 
    FROM eber_gateways_sensors_data WHERE id in (-1) and __time  > CURRENT_TIMESTAMP - INTERVAL '60' SECOND GROUP BY gateway_id, id)"""

    def get_kafka_config_dict(self):
        return {
            "bootstrap_servers": BaseConfig.KAFKA_BOOTSTRAP_SERVER,
            "auto_offset_reset": BaseConfig.KAFKA_AUTO_OFFSET_RESET,
            "enable_auto_commit": BaseConfig.KAFKA_ENABLE_AUTO_COMMIT,
            "security_protocol": BaseConfig.KAFKA_SECURITY_PROTOCOL,
            "sasl_plain_username": BaseConfig.KAFKA_USERNAME,
            "sasl_plain_password": BaseConfig.KAFKA_PASSWORD,
            "sasl_mechanism": BaseConfig.KAFKA_SASL_MECHANISM,
        }


class LocalConfig(BaseConfig):
    CONNECTIVITY_ALARM_QUERY = """select * from eber_gateways_sensors_data where (id,__time )in( SELECT LATEST(id),MAX(__time) 
    FROM eber_gateways_sensors_data WHERE id in (-1) and __time  > CURRENT_TIMESTAMP - INTERVAL '24' HOUR GROUP BY gateway_id, id)"""


class DevelopmentConfig(BaseConfig):
    CONNECTIVITY_ALARM_QUERY = """select * from eber_gateways_sensors_data where (id,__time )in( SELECT LATEST(id),MAX(__time) 
    FROM eber_gateways_sensors_data WHERE id in (-1) and __time  > CURRENT_TIMESTAMP - INTERVAL '24' HOUR GROUP BY gateway_id, id)"""


class ProductionConfig(BaseConfig):
    CONNECTIVITY_ALARM_QUERY = """select * from eber_gateways_sensors_data where (id,__time )in( SELECT LATEST(id),MAX(__time) 
    FROM eber_gateways_sensors_data WHERE id in (-1) and __time  > CURRENT_TIMESTAMP - INTERVAL '24' HOUR GROUP BY gateway_id, id)"""


class QCConfig(BaseConfig):
    CONNECTIVITY_ALARM_QUERY = """select * from eber_gateways_sensors_data where (id,__time )in( SELECT LATEST(id),MAX(__time) 
    FROM eber_gateways_sensors_data WHERE id in (-1) and __time  > CURRENT_TIMESTAMP - INTERVAL '24' HOUR GROUP BY gateway_id, id)"""


config = {
    "development": DevelopmentConfig,
    "production": ProductionConfig,
    "default": DevelopmentConfig,
}


def get_config():
    def dump(obj):
        for attr in dir(obj):
            print("obj.%s = %r" % (attr, getattr(obj, attr)))

    config = None
    if ENV == "DEV":
        config = DevelopmentConfig()
    elif ENV == "LOCAL":
        config = LocalConfig()
    elif ENV == "PROD":
        config = ProductionConfig()
    elif ENV == "QC":
        config = QCConfig()
    else:
        raise ValueError(f"Invalid value of ENV:{ENV}")
    # logging.info("running with below configuraitons")
    # logging.info(dump(config))
    return config
