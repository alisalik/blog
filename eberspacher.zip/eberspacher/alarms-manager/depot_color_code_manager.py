import logging

from sqlalchemy.sql import text

from constants import color_coding, role_with_vehicle_mapping
from database import DatabaseState


class DepotColorCodeManager:
    def __init__(self):
        """fill local objects"""
        self.datasets = {
            "vehicle_color_depot": DatabaseState().get_in_mem_table("vehicle_color_depot"),
            "company_role": DatabaseState().get_in_mem_table("company_role"),
            "company_wise_depot_color": DatabaseState().get_in_mem_table("company_wise_depot_color"),
        }

    def get_depot_vehicle_based_on_role(self, depot_id: int = 0, lookup_column: str = "", company_id: int = 0) -> list:
        df = self.datasets["vehicle_color_depot"]
        if lookup_column == "admin":  # name exception for admin
            return df[df.depo_id == depot_id]
        elif lookup_column == "pta_id":
            return df[(df.depo_id == depot_id) & (df.pta_id == company_id)]
        elif lookup_column == "pto_id":
            return df[(df.depo_id == depot_id) & (df.pto_id == company_id)]
        elif lookup_column == "service_provider_id":
            return df[(df.depo_id == depot_id) & (df.service_provider_id == company_id)]

    def depot_color_generator(self, depot_id: int = 0, vehicles=None) -> str:
        color = "grey"
        for _, row in vehicles.iterrows():
            vehicle_color = row["color_name"]
            # FIXME: hardcoded codes
            if vehicle_color == "red":
                color = "red"
                all_grey = False
                break
            elif vehicle_color == "orange":
                all_grey = False
                color = "orange"
            elif vehicle_color == "green" and color != "orange":
                color = "green"

        return color

    def compute_color(self):  # computre color for all the depots
        depots = set(self.datasets["vehicle_color_depot"]["depo_id"].tolist())  # get unique depots
        depot_color_df = self.datasets["company_wise_depot_color"]
        for d in depots:
            for _, row in self.datasets["company_role"].iterrows():
                company_id, role, role_id = row["company_id"], row["role"], row["role_id"]
                vehicles = self.get_depot_vehicle_based_on_role(
                    depot_id=d,
                    lookup_column=role_with_vehicle_mapping[role],
                    company_id=company_id,
                )
                if not vehicles.empty:
                    logging.debug(f"computing color code for depot:{d}, company:{company_id}, role:{role}")
                    color = self.depot_color_generator(depot_id=d, vehicles=vehicles)
                    color_row = depot_color_df.loc[
                        (depot_color_df["depot_id"] == d) & (depot_color_df["company_role_id"] == role_id) & (depot_color_df["company_id"] == company_id)
                    ]
                    if not color_row.empty:  # update company_wise_depot_color
                        depot_color_df.loc[
                            (depot_color_df["depot_id"] == d) & (depot_color_df["company_role_id"] == role_id) & (depot_color_df["company_id"] == company_id),
                            ["state", "color_name", "color_code"],
                        ] = ["updated", color, color_coding[color]]
                    else:  # new record
                        self.datasets["company_wise_depot_color"] = self.datasets["company_wise_depot_color"].append(
                            {
                                "depot_id": d,
                                "company_role_id": role_id,
                                "company_id": company_id,
                                "color_name": color,
                                "color_code": color_coding[color],
                                "state": "new",
                            },
                            ignore_index=True,
                        )
        pass

    def flush_changes(self):
        # flushing updates
        df = self.datasets["company_wise_depot_color"]
        connection = DatabaseState().connection
        logging.debug("flushing depot color changes into database")
        update_df = df[df["state"] == "updated"]
        statement = text(
            """UPDATE tbl_depot_color"""
            + """ tva SET color_code = :color_code, color_name = :color_name WHERE depot_id= :depot_id and company_id= :company_id and company_role_id=:company_role_id"""
        )
        with connection.connect() as con:
            for depot_color in update_df.to_dict("records"):
                con.execute(statement, **depot_color)

        logging.debug("flushing depot color changes into database")
        create_df = df[df["state"] == "new"]
        req_columns = [c for c in list(df.columns) if c not in ["id", "state"]]

        create_df[req_columns].to_sql(
            con=DatabaseState().connection,
            name="tbl_depot_color",
            if_exists="append",
            chunksize=5,
            index=False,
            # flavor="mysql",
        )


if __name__ == "__main__":
    manager = DepotColorCodeManager()
    manager.compute_color()
    manager.flush_changes()
    pass
