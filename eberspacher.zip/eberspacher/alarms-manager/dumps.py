self._topic_partitions = []
for topic in config.KAFKA_COMSUME_TOPICS.split(","):
    for p in self._consumer.partitions_for_topic(topic):
        self._topic_partitions.append(TopicPartition(topic, p))
self._end_offsets = self._consumer.end_offsets(self._topic_partitions)
self._topic_partition_endoffset_lookup = {}

for topic, offset in self._end_offsets.items():
    topic_name, partition_name = topic[0], str(topic[1])
    if topic_name in last_run_config:
        if partition_name in last_run_config[topic_name]:
            # consumer should start from where last run stopped.
            self._consumer.seek(topic, last_run_config[topic_name][partition_name])
    if topic_name not in self._topic_partition_endoffset_lookup:
        self._topic_partition_endoffset_lookup[topic_name] = {}
    self._topic_partition_endoffset_lookup[topic_name][partition_name] = offset
