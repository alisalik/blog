import datetime
import logging
import time

from dateutil.parser import parse

from alarms import IN_MEM_DB, Alarm
from config import get_config
from constants import CONDITION_ALARMS_QUERY
from database import DatabaseState
from utils import extract_druid_data_rest_api, get_name_from_signal_id

config = get_config()


class ConditionalAlarmsManager(Alarm):

    TYPE_ID = 2
    TRIGGERED_BY = "backend"

    def get_room_and_signal_name(self, signal_id):
        signal_name = get_name_from_signal_id(signal_id)
        room_name, signal_type = signal_name[:5], signal_name[5:]
        return (room_name.upper(), signal_type.lower())  # lower or upper makes sense but both ???

    def get_latest_signal_values(self) -> list:
        try:
            signals = extract_druid_data_rest_api(query=CONDITION_ALARMS_QUERY)
        except Exception as e:
            logging.critical("not able to extract data from DRUID pls check")
            logging.exception(e)
            raise e
        try:
            for s in signals:
                s["timestamp"] = round(parse(s.pop("__time")).timestamp() * 1000)
        except Exception as e:
            pass
        return signals

    def __init__(self, signal_list: list = []):
        # process list of all the signals related to conditional alarms and create
        # dict[gateway_id] -> {"room{n}": "value"}* + {"ignition": "value"}
        if len(signal_list) == 0:
            signal_list = self.get_latest_signal_values()
        self.gateways_to_process = {}
        for signal in signal_list:
            gw_id, signal_id, value, timestamp = (signal["gateway_id"], signal["id"], signal["value"], signal["timestamp"])
            if signal_id in (63, 101, 66, 104):  # handle roomtemp signals
                room_name, signal_type = self.get_room_and_signal_name(signal_id)
                if gw_id not in self.gateways_to_process:
                    self.gateways_to_process[gw_id] = {}
                    self.gateways_to_process[gw_id][room_name] = {}
                    self.gateways_to_process[gw_id][room_name][signal_type] = {"value": value, "timestamp": timestamp}
                else:
                    if room_name not in self.gateways_to_process[gw_id]:
                        self.gateways_to_process[gw_id][room_name] = {}
                        self.gateways_to_process[gw_id][room_name][signal_type] = {"value": value, "timestamp": timestamp}
                    else:
                        self.gateways_to_process[gw_id][room_name][signal_type] = {"value": value, "timestamp": timestamp}
                try:
                    self.gateways_to_process[gw_id][room_name][signal_type] = {"value": value, "timestamp": timestamp}
                except KeyError as e:
                    pass
            elif signal_id == 32:  # ignition signal
                if gw_id not in self.gateways_to_process:
                    self.gateways_to_process[gw_id] = {}
                    self.gateways_to_process[gw_id]["IGNITION"] = signal  # storing ignition signal
                else:
                    self.gateways_to_process[gw_id]["IGNITION"] = signal

        # self.gateways_to_process
        # signals to consider for conditional alarms

        self.delta_t_threshold = 7

    def delta_t_calculation(self):
        self.alarms_to_be_generated = []
        for gw, params in self.gateways_to_process.items():
            if "IGNITION" not in params:
                logging.warning(f"Ignition value not present in the system! dropping condition alarm for gw:{gw}")
                continue
            else:
                ignition_signal = params["IGNITION"]
                if not bool(ignition_signal["value"]):  #  ignition if off &convert float value to boolean 0.0 -> False else True
                    logging.warning(f"Ignition is off not calculating condition alarm for gw:{gw}")
                    continue
                else:  # ignition is on
                    ignition_ts_sec = round(ignition_signal["timestamp"] / 1000)
                    cur_ts_sec = round(time.time())
                    threshold_sec = config.ALARMS_CONDITIONAL_IGNITION_OFFSET_MINS * 60
                    if cur_ts_sec - ignition_ts_sec < threshold_sec:  # desired time has not passed since last ignition on
                        logging.warning(f"Not enough time passed {config.ALARMS_CONDITIONAL_IGNITION_OFFSET_MINS} since ignition on so not calculating condition alarm for gw:{gw}")
                        continue
            for name, values in params.items():
                # to get the vin we use gateway_data in-mem table.
                gw_data = IN_MEM_DB.get_records_in_mem("gateway_data", gateway_id=[gw], unique=True)
                if gw_data is None:
                    logging.warning(f"gw:{gw} is not attached to any VIN")
                    continue
                vin = gw_data["vin"]
                if name.startswith("ROOM"):  # TODO regx probably
                    # conditional alarms against the vin for specific room.
                    existing_alarm = IN_MEM_DB.get_records_in_mem(
                        "vehicle_alarms",
                        type_id=[2],
                        metadata=[{"for": name}],
                        vin=[vin],
                        status=["1"],
                    )
                    if existing_alarm is not None:
                        logging.info(f"conditional alarm already exists: {gw}:{params}")
                        logging.info(f"alarm is->{existing_alarm}")
                        continue
                    try:
                        if values["supplyairtemp"]["timestamp"] < params["IGNITION"]["timestamp"] or values["returnairtemp"]["timestamp"] < params["IGNITION"]["timestamp"]:
                            logging.error("room temperature's timestamp older than IGINITION ON timestamp this shouldn't have happened! check with firmware team")
                            continue
                        delta = values["returnairtemp"]["value"] - values["supplyairtemp"]["value"]
                    except KeyError as key:
                        logging.debug(f"{key.args} not present!")
                        logging.debug(f"gateway:{gw}: name:{name} values: {values}")
                        continue
                    # delta = delta * (-1) if delta < 0 else delta
                    if 0 < delta <= 7.5:
                        logging.debug("delta t condition satisfted for below")
                        logging.debug(f"gateway:{gw}: name:{name} values: {values}")
                        # self.alarms_to_be_generated.append({gw: {name: values | {"delta": delta}}})
                        self.alarms_to_be_generated.append({"gateway_id": gw, "type": "delta_t", "room": name, "delta": delta} | values | {"ignition": params["IGNITION"]})

    def push_to_df(self):
        for a in self.alarms_to_be_generated:
            gw_id = a["gateway_id"]
            gw_data = self.get_gateway_data(gw_id)
            if gw_data is None:
                continue  # gateway not attached to vin
            if a["type"] == "delta_t":
                metadata = {
                    "display_name": f"{a['room']}:{a['delta']}",
                    "for": a["room"],
                    "return_air_temp": a["returnairtemp"]["value"],
                    "return_air_temp_timestamp": a["returnairtemp"]["timestamp"],
                    "supply_air_temp": a["supplyairtemp"]["value"],
                    "supply_air_temp_timestamp": a["supplyairtemp"]["timestamp"],
                    "ignition_timestamp": a["ignition"]["timestamp"],
                    "ignition_value": a["ignition"]["value"],
                }
            alarm_dict = {
                "vin": gw_data["vin"],
                "type_id": self.__class__.TYPE_ID,
                "status": "1",
                "triggered_by": self.__class__.TRIGGERED_BY,
                "triggered_at": datetime.datetime.utcnow(),
                "metadata": metadata,  # FIXME: hardcoded
            }
            self.create(alarm_dict=alarm_dict)


if __name__ == "__main__":
    signals = [
        # {"timestamp": 1662755869152, "value": 25.820000, "id": 63, "gateway_id": 323244323},  # r1_returnairtemp
        {"timestamp": 1670980846000, "value": 15.820000, "id": 63, "gateway_id": "0921a1d75d48b311"},  # r1_retrurnairtemp
        {"timestamp": 1670980846000, "value": 10.0, "id": 66, "gateway_id": "0921a1d75d48b311"},  # r1_supplyairtemp
        # {"timestamp": 1670177016000, "value": 321.00, "id": 66, "gateway_id": "0921a1d75d48b311"},  # r1_supplyairtemp
        {"timestamp": 1670980846000, "value": 15.0, "id": 101, "gateway_id": "0921a1d75d48b311"},  # r2_returnairtemp
        {"timestamp": 1670980846000, "value": 10.0, "id": 104, "gateway_id": "0921a1d75d48b311"},  # r2_supplyairtemp
        # {"timestamp": 1670177016000, "value": 50.00, "id": 66, "gateway_id": "0921a1d75d48b311"},  # r1_supplyairtemp
        # {"timestamp": 1670177016000, "value": 50.820000, "id": 101, "gateway_id": "0921a1d75d48b311"},  # r2_returnairtemp
        # {"timestamp": 1670177016000, "value": 150.810000, "id": 104, "gateway_id": "0921a1d75d48b311"},  # r2_supplyairtemp
        # {"timestamp": 1670177016000, "value": 999.00, "id": 66, "gateway_id": "0921a1d75d48b311"},  # r1_supplyairtemp
        {"timestamp": 1670980846000 - 1800001, "value": 1.0, "id": 32, "gateway_id": "0921a1d75d48b311"},  # ignition_on
    ]
    parsed_signals = {
        "323244323": {
            "ROOM1": {"supplyairtemp": {"value": 321, "timestamp": 1662755868152}},
            "ROOM2": {"returnairtemp": {"value": 322, "timestamp": 1662755868152}, "supplyairtemp": {"value": 321, "timestamp": 1662755868152}},
        },
        "323244399": {
            "ROOM1": {"returnairtemp": 10, "supplyairtemp": 50},
            "ROOM2": {"returnairtemp": 50, "supplyairtemp": 100},
        },
    }

    import pprint

    ca = ConditionalAlarmsManager(signal_list=signals)
    # ca = ConditionalAlarmsManager()
    # ca.get_latest_signal_values()
    pprint.pprint(ca.gateways_to_process)
    ca.delta_t_calculation()

    pprint.pprint(ca.alarms_to_be_generated)
    ca.push_to_df()
    # IN_MEM_DB.persist_changes("vehicle_alarms")
    pass
    pass
