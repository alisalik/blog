import logging
import os
import sys
import time
from os import environ

from config import get_config
from utils import extract_druid_data_rest_api, get_name_from_signal_id

config = get_config()

if environ.get("CHECK_ALREADY_REGISTERED", "1") == "1":
    if os.path.isfile("already_running"):
        logging.info("previous job already running so skipping the task")
        sys.exit(0)
    else:
        open("already_running", "x").close()

import datetime
import json
import traceback

from alarms import IN_MEM_DB, PreventiveAlarm
from color_code_manager import ColorCodeManager
from conditional_alarms import ConditionalAlarmsManager
from connectivity_alarm import ConnectivityAlarmManager
from database import DatabaseState
from kafka_consumer import LATEST_HEARTBEAT_MESSAGES, LATEST_OPERATING_MESSAGE, Consumer, conditional_alarms_related_signals

if environ.get("SLEEP_MODE") == "1":
    logging.debug("in sleep mode not running the script")
    sys.exit(0)


def launch():
    # silent kafka log messages
    kafka_logger = logging.getLogger("kafka")
    kafka_logger.setLevel(logging.ERROR)

    start_time = datetime.datetime.utcnow()

    last_run_record = IN_MEM_DB.get_last_job_run_record()
    logging.debug(f"last run stats {last_run_record}")

    if last_run_record["status"] != "success" and last_run_record != []:
        """what is the status of last run"""
        logging.info("last job was not successfull pls run last flow")
        logging.info(last_run_record)
        sys.exit(0)

    end_offsets = {"eberspacher-gateway-sensor-data-dev": {"0": 79781, "1": 79589, "2": 79672}}

    c = Consumer(
        last_run_record["kafka_end_offset"],
    )
    c.batch_consume()  # read back of files
    print("--------------------------------------operating hours processing--------------------------")
    logging.info("OPERATING HOUR MESSAGES TO PROCESS")
    logging.info(LATEST_OPERATING_MESSAGE)
    for gw_id, msg in LATEST_OPERATING_MESSAGE.items():
        try:
            PreventiveAlarm(msg)
            logging.debug("recieved signal 930 from kafka")
        except Exception as e:
            logging.error(f"Error occured while processing operarting hours msg:{msg}")
            error_type, error_instance, traceback = sys.exc_info()
            logging.exception(e)
    print("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx-operating hours processingxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx")

    print("--------------------------------------time period processing--------------------------")
    gw_records = IN_MEM_DB.get_records_in_mem("gateway_data", unique=False)
    days_since_reference = int(time.time() / 86400)  # following epoch standart ie. 01Jan1970 00:00:00 UTC
    for gw in gw_records:
        try:
            gw_id = gw["gateway_id"]
            msg = {"gateway_id": gw_id, "time_period_days": days_since_reference}
            PreventiveAlarm(msg, mode="time_period_days")
        except ValueError as val_err:
            logging.info("not confiugred for time period maintainence")
        except Exception as err:
            logging.error(f"Error occured while processing preventive alarm message {msg} ")
            error_type, error_instance, traceback = sys.exc_info()
            logging.exception(err)
    print("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx-time period processingxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx")

    #  ------------------------------ CONNECTIVITY ALARM PROCESSING_----------------------
    print("--------------------------------------connectivity alarm processing--------------------------")

    print(f"query is {config.CONNECTIVITY_ALARM_QUERY}")
    if config.SILENT_CONNECTIVITY_ALARM == 0:
        GW_WITH_HEARTBEATS = extract_druid_data_rest_api(query=config.CONNECTIVITY_ALARM_QUERY)
        for gw in GW_WITH_HEARTBEATS:
            msg = {}
            msg["gateway_id"] = gw["gateway_id"]
            msg["timestamp"] = datetime.datetime.strptime(gw["__time"], "%Y-%m-%dT%H:%M:%S.%fZ")
            try:
                ConnectivityAlarmManager(msg, action="heartbeat")
            except Exception as e:
                logging.error(f"Error occured while processing connectivity alarms msg:{msg}")
                logging.exception(e)

        ConnectivityAlarmManager.persist_changes()
    else:
        logging.info("connectivity alarm logic is silenced!")
    print("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx-connectivity alarm processing xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx")

    # ---------------------------------------------------------------------------------------
    print("--------------------------------------conditional alarm processing--------------------------")
    # if config.SILENT_CONDITIONAL_ALARM == 0:
    if False:
        ca = ConditionalAlarmsManager()
        ca.delta_t_calculation()
        ca.push_to_df()
    else:
        logging.info("conditional alarm logic is silenced!")
    print("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx conditional alarm processingxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx")
    IN_MEM_DB.persist_changes("vehicle_alarms")

    color_manager = ColorCodeManager()
    color_manager.apply_color()
    IN_MEM_DB.add_records_in_mem(
        "vehicle_alarm_job_history",
        data={
            "status": "success",
            "start_time": start_time,
            "finish_time": datetime.datetime.utcnow(),
            "kafka_end_offset": c._topic_partition_endoffset_lookup,
            "state": "new",
        },
    )
    # IN_MEM_DB.persist_changes("vehicle_alarms")

    logging.info("job finished logging the state in the job tracking table!")
    IN_MEM_DB.persist_changes("vehicle_alarm_job_history")
    color_manager.flush_changes()


try:
    launch()
except Exception as e:
    error_type, error_instance, traceback = sys.exc_info()
    logging.exception(e)
finally:
    os.remove("already_running")
