role_with_vehicle_mapping = {
    # role present in company_role_table to columns names present in vehicle table mapping
    "admin": "admin",
    "pta": "pta_id",
    "operator": "pto_id",
    "service_provider": "service_provider_id",
}

color_coding = {
    "orange": "F2AF13",
    "grey": "A7AEB4",
    "green": "006B38",
    "red": "D21D26",
}


CONDITION_ALARMS_QUERY = """select * from eber_gateways_sensors_data where (id,__time )in( SELECT LATEST(id),MAX(__time) \
FROM eber_gateways_sensors_data WHERE id in (63, 101, 66, 104, 32) GROUP BY gateway_id, id)"""
