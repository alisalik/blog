import chunk
import os

from sqlalchemy import create_engine

from config import get_config

config = get_config()

import json
import logging
import warnings

warnings.simplefilter(action="ignore", category=FutureWarning)

import pandas as pd

pd.options.mode.chained_assignment = None  # silent warnings
config = get_config()


class DatabaseState:
    DATASETS_NAMES = [
        "maintainance_master",
        "maintenance_dataset",
        "gateway_data",
        "vehicle_alarms",
        "vehicle_alarms_type",
        "vehicle_alarm_job_history",
        # color coding
        "vehicle_color_depot",
        "depot_color",
    ]
    __instance = None

    def __new__(cls, *args, **kwargs):
        if not DatabaseState.__instance:
            DatabaseState.__instance = object.__new__(cls)
        return DatabaseState.__instance

    def __init__(self):
        self.__queries = {
            "maintainance_master": "select * from db_etm.tbl_maintenance_master",
            "maintenance_dataset": "select * from db_etm.tbl_maintenance_dataset",
            "gateway_data": """SELECT tv.vin, engine_type, hvac_id, gateway_id, tcz.name as climate_zone from db_etm.tbl_vehicle tv Inner Join \
                db_etm.tbl_fleet tf on tv.fleet_id = tf.id Inner Join db_etm.tbl_climate_zone tcz on tcz.id = tf.climate_zone_id
                Inner Join db_etm.tbl_hvac_vin_gateway thvg On thvg.vin = tv.vin and thvg.gateway_id is not NULL WHERE thvg.status = "1" """,
            # "gateway_info": {
            #     "is_view": True,
            #     "index_column": "gateway_id",
            #     "query_to_extract": """SELECT tv.vin, engine_type, hvac_id, gateway_id, tcz.name as climate_zone from db_etm.tbl_vehicle tv Inner Join \
            #     db_etm.tbl_fleet tf on tv.fleet_id = tf.id Inner Join db_etm.tbl_climate_zone tcz on tcz.id = tf.climate_zone_id
            #     Inner Join db_etm.tbl_hvac_vin_gateway thvg On thvg.vin = tv.vin and thvg.gateway_id is not NULL""",
            # },
            "vehicle_alarms": """SELECT * from db_etm.tbl_vehicle_alarms""",
            "vehicle_alarms_type": """SELECT * from db_etm.tbl_vehicle_alarms_type""",
            "vehicle_alarm_job_history": """SELECT * FROM db_etm.tbl_vehicle_alarm_job_history""",
            "vehicle_color_depot": """SELECT tv.vin, color_code, color_name, depo_id, pta_id, pto_id, service_provider_id from db_etm.tbl_vehicle tv inner join db_etm.tbl_hvac_vin_gateway thvg on tv.vin = thvg.vin and thvg.gateway_id is not NULL""",
            "depot_color": """SELECT id, color_code, color_name from db_etm.tbl_depot""",
            "company_role": """SELECT tsra.company_id, tcr.name as role, tsra.role_id FROM db_etm.tbl_company_role_assoc tsra inner join db_etm.tbl_company_role tcr  on tcr.id = tsra.role_id WHERE parent_company_id is NULL""",
            "company_wise_depot_color": """SELECT * FROM db_etm.tbl_depot_color""",
        }
        self._in_mem_state = {}
        self.connection = create_engine(config.MYSQL_DB_URI, echo=False)
        self.load()

    def get_query_from_name(self, name):
        return self.__queries[name]

    def acquire_lock(self):
        # maybe for future in multi-threaded environment
        pass

    def release_lock(self):
        pass

    def load(self):
        # lock tables
        # on application startup load data from
        try:
            for obj, q in self.__queries.items():
                if type(q) is dict:
                    self._in_mem_state[obj] = pd.read_sql_query(q, self.connection, index_col="index_col")
                    pass
                self._in_mem_state[obj] = pd.read_sql_query(q, self.connection)
                # NOTE: special handling for vehicle_alarms table
                if obj == "vehicle_alarms":
                    self._in_mem_state[obj]["metadata"] = self._in_mem_state[obj]["metadata"].apply(lambda x: json.loads(x))  # load json string into dict
                self._in_mem_state[obj]["state"] = "synced"  # state of each record
        except Exception as e:
            os.remove("already_running")

        # tbl_hvac_vin_gateway
        # tbl_vehicle_alarms
        # unlock tables
        pass

    def print_state(self):
        for _, object in self._in_mem_state.items():
            print(object)

    def get_in_mem_table(self, name):
        return self._in_mem_state[name]

    def get_alarm_type_id(self, alarm_name):
        # TODO: could be in alarm class
        """get alarm type id from alarm name"""
        logging.debug(f"getting alarm type of {alarm_name}")
        alarm_type_df = self.get_in_mem_table("vehicle_alarms_type")
        row = alarm_type_df.loc[alarm_type_df["name"].str.lower() == alarm_name.lower()]["id"]
        return row.iloc[0]

    def get_maintaince_levels_by_operating_hours(
        self,
        engine_type: str,
        climate_zone: str,
        cur_operating_hours: int,
        last_operating_hours,
    ):
        """get maintainance levels based on operating hours"""
        # TODO: should it be moved to condition class?
        # REVIEW: the logic
        diff = cur_operating_hours - last_operating_hours
        df = self.get_in_mem_table("maintenance_dataset")
        # get records for specific climate_zone and engine_type
        df = df.loc[(df["climate_zone"] == climate_zone) & (df["engine_type"] == engine_type)]
        to_trigger_maintaince_levels = []
        for _, row in df.iterrows():
            level = row["lables"]
            op_hour_threshod = row["operating_hours"]
            if op_hour_threshod == 0:
                # FIXME: why it is zero in db
                continue
            count = int(diff / op_hour_threshod)
            if count == 0:
                # no pts in iterating further
                break
            to_trigger = {"count": count}
            to_trigger["level"] = level
            to_trigger_maintaince_levels.append(to_trigger)
            # to_trigger_maintaince_level[level]["trigger_pt"] = op_hour_threshod

        return to_trigger_maintaince_levels

    def get_last_job_run_record(self):
        df = self.get_in_mem_table("vehicle_alarm_job_history")
        # df["kafka_start_offset"] = df["kafka_start_offset"].apply(json.loads)
        df["kafka_end_offset"] = df["kafka_end_offset"].apply(json.loads)

        df = df[df.finish_time == df.finish_time.max()]

        if df.to_dict("records") != []:
            return df.to_dict("records")[0]  # convert to list so picking first element
        else:
            return {
                "kafka_end_offset": {},
                "status": "success",  # hardcoded success
            }  # no records in the history table the job is running first time.

    def get_records_in_mem(
        self,
        name: str,
        unique=True,
        dataframe=False,  # FIXME: dataframe=True not working as expected
        pick_specific={},
        keep_columns=[],
        **kwargs,
    ):
        # REVIEW: searching using in list.
        df = self.get_in_mem_table(name)
        for arg in kwargs:
            if type(kwargs[arg][0]) is dict:
                # if we are searching for dict type then if search item is present in source then output yes
                df = df[df.apply(lambda x: kwargs[arg][0].items() <= x[arg].items(), axis=1)]
            else:
                # for normal type values
                df = df[(df[arg].isin(kwargs[arg]))]
        if df.empty:
            return None  # none found
        if pick_specific != {}:
            for k, v in pick_specific.items():
                if v == "max":
                    df = df[df[k] == df.max()[k]]
                elif v == "min":
                    df = df[df[k] == df.min()[k]]
        if keep_columns:
            df = df[list(df.columns.intersection(keep_columns))]
        if unique:
            if dataframe:
                return df.head(1)
            else:
                return [v | {"index": k} for k, v in df.to_dict("index").items()][0]
        else:
            if dataframe:
                """return output as dataframe"""
                return df
            else:
                return [v | {"index": k} for k, v in df.to_dict("index").items()]

    def add_records_in_mem(self, name, data):
        df = self.get_in_mem_table(name)
        if type(data) == dict:
            data["state"] = "new"
            self._in_mem_state[name] = df.append(data, ignore_index=True)
        else:
            pass

    def update_records_in_mem(self, name: str, index: int, data: dict):
        if "state" not in data:
            data["state"] = "updated"
        df = self.get_in_mem_table(name)
        df.loc[index, list(data.keys())] = list(data.values())

    def persist_changes(self, name):
        df = self.get_in_mem_table(name)
        df = df[df["state"] == "new"]
        # df["metadata"] = df["metadata"].apply(lambda x: json.dumps(x))
        if name == "vehicle_alarms":
            df.loc[:, "metadata"] = df["metadata"].apply(lambda x: json.dumps(x))
        else:
            df.loc[:, "kafka_end_offset"] = df["kafka_end_offset"].apply(lambda x: json.dumps(x))
        req_columns = [
            c
            for c in list(df.columns)
            if c
            not in [
                "id",
                "state",
            ]
        ]

        df[req_columns].to_sql(
            con=self.connection,
            name="tbl_" + name,
            if_exists="append",
            chunksize=5,
            index=False,
            # flavor="mysql",
        )
        pass
        # for updated objects
        df = self.get_in_mem_table(name)
        df = df[df["state"] == "updated"]
        if name == "vehicle_alarms":
            df.loc[:, "metadata"] = df["metadata"].apply(lambda x: json.dumps(x))
        else:
            pass
        from sqlalchemy.sql import text

        statement = text("""UPDATE """ + "tbl_" + name + """ tva SET status = :status, closed_at = :closed_at, closed_by = :closed_by, metadata = :metadata WHERE id= :id""")

        with self.connection.connect() as con:
            for a in df.to_dict("records"):
                con.execute(statement, **a)

        pass

    def flush(*, self, object_name):
        df = self._in_mem_state["object_name"]

    def create_alarm(
        self,
        type: str,
        vin: str,
        metadata: dict,
    ):
        pass


if __name__ == "__main__":
    """Test cases"""
    db_state = DatabaseState()
    # print(PreventiveAlarms.TYPE)
    # db_state.get_vin_from_gateway("042fa1d75d48b311")
    # print(
    #     db_state.get_maintaince_levels_by_operating_hours(
    #         "ICE", "Moderate Climate", 2750, 1000
    #     )
    # )
    db_state.print_state()
    # db_state.get_last_job_run_record()
    # filtered_df = db_state.get_rows(
    #     "vehicle_alarms",
    #     vin=["YV3T2U824KA192569"],
    #     metadata=[{"alarm_id": 32}],
    # )
    # print(filtered_df)
    # db_state.add_records_in_mem(
    #     "vehicle_alarms",
    #     {
    #         "vin": "YV3T2U824KA192569",
    #         "type_id": 3,
    #         "status": "1",
    #         "metadata": {"timestamp": 1},
    #         "state": "new",
    #     },
    # )
    # db_state.update_records_in_mem("vehicle_alarms", 0, data={"vin": "22"})
    # db_state.get_records_in_mem("gateway_data", gateway_id=["5d48b311042fa1d7"])
    alarms = db_state.get_records_in_mem(
        "vehicle_alarms",
        vin=["TESTCOLORVIN2"],
        type_id=[4],
        dataframe=False,  # need dict
        unique=True,
        pick_specific={"triggered_by": "system"},  # first record will always have config
    )
    pass
