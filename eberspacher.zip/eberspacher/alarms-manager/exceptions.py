class GatewayExecptions(Exception):
    pass


class WrongGatewayMessage(GatewayExecptions):
    """wrong value in gateway payment"""

    pass


class WrongGatewayMessageSchema(GatewayExecptions):
    pass
