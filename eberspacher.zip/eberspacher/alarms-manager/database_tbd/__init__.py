"""API to interact with persistent storage currently MYSQL"""


def flush(*, object_name: str = None):
    """if object_name is given then"""
    pass
