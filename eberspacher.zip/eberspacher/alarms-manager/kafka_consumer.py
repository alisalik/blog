import copy
import json
import logging
import sys
import traceback

from kafka import KafkaConsumer, TopicPartition

from alarms import DataAlarm, PreventiveAlarm
from config import GATEWAY_FILTERS, get_config
from connectivity_alarm import ConnectivityAlarmManager
from database import DatabaseState

IN_MEM_DB = DatabaseState()

config = get_config()

conditional_alarms_related_signals = []
# below object holds {"gw_id": (message, action)}
LATEST_HEARTBEAT_MESSAGES = {}
LATEST_OPERATING_MESSAGE = {}


class Consumer:
    """consumer message from kafka"""

    def __init__(self, last_run_config):
        self._consumer = KafkaConsumer(**config.get_kafka_config_dict())
        self._consumer.subscribe(config.KAFKA_CONSUMER_TOPICS.split(","))
        self.registered_gws = IN_MEM_DB.get_in_mem_table("gateway_data")["gateway_id"].tolist()
        self._topic_partitions = []
        for topic in config.KAFKA_CONSUMER_TOPICS.split(","):
            for p in self._consumer.partitions_for_topic(topic):
                self._topic_partitions.append(TopicPartition(topic, p))  # getting all partitions under topic
        self._end_offsets = self._consumer.end_offsets(self._topic_partitions)  # end offsets for all paritions
        self._begin_offsets = self._consumer.beginning_offsets(self._topic_partitions)
        self._topic_partition_endoffset_lookup = {}  # a lookup dict to get to end offset for any topic and partitions

        for topic, offset in self._end_offsets.items():
            """fill current end offsets"""
            topic_name, partition_name = topic[0], str(topic[1])
            if topic_name in last_run_config:
                if partition_name in last_run_config[topic_name]:
                    # consumer should start from where last run stopped.
                    self._consumer.seek(topic, last_run_config[topic_name][partition_name])
            # constructing lookup dict
            if topic_name not in self._topic_partition_endoffset_lookup:
                self._topic_partition_endoffset_lookup[topic_name] = {}
            self._topic_partition_endoffset_lookup[topic_name][partition_name] = offset
        # to track if end of partition reached for a topic and parition
        self._partition_reached_end = copy.deepcopy(self._topic_partition_endoffset_lookup)

        # fill tracking dict by having all false except for partition which haven't been read.
        for t, ps in self._topic_partition_endoffset_lookup.items():
            for p, o in ps.items():
                # if t in last_run_config:
                #     if (
                #         p in last_run_config[t]
                #     ):  # if partition not present in last_run_config
                #         if o == last_run_config[t][p]:
                #             self._partition_reached_end[t][p] = True
                # else:  # if topic not present in last_run_config
                if self._begin_offsets[TopicPartition(t, int(p))] == self._end_offsets[TopicPartition(t, int(p))]:  # if begin and end offset is same then end is reached
                    self._partition_reached_end[t][p] = True
                else:
                    if t in last_run_config:
                        if p in last_run_config[t]:
                            if o == last_run_config[t][p]:
                                self._partition_reached_end[t][p] = True
                            else:  # if parition not present
                                self._partition_reached_end[t][p] = False

                    else:
                        self._partition_reached_end[t][p] = False
        logging.debug("reading till below kafka offsets")
        logging.debug(self._topic_partition_endoffset_lookup)
        # if bool(end_offsets):
        #     self._topic_partition_endoffset_lookup = end_offsets

    def reached_end_of_all_partitions(self):
        flags = []
        for t, ps in self._partition_reached_end.items():
            for p, f in ps.items():
                flags.append(f)
        return all(flags)

    def reached_end_of_one_partition(self, record):
        # when current record offset for a parition becomes greater than or equal to end offset partition
        return self._topic_partition_endoffset_lookup[record.topic][str(record.partition)] - 1 <= record.offset

    def batch_consume(self):
        if self.reached_end_of_all_partitions():
            logging.debug("No messages in kafka so nothing to do. ")
            return
        for record in self._consumer:
            try:
                # message of kafka is in binary so need to decode.
                msg = json.loads(record.value.decode("utf-8"))
                if bool(GATEWAY_FILTERS):
                    if msg["gateway_id"] not in GATEWAY_FILTERS:
                        continue
                if msg["gateway_id"] not in self.registered_gws:
                    logging.error(f"gw:{msg['gateway_id']} not registered with any vehicle! skipping")
                    continue
                # value in headers is in binary so need to decode.
                headers = {k: v.decode("utf-8") for (k, v) in dict(record.headers).items()}
                if headers["module"] == "gateway" and headers["action"] == "heartbeat":
                    if msg["gateway_id"] in LATEST_HEARTBEAT_MESSAGES:
                        stored_msg, _ = LATEST_HEARTBEAT_MESSAGES[msg["gateway_id"]]
                        if stored_msg["timestamp"] < msg["timestamp"]:
                            LATEST_HEARTBEAT_MESSAGES[msg["gateway_id"]] = (msg, headers["action"])
                    else:
                        LATEST_HEARTBEAT_MESSAGES[msg["gateway_id"]] = (msg, headers["action"])
                    # ConnectivityAlarmManager(msg, action=headers["action"])
                elif headers["module"] == "gateway" and headers["action"] == "alarm_event":
                    logging.debug("recieved data alarm packate from gateway")
                    DataAlarm(msg)
                elif msg["id"] == 930:
                    # continue
                    msg["operating_hours"] = int(msg.pop("value") / 60)
                    if msg["gateway_id"] in LATEST_OPERATING_MESSAGE:
                        stored_msg = LATEST_OPERATING_MESSAGE[msg["gateway_id"]]
                        if stored_msg["timestamp"] < msg["timestamp"]:
                            LATEST_OPERATING_MESSAGE[msg["gateway_id"]] = msg
                    else:
                        LATEST_OPERATING_MESSAGE[msg["gateway_id"]] = msg
                    # PreventiveAlarm(msg)
                elif msg["id"] in (
                    63,  # room1return
                    101,  # room2return
                    66,  # room1supply
                    104,  # room2supply
                ):
                    conditional_alarms_related_signals.append(msg)

            except json.decoder.JSONDecodeError as exc:
                logging.error("couldn't convert message to json, pls check its type.")
                # logging.error(traceback.format_exc())
            except ValueError as err:

                error_type, error_instance, traceback = sys.exc_info()
                # logging.error(str(err))
                logging.exception(err)
            except Exception as e:
                logging.error("Error occured while extracting data from message (Schema differnet??)!")
                error_type, error_instance, traceback = sys.exc_info()
                logging.exception(e)
            finally:
                if self.reached_end_of_one_partition(record):
                    """mark parition end in the log"""
                    self._partition_reached_end[record.topic][str(record.partition)] = True
                if self.reached_end_of_all_partitions():
                    logging.debug("reached end of all kafka paritions for this job iteration")
                    break


if __name__ == "__main__":
    c = Consumer()
    c.batch_consume()
