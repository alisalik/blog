from database import DatabaseState


class PreventiveAlarm:

    def __init__(self, kafka_msg):
        self.l

    def handle(self):
        pass
