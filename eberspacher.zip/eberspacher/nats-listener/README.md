# ABOUT
This service connects to NATs server and subscribes to all the messages under topic - eber.*. Currently the messages under these topics are published by eberspacher gateways that are mounted on vehicles.

# PROJECT SETUP
TODO


# TODOS
- nkeyseed should come from secrets and not be present in repo.
- open and close mysql connection at the time of sql query itself.
-  