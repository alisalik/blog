import asyncio

import aiomysql
from aiokafka import AIOKafkaProducer
from aiokafka.helpers import create_ssl_context

from config import ENV, BaseConfig, ConfigFactory


async def get_mysql_connection(config_dict):
    conn = await aiomysql.connect(**config_dict, connect_timeout=5)
    return conn


async def init_connections(loop):
    connections = {}

    connections["mysql"] = {}
    current_config = ConfigFactory.get_config()
    # current_mysql_pool = await aiomysql.create_pool(loop=loop, **current_config.get_mysql_config())
    connections["mysql"][ENV] = current_config.get_mysql_config()

    relay_envs = BaseConfig.get_relay_envs()

    connections["kafka"] = {}
    current_kafka_producer = AIOKafkaProducer(
        **current_config.get_kafka_config(),
        ssl_context=create_ssl_context(),
    )
    #await current_kafka_producer.start()
    connections["kafka"][ENV] = current_kafka_producer

    for env in relay_envs:
        env_config = ConfigFactory.get_config(env)
        # env_mysql_pool = await aiomysql.create_pool(loop=loop, **env_config.get_mysql_config())
        connections["mysql"][env] = env_config.get_mysql_config()
        env_kafka_producer = AIOKafkaProducer(
            **env_config.get_kafka_config(),
            ssl_context=create_ssl_context(),
        )
        await env_kafka_producer.start()
        connections["kafka"][env] = env_kafka_producer
    return connections
