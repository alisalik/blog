import logging
import logging.handlers
import sys
from os import environ

from can_signal import CanSignalManager, SignalMetadataError, SignalMetadataJsonError

ENV = environ.get("ENV", "local")

logger = logging.getLogger("asyncio")


class BaseConfig:
    """common paramters and function resides here, env specific config will inherit this,
    using this pattern enables code sharing"""

    # TODO[epic=refactoring] rethink
    # mapping kafka topic to some readable name
    KAFKA_TOPICS_MAPPING = {
        "local": {
            "producer_topic_vehicle_components_status": "eber.vehicle.components.status",
            "producer_topic_vehicle_sensors_data": "eber.gw.sensors.data",
            "producer_topic_vehicle_gps": "eber.vehicle.gps",
            "producer_topic_vehicle_alarms": "eberspacher-gateway-sensor-data-dev",
        },
        "development": {
            "producer_topic_vehicle_components_status": "eber.vehicle.components.status",
            "producer_topic_vehicle_sensors_data": "eber.gw.sensors.data",
            "producer_topic_vehicle_gps": "eber.vehicle.gps",
            "producer_topic_vehicle_alarms": "eberspacher-gateway-sensor-data-dev",
        },
        "qc": {
            "producer_topic_vehicle_components_status": "eber.vehicle.components.status.qc",
            "producer_topic_vehicle_sensors_data": "eber.gw.sensors.data.qc",
            "producer_topic_vehicle_gps": "eber.vehicle.gps.qc",
            "producer_topic_vehicle_alarms": "eberspacher-gateway-sensor-data-qc",
        },
        "production": {
            "producer_topic_vehicle_components_status": "eber.vehicle.components.status.uat",
            "producer_topic_vehicle_sensors_data": "eber.gw.sensors.data.uat",
            "producer_topic_vehicle_gps": "eber.vehicle.gps.uat",
            "producer_topic_vehicle_alarms": "eberspacher-gateway-sensor-data-uat",
        },
    }

    RELAY_PATHS = environ.get("RELAY_PATHS", "").split(",")

    LOG_LEVEL = environ.get("LOG_LEVEL", "DEBUG")

    MYSQL_HOSTNAME = "mysql.dev.orahi.com"
    MYSQL_PORT = 3306
    MYSQL_USERNAME = "dev_harish"
    MYSQL_PASSWORD = environ.get("MYSQL_PASSWORD")
    MYSQL_DBNAME = "db_etm"

    def get_mysql_config(self):
        return {
            "host": self.__class__.MYSQL_HOSTNAME,
            "port": self.__class__.MYSQL_PORT,
            "user": self.__class__.MYSQL_USERNAME,
            "password": self.__class__.MYSQL_PASSWORD,
            "db": self.__class__.MYSQL_DBNAME,
        }

    NATS_SERVER = "nats.dev.orahi.com:4222"
    NATS_TOPIC_COMPANY_NAMESPACE = "eber"

    KAFKA_BOOTSTRAP_SERVER = "kafka.dev.orahi.com:443"
    KAFKA_USERNAME = "admin-etm-dev"
    KAFKA_PASSWORD = environ.get("KAFKA_PASSWORD")
    KAFKA_SASL_MECHANISM = "SCRAM-SHA-512"
    KAFKA_AUTO_OFFSET_RESET = "latest"
    KAFKA_ENABLE_AUTO_COMMIT = True
    KAFKA_SECURITY_PROTOCOL = "SASL_SSL"
    PUSH_TO_KAFKA = int(environ.get("PUSH_TO_KAFKA", "1"))

    def get_kafka_config(self):
        return {
            "bootstrap_servers": self.__class__.KAFKA_BOOTSTRAP_SERVER,
            # "auto_offset_reset": self.__class__.KAFKA_AUTO_OFFSET_RESET,
            # "enable_auto_commit": self.__class__.KAFKA_ENABLE_AUTO_COMMIT,
            "security_protocol": self.__class__.KAFKA_SECURITY_PROTOCOL,
            "sasl_plain_username": self.__class__.KAFKA_USERNAME,
            "sasl_plain_password": self.__class__.KAFKA_PASSWORD,
            "sasl_mechanism": self.__class__.KAFKA_SASL_MECHANISM,
        }

    GITLAB_ACCESS_TOKEN = environ.get("GITLAB_ACCESS_TOKEN")
    GITLAB_REPO_URL = [
        "https://code.orahi.com:8929/api/v4/projects/468/repository/files/etc%2Feberspacher%2Fdefault%2Fcan0_signals.json/raw?ref=master",
        "https://code.orahi.com:8929/api/v4/projects/468/repository/files/etc%2Feberspacher%2Fdefault%2Fcan1_signals.json/raw?ref=master",
    ]

    REDIS_CONNECTION_URI = environ.get("REDIS_CONNECTION_URL", "redis://mqtt.orahi.com")

    FILTERS = {
        "gateway_inclusion_list": environ.get("GATEWAY_INCLUSTION_LIST", "*").split(","),
        "gateway_exclusion_list": environ.get("GATEWAY_EXCLUSTION_LIST", "").split(","),
    }

    SMTP_SERVER = "smtp-mail.outlook.com"
    SMTP_PORT = 587
    SMTP_USERNAME = "bsingh5508@outlook.com"
    SMTP_PASSWORD = environ.get("SMTP_PASSWORD")
    SMTP_FROM_ADDRESS = "bsingh5508@outlook.com"
    SMTP_TO_ADDRESS = "harish.singh@orahi.com"
    SMTP_SUBJECT = "DEV: Critical Error From ETM Nats connector"

    @staticmethod
    def get_relay_envs():
        envs = environ.get("RELAY_ENVS", "").split(",")
        if envs == [""]:
            return []
        else:
            return envs


class LocalConfig(BaseConfig):
    # LOG_LEVEL = "ERROR"
    NATS_SERVER = "tls://natsk8.dev.orahi.com:4222"
    PUSH_TO_KAFKA = 0
    pass


class QCConfig(BaseConfig):
    MYSQL_HOSTNAME = "mysql.qc.orahi.com"
    MYSQL_PORT = 3307
    MYSQL_USERNAME = "etm.service.nats.connector"
    MYSQL_PASSWORD = environ.get("MYSQL_PASSWORD_QC")
    MYSQL_DBNAME = "db_etm"

    KAFKA_BOOTSTRAP_SERVER = "qc-kafka-kafka-bootstrap.kafka.svc.cluster.local:9092"
    KAFKA_USERNAME = "admin-etm-qc"
    KAFKA_PASSWORD = environ.get("KAFKA_PASSWORD_QC")
    KAFKA_SECURITY_PROTOCOL = "SASL_PLAINTEXT"
    SMTP_SUBJECT = "QC: Critical Error From ETM Nats connector"


class DevelopmentConfig(BaseConfig):
    NATS_SERVER = "tls://natsk8.dev.orahi.com:4222"
    LOG_LEVEL = "DEBUG"
    pass


class ProductionConfig(BaseConfig):
    MYSQL_HOSTNAME = "mysql.uat.orahi.com"
    MYSQL_PORT = 3308
    MYSQL_USERNAME = "etm.service.nats.connector"
    MYSQL_PASSWORD = environ.get("MYSQL_PASSWORD_UAT")
    MYSQL_DBNAME = "db_etm"
    KAFKA_BOOTSTRAP_SERVER = "uat-kafka-kafka-bootstrap.kafka.svc.cluster.local:9092"
    KAFKA_USERNAME = "admin-etm-uat"
    KAFKA_PASSWORD = environ.get("KAFKA_PASSWORD_UAT")
    KAFKA_SECURITY_PROTOCOL = "SASL_PLAINTEXT"
    SMTP_SUBJECT = "UAT: Critical Error From ETM Nats connector"


class ConfigFactory:
    """for all config management"""

    # stores env specific config values
    _instances = {}
    _signal_metadata = None

    @staticmethod
    def set_instance(env):
        assert env in ["local", "development", "qc", "production"], "invalid value for env"
        if env not in ConfigFactory._instances:
            if env == "local":
                ConfigFactory._instances[env] = LocalConfig()
            elif env == "development":
                ConfigFactory._instances[env] = DevelopmentConfig()
            elif env == "qc":
                ConfigFactory._instances[env] = QCConfig()
            elif env == "production":
                ConfigFactory._instances[env] = ProductionConfig()

    @staticmethod
    def get_config(env: str = None):
        """retuns config based on environment if no env is passed then env value is extracted from env vars."""
        if env is not None:
            assert env in ["local", "development", "qc", "production"], "invalid value for env"
        else:
            env = ENV
        ConfigFactory.set_instance(env)
        return ConfigFactory._instances[env]

    @staticmethod
    def setup_logger():
        """set the logger based on run environment"""
        env = ENV

        # making sure that instance has been set
        ConfigFactory.set_instance(env)
        current_config = ConfigFactory.get_config(env)

        logger = logging.getLogger("asyncio")
        logger.setLevel(current_config.LOG_LEVEL)
        logger.addHandler(logging.StreamHandler())
        smtp_handler = logging.handlers.SMTPHandler(
            (current_config.SMTP_SERVER, current_config.SMTP_PORT),
            current_config.SMTP_FROM_ADDRESS,
            current_config.SMTP_TO_ADDRESS,
            current_config.SMTP_SUBJECT,
            credentials=(current_config.SMTP_USERNAME, current_config.SMTP_PASSWORD),
            secure=(),
        )

        formatter = logging.Formatter("%(asctime)s - %(levelname)s %(filename)s %(message)s%(exc_info)s")
        smtp_handler.setFormatter(formatter)
        # NOTE: only critical log levels are sent to email
        smtp_handler.setLevel("CRITICAL")
        logger.addHandler(smtp_handler)

        # is root logger's level is debug aiokafka logger floods the debug logs hence silencing it
        kafka_logger = logging.getLogger("aiokafka")
        kafka_logger.setLevel(logging.ERROR)
        # ------------------------------------------

    @staticmethod
    def get_logger():
        return logging.getLogger("asyncio")

    @staticmethod
    def get_signal_metadata():
        signal_metadata = None
        current_config = ConfigFactory.get_config()
        if ConfigFactory._signal_metadata is None:
            try:
                signal_metadata = ConfigFactory._signal_metadata = CanSignalManager(
                    current_config.GITLAB_REPO_URL, current_config.GITLAB_ACCESS_TOKEN
                )
            except Exception as e:
                ConfigFactory.get_logger().critical(str(e), exc_info=True)
                sys.exit(0)
        else:
            signal_metadata = ConfigFactory._signal_metadata
        return signal_metadata

    @staticmethod
    def initialize():
        ConfigFactory.set_instance(ENV)
        ConfigFactory.setup_logger()
        ConfigFactory.get_signal_metadata()
