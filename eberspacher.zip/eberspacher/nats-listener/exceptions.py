class MessageProcessingError(Exception):
    pass


class ActionExecutionError(Exception):
    def __init__(self, action_name, message, *args) -> None:
        self.action_name = action_name
        self.message = message
        super().__init__(*args)

    def __str__(self) -> str:
        return f"{self.message} '{self.action_name}' for message '{self.message}'"
