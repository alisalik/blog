"""connect to NATs to receive events from gateways."""
import asyncio
import datetime
import json
import time
import zlib
from pprint import pformat

import nats

from config import ConfigFactory, logger
from message_handler import message_handler as msg_handler
from retry_failed_partial_func import retry_failed_parital_func
from utils import init_connections

# example -> eber.iw-G26.5d48b311042fa1d7.diagnostics.active-alarms


async def main(loop):
    # producer = AIOKafkaProducer(bootstrap_servers='localhost:9092')

    # Connect to NATS!
    ConfigFactory.initialize()
    current_config = ConfigFactory.get_config()

    nc = await nats.connect(current_config.NATS_SERVER, nkeys_seed="nkeyseed")
    company_name = current_config.NATS_TOPIC_COMPANY_NAMESPACE
    connections = await init_connections(loop)
    asyncio.create_task(retry_failed_parital_func()),
    topic = company_name + ".>"

    async def nats_message_handler_v3(nats_msg):
        if nats_msg.subject.split(".")[2] in current_config.FILTERS["gateway_exclusion_list"]:
            logger.debug(
                f"""gateway id:{nats_msg.subject.split(".")[2]} packet has been dropped as it is in exclusion_list"""
            )
            return
        elif (
            nats_msg.subject.split(".")[2] not in current_config.FILTERS["gateway_inclusion_list"]
            and current_config.FILTERS["gateway_inclusion_list"][0] != "*"
        ):
            logger.debug(
                f"""gateway id:{nats_msg.subject.split(".")[2]} packet has been dropped as it is not in inclusion_list"""
            )
            return

        logger.debug(f"NATs-SERVER-> MSG-SUBJECT:{nats_msg.subject}")
        logger.debug(f"NATs-SERVER-> MSG-PAYLOAD:{nats_msg.data}")

        if nats_msg.subject.split(".")[-1] == "c":
            # this is a compressed message uncompress the data!
            nats_msg.data = json.loads(zlib.decompress(nats_msg.data))
            # logger.debug("got below compressed message:")
            # logger.debug(pformat(nats_msg.data))
        elif nats_msg.subject.split(".")[-1] == "u":
            # message is uncompressed
            nats_msg.data = json.loads(nats_msg.data)

        if any(sub_string in nats_msg.subject for sub_string in ["signals.c", "signals.u"]):
            original_subject = nats_msg.subject
            # the payload will have list of signals
            for signal_data in nats_msg.data["signals"]:
                # tweak message as required by upstream flow
                signal_data["timestamp"] = signal_data.pop("t")
                signal_data["value"] = signal_data.pop("v")
                signal_data["id"] = signal_data.pop("i")

                nats_msg.data = json.dumps(signal_data).encode()

                nats_msg.subject = (
                    original_subject.replace("signals", "sensor-signal")[:-2] + "." + str(signal_data["id"])
                )
                logger.debug("decompressed msg")
                logger.debug(nats_msg.data)
                await msg_handler(nats_msg, nc, connections)
        elif any(sub_string in nats_msg.subject for sub_string in ["alarm-event.c", "alarm-event.u"]):
            if "alarms" in nats_msg.subject:
                # for compressed and uncompressed message, remove the identifier as req by upstream flow
                if nats_msg.subject[:-2] in [".c", ".u"]:
                    nats_msg.subject = nats_msg.subject.replace(".c", "")
                    nats_msg.subject = nats_msg.subject.replace(".u", "")
                    for alarm_data in nats_msg.data["alarms"]:
                        nats_msg.data = json.dumps(alarm_data).encode()
                        await msg_handler(nats_msg, nc, connections)
        else:  # old style messages
            if nats_msg.subject[:-2] in [".c", ".u"]:
                nats_msg.subject = nats_msg.subject.replace(".c", "")
                nats_msg.subject = nats_msg.subject.replace(".u", "")
            await msg_handler(nats_msg, nc, connections)

    sub = await nc.subscribe(topic, cb=nats_message_handler_v3)
    # await sub.unsubscribe(limit=200000)


if __name__ == "__main__":
    # asyncio.run(main())
    loop = asyncio.get_event_loop()
    loop.run_until_complete(main(loop))
    loop.run_forever()
    loop.close()
