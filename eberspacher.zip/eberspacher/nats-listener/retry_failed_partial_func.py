"""coroutine to retry failed database transactions in order they came. it will"""
import asyncio

from config import BaseConfig, ConfigFactory, logger

queue = asyncio.Queue()


async def push_failed_func(func):
    await queue.put({"partial_func": func})


async def retry_failed_parital_func():
    while True:
        func_data = await queue.get()
        partial_func = func_data["partial_func"]
        # trying the query again
        is_successful = False
        while not is_successful:
            try:
                await partial_func()
                is_successful = True
            except Exception as err:
                logger.critical(f"retry failed: {partial_func.func.__name__}")
                size = queue.qsize()
                logger.critical(f"current queue size:{size}")
                await asyncio.sleep(5)  # retry again after 5 sec
