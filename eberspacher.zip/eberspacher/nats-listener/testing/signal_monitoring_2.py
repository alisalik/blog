#!/bin/python3

import asyncio
import datetime
import json
import os
import sys
import time
import zlib

import nats
from nats.errors import ConnectionClosedError, NoServersError, TimeoutError

clear = lambda: os.system("clear")
signal_dictionary = {}
signal_print = {}

input_files = [
    # "../../configuration/etc/eberspacher/beta_club_dev/can0_signals.json",
    # "../../configuration/etc/eberspacher/beta_club_dev/can1_signals.json",
    "/Users/anton/projects/eber/nats.connector/nats.connector/testing/can0_signals.json"
]

utc_time = time.gmtime(time.time())
time_str = time.strftime("%Y-%m-%d_%H.%M.%S", utc_time)

output_file = f"sm_{time_str}.log"
open(output_file, "w")

print(f"Saving to '{output_file}'")


def read_signal_db():
    for file_name in input_files:
        # can0_file_name = "../../configuration/etc/eberspacher/beta_club_dev/can0_signals.json"

        with open(file_name, mode="r") as file:
            jsonStr = file.read()

        json_dicti = json.loads(jsonStr)
        frames = json_dicti["frames"]

        for entry in frames:
            for signal_entry in entry["signals"]:
                signal_dictionary[signal_entry["id"]] = signal_entry["name"]
                print(f"Read: {signal_entry['id']} {signal_entry['name']}")


def get_result():
    return signal_dictionary


def print_to_file(log):
    with open(output_file, "a") as f:
        print(log, file=f)


async def main(loop):

    # gw = "042fa1d75d48b311"

    if len(sys.argv) < 2:
        print("usage: signal_monitor.py <gateway id> [--in-place]")
        quit()

    gw = sys.argv[1]

    follow_log = ""
    if len(sys.argv) == 3:
        follow_log = sys.argv[2]

    read_signal_db()
    nc = await nats.connect("nats://nats.dev.orahi.com")

    async def message_handler(msg):
        subject = msg.subject

        if subject[-1] == "c":
            msg_data = zlib.decompress(msg.data)
        else:
            msg_data = msg.data

        data = msg_data.decode()

        json_data = json.loads(data)
        signals = json_data["signals"]

        if follow_log == "--in-place":
            for signal in signals:
                time = signal["t"]
                dt = datetime.datetime.fromtimestamp(time / 1000).replace(microsecond=0)
                id = signal["i"]
                val = signal["v"]
                name = signal_dictionary[id]
                log = "{time} ({id}) {name}={val}".format(time=dt, id=id, name=name, val=val)
                signal_print[id] = log
                print_to_file(log)

            clear()
            print("====================================================")
            for key in signal_print:
                print(signal_print[key])
            print("====================================================")
        else:
            for signal in signals:
                time = signal["t"]
                dt = datetime.datetime.fromtimestamp(time / 1000).replace(microsecond=0)
                id = signal["i"]
                val = signal["v"]
                name = signal_dictionary[id]
                log = "{time} ({id}) {name}={val}".format(time=dt, id=id, name=name, val=val)
                print(log)
                print_to_file(log)

    topic = f"eber.iw-G26.{gw}.signals.>"
    sub = await nc.subscribe(topic, cb=message_handler)

    # await sub.unsubscribe()
    # Terminate connection to NATS.
    # await nc.drain()


if __name__ == "__main__":
    loop = asyncio.get_event_loop()
    loop.run_until_complete(main(loop))
    loop.run_forever()
