import asyncio
import json
import sys
import time

import nats
from nats.errors import ConnectionClosedError, NoServersError, TimeoutError


async def main():
    # gateway_id = "01020304050607ab"
    gateway_id = sys.argv[1]
    can_channel = sys.argv[2]
    record_duration = int(sys.argv[3])

    nc = await nats.connect("nats://nats.dev.orahi.com")

    ms = time.time_ns() / 1000000

    json_data = {}
    json_data["can_channel"] = can_channel
    json_data["record_duration"] = record_duration
    payload = json.dumps(json_data, separators=(",", ":"))

    try:
        topic = f"eber.iw-G26.{gateway_id}.request.candump"
        import pdb

        pdb.set_trace()
        response = await nc.request(topic, str.encode(payload), record_duration + 10.0)
        print(f"gw: {gateway_id} " + "replied: {message}".format(message=response.data.decode()))
    except TimeoutError:
        print(f"No response from {gateway_id}")

    json_data2 = {}
    json_data2["timestamp"] = int(ms)
    json_data2["dir_to_upload"] = "/var/canrecordings"
    json_data2["delete_dir_content_after_upload"] = True
    payload2 = json.dumps(json_data2, separators=(",", ":"))

    try:
        topic2 = f"eber.iw-G26.{gateway_id}.request.upload"
        response2 = await nc.request(topic2, str.encode(payload2), 20.0)
        print(f"gw: {gateway_id} " + "replied: {message}".format(message=response2.data.decode()))
    except TimeoutError:
        print(f"No response from {gateway_id}")

    # Terminate connection to NATS.
    await nc.drain()


if __name__ == "__main__":
    asyncio.run(main())
