import asyncio
import json
import logging

logging.getLogger().setLevel(logging.INFO)
import aioredis


class RedisSingleton:
    _instance = None

    def __new__(cls, *args, **kwargs):
        if cls._instance is None:
            cls._instance = super().__new__(cls, *args, **kwargs)
        return cls._instance

    def __init__(self):
        self.redis = None

    def get_connection(self):
        if self.redis is None:
            self.redis = aioredis.from_url(
                "redis://:3qVk72GP5zNl@redis.dev.orahi.com", encoding="utf-8", decode_responses=False
            )
        return self.redis


async def other_coroutine():
    while True:
        logging.info("inside another coroutine")
        sleep_time = 15
        logging.info(f"sleeping for {sleep_time} seconds")
        await asyncio.sleep(sleep_time)


async def push_to_redis_asioredis(processed_data: dict = {}, key: str = "", msg_type: str = "component_status_on_off"):
    # NOTE: this should be executed for gps-signal, signalvalue and heartbeat.
    # Create Redis connection
    # connection = await asyncio_redis.Pool.create(**config["redis"])
    try:
        logging.info(f"createing redis connection")
        redis = RedisSingleton().get_connection()
        sleep_time = 15
        for i in range(1, 10):
            logging.info(f"setting i to {i}")
            await redis.set("eber:test", json.dumps({"i": i}))
            logging.info(f"sleeping for {sleep_time} seconds")
            await asyncio.sleep(10)

    except Exception as e:
        logging.exception(e)


async def main():
    # Schedule three calls *concurrently*:
    L = await asyncio.gather(push_to_redis_asioredis(), other_coroutine())
    print(L)


asyncio.run(main())
