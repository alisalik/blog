"""message handler
identify(msg) -> based on identify trigger process -> then target
"""

import asyncio
import json
import traceback
from datetime import datetime
from functools import partial

import aioredis
import asyncio_redis
from aiokafka import AIOKafkaProducer
from aiokafka.helpers import create_ssl_context
from nats.aio.msg import Msg
from pymysql.err import OperationalError

from config import BaseConfig, ConfigFactory, logger
from exceptions import ActionExecutionError
from redis_connection import RedisSingleton
from retry_failed_partial_func import push_failed_func
from utils import get_mysql_connection

config = ConfigFactory.get_config()
topic_mapping = BaseConfig.KAFKA_TOPICS_MAPPING

RedisSingleton()


def subject_contains(msg: Msg = None, delimiter: str = ".", index: int = 0, identifier: str = ""):
    try:
        subject = msg.subject
        if delimiter is None:
            return identifier in subject
        return subject.split(delimiter)[index] == identifier
    except Exception as err:
        logger.error(err, exc_info=True)
        return False


def signal_id_in(msg: Msg = None, delimiter: str = ".", identifiers: list = []):
    subject = msg.subject
    try:
        signal_id = int(subject.split(".")[-1])
    except Exception as e:  # for messages whose subject don't have signal ids this will fail
        # so handling the exception properly.
        return False
    if signal_id in identifiers:
        return True
    else:
        return False


def signaljson_has_attribs_val(msg: Msg = None, attribs: dict = {}):
    try:
        signal_id = int(msg.subject.split(".")[-1])
        has_attrib = True
        for key, value in attribs.items():
            has_attrib = ConfigFactory.get_signal_metadata().get_attrib(signal_id, key) == value
        return has_attrib
    except Exception as err:
        logger.error(err, exc_info=True)
        return False


def add_signal_id(msg: Msg, processed_data: dict = {}, id=None):
    if id is not None:
        # some id is passed
        processed_data["id"] = id
    else:
        subject = msg.subject
        signal_id = int(subject.split(".")[-1])  # last object in string will be signal_id
        processed_data["id"] = signal_id
    return processed_data


def add_attribs(msg: Msg, processed_data: dict = {}, **attribs):
    for k, v in attribs.items():
        processed_data[k] = v
    return processed_data


def add_gateway_id(msg: Msg, processed_data: dict = {}):
    """process a nats record"""
    subject = msg.subject
    gateway_id = subject.split(".")[2]
    processed_data = json.loads(msg.data.decode())
    processed_data["gateway_id"] = gateway_id  # adding gateway id
    return processed_data


def add_attribs_from_signal_json(msg: Msg, processed_data: dict = {}, attribs: list = []):
    for a in attribs:
        signal_id = processed_data["id"]
        val = ConfigFactory.get_signal_metadata().get_attrib(signal_id, a)
        processed_data[a] = val
    return processed_data


def rename_lon_to_long(msg: Msg, processed_data: dict = {}):
    processed_data["long"] = processed_data.pop("lon")
    return processed_data


def convert_type_to(attrib: str = "", to_type=None, msg: Msg = None, processed_data: dict = {}):
    """convert a type of specific attribute in the data to passed type"""
    data = processed_data[attrib]
    if type(data) != to_type:
        processed_data[attrib] = to_type(data)
    return processed_data


def drop_if(type: str = "processed_msg_contains", condition: dict = None, msg: Msg = None, processed_data: dict = {}):
    if type == "processed_msg_contains":
        for key, value in condition.itmes():
            if processed_data[key] == value:
                pass


def keep_if(type: str = "processed_msg_contains", condition: dict = None, msg: Msg = None, processed_data: dict = {}):
    if type == "processed_msg_contains":
        for key, value in condition.items():
            to_keep = True
            if key not in processed_data or processed_data[key] != value:
                logger.info("dropping the message from current processing")
                return
    return processed_data


async def nats_msg_reply(nc=None, msg: Msg = None, reply_msg: dict = {}):
    topic = msg.reply
    await nc.publish(topic, json.dumps(reply_msg).encode("utf-8"))


async def push_to_kafka(producers_connections=None, topic: str = "", action: str = "", processed_data: dict = {}):
    headers = [
        ("service", b"NATS_CONNECTOR"),
        ("module", b"gateway"),
        ("action", action.encode("utf-8")),
    ]
    if not config.PUSH_TO_KAFKA:
        # not pushing to kafka helpful for local testing
        return
    for env, conn in producers_connections.items():
        try:
            topic_name = topic_mapping[env][topic]
            logger.debug(f"Push to Kafka{env}(topic={topic}): msg->{processed_data}")
            await conn.send_and_wait(topic_name, json.dumps(processed_data).encode(), headers=headers)
        except Exception as e:
            aee = ActionExecutionError(
                action_name="push_to_kafka:{env}",
                message=f"unable to push to {env}:kafka, topic:{topic_name}, message:{processed_data}",
            )
            logger.exception(aee)
            logger.critical(aee, exc_info=True)


async def multi_push_to_kafka(producer=None, topic: str = "", action: str = "", processed_data: dict = {}):
    headers = [
        ("service", b"NATS_CONNECTOR"),
        ("module", b"gateway"),
        ("action", action.encode("utf-8")),
    ]
    await producer.send_and_wait(topic, json.dumps(processed_data).encode(), headers=headers)


async def get_redis_pool():
    if not hasattr(get_redis_pool, "pool"):
        get_redis_pool.pool = aioredis.from_url(
            "redis://:3qVk72GP5zNl@redis.dev.orahi.com", encoding="utf-8", decode_responses=False
        )
    return get_redis_pool.pool


async def save_ignition_state(connections=None, processed_data: dict = {}):
    gateway_id = processed_data["gateway_id"]
    ignition = "ON" if bool(processed_data["value"]) else "OFF"
    query_get_vin = """SELECT thvg.vin FROM db_etm.tbl_hvac_vin_gateway thvg WHERE thvg.gateway_id=%s"""
    query_update_ignition = """UPDATE db_etm.tbl_vehicle SET ignition = %s where vin = %s"""
    for conn_config_dict in connections:
        vin = None
        conn = None
        try:
            conn = await get_mysql_connection(conn_config_dict)
            result = await read_from_database(conn, query_get_vin, gateway_id)
            if not bool(result):
                logger.error("gateway:%s not registered this shouldn't have happened!" % processed_data["gateway_id"])
                # NOTE: log somewhere that gateway is not in master possibilty reponse with apprpriate reply
            else:
                vin = result[0][0]
                await write_to_database(conn, query_update_ignition, (ignition, vin))

        except Exception as err:

            aee = ActionExecutionError(
                action_name="perform_mysql_operation:{conn_config_dict}",
                message=f"failed to perform_mysql_operation config {conn_config_dict}, message:{processed_data}",
            )
            logger.exception(aee)
            logger.critical(aee, exc_info=True)
            raise aee
        finally:
            if conn is not None:
                conn.close()


async def save_index_error_code(connections=None, processed_data: dict = {}):
    gateway_id = processed_data["gateway_id"]
    query_update_index_error_code = (
        """UPDATE db_etm.tbl_gateway SET index_error_code_packet = %s where serial_number = %s"""
    )
    for conn_config_dict in connections:
        vin = None
        conn = None
        try:
            conn = await get_mysql_connection(conn_config_dict)
            to_store = processed_data.copy()
            to_store.pop("gateway_id")  # not storing gateway id.
            await write_to_database(conn, query_update_index_error_code, (json.dumps(to_store), gateway_id))

        except Exception as err:
            aee = ActionExecutionError(
                action_name="save_index_error_code:{conn_config_dict}",
                message=f"failed to save_index_error_code config {conn_config_dict}, message:{processed_data}",
            )
            logger.exception(aee)
            logger.critical(aee, exc_info=True)
            raise aee
        finally:
            if conn is not None:
                conn.close()


async def save_can_0_active_varchar(connections=None, processed_data: dict = {}):
    gateway_id = processed_data["gateway_id"]
    # can_0_active = "ON" if bool(processed_data["value"]) else "OFF"
    can_0_active = processed_data["value"]
    query_update_index_error_code = """UPDATE db_etm.tbl_gateway SET can0_active_varchar = %s, can0_active_varchar_ts = %s where serial_number = %s"""
    for conn_config_dict in connections:
        conn = None
        try:
            conn = await get_mysql_connection(conn_config_dict)
            await write_to_database(conn, query_update_index_error_code, (can_0_active, datetime.utcnow(), gateway_id))

        # except OperationalError as err:
        #     pass
        except Exception as err:
            aee = ActionExecutionError(
                action_name="save_can_0_active:{conn_config_dict}",
                message=f"failed to save_can_0_active config {conn_config_dict}, message:{processed_data}",
            )
            logger.exception(aee)
            logger.critical(aee, exc_info=True)
            raise aee
        finally:
            if conn is not None:
                conn.close()


async def save_can_0_active(connections=None, processed_data: dict = {}):
    gateway_id = processed_data["gateway_id"]
    can_0_active = "ON" if bool(processed_data["value"]) else "OFF"
    # can_0_active = processed_data["value"]
    query_update_index_error_code = """UPDATE db_etm.tbl_gateway SET can0_active = %s where serial_number = %s"""
    for conn_config_dict in connections:
        conn = None
        try:
            conn = await get_mysql_connection(conn_config_dict)
            await write_to_database(conn, query_update_index_error_code, (can_0_active, gateway_id))

        # except OperationalError as err:
        #     pass
        except Exception as err:
            aee = ActionExecutionError(
                action_name="save_can_0_active:{conn_config_dict}",
                message=f"failed to save_can_0_active config {conn_config_dict}, message:{processed_data}",
            )
            logger.exception(aee)
            logger.critical(aee, exc_info=True)
            raise aee
        finally:
            if conn is not None:
                conn.close()


async def perform_mysql_operation(connections=None, processed_data: dict = {}):
    # check gateway present in master is not log it
    queries = (
        # TODO: update below queries after correcting the tbl_gateway mess!
        ("CHECK_IN_MASTER", "SELECT * from db_etm.tbl_gateway_master WHERE cpu_number=%s"),
        (
            "CHECK_IF_ATTACHED_TO_VIN",
            "SELECT tv.vin FROM db_etm.tbl_vehicle tv INNER JOIN db_etm.tbl_hvac_vin_gateway thvg ON tv.vin = thvg.vin AND thvg.gateway_id=%s",
        ),
        ("SET_ECONTROL", "UPDATE db_etm.tbl_vehicle SET econtrol_version=%s WHERE vin=%s"),
        ("SET_GW_FIRMWARE_VERSION", "UPDATE db_etm.tbl_gateway SET firmware_version=%s WHERE serial_number=%s"),
        ("SAVE_SYSTEM_INFO_PACKET", "UPDATE db_etm.tbl_gateway SET last_system_info_packet=%s WHERE serial_number=%s"),
    )
    # check if vin attached to gateway if yes update econtrol version
    # if no log
    for conn_config_dict in connections:
        vin = None
        conn = None
        try:
            conn = await get_mysql_connection(conn_config_dict)
            for query_name, query_string in queries:
                if query_name in ("CHECK_IN_MASTER", "CHECK_IF_ATTACHED_TO_VIN"):
                    values = processed_data["gateway_id"]
                    result = await read_from_database(conn, query_string, values)
                    if not bool(result):
                        if query_name == "CHECK_IN_MASTER":
                            logger.info("gateway:%s not present in master table" % processed_data["gateway_id"])
                            # NOTE: log somewhere that gateway is not in master possibilty reponse with apprpriate reply
                            return "UNKNOWN_CPU_ID"
                        elif query_name == "CHECK_IF_ATTACHED_TO_VIN":
                            # NOTE: log this gateway is not attached to any vehicle
                            logger.info("gateway:%s not attached to any vehicle" % processed_data["gateway_id"])
                            return "UNREGISTERED"
                    else:
                        # read query returned some data
                        if query_name == "CHECK_IF_ATTACHED_TO_VIN":
                            # result will have all the records represented in tuple
                            vin = result[0][0]
                elif query_name in (
                    "SET_ECONTROL",
                    "SET_GW_FIRMWARE_VERSION",
                ):
                    values = (
                        processed_data["sw_version"]
                        if query_name == "SET_GW_FIRMWARE_VERSION"
                        else processed_data["eControl_version"],
                        processed_data["gateway_id"] if query_name == "SET_GW_FIRMWARE_VERSION" else vin,
                    )
                    await write_to_database(conn, query_string, values)
                elif query_name == "SAVE_SYSTEM_INFO_PACKET":
                    values = (json.dumps(processed_data), processed_data["gateway_id"])
                    await write_to_database(conn, query_string, values)
            return "OK"

        except Exception as err:
            aee = ActionExecutionError(
                action_name="perform_mysql_operation:{conn_config_dict}",
                message=f"failed to perform_mysql_operation config {conn_config_dict}, message:{processed_data}",
            )
            logger.exception(aee)
            logger.critical(aee, exc_info=True)
            raise aee
        finally:
            if conn is not None:
                conn.close()


async def read_from_database(conn, query, values):
    # Get a connection from the pool
    # async with db_pool.acquire() as conn:
    #     # Create a cursor object to execute SQL queries
    async with conn.cursor() as cur:
        # Execute the query with the given values
        await cur.execute(query, values)

        # Fetch the results of the query
        result = await cur.fetchall()

        # Return the results
        return result


async def write_to_database(conn, query, values):
    # Get a connection from the pool
    # async with db_pool.acquire() as conn:
    #     # Create a cursor object to execute SQL queries
    async with conn.cursor() as cur:
        # Write data to the database
        # query = "INSERT INTO my_table (column1, column2) VALUES (%s, %s)"
        # values = (data['column1'], data['column2'])
        await cur.execute(query, values)

        # Commit the changes
        await conn.commit()


async def push_to_redis(processed_data: dict = {}, key: str = "", msg_type: str = "component_status_on_off"):
    # NOTE: this should be executed for gps-signal, signalvalue and heartbeat.
    # Create Redis connection
    # connection = await asyncio_redis.Pool.create(**config["redis"])
    try:
        logger.info(f"createing redis connection")
        connection = await asyncio_redis.Connection.create(**config["redis"])
        value = None
        if msg_type == "component_status_on_off":
            key = key.format(processed_data["gateway_id"])
            current_value = await connection.get(key)
            if current_value is None:
                # key doesn't exists
                # value = {k: processed_data[k] for k in processed_data if k not in ["gateway_id"]}
                value = {
                    processed_data["id"]: {"value": processed_data["value"], "timestamp": processed_data["timestamp"]}
                }

            else:
                value = json.loads(current_value)
                if str(processed_data["id"]) in value:
                    # current signal in processed_data
                    value[str(processed_data["id"])]["value"] = processed_data["value"]
                    value[str(processed_data["id"])]["timestamp"] = processed_data["timestamp"]
                else:
                    value[processed_data["id"]] = {
                        "value": processed_data["value"],
                        "timestamp": processed_data["timestamp"],
                    }
        elif msg_type == "gps":
            key = key.format(processed_data["gateway_id"])
            value = processed_data
            pass
        elif msg_type == "sensor_signal":
            key = key.format(processed_data["gateway_id"], processed_data["id"])
            value = {k: processed_data[k] for k in processed_data if k not in ["gateway_id", "id"]}
        elif msg_type == "last_data_point":
            key = key.format(processed_data["gateway_id"])
            value = {"timestamp": processed_data["timestamp"]}
        else:
            connection.close()
            return
        logger.info(f"pushing key:{key}, value:{value} to redis server")
        await connection.set(key, json.dumps(value))
    except Exception as e:
        logger.error(e)
    finally:
        logger.info("closing redis connection")
        if connection is not None:
            connection.close()
    # When finished, close the connection pool.


async def push_to_redis_asioredis(processed_data: dict = {}, key: str = "", msg_type: str = "component_status_on_off"):
    # NOTE: this should be executed for gps-signal, signalvalue and heartbeat.
    # Create Redis connection
    # connection = await asyncio_redis.Pool.create(**config["redis"])
    try:
        logger.info(f"createing redis connection")
        redis = RedisSingleton().get_connection()
        value = None
        if msg_type == "component_status_on_off":
            key = key.format(processed_data["gateway_id"])
            current_value = None
            current_value = await redis.get(key)
            if current_value is None:
                # key doesn't exists
                # value = {k: processed_data[k] for k in processed_data if k not in ["gateway_id"]}
                value = {
                    processed_data["id"]: {"value": processed_data["value"], "timestamp": processed_data["timestamp"]}
                }

            else:
                value = json.loads(current_value)
                if str(processed_data["id"]) in value:
                    # current signal in processed_data
                    value[str(processed_data["id"])]["value"] = processed_data["value"]
                    value[str(processed_data["id"])]["timestamp"] = processed_data["timestamp"]
                else:
                    value[processed_data["id"]] = {
                        "value": processed_data["value"],
                        "timestamp": processed_data["timestamp"],
                    }
        elif msg_type == "gps":
            key = key.format(processed_data["gateway_id"])
            value = processed_data
            pass
        elif msg_type == "sensor_signal":
            key = key.format(processed_data["gateway_id"], processed_data["id"])
            value = {k: processed_data[k] for k in processed_data if k not in ["gateway_id", "id"]}
        elif msg_type == "last_data_point":
            key = key.format(processed_data["gateway_id"])
            value = {"timestamp": processed_data["timestamp"]}

        logger.info(f"pushing key:{key}, value:{value} to redis server")
        await redis.set(key, json.dumps(value))
    except Exception as e:
        logger.exception(e)
    # When finished, close the connection pool.


FLOW_RULES = {
    "system-info": {
        "identify": [partial(subject_contains, index=-1, identifier="system-info")],
        "process": [partial(add_gateway_id)],
        "action": [
            partial(perform_mysql_operation),
            partial(nats_msg_reply),
        ],
    },
    "heartbeat": {
        "identify": [partial(subject_contains, index=-1, identifier="heartbeat")],
        "process": [
            partial(add_gateway_id),
            partial(add_signal_id, id=-1),
            # partial(convert_type_to, to_type=float, attrib="id"),
            partial(add_attribs, value=-1),
            partial(convert_type_to, to_type=float, attrib="value"),
        ],
        "action": [
            partial(push_to_kafka, topic="producer_topic_vehicle_alarms", action="heartbeat"),
            partial(push_to_kafka, topic="producer_topic_vehicle_sensors_data", action="heartbeat"),
            # partial(push_to_redis_asioredis, key="eber:gateways#{0}:last_data_point", msg_type="last_data_point"),
        ],
    },
    "gps-signal": {
        "identify": [partial(subject_contains, index=-1, identifier="gps-signal")],
        "process": [partial(add_gateway_id), partial(rename_lon_to_long)],
        "action": [
            partial(push_to_kafka, topic="producer_topic_vehicle_gps", action="gps-signal"),
            # partial(push_to_redis_asioredis, key="eber:gateways#{0}:gps", msg_type="gps"),
            # partial(push_to_redis_asioredis, key="eber:gateways#{0}:last_data_point", msg_type="last_data_point"),
        ],
    },
    "alarm-event": {
        "identify": [partial(subject_contains, index=-1, identifier="alarm-event")],
        "process": [partial(add_gateway_id)],
        "action": [
            partial(push_to_kafka, topic="producer_topic_vehicle_alarms", action="alarm_event"),
            partial(nats_msg_reply, reply_msg={"reply-status": "OK"}),
        ],
    },
    "component_on_off_status": {
        "identify": [
            partial(subject_contains, delimiter=None, identifier="sensor-signal"),
            partial(signaljson_has_attribs_val, attribs={"display_type": "COMPONENT_ON_OFF"}),
        ],
        "process": [
            partial(add_gateway_id),
            partial(add_signal_id),
            partial(convert_type_to, to_type=bool, attrib="value"),
        ],
        "action": [
            partial(
                push_to_kafka,
                topic="producer_topic_vehicle_components_status",
                action="component_on_off",
            ),
            # partial(
            #     push_to_redis_asioredis,
            #     key="eber:gateways#{0}:signals:types#on_off",
            #     msg_type="component_status_on_off",
            # ),
            # partial(push_to_redis_asioredis, key="eber:gateways#{0}:last_data_point", msg_type="last_data_point")
            # partial(push_to_kafka, topic=config["kafka"]["producer_topic_vehicle_alarms"], action="alarm_event"),
        ],
    },
    "signal_values": {
        "identify": [
            partial(subject_contains, delimiter=None, identifier="sensor-signal"),
            # partial(push_to_kafka, topic=config["kafka"]["producer_topic_vehicle_alarms"], action="alarm_event"),
        ],
        "process": [
            partial(add_gateway_id),
            partial(add_signal_id),
            partial(convert_type_to, to_type=float, attrib="value"),
        ],
        "action": [
            partial(
                push_to_kafka,
                topic="producer_topic_vehicle_sensors_data",
                action="signal_value",
            ),
            # partial(push_to_redis_asioredis, key="eber:gateways#{0}:signals:#{1}", msg_type="sensor_signal"),
            # partial(push_to_redis_asioredis, key="eber:gateways#{0}:last_data_point", msg_type="last_data_point"),
        ],
    },
    "conditional_alarm_related": {
        "identify": [
            partial(signal_id_in, delimiter=None, identifiers=[63, 66, 101, 104]),
            # partial(push_to_kafka, topic=config["kafka"]["producer_topic_vehicle_alarms"], action="alarm_event"),
        ],
        "process": [
            partial(add_gateway_id),
            partial(add_signal_id),
            partial(convert_type_to, to_type=float, attrib="value"),
        ],
        "action": [
            partial(
                push_to_kafka,
                topic="producer_topic_vehicle_alarms",
                action="signal_value",
            ),
        ],
    },
    "operating_minutes": {
        "identify": [
            partial(subject_contains, delimiter=None, identifier="sensor-signal"),
            partial(signaljson_has_attribs_val, attribs={"name": "HVAC_OperatingMinutes"}),
        ],
        "process": [
            partial(add_gateway_id),
            partial(add_signal_id),
            partial(convert_type_to, to_type=float, attrib="value"),
        ],
        "action": [
            partial(
                push_to_kafka,
                topic="producer_topic_vehicle_alarms",
                action="signal_value",
            ),
        ],
    },
    "ignition": {
        "identify": [
            partial(subject_contains, delimiter=None, identifier="sensor-signal"),
            partial(signaljson_has_attribs_val, attribs={"name": "Ignition"}),
        ],
        "process": [
            partial(add_gateway_id),
            partial(add_signal_id),
            partial(convert_type_to, to_type=float, attrib="value"),
        ],
        "action": [
            partial(save_ignition_state),
        ],
    },
    "index_error_code": {
        "identify": [
            partial(subject_contains, index=-1, identifier="e-control-dtc"),
        ],
        "process": [
            partial(add_gateway_id),
        ],
        "action": [partial(save_index_error_code)],
    },
    "can_0_active": {
        "identify": [
            partial(subject_contains, delimiter=None, identifier="sensor-signal.931"),
            # partial(signaljson_has_attribs_val, attribs={"id": 931}),
        ],
        "process": [
            partial(add_gateway_id),
        ],
        "action": [
            # partial(save_can_0_active_varchar),
            partial(save_can_0_active)
        ],
    },
}


async def message_handler(msg: Msg, nats_connector, connections):
    """each message will land on differnt kafka targets a flow rule can be defined like below
    heartbeat -> identify (from subject) -> target kafka_topic (dev_sensor_values) -> tested
    gps-signal -> identify (from subject) -> target kafka_topic (gps_signal_values) -> tested
    component_on_off -> identify (from payload signal_id ) -> target kafka_topic -> tested
    signal_values -> identify (from subject/payload signal_id) -> target kafka_topic
    system-info -> identify (from subject) -> target reply to message -> tested
    alarm-event -> identify (from subject) -> target kafka_topic
    """
    # logger.debug(f"got message:{msg}")
    rules = []
    for name, flow in FLOW_RULES.items():
        # identify the message_type
        status = False
        functions = flow["identify"]
        for func in functions:
            try:
                status = func(msg=msg)
            except Exception as e:
                logger.exception(f"While running idenify operation, flow rule was {functions}")
                status = False

            if status == False:
                break
        if status:
            rules.append(name)
    # logger.debug(f"identified rule {rules}")
    for rule in rules:
        if rule is None:
            logger.info("No flow rules for message", msg)
            return

        flow = FLOW_RULES[rule]
        # logger.debug(f"flow to be executed: {flow}")
        process_operations = flow["process"]
        processed_data = {}
        for op in process_operations:
            try:
                processed_data = op(msg=msg, processed_data=processed_data)
            except Exception as e:
                logger.exception("While processing")
                logger.exception(traceback.format_exc())
                return

        if "action" in flow:
            action_operations = flow["action"]
            for op in action_operations:
                try:
                    if op.func is push_to_kafka:
                        await op(producers_connections=connections["kafka"], processed_data=processed_data)
                    elif op.func is nats_msg_reply:
                        if rule == "system-info":
                            # while replying system-info the proper status is returned
                            gw_reply_msg = gw_reply_msg if gw_reply_msg is not None else "NOT_OK"
                            await op(msg=msg, nc=nats_connector, reply_msg={"reply-status": gw_reply_msg})
                        else:
                            # TODO: do the same as above for alarm-event. here all the time "OK" is replied
                            pass
                        await op(msg=msg, nc=nats_connector)
                    elif op.func is push_to_redis_asioredis:
                        pass
                        await op(processed_data=processed_data)
                    elif op.func is perform_mysql_operation:
                        gw_reply_msg = await op(
                            connections=connections["mysql"].values(), processed_data=processed_data
                        )
                    elif op.func is save_ignition_state:
                        await op(connections=connections["mysql"].values(), processed_data=processed_data)
                    elif op.func is save_index_error_code:
                        await op(connections=connections["mysql"].values(), processed_data=processed_data)
                    elif op.func is save_can_0_active_varchar:
                        await op(connections=connections["mysql"].values(), processed_data=processed_data)
                    elif op.func is save_can_0_active:
                        await op(connections=connections["mysql"].values(), processed_data=processed_data)
                except ActionExecutionError as aee:
                    logger.exception(aee)
                    logger.critical(aee, exc_info=True)
                    gw_reply_msg = "NOT_OK"  # if exception then set reply to not ok

                    if op.func is save_ignition_state:
                        await push_failed_func(
                            partial(
                                save_ignition_state,
                                connections=connections["mysql"].values(),
                                processed_data=processed_data,
                            )
                        )
                    elif op.func is save_can_0_active_varchar:
                        await push_failed_func(
                            partial(
                                save_can_0_active_varchar,
                                connections=connections["mysql"].values(),
                                processed_data=processed_data,
                            )
                        )
                    elif op.func is save_can_0_active:
                        await push_failed_func(
                            partial(
                                save_can_0_active,
                                connections=connections["mysql"].values(),
                                processed_data=processed_data,
                            )
                        )
                        
                    elif op.func is perform_mysql_operation:
                        await push_failed_func(
                            partial(
                                perform_mysql_operation,
                                connections=connections["mysql"].values(),
                                processed_data=processed_data,
                            )
                        )
                        
                    elif op.func is save_index_error_code:
                        await push_failed_func(
                            partial(
                                save_index_error_code,
                                connections=connections["mysql"].values(),
                                processed_data=processed_data,
                            )
                        )
                        
                        # save_index_error_code
                except Exception as e:
                    log_msg = "Failed to execute action: %s " % op.func.__name__
                    log_msg += "\n "
                    logger.critical(log_msg, exc_info=True)
                    gw_reply_msg = "NOT_OK"  # if exception then set reply to not ok
