import aioredis

from config import ConfigFactory


class RedisSingleton:
    _instance = None

    def __new__(cls, *args, **kwargs):
        if cls._instance is None:
            cls._instance = super().__new__(cls, *args, **kwargs)
        return cls._instance

    def __init__(self):
        self.redis = None

    def get_connection(self):
        if self.redis is None:
            self.redis = aioredis.from_url(
                ConfigFactory.get_config().REDIS_CONNECTION_URI, encoding="utf-8", decode_responses=False
            )
        return self.redis
