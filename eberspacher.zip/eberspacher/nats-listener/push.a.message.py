import asyncio
import json
import time
import zlib

import nats

gateway_id = "0921a1d75d48b311"  # gateway_id
current_timestamp = round(time.time() * 1000)  # timestamp in milis

messages = {
    "system-info": {
        "topic_prefix": "system-info",
        "timestamp": current_timestamp,
        "gwid": gateway_id,
        "model": "iw-G26",
        "hw-revision": "2.0B",
        "bsp-version": "iW-PRGET-DF-R3.0-REL2.7",
        "sw-version": "iW-G26-ARM-R22.15.0",
        "ip-address": "145.234.20.142",
        "uptime-sec": 5235,
        # TODO: get below attribs corrected by checking actual message from gw
        "sw_version": "sv-test-1",
        "eControl_version": "ecv-testca-1",
    },
    "heartbeat": {"timestamp": 1686979828, "topic_prefix": "heartbeat"},
    "data_alarm.create": {
        "timestamp": current_timestamp,
        "alarm_event": {
            "signal_id": 0,  # FIXME: change if want to create alarm for differnt signal
            "alarm_id": 1,  # FIXME: change if different alarm id is needed to create alarm
            "device": "can0",
            "cause": "CAN_DEVICE_DISCONNECTED",
            "alarm_created": current_timestamp,
            "alarm_cleared": 0,
            # "value_last_updated": current_timestamp,
            # "time_accumulation_trigger": "SIGNAL_IGNITION_ON",  # FIXME: change as per required
            "cleared": False,
            "error_measuring_time": 0,
        },
        "topic_prefix": "alarm-event",
    },
    "data_alarm.clear": {
        "timestamp": current_timestamp,
        "alarm_event": {
            "signal_id": 13,  # FIXME: change if want to create alarm for differnt signal
            "alarm_id": 1,  # FIXME: change if different alarm id is needed to create alarm
            "device": "can0",
            "cause": "MISSING_SIGNAL_VALUES",
            "alarm_created": 0,
            "alarm_cleared": current_timestamp,
            "value_last_updated": current_timestamp,
            "time_accumulation_trigger": "SIGNAL_IGNITION_ON",  # FIXME: change as per required
            "cleared": True,
        },
        "topic_prefix": "alarm-event",
    },
    "operating_minutes": {
        "timestamp": current_timestamp,
        "value": 43200,  # FIXME: update value
        "topic_prefix": "sensor-signal.930",
    },
    "room1_returnairtemp": {
        "timestamp": 1687138250000,
        "value": 10,  # FIXME: update value
        "topic_prefix": "sensor-signal.63",
    },
    "room1_supplayairtemp": {
        "timestamp": 1687138250000,
        "value": 6,  # FIXME: update value
        "topic_prefix": "sensor-signal.66",
    },
    "room2_returnairtemp": {
        "timestamp": current_timestamp,
        "value": 10,  # FIXME: update value
        "topic_prefix": "sensor-signal.101",
    },
    "room2_supplyairtemp": {
        "timestamp": current_timestamp,
        "value": 10,  # FIXME: update value
        "topic_prefix": "sensor-signal.104",
    },
    
    "room1_setpoint": {
        "timestamp": 1687138250000,
        "value": 3,  # FIXME: update value
        "topic_prefix": "sensor-signal.65",
    },
    
    "room2_setpoint": {
        "timestamp": 1686979828,
        "value": 1,  # FIXME: update value
        "topic_prefix": "sensor-signal.103",
    },
    # "ignition": {"timestamp": current_timestamp - 1800010, "value": 1, "topic_prefix": "sensor-signal.32"},
    "ignition": {"timestamp": current_timestamp, "value": 1, "topic_prefix": "sensor-signal.32"},
    "can_0_active": {"timestamp": current_timestamp, "value": 1, "topic_prefix": "sensor-signal.931"},
    "can_0_active_compressed": {"seq_number": 62976, "signals": [{"i": 931, "t": 1687330750000, "v": 1}]},
    "can_0_batch_uncompressed": {"seq_number": 62976, "signals": [{"i": 931, "t": 1687330750000, "v": 1}]},
    "compressor_1_release": {
        "timestamp": 1687138250000,
        "value": 1,  # FIXME: update value
        "topic_prefix": "sensor-signal.13",
    },
    "compressor_1_unloader1": {
        "timestamp": current_timestamp,
        "value": False,  # FIXME: update value
        "topic_prefix": "sensor-signal.14",
    },
    "compressor_1_unloader2": {
        "timestamp": current_timestamp,
        "value": False,  # FIXME: update value
        "topic_prefix": "sensor-signal.15",
    },
    "gps": {
        "timestamp": current_timestamp,
        "lat": 2.0,
        "lon": 2.0,
        "alt": 20.3,
        "topic_prefix": "gps-signal",
    },
    "ambient_temperature": {
        "timestamp": 1681292581000,
        "value": 99,  # FIXME: update value
        "topic_prefix": "sensor-signal.8",
    },
    "diagnostics.e-control-dtc": {
        "timestamp": 1686037755257,
        "dtc_list": [
            {"index": 0, "code": 95, "date": "2006-07-21"},
            {"index": 1, "code": 96, "date": "2006-07-21"},
            {"index": 2, "code": 92, "date": "2006-07-21"},
            {"index": 3, "code": 16, "date": "2006-07-20"},
            {"index": 4, "code": 93, "date": "2006-07-21"},
            {"index": 5, "code": 107, "date": "2006-07-21"},
            {"index": 6, "code": 7, "date": "2006-07-05"},
            {"index": 7, "code": 4, "date": "2006-07-05"},
            {"index": 8, "code": 78, "date": "2006-07-20"},
            {"index": 9, "code": 18, "date": "2005-08-15"},
            {"index": 10, "code": 26, "date": "2005-09-25"},
            {"index": 11, "code": 70, "date": "2005-09-03"},
            {"index": 12, "code": 30, "date": "2006-01-12"},
            {"index": 13, "code": 0, "date": "2000-01-01"},
            {"index": 14, "code": 0, "date": "2000-01-01"},
            {"index": 15, "code": 0, "date": "2000-01-01"},
            {"index": 16, "code": 0, "date": "2000-01-01"},
            {"index": 17, "code": 0, "date": "2000-01-01"},
            {"index": 18, "code": 0, "date": "2000-01-01"},
            {"index": 19, "code": 0, "date": "2000-01-01"},
        ],
        "topic_prefix": "diagnostics.e-control-dtc",
    },
}


if __name__ == "__main__":

    signal_to_test = [
        ("heartbeat", "N"),
        ("data_alarm.create", "N"),
        ("data_alarm.clear", "N"),
        ("operating_minutes", "N"),
        ("room1_returnairtemp", "N"),
        ("room1_supplayairtemp", "N"),
        ("room2_returnairtemp", "N"),
        ("room2_supplyairtemp", "N"),
        ("ignition", "N"),
        ("can_0_active", "N"),
        ("can_0_active_compressed", "Y"),
        ("can_0_batch_uncompressed", "N"),
        ("compressor_1_release", "N"),  # component on off
        ("compressor_1_unloader1", "N"),  # component on off
        ("compressor_1_unloader2", "N"),  # component on off
        ("gps", "N"),  # gps
        ("ambient_temperature", "N"),
        ("system-info", "N"),
        ("diagnostics.e-control-dtc", "N"),
        ("room1_setpoint", "N"),
        ("room2_setpoint", "N"),
    ]

    async def main():
        # nc = await nats.connect("nats://localhost:4222")
        nc = await nats.connect("nats.dev.orahi.com:4222", nkeys_seed="nkeyseed")
        for s in signal_to_test:
            if s[1] == "N":
                continue
            if s[0] == "system-info":
                reply = await nc.request(
                    f"eber.iw-G26.{gateway_id}.system-info",
                    json.dumps(messages[s[0]]).encode("utf-8"),
                    timeout=15,
                )
                print(reply.data)
            elif "alarm.create" in s[0] or "alarm.clear" in s[0]:
                await nc.request(
                    f"eber.iw-G26.{gateway_id}.{messages[s[0]].pop('topic_prefix')}",
                    json.dumps(messages[s[0]]).encode("utf-8"),
                    timeout=5,
                )
                pass
            elif "can_0_active_compressed" in s[0]:

                await nc.publish(
                    f"eber.iw-G26.{gateway_id}.signals.c",
                    zlib.compress(json.dumps(messages[s[0]], separators=(",", ":")).encode()),
                )
            elif "can_0_batch_uncompressed" in s[0]:
                await nc.publish(
                    f"eber.iw-G26.{gateway_id}.signals.u",
                    json.dumps(messages[s[0]], separators=(",", ":")).encode("utf-8"),
                )
            else:
                await nc.publish(
                    "eber.iw-G26." + gateway_id + "." + messages[s[0]].pop("topic_prefix"),
                    json.dumps(messages[s[0]]).encode("utf-8"),
                )
            await asyncio.sleep(1)

    asyncio.run(main(), debug=True)