import json
import os
import sys
import traceback

import requests


class SignalMetadataError(Exception):
    pass


class SignalMetadataJsonError(SignalMetadataError):
    def __init__(self, msg="Error while parsing signal metadata json") -> None:
        self.message = msg
        super().__init__(self.message)


class SignalMetadataDownloadError(SignalMetadataError):
    def __init__(self, msg="Error while parsing signal metadata json") -> None:
        self.message = msg
        super().__init__(self.message)


class CanSignalManager:
    data_type_conversion = {"INT": int, "FLOAT": float, "BOOL": bool}

    def __init__(self, repo_urls, access_token):
        req_headers = {"PRIVATE-TOKEN": access_token}
        self.signal_jsons = []
        try:
            for url in repo_urls:
                res = requests.get(url, headers=req_headers)
                res.raise_for_status()  # raise for http failed statuses
                self.signal_jsons.append(json.loads(res.text))
        except (ValueError, json.JSONDecodeError) as e:
            raise SignalMetadataJsonError() from e
        except Exception as e:
            raise SignalMetadataDownloadError() from e

        self.signals = {}
        for sj in self.signal_jsons:
            frames = [f for f in sj["frames"]]
            for f in frames:
                for s in f["signals"]:
                    # signals hashmap id->signal_data
                    self.signals[s.pop("id")] = s

        self.validate()
        self.parse()

    def fill_signals_from_frame(self, frame):
        for s in frame["signals"]:
            self.signals[s.pop("id")] = s

    def validate(self):
        # TODO: validate json, some schema checks
        for s_id, s in self.signals.items():
            if s["value_type"] not in CanSignalManager.data_type_conversion.keys():
                logger.critical(f"Unsupported signal value_type {s['value_type']}")
                sys.exit(0)
        pass

    def parse(self):
        # convert value_type identifier to python native type classes
        for s_id, s in self.signals.items():
            identifier = s["value_type"]
            s["value_type"] = CanSignalManager.data_type_conversion[identifier]
        pass

    def get_signal_data_type(self, signal_id: int):
        """get datatype of a signal_id from json"""
        return self.signals[signal_id]["value_type"]

    def get_signal_display_type(self, signal_id: int):
        """get display_type of a signal_id from json"""
        return self.signals[signal_id]["display_type"]

    def get_attrib(self, signal_id: int, attrib_name):
        return self.signals[signal_id][attrib_name]


if __name__ == "__main__":
    can_signal = CanSignalManager()
    can_signal.get_signal_data_type(930)
